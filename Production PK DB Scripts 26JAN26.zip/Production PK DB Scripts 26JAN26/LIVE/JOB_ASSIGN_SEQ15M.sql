--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PROCEDURE

--Prepared by		: SRINATH CH
--Prepared Date		: 12JAN26

-------------------------------------------------------------------------------
PROMPT Stopping scheduler job JOB_ASSIGN_SEQ1H ...

-- Good practice when pasting scripts into SQL*Plus:
SET SQLBLANKLINES ON
SET DEFINE OFF

BEGIN
  DBMS_SCHEDULER.STOP_JOB(
    job_name => 'WOSINT.JOB_ASSIGN_SEQ1H',
    force    => TRUE
  );
END;
/