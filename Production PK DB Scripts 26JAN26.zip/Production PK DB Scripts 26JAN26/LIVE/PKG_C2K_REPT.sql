--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PACKAGE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT CREATE OR REPLACE PACKAGE WOSINT.PKG_C2K_REPT
CREATE OR REPLACE PACKAGE  WOSINT.PKG_C2K_REPT AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 

  PROCEDURE SP_IMP_EXP_REPT(P_MONTH_NAME VARCHAR2,P_YEAR VARCHAR2);
  PROCEDURE SP_TRN_TRF_REPT(P_MONTH_NAME VARCHAR2,P_YEAR VARCHAR2);
END PKG_C2K_REPT;
/

PROMPT CREATE OR REPLACE PACKAGE BODY WOSINT.PKG_C2K_REPT
CREATE OR REPLACE PACKAGE BODY WOSINT.PKG_C2K_REPT AS

P_START_DATE VARCHAR2(20);
P_END_DATE VARCHAR2(20);
PROCEDURE SP_IMP_EXP_REPT(P_MONTH_NAME VARCHAR2,P_YEAR VARCHAR2) AS
  BEGIN
     DELETE FROM AA_C2K_IMP_EXP;
     DELETE FROM REPT_IMP_AWB_LIST;
     DELETE FROM REPT_IMP_FLT_AWB_LIST;
     DELETE FROM REPT_EXP_FLT_AWB_LIST;
     DELETE FROM REPT_EXP_AWB_LIST;
     SELECT TO_CHAR(TRUNC(TO_DATE(P_MONTH_NAME||P_YEAR,'MONYYYY'),'MM'),'DDMONYY'),
     TO_CHAR(LAST_DAY(TO_CHAR(trunc(TO_DATE(P_MONTH_NAME||P_YEAR,'MONYYYY'),'MM'),'DDMONYY')),'DDMONYY')
     INTO P_START_DATE,P_END_DATE
     FROM DUAL;


    BEGIN



      INSERT INTO  REPT_IMP_AWB_LIST (FLT_KEY,FLT_DATE,ACT_DATE,ACT_TIME,CGO_ACFT_TYPE,AWB_NO,AWB_DATE,CARR_CODE,ACCEPT_MODE,COD_FSU_STS,RANK,AWB_SHP_STS_CR_DATE)
      SELECT A.FLT_KEY,F.SCH_DATE FLT_DATE,f.act_date,F.ACT_TIME,f.CGO_ACFT_TYPE, AWB.AWB_NO,AWB.AWB_DATE, F.CARR_CODE, AWB.ACCEPT_MODE, S.COD_FSU_STS,
      DENSE_RANK() OVER (PARTITION BY AWB.AWB_NO, AWB.AWB_DATE ORDER BY A.FLT_DATE, F.SCH_TIME, A.FLT_KEY),S.CR_DATE
      FROM AWB, AWB_SHP_STS S, IMP_CAR_SHP A, FLT_OPR F
      WHERE
      AWB.AWB_NO = S.AWB_NO AND AWB.AWB_DATE = S.AWB_DATE AND
      S.AWB_NO = A.AWB_NO AND S.AWB_DATE = A.AWB_DATE AND
      A.FLT_KEY = F.FLT_KEY AND A.FLT_DATE = F.SCH_DATE AND
      (TRUNC(F.SCH_DATE) >= TO_DATE(P_START_DATE,'DDMONYY') AND TRUNC(F.SCH_DATE) <= TO_DATE(P_END_DATE,'DDMONYY')) AND
      AWB.AWB_TYPE = UPPER('I')
      AND F.FLT_TYPE = 'A';

      INSERT INTO REPT_IMP_FLT_AWB_LIST (FLT_KEY,FLT_DATE,ACT_DATE,ACT_TIME,CGO_ACFT_TYPE,AWB_NO,AWB_DATE,CARR_CODE,ACCEPT_MODE,COD_FSU_STS,RANK,AWB_SHP_STS_CR_DATE)
      SELECT A.FLT_KEY,F.SCH_DATE FLT_DATE,f.act_date,F.ACT_TIME,f.CGO_ACFT_TYPE, AWB.AWB_NO,AWB.AWB_DATE, F.CARR_CODE, AWB.ACCEPT_MODE, S.COD_FSU_STS,
      DENSE_RANK() OVER (PARTITION BY AWB.AWB_NO, AWB.AWB_DATE ORDER BY A.FLT_DATE, F.SCH_TIME, A.FLT_KEY),S.CR_DATE
      FROM AWB, AWB_SHP_STS S, IMP_CAR_SHP A, FLT_OPR F
      WHERE
      AWB.AWB_NO = S.AWB_NO AND AWB.AWB_DATE = S.AWB_DATE AND
      S.AWB_NO = A.AWB_NO AND S.AWB_DATE = A.AWB_DATE AND S.FLT_NO = A.FLT_KEY AND S.FLT_DATE = A.FLT_DATE AND
      A.FLT_KEY = F.FLT_KEY AND A.FLT_DATE = F.SCH_DATE AND
      (TRUNC(F.SCH_DATE) >= TO_DATE(P_START_DATE,'DDMONYY') AND TRUNC(F.SCH_DATE) <= TO_DATE(P_END_DATE,'DDMONYY')) AND
      AWB.AWB_TYPE = UPPER('I')
      AND F.FLT_TYPE = 'A';

      INSERT INTO REPT_EXP_FLT_AWB_LIST (FLT_KEY,FLT_DATE,ACT_DATE,ACT_TIME,CGO_ACFT_TYPE,AWB_NO,AWB_DATE,CARR_CODE,ACCEPT_MODE,COD_FSU_STS,RANK,AWB_SHP_STS_CR_DATE)
      SELECT A.FLT_KEY,F.SCH_DATE FLT_DATE,f.act_date,F.ACT_TIME,f.CGO_ACFT_TYPE, AWB.AWB_NO,AWB.AWB_DATE, F.CARR_CODE, AWB.ACCEPT_MODE, S.COD_FSU_STS,
      DENSE_RANK() OVER (PARTITION BY AWB.AWB_NO, AWB.AWB_DATE ORDER BY A.FLT_DATE, F.SCH_TIME, A.FLT_KEY),S.CR_DATE
      FROM AWB, AWB_SHP_STS S, EXP_PMANIFEST_AWB A, FLT_OPR F
      WHERE
      AWB.AWB_NO = S.AWB_NO AND AWB.AWB_DATE = S.AWB_DATE AND
      S.AWB_NO = A.AWB_NO AND S.AWB_DATE = A.AWB_DATE AND S.FLT_NO = A.FLT_KEY AND S.FLT_DATE = A.FLT_DATE AND
      A.FLT_KEY = F.FLT_KEY AND A.FLT_DATE = F.SCH_DATE AND
      (TRUNC(F.SCH_DATE) >= TO_DATE(P_START_DATE,'DDMONYY') AND TRUNC(F.SCH_DATE) <= TO_DATE(P_END_DATE,'DDMONYY')) AND
      AWB.AWB_TYPE = UPPER('E')
      AND F.flt_type = 'D'
      UNION
      SELECT A.FLT_KEY,F.SCH_DATE FLT_DATE,f.act_date,F.ACT_TIME,f.CGO_ACFT_TYPE, AWB.AWB_NO,AWB.AWB_DATE, F.CARR_CODE, AWB.ACCEPT_MODE, S.COD_FSU_STS,
      DENSE_RANK() OVER (PARTITION BY AWB.AWB_NO, AWB.AWB_DATE ORDER BY A.FLT_DATE, F.SCH_TIME, A.FLT_KEY),S.CR_DATE
      FROM AWB, AWB_SHP_STS S, EXP_PMAN_TARMAC_AWB A, FLT_OPR F
      WHERE
      AWB.AWB_NO = S.AWB_NO AND AWB.AWB_DATE = S.AWB_DATE AND
      S.AWB_NO = A.AWB_NO AND S.AWB_DATE = A.AWB_DATE AND  S.FLT_NO = A.FLT_KEY AND S.FLT_DATE = A.FLT_DATE AND
      A.FLT_KEY = F.FLT_KEY AND A.FLT_DATE = F.SCH_DATE AND
      (TRUNC(F.SCH_DATE) >= TO_DATE(P_START_DATE,'DDMONYY') AND TRUNC(F.SCH_DATE) <= TO_DATE(P_END_DATE,'DDMONYY')) AND
      AWB.AWB_TYPE = UPPER('E')
      AND F.flt_type = 'D';

      INSERT INTO REPT_EXP_AWB_LIST (FLT_KEY,FLT_DATE,ACT_DATE,ACT_TIME,CGO_ACFT_TYPE,AWB_NO,AWB_DATE,CARR_CODE,ACCEPT_MODE,COD_FSU_STS,RANK,AWB_SHP_STS_CR_DATE)
      SELECT A.FLT_KEY,F.SCH_DATE FLT_DATE,f.act_date,F.ACT_TIME,f.CGO_ACFT_TYPE, AWB.AWB_NO,AWB.AWB_DATE, F.CARR_CODE, AWB.ACCEPT_MODE, S.COD_FSU_STS,
      DENSE_RANK() OVER (PARTITION BY AWB.AWB_NO, AWB.AWB_DATE ORDER BY A.FLT_DATE, F.SCH_TIME, A.FLT_KEY),S.CR_DATE
      FROM AWB, AWB_SHP_STS S, EXP_PMANIFEST_AWB A, FLT_OPR F
      WHERE
      AWB.AWB_NO = S.AWB_NO AND AWB.AWB_DATE = S.AWB_DATE AND
      S.AWB_NO = A.AWB_NO AND S.AWB_DATE = A.AWB_DATE AND
      A.FLT_KEY = F.FLT_KEY AND A.FLT_DATE = F.SCH_DATE AND
      (TRUNC(F.SCH_DATE) >= TO_DATE(P_START_DATE,'DDMONYY') AND TRUNC(F.SCH_DATE) <= TO_DATE(P_END_DATE,'DDMONYY')) AND
      AWB.AWB_TYPE = UPPER('E')
      AND F.flt_type = 'D'
      UNION
      SELECT A.FLT_KEY,F.SCH_DATE FLT_DATE,f.act_date,F.ACT_TIME,f.CGO_ACFT_TYPE, AWB.AWB_NO,AWB.AWB_DATE, F.CARR_CODE, AWB.ACCEPT_MODE, S.COD_FSU_STS,
      DENSE_RANK() OVER (PARTITION BY AWB.AWB_NO, AWB.AWB_DATE ORDER BY A.FLT_DATE, F.SCH_TIME, A.FLT_KEY),S.CR_DATE
      FROM AWB, AWB_SHP_STS S, EXP_PMAN_TARMAC_AWB A, FLT_OPR F
      WHERE
      AWB.AWB_NO = S.AWB_NO AND AWB.AWB_DATE = S.AWB_DATE AND
      S.AWB_NO = A.AWB_NO AND S.AWB_DATE = A.AWB_DATE AND
      A.FLT_KEY = F.FLT_KEY AND A.FLT_DATE = F.SCH_DATE AND
      (TRUNC(F.SCH_DATE) >= TO_DATE(P_START_DATE,'DDMONYY') AND TRUNC(F.SCH_DATE) <= TO_DATE(P_END_DATE,'DDMONYY')) AND
      AWB.AWB_TYPE = UPPER('E')
      AND F.flt_type = 'D';



    EXCEPTION WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('INSERTING DATA LIST SQLERRM:'||SQLERRM);
    END;





     INSERT INTO AA_C2K_IMP_EXP (
      MONTH_NAME,
      C2K_IDENTIFIER,
      GHA,
      STATION,
      AIRLINE,
      EXP_AWB,
      EXP_AWB_MANIFEST,
      RCS_SENT,
      FFM_SENT,
      FFM_SENT_IN_TIME,
      DEP_SENT,
      DEP_SENT_IN_TIME,
      IMP_AWB,
      IMP_AWB_MANIFEST,
      FFM_RECD_BEFORE_ATA,
      RCF_SENT,
      RCF_SENT_IN_TIME,
      AWD_SENT,
      AWD_SENT_IN_TIME,
      NFD_MSG_SENT,
      NFD_SENT_IN_TIME,
      FWB_RECD,
      fwb_recd_before_rcs,
      FWB_RECD_BEFORE_ATA,
      DLV_EVENT,
      DLV_EVT_SENT_IN_TIME
      )
     SELECT
      to_char(TO_DATE(P_MONTH_NAME||P_YEAR,'MONYYYY'), 'YYYY-MM'),
      NVL((select DECODE(c2k_member,'','N','N','N','C') from cust_company where carr_code=B.CODE AND ROWNUM=1),'N'),
      'CPS',
      'HKG',
      CODE,
      0,--v_exp_awb,
      0,--v_exp_mnft,
      0,--V_RCS_SENT,
      0,--V_FFM_SENT,
      0,--V_FFM_SENT_IN_TIME,
      0,--V_DEP_SENT,
      0,--V_DEP_SENT_IN_TIME,
      0,--v_IMP_awb,
      0,--v_IMP_mnft,
      0,--V_FFM_SENT_BF_ATA,
      0,--V_RCF_SENT,
      0,--V_RCF_SENT_IN_TIME,
      0,--V_AWD_SENT,
      0,--V_AWD_SENT_IN_TIME ,
      0,--V_NFD_SENT,
      0,--V_NFD_SENT_IN_TIME,
      0,--V_FWB_RECD,
      0,--V_FWB_RECD_BF_ATA,
      0,--v_fwb_recd_bf_rcs,
      0,--v_dlv_event,
      0--V_DLV_EVT_SENT_IN_TIME
     FROM MAST_CARRIER B WHERE owned_carr = 'Y'
     and code in (select carrier_code from aa_c2k_sla_config_setup)
     order by b.code;


     --Export_AWB/MWBs
     --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    FOR I IN
     (SELECT B.CARR_CODE V_CARR_CODE,COUNT(A.AWB_NO) V_EXP_AWB
      from
      (select B.AWB_NO,B.AWB_DATE, b.flt_date, fo.carr_code,
      DENSE_RANK() OVER (PARTITION BY B.AWB_NO, B.AWB_DATE ORDER BY B.FLT_DATE, FO.SCH_TIME, B.FLT_KEY) RANK
        from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
      UNION ALL
      SELECT AWB_NO, AWB_DATE, FLT_KEY, FLT_DATE FROM EXP_PMAN_TARMAC_AWB) B
      JOIN AWB AWB ON AWB.AWB_NO=B.AWB_NO AND AWB.AWB_DATE=B.AWB_DATE AND (AWB.AWB_TYPE='E' AND
      AWB.accept_mode not in ('LIT'))
      join flt_opr fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date) B
      JOIN AWB A ON A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE and rank = 1
      GROUP BY B.CARR_CODE )
    LOOP
      UPDATE AA_C2K_IMP_EXP SET EXP_AWB = I.v_exp_awb WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


    --Export_Shipments_Manifested
    --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    FOR I IN
     (WITH FLT_DATA AS (SELECT FLT_KEY,SCH_DATE,CARR_CODE FROM FLT_OPR
      WHERE SCH_DATE BETWEEN P_START_DATE and P_END_DATE AND FLT_TYPE = 'D'),
      PMAN_TARMAC_AWB AS
      (SELECT AWB_NO, AWB_DATE, FLT_KEY, FLT_DATE FROM EXP_PMANIFEST_AWB
      WHERE FLT_DATE BETWEEN P_START_DATE and P_END_DATE
      UNION
      SELECT AWB_NO, AWB_DATE, FLT_KEY, FLT_DATE FROM EXP_PMAN_TARMAC_AWB WHERE FLT_DATE BETWEEN P_START_DATE and P_END_DATE),
      AWB_DATA AS
      (SELECT AWB_NO,AWB_DATE FROM AWB WHERE (awb_type='E' and ACCEPT_MODE NOT IN ('LIT')))
      select fo.CARR_CODE V_CARR_CODE, count(a.awb_no) v_exp_mnft
      FROM
      PMAN_TARMAC_AWB B
      join FLT_DATA fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date
      JOIN AWB_DATA A ON A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      GROUP BY fo.CARR_CODE)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET EXP_AWB_MANIFEST = I.v_exp_mnft WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


     --FWB_Received
     --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    FOR I IN
     (SELECT B.CARR_CODE V_CARR_CODE, COUNT(B.AWB_NO) V_FWB_RECD
      from
      (select B.AWB_NO,B.AWB_DATE, b.flt_date, fo.carr_code,
          DENSE_RANK() OVER (PARTITION BY B.AWB_NO, B.AWB_DATE ORDER BY b.flt_date, fo.sch_time, b.flt_key) RANK
        from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
      union all select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb) B
        join flt_opr fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date and fo.flt_type = 'D'
      JOIN EDI_FWB FWB ON FWB.AWB_NO=B.AWB_NO AND FWB.AWB_DATE=B.AWB_DATE
      join awb AWB on FWB.AWB_NO=AWB.AWB_NO AND FWB.AWB_DATE=AWB.AWB_DATE
      and (AWB.awb_type='E' AND AWB.ACCEPT_MODE NOT IN ('LIT'))) B
      WHERE b.flt_date between P_START_DATE and P_END_DATE and rank = 1
      GROUP BY b.CARR_CODE)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET FWB_RECD = I.v_fwb_recd WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


   --FWB_Received_Before_RCS
    FOR I IN
     (
--     SELECT b.CARR_CODE V_CARR_CODE, count(a.awb_no) v_fwb_recd_bf_rcs
--      FROM
--      (select B.AWB_NO,B.AWB_DATE, b.flt_date, fo.carr_code,
--          DENSE_RANK() OVER (PARTITION BY B.AWB_NO, B.AWB_DATE ORDER BY b.flt_date, fo.sch_time, b.flt_key) RANK
--        from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
--          union select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb) B
--        join flt_opr fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date and fo.flt_type = 'D'
--        join edi_fwb fwb on fwb.AWB_NO=B.AWB_NO AND fwb.AWB_DATE=B.AWB_DATE
--        join AWB_SHP_STS f on f.AWB_NO=B.AWB_NO AND f.AWB_DATE=B.AWB_DATE
--        where f.COD_FSU_STS = 'RCS'
--        and fwb.cr_date <= f.cr_date) B
--      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
--      WHERE b.flt_date between P_START_DATE and P_END_DATE and rank = 1
--      and (a.awb_type='E' and a.accept_mode not in ('TIT','LIT'))
--      GROUP BY b.CARR_CODE


---CHANGED THE QUERY FOR CR15072001
--CR15030203 - TIT LOGIC HAS BEEN CHANGED
      select CARR_CODE V_CARR_CODE,case when NVL(exclude_yn,'N')='N' THEN
      v_fwb_recd_bf_rcs
      ELSE
      0 END v_fwb_recd_bf_rcs FROM
      (SELECT B.CARR_CODE,COUNT(B.AWB_NO) v_fwb_recd_bf_rcs
      from REPT_EXP_AWB_LIST B
      join edi_fwb fwb on fwb.AWB_NO=B.AWB_NO AND fwb.AWB_DATE=B.AWB_DATE
      where COD_FSU_STS = 'RCS'
      AND FWB.CR_DATE <= B.AWB_SHP_STS_cr_date
      AND B.RANK=1
      AND B.accept_mode NOT IN ('LIT')
      GROUP BY B.CARR_CODE) A
      LEFT JOIN AA_C2K_SLA_CONFIG_SETUP E ON A.CARR_CODE=E.CARRIER_CODE AND E.MSG_TYPE='FSU/RCS'
      )
    LOOP
      UPDATE AA_C2K_IMP_EXP SET fwb_recd_before_rcs = I.v_fwb_recd_bf_rcs WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


    --RCS_Sent
    --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    FOR I IN
     (
         select V_CARR_CODE,case when NVL(exclude_yn,'N')='N' THEN
        V_RCS_SENT
        ELSE
        0 END V_RCS_SENT FROM
        (
        select B.CARR_CODE V_CARR_CODE, COUNT(distinct B.AWB_NO) V_RCS_SENT
        FROM
        (
        SELECT B.CARR_CODE,B.AWB_NO,B.AWB_DATE, MIN(B.FLT_DATE) FLT_DATE
        FROM REPT_EXP_AWB_LIST B
        WHERE B.COD_FSU_STS = 'RCS'
        AND ACCEPT_MODE NOT IN ('LIT')
        GROUP BY B.CARR_CODE, B.AWB_NO, B.AWB_DATE) B
        GROUP BY B.CARR_CODE) A
        left JOIN aa_c2k_sla_config_setup e ON A.V_CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/RCS'
      )
    LOOP
      UPDATE AA_C2K_IMP_EXP SET RCS_SENT = I.V_RCS_SENT WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


    --FFM_Sent
    --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    FOR I IN
     (select b.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_FFM_SENT
    from
    (select p.awb_no, p.awb_date, p.flt_key, p.flt_date, fe.carr_code
    from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
    union select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb) p
    join flt_opr fo on fo.flt_key = p.flt_key and fo.sch_date = p.flt_date and fo.act_date is not null and fo.flt_type = 'D'
    join flt_opr_events fe on fo.tr_no = fe.tr_no
    --   JOIN aa_c2k_sla_config_setup e ON fo.CARR_CODE=E.CARRIER_CODE and e.msg_type='FFM' AND IMP_EXP_TYPE='E' AND E.PAX_CGO_TYPE = fo.CGO_ACFT_TYPE
    where fe.ctm_out_date is not null) B
    join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
    WHERE b.flt_date between P_START_DATE and P_END_DATE
    and (a.awb_type='E' and
    --a.accept_mode not in ('TIT','LIT')
    a.accept_mode not in ('LIT')
    )
    group by b.CARR_CODE)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET FFM_SENT = I.V_FFM_SENT WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


    --FFM_Sent_In-time
     --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    FOR I IN
     (SELECT b.CARR_CODE V_CARR_CODE, COUNT(a.awb_no) V_FFM_SENT_IN_TIME
      FROM
      (select p.awb_no, p.awb_date, p.flt_key, p.flt_date, fo.carr_code
        from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
          union select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb) p
         join flt_opr fo on fo.flt_key = p.flt_key and fo.sch_date = p.flt_date and fo.act_date is not null and fo.flt_type = 'D'
         join flt_opr_events fe on fo.tr_no = fe.tr_no
        JOIN aa_c2k_sla_config_setup e ON fo.CARR_CODE=E.CARRIER_CODE and e.msg_type='FFM' AND IMP_EXP_TYPE='E' AND E.PAX_CGO_TYPE = fo.CGO_ACFT_TYPE
        where fe.ctm_out_date <= to_date(TO_CHAR(fo.ACT_DATE, 'DDMONYY')||' '||LPAD(fo.ACT_TIME,4,0), 'DDMONYY HH24MI')+ TO_NUMBER(e.SLA_IN_MINUTES)/1440
        ) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and (a.awb_type='E' and
      --a.accept_mode not in ('TIT','LIT')
      a.accept_mode not in ('LIT')
      )
      GROUP BY b.carr_code)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET FFM_SENT_IN_TIME = I.V_FFM_SENT_IN_TIME WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


    --DEP_Sent
    --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    FOR I IN
     (SELECT  COUNT(P.AWB_NO) V_DEP_SENT,P.CARR_CODE V_CARR_CODE
      FROM REPT_EXP_FLT_AWB_LIST P
      join flt_opr_events fe on fe.flt_key = p.flt_key and fe.sch_date = p.flt_date
      JOIN aa_c2k_sla_config_setup e ON p.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/DEP' AND IMP_EXP_TYPE='E' AND E.PAX_CGO_TYPE = p.CGO_ACFT_TYPE
      where p.COD_FSU_STS = 'DEP'
      AND FE.CTM_OUT_DATE IS NOT NULL
      AND ACCEPT_MODE NOT IN ('LIT')
      GROUP BY P.CARR_CODE)
   LOOP
      UPDATE AA_C2K_IMP_EXP SET DEP_SENT = I.V_DEP_SENT WHERE AIRLINE = I.V_CARR_CODE;
   END LOOP;


    --DEP_Sent_in-time
    --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    for i in
     (SELECT P.CARR_CODE V_CARR_CODE, COUNT(P.AWB_NO)  V_DEP_SENT_IN_TIME
      FROM REPT_EXP_FLT_AWB_LIST P
      JOIN FLT_OPR_EVENTS FE ON P.FLT_KEY=FE.FLT_KEY AND P.FLT_DATE=FE.SCH_DATE and P.ACT_DATE is not null
      JOIN aa_c2k_sla_config_setup e ON E.CARRIER_CODE=P.CARR_CODE and e.msg_type='FSU/DEP' AND IMP_EXP_TYPE='E' AND E.PAX_CGO_TYPE = P.CGO_ACFT_TYPE
      where P.AWB_SHP_STS_CR_DATE <= to_date(TO_CHAR(P.ACT_DATE, 'DDMONYY')||' '||LPAD(P.ACT_TIME,4,0), 'DDMONYY HH24MI')+ TO_NUMBER(e.SLA_IN_MINUTES)/1440
      and P.COD_FSU_STS = 'DEP'
      AND FE.CTM_OUT_DATE IS NOT NULL
      AND P.accept_mode not in ('LIT') GROUP BY P.CARR_CODE)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET DEP_SENT_IN_TIME = I.V_DEP_SENT_IN_TIME WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


  --Import_AWB/MWBs
    FOR I IN
     (SELECT a.CARR_CODE V_CARR_CODE, COUNT(A.AWB_NO) v_IMP_awb
      FROM
      (select B.AWB_NO,B.AWB_DATE, min(flt_date) flt_date
        from imp_car_shp B
        group by B.AWB_NO, B.AWB_DATE) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and (a.awb_type='I')
      GROUP BY a.CARR_CODE)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET IMP_AWB = I.v_IMP_awb WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


    --Import_Shipments_Manifested
    FOR I IN
      (select fo.CARR_CODE V_CARR_CODE, count(a.awb_no) v_IMP_mnft
      from
      imp_car_shp B
      join flt_opr fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date and fo.flt_type = 'A'
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and (a.awb_type='I')
      group by fo.CARR_CODE)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET IMP_AWB_MANIFEST = I.v_IMP_mnft WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


   --FWB_Received_Before_ATA
    FOR I IN
      (SELECT a.CARR_CODE V_CARR_CODE,count(a.awb_no) V_FWB_RECD_BF_ATA
      from
      (select B.AWB_NO,B.AWB_DATE, min(flt_date) flt_date
        from imp_car_shp B
        join flt_opr fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date and fo.flt_type = 'A' and fo.act_date is not null
        join flt_opr_events fe on fo.tr_no = fe.tr_no
        join edi_fwb fwb on fwb.AWB_NO=B.AWB_NO AND fwb.AWB_DATE=B.AWB_DATE
        where fwb.cr_date <= to_date(TO_CHAR(fo.ACT_DATE, 'DDMONYY')||' '||LPAD(fo.ACT_TIME,4,0), 'DDMONYY HH24MI')
        group by B.AWB_NO, B.AWB_DATE) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      where b.flt_date between P_START_DATE and P_END_DATE
      and (a.awb_type='I')
      group by a.CARR_CODE )
    LOOP
      UPDATE AA_C2K_IMP_EXP SET FWB_RECD_BEFORE_ATA = I.V_FWB_RECD_BF_ATA WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


    --FFM_Received_Before_ATA
    FOR I IN
      (SELECT ffm.CARR_CODE V_CARR_CODE, count(a.awb_no) V_FFM_SENT_BF_ATA
      from
      imp_car_shp B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      join (select s.awb_no, s.awb_date, b.flt_key, b.flt_date, fo.carr_code
        from edi_ffm_msg b
        join edi_ffm_shp s on s.flt_key = b.flt_key and s.flt_date = b.flt_date
        join flt_opr fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date and fo.flt_type = 'A' and fo.act_date is not null
        join flt_opr_events fe on fo.tr_no = fe.tr_no
        where b.ffm_status = 'P'
        and b.cr_date <= to_date(TO_CHAR(fo.ACT_DATE, 'DDMONYY')||' '||LPAD(fo.ACT_TIME,4,0), 'DDMONYY HH24MI')
        group by s.awb_no, s.awb_date, b.flt_key, b.flt_date, fo.carr_code) ffm
        on ffm.AWB_NO=B.AWB_NO AND ffm.AWB_DATE=B.AWB_DATE and ffm.flt_key = b.flt_key and ffm.flt_date = b.flt_date
      where b.flt_date between P_START_DATE and P_END_DATE
      and (a.awb_type='I')
      group by ffm.CARR_CODE)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET FFM_RECD_BEFORE_ATA = I.V_FFM_SENT_BF_ATA WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


    --RCF_Sent
    FOR I IN
      (SELECT P.CARR_CODE V_CARR_CODE, COUNT(P.AWB_NO) V_RCF_SENT
      from REPT_IMP_FLT_AWB_LIST P
      JOIN aa_c2k_sla_config_setup e ON P.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/RCF' AND IMP_EXP_TYPE='I' AND E.PAX_CGO_TYPE = P.CGO_ACFT_TYPE
      WHERE P.COD_FSU_STS = 'RCF'
      GROUP BY P.CARR_CODE)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET RCF_SENT = I.V_RCF_SENT WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


    --RCF_sent_In-time
    FOR I IN
      (SELECT P.CARR_CODE V_CARR_CODE, count(P.awb_no) v_rcf_sent_in_time
        FROM REPT_IMP_FLT_AWB_LIST P
        join flt_opr_events fe on P.FLT_KEY=FE.FLT_KEY AND P.FLT_DATE=FE.SCH_DATE and P.ACT_DATE is not null
        JOIN aa_c2k_sla_config_setup e ON P.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/RCF' AND IMP_EXP_TYPE='I' AND E.PAX_CGO_TYPE = P.CGO_ACFT_TYPE
        where P.AWB_SHP_STS_CR_DATE <= to_date(TO_CHAR(P.ACT_DATE, 'DDMONYY')||' '||LPAD(P.ACT_TIME,4,0), 'DDMONYY HH24MI')+ TO_NUMBER(e.SLA_IN_MINUTES)/1440
        and P.COD_FSU_STS = 'RCF' GROUP BY P.CARR_CODE)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET RCF_SENT_IN_TIME = I.v_rcf_sent_in_time WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


     --AWD_Sent
    FOR I IN
      (select B.CARR_CODE V_CARR_CODE, count(B.awb_no) v_awd_sent
        FROM
        (select P.AWB_NO,P.AWB_DATE, min(P.flt_date) flt_date,P.CARR_CODE
        from REPT_IMP_FLT_AWB_LIST P
        JOIN aa_c2k_sla_config_setup e ON P.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/AWD' AND IMP_EXP_TYPE='I' AND E.PAX_CGO_TYPE = P.CGO_ACFT_TYPE
        where P.COD_FSU_STS = 'AWD'
        GROUP BY P.AWB_NO, P.AWB_DATE, P.CARR_CODE) B
        GROUP BY B.CARR_CODE)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET AWD_SENT = I.v_awd_sent WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


    --AWD_Sent_In-time
    FOR I IN
      (SELECT B.CARR_CODE V_CARR_CODE, count(B.awb_no) v_awd_sent_in_time
      FROM
        (select P.AWB_NO,P.AWB_DATE,P.CARR_CODE, min(P.flt_date) flt_date
        FROM REPT_IMP_AWB_LIST P
        join flt_opr_events fe on P.FLT_KEY=FE.FLT_KEY AND P.FLT_DATE=FE.SCH_DATE and P.ACT_DATE is not null
        JOIN aa_c2k_sla_config_setup e ON P.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/AWD' AND IMP_EXP_TYPE='I' AND E.PAX_CGO_TYPE = P.CGO_ACFT_TYPE
        where P.AWB_SHP_STS_CR_DATE <= to_date(TO_CHAR(P.ACT_DATE, 'DDMONYY')||' '||LPAD(P.ACT_TIME,4,0), 'DDMONYY HH24MI')+ TO_NUMBER(e.SLA_IN_MINUTES)/1440
        and P.COD_FSU_STS = 'AWD'
        GROUP BY P.AWB_NO, P.AWB_DATE, P.CARR_CODE) B
        GROUP BY B.CARR_CODE)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET AWD_SENT_IN_TIME = I.v_awd_sent_in_time WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


    --NFD_Messages_Sent
    FOR I IN
      (SELECT P.CARR_CODE V_CARR_CODE,count(P.awb_no) v_nfd_sent
      from REPT_IMP_FLT_AWB_LIST P
      JOIN aa_c2k_sla_config_setup e ON P.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/NFD' AND IMP_EXP_TYPE='I' AND E.PAX_CGO_TYPE = P.CGO_ACFT_TYPE
      where P.COD_FSU_STS = 'NFD'
      GROUP BY P.CARR_CODE)
   LOOP
      UPDATE AA_C2K_IMP_EXP SET NFD_MSG_SENT = I.v_nfd_sent WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


     --NFD_Sent_In-time
     FOR I IN
      (SELECT P.CARR_CODE V_CARR_CODE, count(P.awb_no) v_nfd_sent_in_time
      FROM REPT_IMP_FLT_AWB_LIST P
      join flt_opr_events fe on P.FLT_KEY=FE.FLT_KEY AND P.FLT_DATE=FE.SCH_DATE and P.ACT_DATE is not null
      JOIN aa_c2k_sla_config_setup e ON P.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/NFD' AND IMP_EXP_TYPE='I' AND E.PAX_CGO_TYPE = P.CGO_ACFT_TYPE
      where P.AWB_SHP_STS_CR_DATE <= to_date(TO_CHAR(P.ACT_DATE, 'DDMONYY')||' '||LPAD(P.ACT_TIME,4,0), 'DDMONYY HH24MI')+ TO_NUMBER(e.SLA_IN_MINUTES)/1440
      and P.COD_FSU_STS = 'NFD'
      group by P.carr_code)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET NFD_SENT_IN_TIME = I.v_nfd_sent_in_time WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


     --Delivery Event
    FOR I IN
      (SELECT a.CARR_CODE V_CARR_CODE, count(a.awb_no) V_DLV_EVENT
      FROM imp_car_shp B
      join AWB_SHP_STS f on f.AWB_NO=B.AWB_NO AND f.AWB_DATE=B.AWB_DATE
      join awb a on A.AWB_NO=b.AWB_NO AND A.AWB_DATE=b.AWB_DATE
      join flt_opr fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date and fo.flt_type = 'A'
      JOIN aa_c2k_sla_config_setup e ON fo.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/DLV' AND IMP_EXP_TYPE='I' AND E.PAX_CGO_TYPE = fo.CGO_ACFT_TYPE
      where f.COD_FSU_STS = 'DLV'
      and f.cr_date between P_START_DATE and P_END_DATE
      and (a.awb_type='I')
      GROUP BY a.CARR_CODE)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET DLV_EVENT = I.V_DLV_EVENT WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


    -------Delivery Event Sent in Time
    FOR I IN
      (SELECT a.CARR_CODE V_CARR_CODE, count(a.awb_no) V_DLV_EVT_SENT_IN_TIME
      from
      imp_car_shp B
      join AWB_SHP_STS f on f.AWB_NO=B.AWB_NO AND f.AWB_DATE=B.AWB_DATE
      join flt_opr fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date and fo.flt_type = 'A' and fo.act_date is not null
      join flt_opr_events fe on fo.tr_no = fe.tr_no
      join awb a on A.AWB_NO=b.AWB_NO AND A.AWB_DATE=b.AWB_DATE
      JOIN aa_c2k_sla_config_setup e ON fo.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/DLV' AND IMP_EXP_TYPE='I' AND E.PAX_CGO_TYPE = fo.CGO_ACFT_TYPE
      where f.cr_date <= to_date(TO_CHAR(fo.ACT_DATE, 'DDMONYY')||' '||LPAD(fo.ACT_TIME,4,0), 'DDMONYY HH24MI')+ TO_NUMBER(e.SLA_IN_MINUTES)/1440
      and f.COD_FSU_STS = 'DLV'
      and f.cr_date between P_START_DATE and P_END_DATE
      and (a.awb_type='I')
      GROUP BY a.CARR_CODE)
    LOOP
      UPDATE AA_C2K_IMP_EXP SET DLV_EVT_SENT_IN_TIME = I.V_DLV_EVT_SENT_IN_TIME WHERE AIRLINE = I.V_CARR_CODE;
    END LOOP;


  END SP_IMP_EXP_REPT;



  PROCEDURE SP_TRN_TRF_REPT(P_MONTH_NAME VARCHAR2,P_YEAR VARCHAR2) AS
  BEGIN
    DELETE FROM AA_C2K_TRN_TRF;
    SELECT TO_CHAR(TRUNC(TO_DATE(P_MONTH_NAME||P_YEAR,'MONYYYY'),'MM'),'DDMONYY'),
    TO_CHAR(LAST_DAY(TO_CHAR(trunc(TO_DATE(P_MONTH_NAME||P_YEAR,'MONYYYY'),'MM'),'DDMONYY')),'DDMONYY')
    INTO P_START_DATE,P_END_DATE
    FROM DUAL;





     INSERT INTO AA_C2K_TRN_TRF (MONTH_NAME, C2K_IDENTIFIER, GHA, STATION, AIRLINE,
          TT_EXP_TRF_MNFT_AWB,
          TT_RCT_SENT,
          TT_EXP_TRF_FFM_SENT,
          TT_EXP_TRF_FFM_SENT_IN_TIME,
          TT_EXP_TRF_DEP_SENT,
          TT_EXP_TRF_DEP_SENT_IN_TIME,
          TT_IMP_TRF_AWB,
          TT_IMP_TRF_MNFT_AWB,
          TT_IMP_TRF_FWB_RECD,
          TT_IMP_TRF_FFM_RECD_BF_ATA,
          TT_IMP_TRF_RCF_SENT,
          TT_IMP_TRF_RCF_SENT_IN_TIME,
          TT_TFD_MSG,
          TT_TFD_MSG_SENT_IN_TIME,
          TT_IMP_TRN_AWB,
          TT_IMP_TRN_MNFT_AWB,
          TT_FWB_RECD,
          TT_FFM_RECD_BF_ATA,
          TT_TRN_RCF_SENT,
          TT_TRN_RCF_SENT_IN_TIME,
          TT_TRN_FFM_SENT,
          TT_TRN_FFM_SENT_IN_TIME,
          TT_TRN_DEP_SENT,
          TT_TRN_DEP_SENT_IN_TIME)
        SELECT to_char(TO_DATE(P_MONTH_NAME||P_YEAR,'MONYYYY'), 'YYYY-MM'),
          NVL((select DECODE(c2k_member,'','N','N','N','C') from cust_company where carr_code=B.CODE AND ROWNUM=1),'N'),
          'CPS',
          'HKG',
          code,
          0, --TT_EXP_TRF_MNFT_AWB
          0, --TT_RCT_SENT
          0, --TT_EXP_TRF_FFM_SENT
          0, --TT_EXP_TRF_FFM_SENT_IN_TIME
          0, --TT_EXP_TRF_DEP_SENT
          0, --TT_EXP_TRF_DEP_SENT_IN_TIME
          0, --TT_IMP_TRF_AWB
          0, --TT_IMP_TRF_MNFT_AWB
          0, --TT_IMP_TRF_FWB_RECD
          0, --TT_IMP_TRF_FFM_RECD_BF_ATA
          0, --TT_IMP_TRF_RCF_SENT
          0, --TT_IMP_TRF_RCF_SENT_IN_TIME
          0, --TT_TFD_MSG
          0, --TT_TFD_MSG_SENT_IN_TIME
          0, --TT_IMP_TRN_AWB
          0, --TT_IMP_TRN_MNFT_AWB
          0, --TT_FWB_RECD
          0, --TT_FFM_RECD_BF_ATA
          0, --TT_TRN_RCF_SENT
          0, --TT_TRN_RCF_SENT_IN_TIME
          0, --TT_TRN_FFM_SENT
          0, --TT_TRN_FFM_SENT_IN_TIME
          0, --TT_TRN_DEP_SENT
          0 --TT_TRN_DEP_SENT_IN_TIME
        from mast_carrier B where owned_carr = 'Y'
        and code in (select carrier_code from aa_c2k_sla_config_setup)
        order by b.code;


    --Import_Transfer_AWB/MWBs
    for I in (
      SELECT a.CARR_CODE V_CARR_CODE, COUNT(A.AWB_NO) V_IMP_TRF_AWB
      FROM
      (select B.AWB_NO,B.AWB_DATE, min(flt_date) flt_date
        from imp_car_shp B
        group by B.AWB_NO, B.AWB_DATE) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      and (a.awb_type='T' and exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      GROUP BY a.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_IMP_TRF_AWB = nvl(i.V_IMP_TRF_AWB, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

    --Import_Transfer_Shipments_Manifested
    for I in (
      select fo.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_IMP_TRF_MNFT_AWB
      from
      imp_car_shp B
      join flt_opr fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date and fo.flt_type = 'A'
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      and (a.awb_type='T' and exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      group by fo.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_IMP_TRF_MNFT_AWB = nvl(i.V_IMP_TRF_MNFT_AWB, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

    --FWB_Received
    for I in (
      SELECT a.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_IMP_TRF_FWB_RECD
      from
      (select B.AWB_NO,B.AWB_DATE, min(flt_date) flt_date
        from imp_car_shp B
        group by B.AWB_NO, B.AWB_DATE) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      join edi_fwb fwb on fwb.AWB_NO=B.AWB_NO AND fwb.AWB_DATE=B.AWB_DATE
      where b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      and (a.awb_type='T' and exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      group by a.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_IMP_TRF_FWB_RECD = nvl(i.V_IMP_TRF_FWB_RECD, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

   --Import_Transfer_FFM_Received_Before_ATA
    for I in (
      SELECT ffm.CARR_CODE V_CARR_CODE, count(a.awb_no) V_TRF_FFM_RECD_BT_ATA
      FROM
      imp_car_shp B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      join (select s.awb_no, s.awb_date, b.flt_key, b.flt_date, fo.CARR_CODE
        from edi_ffm_msg b
        join edi_ffm_shp s on s.flt_key = b.flt_key and s.flt_date = b.flt_date
        join flt_opr fe on fe.flt_key = b.flt_key and fe.sch_date = b.flt_date and fe.flt_type = 'A' and fe.act_date is not null
        join flt_opr_events fo on fo.tr_no = fe.tr_no
        where b.ffm_status = 'P'
        and b.cr_date <= to_date(TO_CHAR(fe.ACT_DATE, 'DDMONYY')||' '||LPAD(fe.ACT_TIME,4,0), 'DDMONYY HH24MI')
        group by s.awb_no, s.awb_date, b.flt_key, b.flt_date, fo.CARR_CODE) ffm
        on ffm.AWB_NO=B.AWB_NO AND ffm.AWB_DATE=B.AWB_DATE and ffm.flt_key = b.flt_key and ffm.flt_date = b.flt_date
      where b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      and (a.awb_type='T' and exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      group by ffm.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_IMP_TRF_FFM_RECD_BF_ATA = nvl(i.V_TRF_FFM_RECD_BT_ATA, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

    --Import_Transfer_RCF_Sent
    for I in (
      select b.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_IMP_TRF_RCF_SENT
      from
      (select B.AWB_NO, B.AWB_DATE, b.flt_key, b.flt_date, fo.CARR_CODE
        from imp_car_shp B
        join AWB_SHP_STS f on f.AWB_NO=B.AWB_NO AND f.AWB_DATE=B.AWB_DATE and f.flt_no = b.flt_key and f.flt_date = b.flt_date
        join flt_opr fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date and fo.flt_type = 'A'
        JOIN aa_c2k_sla_config_setup e ON fo.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/RCF' AND IMP_EXP_TYPE='T' AND E.PAX_CGO_TYPE = fo.CGO_ACFT_TYPE
        where f.COD_FSU_STS = 'RCF'
        group by B.AWB_NO, B.AWB_DATE, b.flt_key, b.flt_date, fo.CARR_CODE) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      and (a.awb_type='T' and exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      GROUP BY b.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_IMP_TRF_RCF_SENT = nvl(i.V_IMP_TRF_RCF_SENT, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

    --Import_Transfer_RCF_Sent_In-time
    for I in (
      SELECT b.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_IMP_TRF_RCF_SENT_IN_TIME
      FROM
      (select B.AWB_NO, B.AWB_DATE, b.flt_key, b.flt_date, fo.CARR_CODE
        from imp_car_shp B
        join AWB_SHP_STS f on f.AWB_NO=B.AWB_NO AND f.AWB_DATE=B.AWB_DATE and f.flt_no = b.flt_key and f.flt_date = b.flt_date
        join flt_opr fe on fe.flt_key = b.flt_key and fe.sch_date = b.flt_date and fe.flt_type = 'A' and fe.act_date is not null
        join flt_opr_events fo on fo.tr_no = fe.tr_no
        JOIN aa_c2k_sla_config_setup e ON fo.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/RCF' AND IMP_EXP_TYPE='T' AND E.PAX_CGO_TYPE = fe.CGO_ACFT_TYPE
        where f.cr_date <= to_date(TO_CHAR(fe.ACT_DATE, 'DDMONYY')||' '||LPAD(fe.ACT_TIME,4,0), 'DDMONYY HH24MI')+ TO_NUMBER(e.SLA_IN_MINUTES)/1440
          and f.COD_FSU_STS = 'RCF'
        group by B.AWB_NO, B.AWB_DATE, b.flt_key, b.flt_date, fo.CARR_CODE) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      and (a.awb_type='T' and exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      group by b.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_IMP_TRF_RCF_SENT_IN_TIME = nvl(i.V_IMP_TRF_RCF_SENT_IN_TIME, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

    --TFD_Event_Completed
    for I in (
      select A.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_TFD_EVT
      from
      (select B.AWB_NO,B.AWB_DATE, min(b.flt_date) flt_date
        from imp_car_shp B
        join AWB_SHP_STS f on f.AWB_NO=B.AWB_NO AND f.AWB_DATE=B.AWB_DATE
        JOIN FLT_OPR FO ON FO.FLT_KEY = B.FLT_KEY AND FO.SCH_DATE = B.FLT_DATE AND FO.FLT_TYPE='A'
        JOIN aa_c2k_sla_config_setup e ON fo.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/TFD' AND IMP_EXP_TYPE='T' AND E.PAX_CGO_TYPE = fo.CGO_ACFT_TYPE
        where f.COD_FSU_STS = 'TFD'
        group by B.AWB_NO, B.AWB_DATE) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      and (a.awb_type='T' and exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      group by A.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_TFD_MSG = nvl(i.V_TFD_EVT, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

    --TFD_Message_Sent_In-time
    for I in (
      SELECT a.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_TFD_EVNT_SENT_IN_TIME
      FROM
      (select B.AWB_NO,B.AWB_DATE, min(b.flt_date) flt_date
        from imp_car_shp B
        join AWB_SHP_STS f on f.AWB_NO=B.AWB_NO AND f.AWB_DATE=B.AWB_DATE
        join flt_opr fe on fe.flt_key = b.flt_key and fe.sch_date = b.flt_date and fe.flt_type = 'A' and fe.act_date is not null
        join flt_opr_events fo on fo.tr_no = fe.tr_no
        JOIN aa_c2k_sla_config_setup e ON fo.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/TFD' AND IMP_EXP_TYPE='T' AND E.PAX_CGO_TYPE = fe.CGO_ACFT_TYPE
        where f.cr_date <= to_date(TO_CHAR(fe.ACT_DATE, 'DDMONYY')||' '||LPAD(fe.ACT_TIME,4,0), 'DDMONYY HH24MI')+ TO_NUMBER(e.SLA_IN_MINUTES)/1440
        and f.COD_FSU_STS = 'TFD'
        group by B.AWB_NO, B.AWB_DATE) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      and (a.awb_type='T' and exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      group by a.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_TFD_MSG_SENT_IN_TIME = nvl(i.V_TFD_EVNT_SENT_IN_TIME, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;


    --Import_Transit_AWB/MWBs
    for I in (
      SELECT A.CARR_CODE V_CARR_CODE, COUNT(A.AWB_NO) V_IMP_TRN_AWB
      FROM
      (select B.AWB_NO,B.AWB_DATE, min(flt_date) flt_date
        from imp_car_shp B
        group by B.AWB_NO, B.AWB_DATE) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog != 'TM'
      and (a.awb_type='T' and not exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      group by A.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_IMP_TRN_AWB = nvl(i.V_IMP_TRN_AWB, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;


    --Import_Transit_Shipment_Movements
    for I in (
      SELECT fo.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_IMP_TRN_MNFT_AWB
      FROM
      imp_car_shp B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      join flt_opr fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date and fo.flt_type = 'A'
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog != 'TM'
      and (a.awb_type='T' and not exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      GROUP BY fo.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_IMP_TRN_MNFT_AWB = nvl(i.V_IMP_TRN_MNFT_AWB, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

    --FWB_Received
    for I in (
      SELECT a.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_IMP_TRN_FWB_RECD
      from
      (select B.AWB_NO,B.AWB_DATE, min(flt_date) flt_date
        from imp_car_shp B
        group by B.AWB_NO, B.AWB_DATE) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      join edi_fwb fwb on fwb.AWB_NO=B.AWB_NO AND fwb.AWB_DATE=B.AWB_DATE
      where b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog != 'TM'
      and (a.awb_type='T' and not exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      GROUP BY a.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_FWB_RECD = nvl(i.V_IMP_TRN_FWB_RECD, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

    --FFM_Received_Before_ATA
    for I in (
    SELECT b.CARR_CODE V_CARR_CODE, count(a.awb_no) V_TRN_FFM_RECD_BT_ATA
      FROM
      imp_car_shp B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      join (select s.awb_no, s.awb_date, b.flt_key, b.flt_date, fo.carr_code
        from edi_ffm_msg b
        join edi_ffm_shp s on s.flt_key = b.flt_key and s.flt_date = b.flt_date
        join flt_opr fe on fe.flt_key = b.flt_key and fe.sch_date = b.flt_date and fe.flt_type = 'A' and fe.act_date is not null
        join flt_opr_events fo on fo.tr_no = fe.tr_no
        where b.ffm_status = 'P'
        and b.cr_date <= to_date(TO_CHAR(fe.ACT_DATE, 'DDMONYY')||' '||LPAD(fe.ACT_TIME,4,0), 'DDMONYY HH24MI')
        group by s.awb_no, s.awb_date, b.flt_key, b.flt_date, fo.carr_code) ffm
        on ffm.AWB_NO=B.AWB_NO AND ffm.AWB_DATE=B.AWB_DATE and ffm.flt_key = b.flt_key and ffm.flt_date = b.flt_date
      where b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog != 'TM'
      and (a.awb_type='T' and not exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      GROUP BY b.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_FFM_RECD_BF_ATA = nvl(i.V_TRN_FFM_RECD_BT_ATA, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

    --Transit_RCF_Sent
    for I in (
      select b.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_TRN_RCF_SENT
      from
      (select B.AWB_NO, B.AWB_DATE, b.flt_key, b.flt_date, fo.carr_code
        from imp_car_shp B
        join AWB_SHP_STS f on f.AWB_NO=B.AWB_NO AND f.AWB_DATE=B.AWB_DATE and f.flt_no = b.flt_key and f.flt_date = b.flt_date
        join flt_opr fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date and fo.flt_type = 'A'
        JOIN aa_c2k_sla_config_setup e ON fo.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/RCF' AND IMP_EXP_TYPE='I' AND E.PAX_CGO_TYPE = fo.CGO_ACFT_TYPE
        where f.COD_FSU_STS = 'RCF'
        group by B.AWB_NO, B.AWB_DATE, b.flt_key, b.flt_date, fo.carr_code) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog != 'TM'
      and (a.awb_type='T' and not exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      group by b.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_TRN_RCF_SENT = nvl(i.V_TRN_RCF_SENT, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

    --Transit_RCF_Sent_In-time
    for I in (
      SELECT b.CARR_CODE V_CARR_CODE, count(a.awb_no) V_TRN_RCF_SENT_IN_TIME
      FROM
      (select B.AWB_NO, B.AWB_DATE, b.flt_key, b.flt_date, fo.carr_code
        from imp_car_shp B
        join AWB_SHP_STS f on f.AWB_NO=B.AWB_NO AND f.AWB_DATE=B.AWB_DATE and f.flt_no = b.flt_key and f.flt_date = b.flt_date
        join flt_opr fe on fe.flt_key = b.flt_key and fe.sch_date = b.flt_date and fe.flt_type = 'A' and fe.act_date is not null
        join flt_opr_events fo on fo.tr_no = fe.tr_no
        JOIN aa_c2k_sla_config_setup e ON fe.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/RCF' AND IMP_EXP_TYPE='I' AND E.PAX_CGO_TYPE = fe.CGO_ACFT_TYPE
        where f.cr_date <= to_date(TO_CHAR(fe.ACT_DATE, 'DDMONYY')||' '||LPAD(fe.ACT_TIME,4,0), 'DDMONYY HH24MI')+ TO_NUMBER(e.SLA_IN_MINUTES)/1440
          and f.COD_FSU_STS = 'RCF'
        group by B.AWB_NO, B.AWB_DATE, b.flt_key, b.flt_date, fo.carr_code) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog != 'TM'
      and (a.awb_type='T' and not exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      GROUP BY b.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_TRN_RCF_SENT_IN_TIME = nvl(i.V_TRN_RCF_SENT_IN_TIME, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

    --Transit_FFM_Sent
    for I in (
      select b.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_TRN_FFM_SENT
      from
      (select p.awb_no, p.awb_date, p.flt_key, p.flt_date, fE.carr_code
        from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
          union select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb) p
        join flt_opr fE on fE.flt_key = p.flt_key and fE.sch_date = p.flt_date and fE.flt_type = 'D' and fe.act_date is not null
        join flt_opr_events fo on fo.tr_no = fe.tr_no
        JOIN aa_c2k_sla_config_setup e ON fe.CARR_CODE=E.CARRIER_CODE and e.msg_type='FFM' AND IMP_EXP_TYPE='E' AND E.PAX_CGO_TYPE = fe.CGO_ACFT_TYPE
        where fo.ctm_out_date is not null) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      and (a.awb_type='T' and not exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      group by b.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_TRN_FFM_SENT = nvl(i.V_TRN_FFM_SENT, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

    --Transit_FFM_Sent_In-time
    for I in (
      SELECT b.CARR_CODE V_CARR_CODE, count(a.awb_no) V_TRN_FFM_SENT_IN_TIME
      FROM
      (select p.awb_no, p.awb_date, p.flt_key, p.flt_date, fo.carr_code
        from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
          union select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb) p
        join flt_opr fe on fe.flt_key = p.flt_key and fe.sch_date = p.flt_date and fe.flt_type = 'D' and fe.act_date is not null
        join flt_opr_events fo on fo.tr_no = fe.tr_no
        JOIN aa_c2k_sla_config_setup e ON fo.CARR_CODE=E.CARRIER_CODE and e.msg_type='FFM' AND IMP_EXP_TYPE='E' AND E.PAX_CGO_TYPE = fe.CGO_ACFT_TYPE
        where fo.ctm_out_date <= to_date(TO_CHAR(fe.ACT_DATE, 'DDMONYY')||' '||LPAD(fe.ACT_TIME,4,0), 'DDMONYY HH24MI')+ TO_NUMBER(e.SLA_IN_MINUTES)/1440
        ) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      and (a.awb_type='T' and not exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      GROUP BY b.carr_code)
    loop
      update AA_C2K_TRN_TRF set TT_TRN_FFM_SENT_IN_TIME = nvl(i.V_TRN_FFM_SENT_IN_TIME, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;


    --Transit_DEP_Sent
    for I in (
      select b.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_TRN_DEP_SENT
      from
      (select p.awb_no, p.awb_date, p.flt_key, p.flt_date, fe.carr_code
        from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
          union select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb) p
        join AWB_SHP_STS f on f.AWB_NO=p.AWB_NO AND f.AWB_DATE=p.AWB_DATE and f.flt_no = p.flt_key and f.flt_date = p.flt_date
        join flt_opr fe on fe.flt_key = p.flt_key and fe.sch_date = p.flt_date and fe.flt_type = 'D' and fe.act_date is not null
        join flt_opr_events fo on fo.tr_no = fe.tr_no
        JOIN aa_c2k_sla_config_setup e ON fo.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/DEP' AND IMP_EXP_TYPE='E' AND E.PAX_CGO_TYPE = fe.CGO_ACFT_TYPE
        where f.COD_FSU_STS = 'DEP'
        and fo.ctm_out_date is not null) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      and (a.awb_type='T' and not exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      group by b.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_TRN_DEP_SENT = nvl(i.V_TRN_DEP_SENT, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;


    --Transit_DEP_Sent_In-time
    for I in (
      SELECT b.CARR_CODE V_CARR_CODE, count(a.awb_no) V_TRN_DEP_SENT_IN_TIME
      FROM
      (select p.awb_no, p.awb_date, p.flt_key, p.flt_date, fo.carr_code
        from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
          union select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb) p
        join AWB_SHP_STS f on f.AWB_NO=p.AWB_NO AND f.AWB_DATE=p.AWB_DATE and f.flt_no = p.flt_key and f.flt_date = p.flt_date
        join flt_opr fe on fe.flt_key = p.flt_key and fe.sch_date = p.flt_date and fe.flt_type = 'D' and fe.act_date is not null
        join flt_opr_events fo on fo.tr_no = fe.tr_no
        JOIN aa_c2k_sla_config_setup e ON fo.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/DEP' AND IMP_EXP_TYPE='E' AND E.PAX_CGO_TYPE = fe.CGO_ACFT_TYPE
        where f.cr_date <= to_date(TO_CHAR(fe.ACT_DATE, 'DDMONYY')||' '||LPAD(fe.ACT_TIME,4,0), 'DDMONYY HH24MI')+ TO_NUMBER(e.SLA_IN_MINUTES)/1440
        and f.COD_FSU_STS = 'DEP'
          and fo.ctm_out_date is not null) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      and (a.awb_type='T' and not exists(select null from imp_trm_hd h join imp_trm_dtl d on h.trm_no = d.trm_no
                    where d.AWB_NO=B.AWB_NO AND d.AWB_DATE=B.AWB_DATE))
      GROUP BY b.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_TRN_DEP_SENT_IN_TIME = nvl(i.V_TRN_DEP_SENT_IN_TIME, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;


    --Export_Transfer_Shipments_Manifested
    --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    for I in (
      select fo.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_EXP_TRF_MNFT_AWB
      from
      (select awb_no, awb_date, flt_key, flt_date
      from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
        union select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb)) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      join flt_opr fo on fo.flt_key = b.flt_key and fo.sch_date = b.flt_date and fo.flt_type = 'D'
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      --and (a.awb_type='E' and a.accept_mode in ('TIT','LIT'))
     -- and ((a.awb_type='E' and a.accept_mode in ('LIT')) OR (a.awb_type='T' and a.accept_mode in ('TIT')))
      and ((a.awb_type='E' and a.accept_mode in ('LIT')) OR ((a.awb_type='T' and a.accept_mode in ('TIT'))
      and exists(select 1 from (select awb_no,awb_date from trf_accept_brkdn
      union
      select awb_no,awb_date from trf_accept_hd)
      where awb_no=a.awb_no
      and awb_date=a.awb_date)))
      GROUP BY fo.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_EXP_TRF_MNFT_AWB = nvl(i.V_EXP_TRF_MNFT_AWB, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;


    --RCT_Sent
    --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    for I in (
      select b.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_RCT_SENT
      from
      (select distinct p.awb_no, p.awb_date, p.flt_key, p.flt_date, fo.carr_code,
            DENSE_RANK() OVER (PARTITION BY p.AWB_NO, p.AWB_DATE ORDER BY p.flt_date, fo.sch_time, p.flt_key) RANK
        from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
          union select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb) p
        join flt_opr fo on fo.flt_key = p.flt_key and fo.sch_date = p.flt_date and fo.flt_type = 'D'
        join AWB_SHP_STS f on f.AWB_NO=p.AWB_NO AND f.AWB_DATE=p.AWB_DATE
        where f.COD_FSU_STS = 'RCT') B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE and rank = 1
      and a.catalog not in ('TM')
      --and (a.awb_type='E' and a.accept_mode in ('TIT','LIT'))
     -- and ((a.awb_type='E' and a.accept_mode in ('LIT')) OR (a.awb_type='T' and a.accept_mode in ('TIT')))
      and ((a.awb_type='E' and a.accept_mode in ('LIT')) OR ((a.awb_type='T' and a.accept_mode in ('TIT'))
      and exists(select 1 from (select awb_no,awb_date from trf_accept_brkdn
      union
      select awb_no,awb_date from trf_accept_hd)
      where awb_no=a.awb_no
      and awb_date=a.awb_date)))
      GROUP BY b.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_RCT_SENT = nvl(i.V_RCT_SENT, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;


    --Export_Transfer_FFM_Sent
    --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    for I in (
      select b.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_EXP_TRF_FFM_SENT
      from
      (select p.awb_no, p.awb_date, p.flt_key, p.flt_date, fE.carr_code
        from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
          union select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb) p
        join flt_opr fe on fE.flt_key = p.flt_key and fE.sch_date = p.flt_date and fE.flt_type = 'D' and fe.act_date is not null
        join flt_opr_events fo on fo.tr_no = fe.tr_no
        JOIN aa_c2k_sla_config_setup e ON fe.CARR_CODE=E.CARRIER_CODE and e.msg_type='FFM' AND IMP_EXP_TYPE='E' AND E.PAX_CGO_TYPE = fe.CGO_ACFT_TYPE
        where fo.ctm_out_date is not null) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      --and (a.awb_type='E' and a.accept_mode in ('TIT','LIT'))
      --and ((a.awb_type='E' and a.accept_mode in ('LIT')) OR (a.awb_type='T' and a.accept_mode in ('TIT')))
      and ((a.awb_type='E' and a.accept_mode in ('LIT')) OR ((a.awb_type='T' and a.accept_mode in ('TIT'))
      and exists(select 1 from (select awb_no,awb_date from trf_accept_brkdn
      union
      select awb_no,awb_date from trf_accept_hd)
      where awb_no=a.awb_no
      and awb_date=a.awb_date)))
      GROUP BY b.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_EXP_TRF_FFM_SENT = nvl(i.V_EXP_TRF_FFM_SENT, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;


    --Export_Transfer_FFM_Sent_In-time
    --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    for I in (
      SELECT b.CARR_CODE V_CARR_CODE, count(a.awb_no) V_EXP_TRF_FFM_SENT_IN_TIME
      FROM
      (select p.awb_no, p.awb_date, p.flt_key, p.flt_date, fo.carr_code
        from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
          union select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb) p
        join flt_opr fe on fe.flt_key = p.flt_key and fe.sch_date = p.flt_date and fe.flt_type = 'D' and fe.act_date is not null
        join flt_opr_events fo on fo.tr_no = fe.tr_no
        JOIN aa_c2k_sla_config_setup e ON fo.CARR_CODE=E.CARRIER_CODE and e.msg_type='FFM' AND IMP_EXP_TYPE='E' AND E.PAX_CGO_TYPE = fe.CGO_ACFT_TYPE
        where fo.ctm_out_date <= to_date(TO_CHAR(fe.ACT_DATE, 'DDMONYY')||' '||LPAD(fe.ACT_TIME,4,0), 'DDMONYY HH24MI')+ TO_NUMBER(e.SLA_IN_MINUTES)/1440
        ) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      --and (a.awb_type='E' and a.accept_mode in ('TIT','LIT'))
      --and ((a.awb_type='E' and a.accept_mode in ('LIT')) OR (a.awb_type='T' and a.accept_mode in ('TIT')))
      and ((a.awb_type='E' and a.accept_mode in ('LIT')) OR ((a.awb_type='T' and a.accept_mode in ('TIT'))
      and exists(select 1 from (select awb_no,awb_date from trf_accept_brkdn
      union
      select awb_no,awb_date from trf_accept_hd)
      where awb_no=a.awb_no
      and awb_date=a.awb_date)))
      GROUP BY b.carr_code)
    loop
      update AA_C2K_TRN_TRF set TT_EXP_TRF_FFM_SENT_IN_TIME = nvl(i.V_EXP_TRF_FFM_SENT_IN_TIME, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;

    --Export_Transfer_DEP_Sent
    --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    for I in (
      select b.CARR_CODE V_CARR_CODE, COUNT(a.AWB_NO) V_EXP_TRF_DEP_SENT
      from
      (select p.awb_no, p.awb_date, p.flt_key, p.flt_date, fe.carr_code
        from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
          union select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb) p
        join AWB_SHP_STS f on f.AWB_NO=p.AWB_NO AND f.AWB_DATE=p.AWB_DATE and f.flt_no = p.flt_key and f.flt_date = p.flt_date
        join flt_opr fe on fe.flt_key = p.flt_key and fe.sch_date = p.flt_date and fe.flt_type = 'D' and fe.act_date is not null
        join flt_opr_events fo on fo.tr_no = fe.tr_no
        JOIN aa_c2k_sla_config_setup e ON fe.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/DEP' AND IMP_EXP_TYPE='E' AND E.PAX_CGO_TYPE = fe.CGO_ACFT_TYPE
        where f.COD_FSU_STS = 'DEP'
        and fo.ctm_out_date is not null) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      --and (a.awb_type='E' and a.accept_mode in ('TIT','LIT'))
      --and ((a.awb_type='E' and a.accept_mode in ('LIT')) OR (a.awb_type='T' and a.accept_mode in ('TIT')))
      and ((a.awb_type='E' and a.accept_mode in ('LIT')) OR ((a.awb_type='T' and a.accept_mode in ('TIT'))
      and exists(select 1 from (select awb_no,awb_date from trf_accept_brkdn
      union
      select awb_no,awb_date from trf_accept_hd)
      where awb_no=a.awb_no
      and awb_date=a.awb_date)))
      group by b.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_EXP_TRF_DEP_SENT = nvl(i.V_EXP_TRF_DEP_SENT, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;


    --Export_Transfer_DEP_Sent_In-time
    --CR15030203 - TIT LOGIC HAS BEEN CHANGED
    for I in (
      SELECT b.CARR_CODE V_CARR_CODE, count(a.awb_no) V_EXP_TRF_DEP_SENT_IN_TIME
      FROM
      (select p.awb_no, p.awb_date, p.flt_key, p.flt_date, fo.carr_code
        from (select awb_no, awb_date, flt_key, flt_date from EXP_PMANIFEST_AWB
          union select awb_no, awb_date, flt_key, flt_date from exp_pman_tarmac_awb) p
        join AWB_SHP_STS f on f.AWB_NO=p.AWB_NO AND f.AWB_DATE=p.AWB_DATE and f.flt_no = p.flt_key and f.flt_date = p.flt_date
        join flt_opr fe on fe.flt_key = p.flt_key and fe.sch_date = p.flt_date and fe.flt_type = 'D' and fe.act_date is not null
        join flt_opr_events fo on fo.tr_no = fe.tr_no
        JOIN aa_c2k_sla_config_setup e ON fe.CARR_CODE=E.CARRIER_CODE and e.msg_type='FSU/DEP' AND IMP_EXP_TYPE='E' AND E.PAX_CGO_TYPE = fe.CGO_ACFT_TYPE
        where f.cr_date <= to_date(TO_CHAR(fe.ACT_DATE, 'DDMONYY')||' '||LPAD(fe.ACT_TIME,4,0), 'DDMONYY HH24MI')+ TO_NUMBER(e.SLA_IN_MINUTES)/1440
        and f.COD_FSU_STS = 'DEP'
          and fo.ctm_out_date is not null) B
      join awb a on A.AWB_NO=B.AWB_NO AND A.AWB_DATE=B.AWB_DATE
      WHERE b.flt_date between P_START_DATE and P_END_DATE
      and a.catalog not in ('TM')
      --and (a.awb_type='E' and a.accept_mode in ('TIT','LIT'))
      --and ((a.awb_type='E' and a.accept_mode in ('LIT')) OR (a.awb_type='T' and a.accept_mode in ('TIT')))
      and ((a.awb_type='E' and a.accept_mode in ('LIT')) OR ((a.awb_type='T' and a.accept_mode in ('TIT'))
      and exists(select 1 from (select awb_no,awb_date from trf_accept_brkdn
      union
      select awb_no,awb_date from trf_accept_hd)
      where awb_no=a.awb_no
      and awb_date=a.awb_date)))
      group by b.CARR_CODE)
    loop
      update AA_C2K_TRN_TRF set TT_EXP_TRF_DEP_SENT_IN_TIME = nvl(i.V_EXP_TRF_DEP_SENT_IN_TIME, 0) where AIRLINE = i.V_CARR_CODE;
    end loop;



  END SP_TRN_TRF_REPT;

END PKG_C2K_REPT;
/
SHOW ERRORS