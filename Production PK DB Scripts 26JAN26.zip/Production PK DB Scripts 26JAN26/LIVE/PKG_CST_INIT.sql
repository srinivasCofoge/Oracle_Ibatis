--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PACKAGE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT CREATE OR REPLACE PACKAGE WOSINT.PKG_CST_INIT
CREATE OR REPLACE PACKAGE WOSINT.PKG_CST_INIT
IS
FUNCTION INITIAL_CONSIGNMENT_SUBMISSION(
    P_FLT_KEY  IN VARCHAR2,
    P_FLT_DATE IN VARCHAR2,
    P_VER_NO   IN OUT NUMBER,
    P_USER_ID  IN VARCHAR2,
    P_LM_DATE  IN DATE,
    P_FLT_TYPE IN VARCHAR2)
  RETURN VARCHAR2;
FUNCTION AMEND_CONSIGNMENT_SUBMISSION(
    P_FLT_KEY  VARCHAR2,
    P_FLT_DATE VARCHAR2,
    P_VER_NO  IN OUT NUMBER,
    P_USER_ID IN VARCHAR2,
    P_LM_DATE IN DATE,
    P_FLT_TYPE IN VARCHAR2)
  RETURN VARCHAR2;
FUNCTION BEHIND_CONSIGNMENT_SUBMISSION(
    P_FLT_KEY  VARCHAR2,
    P_FLT_DATE VARCHAR2,
    P_VER_NO  IN OUT NUMBER,
    P_USER_ID IN VARCHAR2,
    P_LM_DATE IN DATE,
    P_FLT_TYPE IN VARCHAR2)
  RETURN VARCHAR2;
/* START FOR CR - 16051801_CR_Customs Submission */ 
FUNCTION FUN_VALIDATE_AWB_SUBM(
    P_FLT_KEY IN VARCHAR2, 
    P_FLT_DATE IN DATE, 
    P_AWB_NO IN VARCHAR2, 
    P_AWB_DATE IN DATE)
  RETURN VARCHAR2;
/* END FOR CR - 16051801_CR_Customs Submission */
END PKG_CST_INIT;
/
PROMPT CREATE OR REPLACE PACKAGE BODY WOSINT.PKG_CST_INIT
CREATE OR REPLACE PACKAGE BODY WOSINT.PKG_CST_INIT
IS
  s_cons_header   VARCHAR2(500);
  s_cons_detail   VARCHAR2(2500);
  s_cons_footer   VARCHAR2(30);
  s_schedule_date VARCHAR2(8);
  s_version_no    VARCHAR2(2);
  s_lic_per       VARCHAR2(240);
  s_cargo_ind     VARCHAR2(1) := 'Y';
  s_cms3_error    VARCHAR2(200);
  s_error_msg     VARCHAR2(200);
  s_int_amd       VARCHAR2(3);
  s_action_code   VARCHAR2(1);
  s_cnsl_ind      VARCHAR2(1);
  s_man_pcs       VARCHAR2(6);
  s_man_wt        VARCHAR2(9);
  s_content       VARCHAR2(70);
  s_ldg_point     VARCHAR2(3);
  s_simp_cnt      NUMBER;
  s_cnsl_cnt      NUMBER;
  s_hawb_cnt      NUMBER;
  s_shpt_typ      VARCHAR2(1);
  s_rel_ind       VARCHAR2(1);
  s_uid           VARCHAR2(44);
  s_user_id       VARCHAR2(20);
  s_lm_date DATE;
  v_cnt           NUMBER;
  s_detail_seq_no NUMBER;
  s_int_ver_no    NUMBER;
  v_awb_date DATE;
  v_awb_shpm_type VARCHAR2(1);
  s_awb_csgn_addr   VARCHAR2(500);
  s_awb_shpr_addr   VARCHAR2(500);
  s_awb_noti_addr   VARCHAR2(500);
  s_hawb_csgn_addr   VARCHAR2(500);
  s_hawb_shpr_addr   VARCHAR2(500);
  s_hawb_noti_addr   VARCHAR2(500);
  s_vessel_information VARCHAR2(450);
  V_STFS_COUNT NUMBER;
  v_ppk_ind VARCHAR2(1);
  V_STFS_FLT_KEY              VARCHAR2(10);
  V_STFS_FLT_DATE             VARCHAR2(10);
  V_STFS_SOUTH_BND NUMBER;
  stfs_shpt_type      VARCHAR2(1);
TYPE cursor_t
IS
  REF
  CURSOR;
    t_awb awblist;
    v_flt_key VARCHAR2(10);
    v_flt_type VARCHAR2(1);
    v_flt_date DATE;
    v_awb_no  VARCHAR2(30);
    v_hawb_no VARCHAR2(18);
    v_dummy_flt_type   VARCHAR2(1) := 'I';
    v_dummy_exp_flt_type   VARCHAR2(1) := 'E';
 c_hdlg_agent constant VARCHAR2(3) := 'CPA';
    cheader   CONSTANT VARCHAR2(6) := 'HEADER';
    cdetail   CONSTANT VARCHAR2(6) := 'DETAIL';
    cfooter   CONSTANT VARCHAR2(6) := 'FOOTER';
    --ERROR MESSAGE
    --c_awb_00001 CONSTANT VARCHAR2(100) := ' Airway bill declare currency code is invalid when customs declare value is not null.';
    --c_awb_00002 CONSTANT VARCHAR2(100) := ' Airway bill(house airyway bill) is null or format is wrong(its length should be 11)';
    --c_awb_00003 CONSTANT VARCHAR2(100) := ' Airway bill(house airyway bill) origin or destination value is null';
    --c_awb_00004 CONSTANT VARCHAR2(100) := ' Airway bill(house airyway bill) piece or weight is invvalid';
    --c_awb_00005 CONSTANT VARCHAR2(100) := ' Airway bill(house airyway bill) content is invalid';
    --c_awb_00006 CONSTANT VARCHAR2(100) := ' Airway bill(house airyway bill) importer is invalid';
    --c_awb_00007 CONSTANT VARCHAR2(100) := ' Airway bill(house airyway bill) shipper is invalid';
    --c_awb_00008 CONSTANT VARCHAR2(100) := ' Airway bill pieces or weight is invalid';
    c_awb_00009 CONSTANT VARCHAR2(100) := ' Generated message format is wrong.now its length is';
    --c_awb_00013 CONSTANT VARCHAR2(100) := ' Airway bill shipper/consignee address is invalid';
    --c_awb_00014 CONSTANT VARCHAR2(100) := ' House airway bill can not have space';
    --c_awb_00010 CONSTANT VARCHAR2(100) := ' Airway bill manifest piece or weight is invalid';
    --c_awb_00011 CONSTANT VARCHAR2(100) := ' No data found';
    --c_awb_00012 CONSTANT VARCHAR2(100) := ' Aireay bill release indicator is wrong';
    --c_flt_00002 CONSTANT VARCHAR2(100) := ' Flight scheduled arrival time is wrong';
    c_flt_00003 CONSTANT VARCHAR2(100) := ' Submit is in progress';
    --C_FLT_00003 CONSTANT VARCHAR2(50):=' Flight port code of flight last take off is wrong';
    v_ver_no VARCHAR2(10);
    /************************************/
    /*INSERT INTO INITIAL CONSIGNMENT INFORMATION
    INTO CST_CSGNM TABLE
    /************************************/
  FUNCTION fun_valid_hawb_no
    RETURN BOOLEAN
  IS
  BEGIN
    s_error_msg := '';
    FOR c       IN
    (SELECT b.awb_no,
      b.hawb_no,
      a.cst_type
    FROM cst_submit_temp a,
      cst_hawb b
    WHERE a.awb_no            = b.awb_no
    AND a.flt_key             = v_flt_key
    AND a.flt_date            = v_flt_date
    AND a.ver_no              = 1
    AND a.cst_type            = s_int_amd
    AND instr(b.hawb_no, ' ') > 0
    ORDER BY b.awb_no,
      b.hawb_no
    )
  LOOP
    IF (LENGTH(s_error_msg) + LENGTH(' ' || c.awb_no || ':' || c.hawb_no)) >= 150 THEN
      EXIT;
    END IF;
    s_error_msg := s_error_msg || ' ' || c.awb_no || ':' || c.hawb_no;
  END LOOP;
  IF s_error_msg IS NOT NULL THEN
    RETURN FALSE;
  END IF;
  RETURN TRUE;
EXCEPTION
WHEN OTHERS THEN
  IF s_error_msg IS NOT NULL THEN
    RETURN FALSE;
  END IF;
  RETURN TRUE;
END;
FUNCTION insert_cst_csgnm(
    p_hawb_no VARCHAR2,
    msg_type  VARCHAR2)
  RETURN BOOLEAN
IS
  s_seq_no NUMBER;

BEGIN
  /*IF msg_type = cdetail THEN
  SELECT nvl(MAX(seq_no), 0) + 1
  INTO s_detail_seq_no
  FROM cst_csgnm a
  WHERE a.flt_type = 'I'
  AND a.flt_key = v_flt_key
  AND a.flt_date = v_flt_date
  AND ver_no = s_version_no
  AND a.recv_rec_type = s_int_amd
  AND seq_no < 9999;
  ELSE
  s_detail_seq_no := (CASE msg_type WHEN cheader THEN 0 ELSE 99999 END);
  END IF;*/
  IF msg_type        = cheader THEN
    s_seq_no        := 0;
  ELSIF msg_type     = cfooter THEN
    s_seq_no        := 99999;
  ELSIF msg_type     = cdetail THEN
    s_detail_seq_no := s_detail_seq_no + 1;
    s_seq_no        := s_detail_seq_no;
  ELSE
    NULL;
  END IF;
--  INSERT
--  INTO cst_auto_submit_log VALUES
--    (
--      'cdetail '
--      || cdetail
--      ||'......awb...'
--      ||v_awb_no
--    );
--  dbms_output.put_line
--  (
--    'cdetail-'||cdetail||'..msg..'||msg_type||'..v_awb_no..'||v_awb_no||'..h..'||p_hawb_no||'....s_cons_detail...'||s_cons_detail
--  )
--  ;

 BEGIN
      SELECT  stfs_flt_key,stfs_flt_date  INTO V_STFS_FLT_KEY,V_STFS_FLT_DATE from flt_opr
      where sch_date = v_flt_date and flt_key=v_flt_key and flt_type=DECODE(v_flt_type,'I','A','E','D',v_flt_type);
      --DECODE(flt_type,'I','A','E','D','T','S');
         EXCEPTION
              WHEN NO_DATA_FOUND THEN
                V_STFS_FLT_KEY:=NULL;
                V_STFS_FLT_DATE:=NULL;
   END;

 if msg_type = cdetail then
  if v_awb_no is not null and  p_hawb_no = '000000000000000000' then
    v_ppk_ind:=FUN_VSL_SHP_PPK_TYPE(v_flt_key,v_flt_date,v_flt_type,v_awb_no);
   s_cons_detail:=s_cons_detail||v_ppk_ind;
 else
   s_cons_detail:=s_cons_detail||v_ppk_ind;
  END IF;
END IF;

  INSERT
  INTO cst_csgnm
    (
      carr_code,
      flt_type,
      flt_date,
      flt_key,
      ver_no,
      recv_rec_type,
      seq_no,
      ctrl_date,
      req_uid,
      awb_no,
      hawb_no,
      cns_hdr,
      cns_dtl,
      cns_ftr,
      lm_user_id,
      lm_date,
      lm_ver,
      VESSEL_FLT_INFO
    )
    VALUES
    (
     SUBSTR(NVL(V_STFS_FLT_KEY,v_flt_key), 1, 2),
      v_flt_type,
      NVL(V_STFS_FLT_DATE,v_flt_date),
      NVL(V_STFS_FLT_KEY,v_flt_key),
      s_version_no,
      s_int_amd,
      s_seq_no,
      SYSDATE,
      ' ',
      DECODE(msg_type, cdetail, v_awb_no, NULL),
      DECODE(msg_type, cdetail, p_hawb_no, NULL),
      DECODE(msg_type, cheader, s_cons_header, NULL),
      DECODE(msg_type, cdetail, upper(s_cons_detail), NULL),
      DECODE(msg_type, cfooter, s_cons_footer, NULL),
      USER,
      SYSDATE,
      1,
      DECODE(msg_type, cheader,s_vessel_information, NULL)
    );
  RETURN TRUE;
EXCEPTION
WHEN OTHERS THEN
  s_error_msg := SUBSTR
  (
    SQLCODE || SQLERRM, 1, 100
  )
  ;
  INSERT INTO CST_AUTO_SUBMIT_LOG (MSG)VALUES
    ('s_error_msg 1 ' || SYSDATE || ' - ' || S_ERROR_MSG
    );
  INSERT INTO SYS_EXCEPTION_DTLS(FUNC_CODE,FUNC_TYPE,ACCESS_USER_ID,URL_PATH,EXCEP_MSG,EXCEP_STACK_TRACE,EXCEP_OCC_DATE)
   		VALUES('ACCSFltSubm', 'C', USER, 'ACCSFlightSubmission', 's_int_amd : '||s_int_amd||' :: s_error_msg 1 ' || s_error_msg, UTL_RAW.CAST_TO_RAW(s_error_msg) , sysdate);


  RETURN FALSE;
END;
PROCEDURE insert_awb_event
  (
    p_awb_pcs NUMBER,
    p_awb_wt  NUMBER
  )
IS
  v_event_desc VARCHAR2
  (
    100
  )
  ;
  --v_awb_date   DATE;
  v_event_id VARCHAR2
  (
    12
  )
  ;
BEGIN
  --get airway bill date
  /*    BEGIN
  SELECT awb_date
  INTO v_awb_date
  FROM imp_car_shp
  WHERE flt_key = v_flt_key
  AND flt_date = v_flt_date
  AND awb_no = v_awb_no
  AND rownum = 1;
  EXCEPTION
  WHEN no_data_found THEN
  v_awb_date := trunc(SYSDATE);
  END;*/
  v_event_id :=
  (
    CASE
    WHEN s_int_amd = 'INT' THEN
      'SUBINTC'
    WHEN s_int_amd = 'AMD' THEN
      'SUBAMDC'
    WHEN s_int_amd = 'BDS' THEN
      'SUBLBC'
    END
  )
  ;
  BEGIN
    SELECT event_desc
    INTO v_event_desc
    FROM mast_awb_events
    WHERE event_id = v_event_id;
  EXCEPTION
  WHEN no_data_found THEN
    v_event_desc :=
    (
      CASE
      WHEN s_int_amd = 'INT' THEN
        'Submit INT consignment'
      WHEN s_int_amd = 'AMD' THEN
        'Submit AMD consignment'
      WHEN s_int_amd = 'BDS' THEN
        'Submit LB consignment'
      END);
  END;
  INSERT
  INTO awb_events
    (
      awb_no,
      awb_date,
      event_id,
      event_desc,
      flt_key,
      flt_date,
      flt_type,
      tr_no,
      pcs,
      wt,
      cr_user_id,
      cr_date,
      lm_user_id,
      lm_date
    )
    VALUES
    (
      v_awb_no,
      v_awb_date,
      v_event_id,
      v_event_desc,
      v_flt_key,
      v_flt_date,
      v_flt_type,
      awb_event_seq.NEXTVAL,
      p_awb_pcs,
      p_awb_wt,
      s_user_id,
      s_lm_date,
      s_user_id,
      s_lm_date
    );
EXCEPTION
WHEN OTHERS THEN
  RETURN;
END;
PROCEDURE pro_awb_list
IS
BEGIN
  t_awb := awblist
  (
  )
  ;
  FOR c IN
  (SELECT DISTINCT a.flt_key,
      a.flt_date,
      a.ver_no,
      a.awb_no,
      a.hawb_no,
      a.cst_type
    FROM cst_submit_temp a
    WHERE flt_key = v_flt_key
    AND FLT_DATE  = V_FLT_DATE
    AND ver_no    =  1
    AND cst_type  = s_int_amd
    ORDER BY awb_no,
      hawb_no
  )
  LOOP
    t_awb.EXTEND;
--    dbms_output.put_line
--    (
--      'pro awb list....'||c.awb_no
--    )
--    ;
    t_awb
    (
      t_awb.COUNT
    )
    := subm_list
    (
      c.awb_no, NVL(c.hawb_no, '000000000000000000')
    )
    ;
  END LOOP;
  IF t_awb.COUNT > 0 THEN
    IF t_awb
      (
        1
      )
      .awb_no      = 'NIL' THEN
      s_cargo_ind := 'N';
    ELSE
      s_cargo_ind := 'Y';
    END IF;
  END IF;
EXCEPTION
WHEN OTHERS THEN
  s_error_msg := SUBSTR
  (
    SQLCODE || SQLERRM, 1, 200
  )
  ;
  INSERT INTO CST_AUTO_SUBMIT_LOG (MSG) VALUES
    ('PRO_AWB_LIST 1' ||sysdate ||' ' || s_error_msg
    );

  INSERT INTO SYS_EXCEPTION_DTLS(FUNC_CODE,FUNC_TYPE,ACCESS_USER_ID,URL_PATH,EXCEP_MSG,EXCEP_STACK_TRACE,EXCEP_OCC_DATE)
   		VALUES('ACCSFltSubm', 'C', USER, 'ACCSFlightSubmission', 'S_INT_AMD: '||S_INT_AMD||' : PRO_AWB_LIST 1 ' || s_error_msg, UTL_RAW.CAST_TO_RAW(s_error_msg) , SYSDATE);

END;
FUNCTION update_accs_ind
  (
    p_table_name IN VARCHAR2
  )
  RETURN BOOLEAN
IS
BEGIN
  IF s_int_amd = 'BDS' THEN
    RETURN TRUE;
  END IF;
  IF p_table_name = 'CST_HAWB' THEN
          if v_flt_type ='E' then
            UPDATE cst_hawb
              SET accs_ind  = s_int_amd,
                lm_date     = SYSDATE,
                lm_user_id  = USER,
                subm_ver_no = s_version_no
              WHERE awb_no  = v_awb_no
              AND accs_ind  = 'N'
              AND FLT_TYPE = 'E'
              AND flt_key     = v_flt_key
              AND flt_date    = v_flt_date
              AND hawb_no   = NVL(v_hawb_no, hawb_no);
          else
                UPDATE cst_hawb
                SET accs_ind  = s_int_amd,
                lm_date     = SYSDATE,
                flt_key     = v_flt_key,
                flt_date    = v_flt_date,
                lm_user_id  = USER,
                subm_ver_no = s_version_no
              WHERE awb_no  = v_awb_no
              AND accs_ind  = 'N'
              AND hawb_no   = NVL(v_hawb_no, hawb_no) AND NVL(FLT_TYPE,'I') <> 'E';
        END IF;
  ELSE
    UPDATE cst_awb
    SET accs_ind  = s_int_amd,
      lm_date     = SYSDATE,
      lm_user_id  = USER,
      subm_ver_no = s_version_no
    WHERE flt_key = v_flt_key
    AND flt_date  = v_flt_date
    AND flt_type  = v_flt_type
    AND accs_ind  = 'N'
    AND awb_no    = v_awb_no;
  END IF;
  RETURN TRUE;
EXCEPTION
WHEN OTHERS THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 200);
  INSERT INTO CST_AUTO_SUBMIT_LOG (MSG) VALUES
    ('PRO_AWB_LIST 2 ' || sysdate ||' ' ||  s_error_msg
    );
  INSERT INTO SYS_EXCEPTION_DTLS(FUNC_CODE,FUNC_TYPE,ACCESS_USER_ID,URL_PATH,EXCEP_MSG,EXCEP_STACK_TRACE,EXCEP_OCC_DATE)
 	VALUES('ACCSFltSubm', 'C', USER, 'ACCSFlightSubmission', 'S_INT_AMD: '||S_INT_AMD||'PRO_AWB_LIST 2 ' || s_error_msg, UTL_RAW.CAST_TO_RAW(s_error_msg) , SYSDATE);

  RETURN FALSE;
END;
PROCEDURE init
IS
BEGIN
  s_cons_header   := NULL;
  s_cons_detail   := NULL;
  s_cons_footer   := NULL;
  s_schedule_date := NULL;
  s_lic_per       := NULL;
  s_cargo_ind     := 'N';
  s_error_msg     := NULL;
  s_action_code   := NULL;
  s_cnsl_ind      := 'N';
  s_man_pcs       := 0;
  s_man_wt        := 0;
  s_simp_cnt      := 0;
  s_cnsl_cnt      := 0;
  s_hawb_cnt      := 0;
  s_detail_seq_no := 0;
  s_vessel_information:= NULL;
  v_ppk_ind :=null;
  V_STFS_FLT_KEY := NULL;
  V_STFS_FLT_DATE := NULL;
END;
/************************************/
/*GET THE LICENSE OR PERMIT
************************************/
PROCEDURE get_lic_per
  (
    p_hawb_no VARCHAR2 DEFAULT NULL
  )
IS
  CURSOR cur_lic
  IS
    SELECT SUBSTR(e.permit, 1, 16)
    FROM cst_permit e
    WHERE e.awb_no = v_awb_no
    AND e.hawb_no  = NVL(p_hawb_no, e.hawb_no)
    AND rownum     < 1;
  s_temp_lic VARCHAR(15);
BEGIN
  OPEN cur_lic;
  LOOP
    FETCH cur_lic INTO s_temp_lic;
    EXIT
  WHEN cur_lic%NOTFOUND;
    s_lic_per := s_lic_per || rpad(s_temp_lic, 16, ' ');
  END LOOP;
  s_lic_per := rpad(s_lic_per || ' ', 240, ' ');
  CLOSE cur_lic;
EXCEPTION
WHEN OTHERS THEN
  s_lic_per := rpad(s_lic_per || ' ', 240, ' ');
END;
FUNCTION get_others_shpt_type(
    p_dest IN VARCHAR2)
  RETURN VARCHAR2
IS
  v_shpt_type VARCHAR2(1);
BEGIN
  SELECT 'I'
  INTO v_shpt_type
  FROM mast_code_dtl b
  WHERE group_code = '38'
  AND code_type    = 'ACCS_IMP_PORT'
  AND code         = p_dest
  AND rownum       = 1;
  RETURN v_shpt_type;
EXCEPTION
WHEN no_data_found THEN
  RETURN 'T';
END;
FUNCTION get_dhl_shpt_type
  RETURN VARCHAR2
IS
  v_shpt_type   VARCHAR2(1);
  v_shpt_type_i NUMBER;
  v_shpt_type_t NUMBER;
  v_ver_no      NUMBER;
BEGIN
  IF s_int_amd IN ('INT', 'BDS') THEN
    SELECT SUM(a.hawb_no)
    INTO v_shpt_type_i
    FROM mast_hawb a,
      mast_code_dtl b
    WHERE a.hawb_des = b.code
    AND a.awb_no     = v_awb_no
    AND b.group_code = '38'
    AND b.code_type  = 'ACCS_IMP_PORT';
    SELECT SUM(hawb_no) INTO v_shpt_type_t FROM mast_hawb WHERE awb_no = v_awb_no;
  ELSE
    SELECT MAX(ver_no)
    INTO v_ver_no
    FROM cst_subm
    WHERE rec_type = 'INT'
    AND flt_type   = v_flt_type
    AND flt_key    = NVL(V_STFS_FLT_KEY,v_flt_key)
    AND flt_date   = NVL(V_STFS_FLT_DATE,v_flt_date);

    SELECT SUM(1)
    INTO v_shpt_type_i
    FROM mast_hawb m,
      mast_code_dtl n,
      (SELECT awb_no,
        hawb_no
      FROM cst_csgnm a
      WHERE a.flt_type    = v_flt_type
      AND a.flt_key       = NVL(V_STFS_FLT_KEY,v_flt_key)
      AND a.flt_date      = NVL(V_STFS_FLT_DATE,v_flt_date)
      AND a.recv_rec_type = 'INT'
      AND a.ver_no        = v_ver_no
      AND a.awb_no        = v_awb_no
      AND a.hawb_no      <> '000000000000000000'
      UNION
      SELECT awb_no,
        hawb_no
      FROM TABLE(CAST(t_awb AS awblist))
      WHERE awb_no = v_awb_no
      AND hawb_no <> '000000000000000000'
      ) k
    WHERE m.hawb_des = n.code
    AND m.awb_no     = k.awb_no
    AND m.hawb_no    = k.hawb_no
    AND n.group_code = '38'
    AND n.code_type  = 'ACCS_IMP_PORT';

    SELECT SUM(1)
    INTO v_shpt_type_t
    FROM
      (SELECT awb_no,
        hawb_no
      FROM cst_csgnm a
      WHERE a.flt_type    = v_flt_type
      AND a.flt_key       = NVL(V_STFS_FLT_KEY,v_flt_key)
      AND a.flt_date      = NVL(V_STFS_FLT_DATE,v_flt_date)
      AND a.recv_rec_type = 'INT'
      AND a.ver_no        = v_ver_no
      AND a.awb_no        = v_awb_no
      AND a.hawb_no      <> '000000000000000000'
      UNION
      SELECT awb_no,
        hawb_no
      FROM TABLE(CAST(t_awb AS awblist))
      WHERE awb_no = v_awb_no
      AND hawb_no <> '000000000000000000'
      );
  END IF;
  v_shpt_type_i   := NVL(v_shpt_type_i, 0);
  v_shpt_type_t   := NVL(v_shpt_type_t, 0);
  IF v_shpt_type_t > v_shpt_type_i THEN
    v_shpt_type   := 'M';
  ELSE
    IF v_shpt_type_i = 0 THEN
      v_shpt_type   := 'T';
    ELSE
      v_shpt_type := 'I';
    END IF;
  END IF;
  RETURN v_shpt_type;
END;
FUNCTION get_isdhl(
    p_handle_id IN VARCHAR2)
  RETURN BOOLEAN
IS
  v_dhl NUMBER;
BEGIN
  SELECT SUM(1)
  INTO v_dhl
  FROM mast_code_dtl
  WHERE group_code     = '38'
  AND code_type        = 'EC_HANDLER_TYPE'
  AND code             = p_handle_id
  AND rownum           = 1;
  RETURN NVL(v_dhl, 0) > 0;
EXCEPTION
WHEN OTHERS THEN
  RETURN FALSE;
END;
/************************************/
/*GET THE AWB INFORMATION WHICH HAS NO HOUSE AIRAYBILL AND
INSERT INTO TABLE
************************************/
FUNCTION get_awb_info
  RETURN BOOLEAN
IS
  --s_sql_str    VARCHAR2(400);
  c_awb cst_awb%ROWTYPE;
  s_awb_no     VARCHAR2(30);
  v_cnt        NUMBER;
  s_msg_length NUMBER;
  v_isdhl      BOOLEAN;
  v_shc        VARCHAR2(30);

  CURSOR cur_awb
  IS
    SELECT *
    FROM cst_awb
    WHERE flt_type = v_flt_type
    AND flt_key    = v_flt_key
    AND flt_date   = v_flt_date
    AND awb_no     = v_awb_no;
BEGIN
  --CHECK WHETHER THE AWB MESSAGE EXISTS OR NOT
  DBMS_OUTPUT.PUT_LINE('get_awb_info s_int_amd '|| s_int_amd);

  IF s_int_amd = 'AMD' THEN
    BEGIN
      SELECT awb_no
      INTO s_awb_no
      FROM cst_csgnm
      WHERE flt_type    = v_flt_type
      AND flt_key       = NVL(V_STFS_FLT_KEY,v_flt_key)
      AND flt_date      = NVL(V_STFS_FLT_DATE,v_flt_date)
      AND ver_no        = s_version_no
      AND recv_rec_type = 'AMD'
      AND awb_no        = v_awb_no
      AND hawb_no       = '000000000000000000';
      RETURN TRUE;
    EXCEPTION
    WHEN no_data_found THEN
      NULL;
    WHEN too_many_rows THEN
      RETURN TRUE;
    END;
  END IF;
  /*s_sql_str := 'SELECT * FROM CST_AWB
  WHERE FLT_KEY=:V_FLT_KEY
  AND FLT_DATE = :V_FLT_DATE
  AND FLT_TYPE = :V_FLT_TYPE
  AND AWB_NO = :V_AWB_NO';*/
  IF cur_awb%ISOPEN THEN
    CLOSE cur_awb;
  END IF;
  OPEN cur_awb;
  FETCH cur_awb INTO c_awb;
  IF cur_awb%NOTFOUND THEN
    -- s_cms3_error := c_awb_00011;
    CLOSE cur_awb;
    --  RETURN FALSE;
    NULL;
  END IF;
  CLOSE cur_awb;
  s_cnsl_ind  := 'N';
  IF s_int_amd = 'AMD' THEN
    SELECT COUNT(*)
    INTO v_cnt
    FROM TABLE(CAST(t_awb AS awblist))
    WHERE awb_no     = v_awb_no
    AND hawb_no     <> '000000000000000000';
    IF NVL(v_cnt, 0) > 0 THEN
      s_cnsl_ind    := 'Y';
    ELSE
      BEGIN
        SELECT 'Y'
        INTO s_cnsl_ind
        FROM cst_csgnm
        WHERE flt_type    = v_flt_type
        AND flt_key       = NVL(V_STFS_FLT_KEY,v_flt_key)
        AND flt_date      = NVL(V_STFS_FLT_DATE,v_flt_date)
        AND recv_rec_type = 'INT'
        AND awb_no        = v_awb_no
        AND hawb_no      <> '000000000000000000'
        AND rownum        = 1;
      EXCEPTION
      WHEN no_data_found THEN
        s_cnsl_ind := 'N';
      WHEN OTHERS THEN
        s_cnsl_ind := 'N';
      END;
    END IF;
  ELSE
    BEGIN
      SELECT 'Y'
      INTO s_cnsl_ind
      FROM cst_hawb
      WHERE awb_no = v_awb_no
      and exists (select null from awb
                      where awb.awb_no = cst_hawb.awb_no and awb.awb_date = cst_hawb.awb_date
                      and nvl(awb.awb_closed_yn,'**') = 'N')
      AND rownum   = 1;
    EXCEPTION
    WHEN no_data_found THEN
      s_cnsl_ind := 'N';
    END;
  END IF;
  IF s_cnsl_ind = 'Y' THEN
    s_cnsl_cnt := s_cnsl_cnt + 1;
  ELSE
    s_simp_cnt := s_simp_cnt + 1;
  END IF;
  get_lic_per;
  s_rel_ind :=
  (
    CASE
    WHEN s_int_amd IN ('AMD', 'BDS') THEN
      ' '
    ELSE
      NVL(c_awb.rel_ind, ' ')
    END);
  v_isdhl := get_isdhl(c_awb.hdlg_agent);
  /*
  IF v_isdhl THEN
  IF s_cnsl_ind = 'Y' THEN
  s_shpt_typ := get_dhl_shpt_type;
  ELSE
  s_shpt_typ := get_others_shpt_type(c_awb.des);
  END IF;
  ELSE
  IF c_awb.des = 'HKG' THEN
  s_shpt_typ := 'I';
  ELSE
  s_shpt_typ := 'T';
  END IF;
  END IF;
  */
  BEGIN
  IF c_awb.flt_type = 'E' THEN
         BEGIN
          SELECT awb_date
          INTO v_awb_date
          FROM exp_pmanifest_awb
          WHERE flt_key = c_awb.flt_key
          AND flt_date  = c_awb.flt_date
          AND awb_no    = c_awb.awb_no
          AND rownum    = 1;
        EXCEPTION
          WHEN no_data_found THEN
          SELECT awb_date
          INTO v_awb_date
          FROM exp_pman_tarmac_awb
          WHERE flt_key = c_awb.flt_key
          AND flt_date  = c_awb.flt_date
          AND awb_no    = c_awb.awb_no
          AND rownum    = 1;
        END;
  ELSE
    SELECT awb_date
    INTO v_awb_date
    FROM imp_car_shp
    WHERE flt_key = c_awb.flt_key
    AND flt_date  = c_awb.flt_date
    AND awb_no    = c_awb.awb_no
    AND rownum    = 1;
  END IF;
  EXCEPTION
  WHEN no_data_found THEN
    v_awb_date := TRUNC(SYSDATE);
  END;
  s_shpt_typ      := pkg_cst.get_shpt_type(c_awb.awb_no, v_awb_date, c_awb.hdlg_agent, s_cnsl_ind);
  v_awb_shpm_type := s_shpt_typ;
  -- dbms_output.put_line('val........:.....'||s_shpt_typ||'.......'||c_awb.awb_no||'...'||c_awb.awb_date||'...'||c_awb.hdlg_agent||'...'||s_cnsl_ind);
  --2.26 AND 2.27 validation
  --IF c_awb.des = 'HKG' THEN
  --  s_shpt_typ := 'I';
  IF s_shpt_typ = 'I' AND s_rel_ind NOT IN ('R', 'S', 'X', ' ') THEN
    -- s_cms3_error := c_awb_00012;
    --RETURN FALSE;
    NULL;
  END IF;
  --ELSE
  -- s_shpt_typ := 'T';
  IF s_shpt_typ = 'T' AND s_rel_ind NOT IN ('F', 'M', 'X', ' ') THEN
    --s_cms3_error := c_awb_00012;
    --RETURN FALSE;
    NULL;
  END IF;
  --END IF;
  s_cons_detail := '';
  --validation start
  --manifest piece and weight
  IF c_awb.change_ind        = 'D' THEN
    IF NVL(c_awb.man_pcs, 0) = 0 OR NVL(c_awb.man_wgt, 0) = 0 THEN
      --  s_cms3_error := c_awb.awb_no || c_awb_00010;
      -- RETURN FALSE;
      NULL;
    END IF;
    s_man_wt  := lpad(TRIM(TO_CHAR(c_awb.man_wgt, '9999999.0')), 9, '0');
    s_man_pcs := lpad(c_awb.man_pcs, 6, '0');
  ELSE
    IF to_number(s_man_pcs) = 0 OR to_number(s_man_wt) = 0 THEN
      --s_cms3_error := c_awb.awb_no || c_awb_00010;
      --RETURN FALSE;
      NULL;
    END IF;
  END IF;
  --airway bill number
  IF LENGTH(c_awb.awb_no) <> 11 OR c_awb.awb_no IS NULL THEN
    -- s_cms3_error := c_awb.awb_no || c_awb_00002;
    --RETURN FALSE;
    NULL;
  END IF;
  --airway bill origin and destination
  IF c_awb.org IS NULL OR c_awb.des IS NULL OR NVL(c_awb.rtg_apt_code, s_ldg_point) IS NULL OR LENGTH(c_awb.org) <> 3 OR LENGTH(c_awb.des) <> 3 OR LENGTH(NVL(c_awb.rtg_apt_code, s_ldg_point)) <> 3 THEN
    --s_cms3_error := c_awb.awb_no || c_awb_00003;
    --RETURN FALSE;
    NULL;
  END IF;
  --airway bill piece and weight
  IF NVL(c_awb.pcs, 0) = 0 OR NVL(c_awb.wgt, 0) = 0 THEN
    --s_cms3_error := c_awb.awb_no || c_awb_00004;
    --RETURN FALSE;
    NULL;
  END IF;
  --airway bill contenct
  IF NVL(c_awb.content, s_content) IS NULL THEN
    --s_cms3_error := c_awb.awb_no || c_awb_00005;
    --RETURN FALSE;
    NULL;
  END IF;
  --customs declare value
  IF NVL(c_awb.cvd_chg_cust_val, 0) = 0 THEN
    c_awb.cvd_chg_cust_ind         := 'NCV';
    c_awb.cvd_iso_curr_code        := ' ';
  ELSE
    IF c_awb.cvd_iso_curr_code IS NULL THEN
      -- s_cms3_error := c_awb.awb_no || c_awb_00001;
      --RETURN FALSE;
      NULL;
    END IF;
    c_awb.cvd_chg_cust_ind := NULL;
  END IF;
  --consignee
  IF c_awb.csgne_name IS NULL OR c_awb.csgne_addr IS NULL THEN
    --s_cms3_error := c_awb.awb_no || c_awb_00006;
    --RETURN FALSE;
    NULL;
  END IF;
  --shipper
  IF c_awb.shpr_name IS NULL OR c_awb.shpr_addr IS NULL THEN
    --s_cms3_error := c_awb.awb_no || c_awb_00007;
    --RETURN FALSE;
    NULL;
  END IF;
  IF c_awb.shpr_addr IS NULL OR c_awb.csgne_addr IS NULL THEN
    --s_cms3_error := c_awb.awb_no || c_awb_00013;
    --RETURN FALSE;
    NULL;
  END IF;
--  dbms_output.put_line('before...'||c_awb.awb_no||'...'||s_cons_detail);
  --validation end
--
--CSGNE_PLACE                    VARCHAR2(17)
--CSGNE_CTRY_CODE                VARCHAR2(3)
--CSGNE_STATE_PROVINCE           VARCHAR2(9)
--CSGNE_PIN_CODE                 VARCHAR2(9)

  -- Country, State, City and Postal Code -- 15120201_CR_Additional address information to ACCS for MAWB and HAWB
  s_awb_csgn_addr := null;

    if c_awb.csgne_addr is not null
        or c_awb.csgne_addr2 is not null
        or c_awb.csgne_addr3 is not null
        or c_awb.csgne_addr4 is not null then
    s_awb_csgn_addr := FUN_CONCAT_ADDR_WITHSPACE(c_awb.csgne_addr , c_awb.csgne_addr2 , c_awb.csgne_addr3,c_awb.csgne_addr4 , null,c_awb.CSGNE_PLACE , c_awb.CSGNE_STATE_PROVINCE , c_awb.CSGNE_CTRY_CODE , c_awb.CSGNE_PIN_CODE)  ;
    end if;

--  SHPR_PLACE                     VARCHAR2(17)
--SHPR_CTRY_CODE                 VARCHAR2(3)
--SHPR_STATE_PROVINCE            VARCHAR2(9)
--SHPR_PIN_CODE                  VARCHAR2(9)

   s_awb_shpr_addr := null;

    if c_awb.SHPR_addr is not null
        or c_awb.SHPR_addr2 is not null
        or c_awb.SHPR_addr3 is not null
        or c_awb.SHPR_addr4 is not null then
    s_awb_shpr_addr := FUN_CONCAT_ADDR_WITHSPACE(c_awb.SHPR_addr , c_awb.SHPR_addr2 , c_awb.SHPR_addr3 , c_awb.SHPR_addr4 , null, c_awb.SHPR_PLACE , c_awb.SHPR_STATE_PROVINCE , c_awb.SHPR_CTRY_CODE , c_awb.SHPR_PIN_CODE)  ;
    end if;

 --
--NOTIFY_PLACE                   VARCHAR2(17)
--NOTIFY_CTRY_CODE               VARCHAR2(3)
--NOTIFY_STATE_PROVINCE          VARCHAR2(9)
--NOTIFY_PIN_CODE                VARCHAR2(9)

  s_awb_noti_addr := null;

    if c_awb.NOTIFY_addr is not null
        or c_awb.NOTIFY_addr2 is not null
        or c_awb.NOTIFY_addr3 is not null
        or c_awb.NOTIFY_addr4 is not null then
    s_awb_noti_addr := FUN_CONCAT_ADDR_WITHSPACE(c_awb.NOTIFY_addr, c_awb.NOTIFY_addr2, c_awb.NOTIFY_addr3, c_awb.NOTIFY_addr4 , null, c_awb.NOTIFY_PLACE , c_awb.NOTIFY_STATE_PROVINCE , c_awb.NOTIFY_CTRY_CODE , c_awb.NOTIFY_PIN_CODE ) ;
    end if;



  if V_STFS_FLT_KEY IS NOT NULL then
       BEGIN
         SELECT instr(STRAGG(STRINGDELIM(rule_value,',')), substr(V_STFS_FLT_KEY,0,2)) into V_STFS_SOUTH_BND
          FROM cmsrules where rule_code = 'STFS_SB_DUMMY_FLIGHT';
      EXCEPTION
      WHEN no_data_found THEN
        V_STFS_SOUTH_BND := 0;
      END;

       if(V_STFS_SOUTH_BND > 0) then
         s_shpt_typ := 'I';
       end if;
  end if;

  BEGIN
  SELECT REPLACE(STRAGG(STRINGDELIM(CODE,'')), ' ', '')  INTO v_shc
    FROM ( SELECT spl.code code FROM cst_awb awb,mast_spl_hand_code spl
      where (spl.CODE = AWB.sph_spl_code1 OR spl.CODE = AWB.sph_spl_code2 OR spl.CODE = AWB.sph_spl_code3 OR
                spl.CODE = AWB.sph_spl_code4 OR spl.CODE = AWB.sph_spl_code5 OR spl.CODE = AWB.sph_spl_code6 OR
                spl.CODE = AWB.sph_spl_code7 OR spl.CODE = AWB.sph_spl_code8 OR spl.CODE = AWB.sph_spl_code9)
      and flt_type = v_flt_type AND flt_key    = v_flt_key
      AND flt_date   = v_flt_date AND awb.awb_no =  c_awb.awb_no and awb.awb_date = c_awb.awb_date ORDER BY PRIORITY DESC) WHERE ROWNUM <= 6;
  EXCEPTION
   WHEN no_data_found THEN
        v_shc := '';
   END;

  s_cons_detail := s_schedule_date || --2.2.1
  rpad(FUN_CST_ACCS_TRANSITION(FUN_CST_FLT_KEY_SUBM(NVL(V_STFS_FLT_KEY,v_flt_key),NVL(V_STFS_FLT_DATE,v_flt_date),v_ver_no)), 9, ' ') ||          --2.2.2-3
  s_version_no ||                     --2.2.4
  (
    CASE
    WHEN s_int_amd = 'BDS' THEN
      'BLB'
    ELSE
      ''
    END) ||                                                       --ONLY FOR LBS 2.2.5-6
  SUBSTR(c_awb.awb_no, 1, 3) || '-' || SUBSTR(c_awb.awb_no, 4) || --2.2.5
  lpad('0', 18, '0') ||                                           --2.2.6
  c_awb.org ||                                                    --2.2.7
  NVL(c_awb.rtg_apt_code, s_ldg_point) ||                         --2.2.8
  c_awb.des ||                                                    --2.2.9
  s_man_pcs ||                                                    --2.2.10
  s_man_wt ||                                                     --2.2.11
  lpad(c_awb.pcs, 6, '0') ||                                      --2.2.12
      lpad(TRIM(to_char(c_awb.wgt,   '9999999.0')),   9,   '0') || --2.2.13
      FUN_CONCAT_ACCS_ADDRESS_VALUE(rpad(nvl(c_awb.content,   s_content),   265,   ' ')) || --2.2.14
      rpad(nvl(c_awb.cvd_iso_curr_code,   ' '),   3,   ' ') || --2.2.15
  (
    CASE (c_awb.cvd_chg_cust_ind)
    WHEN 'NCV' THEN
      rpad('NCV', 12, ' ')
    ELSE
      lpad(c_awb.cvd_chg_cust_val, 12, '0')
    END) ||                                                                                                                                                                              --2.2.16
   --     rpad(substr(c_awb.csgne_name, 1, 35), 95, ' ') || --2.2.17-18
    --     rpad(nvl(c_awb.csgne_addr, ' '), 53, ' ') || rpad(nvl(c_awb.csgne_addr2, ' '), 53, ' ') || rpad(nvl(c_awb.csgne_addr3, ' '), 53, ' ') || rpad(nvl(c_awb.csgne_addr4, ' '), 106, ' ') || --2.2.19
  --  rpad(nvl(c_awb.csgne_name,   'XXX'),   35,   ' ') ||

-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
    (CASE
    WHEN LENGTH(rpad(nvl(c_awb.csgne_name,   'XXX'),   70,   ' ')) < 70 THEN
    rpad(nvl(c_awb.csgne_name,   'XXX'),   70,   ' ') ||  rpad(' ',   70 - LENGTH(rpad(nvl(c_awb.csgne_name,   'XXX'),   70,   ' ')),   ' ')
    else rpad(nvl(c_awb.csgne_name,   'XXX'),   70,   ' ')
    END) ||
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401

     rpad(' ',   60,   ' ') || --Consignee Chinese Name

--  s_awb_csgn_addr
    FUN_CONCAT_ACCS_ADDRESS_VALUE(nvl(s_awb_csgn_addr,   'XXX') || rpad(' ',265-lengthb(nvl(s_awb_csgn_addr,   'XXX')),' ')) ||

--     rpad(nvl(c_awb.csgne_addr,   'XXX'),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.csgne_addr,   'XXX'),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.csgne_addr,   'XXX'),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.csgne_addr,   'XXX'),   53,   ' ')),   ' ')
--    else rpad(nvl(c_awb.csgne_addr,   'XXX'),   53,   ' ')
--    END) ||

--     rpad(nvl(c_awb.csgne_addr2,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.csgne_addr2,   ' '),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.csgne_addr2,   ' '),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.csgne_addr2,   ' '),   53,   ' ')),   ' ')
--    else  rpad(nvl(c_awb.csgne_addr2,   ' '),   53,   ' ')
--    END) ||

--    rpad(nvl(c_awb.csgne_addr3,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.csgne_addr3,   ' '),   53,   ' ')) < 53 THEN
--     rpad(nvl(c_awb.csgne_addr3,   ' '),   53,   ' ') || rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.csgne_addr3,   ' '),   53,   ' ')),   ' ')
--     else rpad(nvl(c_awb.csgne_addr3,   ' '),   53,   ' ')
--    END) ||

--     rpad(nvl(c_awb.csgne_addr4,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.csgne_addr4,   ' '),   53,   ' ')) < 53 THEN
--      rpad(nvl(c_awb.csgne_addr4,   ' '),   53,   ' ') || rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.csgne_addr4,   ' '),   53,   ' ')),   ' ')
--      else  rpad(nvl(c_awb.csgne_addr4,   ' '),   53,   ' ')
--    END) ||

--     rpad(nvl(c_awb.csgne_addr4,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.csgne_addr4,   ' '),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.csgne_addr4,   ' '),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.csgne_addr4,   ' '),   53,   ' ')),   ' ')
--    else rpad(nvl(c_awb.csgne_addr4,   ' '),   53,   ' ')
--    END) ||

--     lpad(nvl(c_awb.notify_name, ' '), 95, ' ') || --2.2.20-21
--    lpad(nvl(c_awb.notify_addr, ' '), 265, ' ') || --2.2.22
--    rpad(nvl(c_awb.notify_name,   ' '),   35,   ' ') ||
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
    (CASE
    WHEN LENGTH(rpad(nvl(c_awb.notify_name,   ' '),   70, ' ')) < 70 THEN
     rpad(nvl(c_awb.notify_name,   ' '),   70,   ' ') || rpad(' ',   70 - LENGTH(rpad(c_awb.notify_name,   70,   ' ')),   ' ')
     else rpad(nvl(c_awb.notify_name,   ' '),   70,   ' ')
    END) ||
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401

     rpad(' ',   60,   ' ') || --Notify Party Chinese Name

--    s_awb_noti_addr
  FUN_CONCAT_ACCS_ADDRESS_VALUE(nvl(s_awb_noti_addr,   ' ') || rpad(' ',265-lengthb(nvl(s_awb_noti_addr,   ' ')),' ')) ||

--    lpad(nvl(c_awb.notify_addr,   ' '),   265,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.notify_addr,   ' '),   265,   ' ')) < 265 THEN
--    rpad(nvl(c_awb.notify_addr,   ' '),   265,   ' ') ||  rpad(' ',   265 - LENGTH(rpad(nvl(c_awb.notify_addr,   ' '),   265,   ' ')),   ' ')
--    else lpad(nvl(c_awb.notify_addr,   ' '),   265,   ' ')
--    END) ||
     --	 rpad(substr(c_awb.shpr_name, 1, 35), 95, ' ') || --2.2.23-24
    --     rpad(nvl(c_awb.shpr_addr, ' '), 53, ' ') || rpad(nvl(c_awb.shpr_addr2, ' '), 53, ' ') || rpad(nvl(c_awb.shpr_addr3, ' '), 53, ' ') || rpad(nvl(c_awb.shpr_addr4, ' '), 106, ' ') || --2.2.25
--    rpad(nvl(c_awb.shpr_name,   'XXX'),   35,   ' ') ||
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
   (CASE
    WHEN LENGTH(rpad(nvl(c_awb.shpr_name,   'XXX'),   70,   ' ')) < 70 THEN
      rpad(nvl(c_awb.shpr_name,   'XXX'),   70,   ' ') || rpad(' ',   70 - LENGTH(rpad(nvl(c_awb.shpr_name,   'XXX'),   70,   ' ')),   ' ')
      else  rpad(nvl(c_awb.shpr_name,   'XXX'),   70,   ' ')
    END) ||
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
     rpad(' ',   60,   ' ') || --Exporter Chinese Name

--    s_awb_shpr_addr
    FUN_CONCAT_ACCS_ADDRESS_VALUE(nvl(s_awb_shpr_addr,   'XXX') || rpad(' ',265-lengthb(nvl(s_awb_shpr_addr,   'XXX')),' ')) ||

--  rpad(nvl(c_awb.shpr_addr,   'XXX'),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.shpr_addr,   'XXX'),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.shpr_addr,   'XXX'),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.shpr_addr,   'XXX'),   53,   ' ')),   ' ')
--    else rpad(nvl(c_awb.shpr_addr,   'XXX'),   53,   ' ')
--    END) ||

--     rpad(nvl(c_awb.shpr_addr2,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.shpr_addr2,   ' '),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.shpr_addr2,   ' '),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.shpr_addr2,   ' '),   53,   ' ')),   ' ')
--    else rpad(nvl(c_awb.shpr_addr2,   ' '),   53,   ' ')
--    END) ||

--     rpad(nvl(c_awb.shpr_addr3,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.shpr_addr3,   ' '),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.shpr_addr3,   ' '),   53,   ' ') ||   rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.shpr_addr3,   ' '),   53,   ' ')),   ' ')
--    else  rpad(nvl(c_awb.shpr_addr3,   ' '),   53,   ' ')
--    END) ||

--     rpad(nvl(c_awb.shpr_addr4,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.shpr_addr4,   ' '),   53,   ' ')) < 53 THEN
--     rpad(nvl(c_awb.shpr_addr4,   ' '),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.shpr_addr4,   ' '),   53,   ' ')),   ' ')
--     else  rpad(nvl(c_awb.shpr_addr4,   ' '),   53,   ' ')
--    END) ||

--     rpad(nvl(c_awb.shpr_addr4,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.shpr_addr3,   ' '),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.shpr_addr4,   ' '),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.shpr_addr3,   ' '),   53,   ' ')),   ' ')
--    else rpad(nvl(c_awb.shpr_addr4,   ' '),   53,   ' ')
--    END) ||


  s_shpt_typ ||                                                                                                                                                                          --2.2.26
  NVL(s_rel_ind, ' ') ||                                                                                                                                                                 --2.2.27
  rpad(NVL(v_shc, ' '), 18, ' ') ||                     --2.2.28
  rpad(NVL(SUBSTR(c_awb.awb_remarks, 1, 35), ' '), 35, ' ') ||                                                                                                                           --2.2.29
  rpad(NVL(c_awb.ref_carr, ' '), 2, ' ') ||                                                                                                                                              --2.2.30
  rpad(NVL(c_awb.ref_num, ' '), 7, ' ') ||                                                                                                                                               --2.2.31
  rpad(NVL(TO_CHAR(c_awb.ref_date, 'YYYYMMDD'), ' '), 8, ' ') ||                                                                                                                         --2.2.32
  --RPAD(NVL(C_AWB.ULD_KEY1||C_AWB.ULD_KEY2||
  -- C_AWB.ULD_KEY1||C_AWB.ULD_KEY2,' '),
  -- 44,' ')||
  s_uid ||                         --2.2.33
  s_lic_per ||                     --2.2.34
  NVL(s_cnsl_ind, 'N') ||          --2.2.35
  lpad(' ', 11, ' ') ||            --2.2.36
  CASE c_awb.hdlg_agent
  WHEN 'CPCT' THEN
    c_hdlg_agent
  ELSE
    nvl(c_awb.hdlg_agent,   c_hdlg_agent)
  END || --2.2.37
  (
    CASE s_int_amd
    WHEN 'BDS' THEN
      lpad(' ', 4, ' ') || s_shpt_typ || ' ' --LBS
    ELSE
      lpad(' ', 5, ' ')
    END); --INT AND AMD 2.2.38-39
  IF s_int_amd        = 'AMD' THEN
    IF c_awb.accs_ind = 'INT' THEN
      BEGIN
      if  v_flt_type ='E' then
        BEGIN
            SELECT COUNT(1)
              INTO v_cnt
              FROM exp_pmanifest_awb
              WHERE flt_key     = v_flt_key
              AND  flt_date    = v_flt_date
              AND  awb_no      = v_awb_no
              AND  pman_pcs     > 0;
        EXCEPTION
          WHEN no_data_found THEN
              SELECT COUNT(1)
              INTO v_cnt
              FROM exp_pman_tarmac_awb
              WHERE flt_key     = v_flt_key
              AND  flt_date    = v_flt_date
              AND  awb_no      = v_awb_no
              AND  nvl(bulk_pcs,0)+nvl(ppk_pcs,0) > 0;
          WHEN OTHERS THEN
            v_cnt := 1;
        END;
       else
        SELECT COUNT(1)
        INTO v_cnt
        FROM edi_ffm_msg a,
          edi_ffm_shp b
        WHERE a.tr_no     = b.tr_no
        AND a.ffm_status IN ('P', 'F')
        AND a.flt_key     = v_flt_key
        AND a.flt_date    = v_flt_date
        AND b.awb_no      = v_awb_no
        AND b.man_pcs     > 0;
      end if;
      EXCEPTION
      WHEN OTHERS THEN
        v_cnt := 1;
      END;
      IF NVL(v_cnt, 0) > 0 THEN
        s_cons_detail := 'U' || s_cons_detail;
        s_action_code := 'U';
      ELSE
        s_cons_detail := 'D' || s_cons_detail;
        s_action_code := 'D';
      END IF;
    ELSE
      s_cons_detail := 'A' || s_cons_detail;
      s_action_code := c_awb.change_ind;
    END IF;
  END IF;
  --MESSAGE VAILDATION START
  s_msg_length := LENGTHB(s_cons_detail);
DBMS_OUTPUT.PUT_LINE('s_msg_length...' || s_msg_length || '....' || cdetail);

-- s_cons_detail := s_cons_detail || rpad(' ',2500-lengthb(s_cons_detail),' ');
IF s_int_amd = 'INT' THEN
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401 - 1824 old --> new 1824 + 105 = 1929
  IF s_msg_length <> 1929 THEN
    s_cms3_error := 'INT - ' || c_awb.awb_no || c_awb_00009 || s_msg_length;
    RETURN FALSE;
  END IF;

  ELSIF s_int_amd = 'AMD' THEN
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401 - 1825 old --> new 1825 + 105 = 1930
    IF s_msg_length <> 1930 THEN
      s_cms3_error := 'AMD - ' || c_awb.awb_no || c_awb_00009 || s_msg_length;
      RETURN FALSE;
    END IF;

    ELSIF s_int_amd = 'BDS' THEN
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401 - 1828 old --> new 1828 + 105 = 1933
      IF s_msg_length <> 1933 THEN
        s_cms3_error := 'BDS - ' || c_awb.awb_no || c_awb_00009 || s_msg_length;
        RETURN FALSE;
      END IF;

    END IF;
  --MESSAGE VALIDATION END
  IF NOT insert_cst_csgnm(lpad('0', 18, '0'), cdetail) THEN
    s_cms3_error := 'CST_204';
    RETURN FALSE;
  END IF;
  --AWB EVENTS
  insert_awb_event(c_awb.man_pcs, c_awb.man_wgt);
  --UPDATE ACCS AWB INDICATOR
  RETURN update_accs_ind('CST_AWB');
END;
/************************************/
/*GET VERSION NUMBER
************************************/
FUNCTION get_ver_no
  RETURN BOOLEAN
IS
  n_ver_no NUMBER;
BEGIN
  --GET VERSION NUMBER

   BEGIN
      SELECT  stfs_flt_key,stfs_flt_date  INTO V_STFS_FLT_KEY,V_STFS_FLT_DATE from flt_opr
      where sch_date = v_flt_date and flt_key=v_flt_key and flt_type=DECODE(v_flt_type,'I','A','E','D',v_flt_type);
      --DECODE(flt_type,'I','A','E','D','T','S');
         EXCEPTION
              WHEN NO_DATA_FOUND THEN
                V_STFS_FLT_KEY:=NULL;
                V_STFS_FLT_DATE:=NULL;
   END;

  FOR c IN
  (SELECT ver_no,
          send_status,
          err_msg,
          nvl(length(err_msg),0) errLen
  FROM cst_subm c
  WHERE c.flt_type = v_flt_type
  AND c.flt_key    = NVL(V_STFS_FLT_KEY,v_flt_key)
  AND c.flt_date   = NVL(V_STFS_FLT_DATE,v_flt_date)
  AND c.rec_type   = s_int_amd
  ORDER BY ver_no DESC
  )
  LOOP
    IF c.send_status = 'E' THEN -- and (c.errLen > 8 OR c.errLen = 0 OR c.errLen = 7)  THEN
      DELETE
      FROM cst_csgnm
      WHERE flt_type    = v_flt_type
      AND flt_key       = NVL(V_STFS_FLT_KEY,v_flt_key)
      AND flt_date      = NVL(V_STFS_FLT_DATE,v_flt_date)
      AND recv_rec_type = s_int_amd
      AND ver_no        = c.ver_no;
      DELETE
      FROM cst_subm
      WHERE flt_type     = v_flt_type
      AND flt_key        = NVL(V_STFS_FLT_KEY,v_flt_key)
      AND flt_date       = NVL(V_STFS_FLT_DATE,v_flt_date)
      AND rec_type       = s_int_amd
      AND ver_no         = c.ver_no;
      N_VER_NO          := C.VER_NO;
    ELSIF c.send_status            IN ('P', 'W') THEN
      N_VER_NO          :=          -1;
    ELSIF c.send_status IN ('R', 'A') THEN -- OR (c.send_status = 'E' and c.errLen = 8)  THEN
      n_ver_no          := c.ver_no + 1;
    END IF;
    EXIT;
  END LOOP;
  IF n_ver_no = -1 THEN
    RETURN FALSE;
  END IF;
  IF NVL(n_ver_no, 0) = 0 THEN
    n_ver_no         := 1;
  END IF;
--  DBMS_OUTPUT.PUT_LINE('1- n_ver_no in INT PKG - n '|| n_ver_no);
--  s_version_no := lpad(n_ver_no, 2, '0');

  if s_version_no = '99' then
   SELECT NVL(MAX(ver_no), 1) + 1 into n_ver_no
   FROM cst_subm c
   WHERE c.flt_type = v_flt_type
    AND c.flt_key    = NVL(V_STFS_FLT_KEY,v_flt_key)
    AND c.flt_date   = NVL(V_STFS_FLT_DATE,v_flt_date)
    AND c.rec_type   = s_int_amd
    ORDER BY ver_no DESC;
    end if;

    s_version_no := lpad(n_ver_no, 2, '0');

--   DBMS_OUTPUT.PUT_LINE('1- s_version_no in INT PKG - n '|| s_version_no);
  RETURN TRUE;
END;
FUNCTION get_port(
    p_port OUT VARCHAR2)
  RETURN BOOLEAN
IS
BEGIN
  --GET FLIGHT PORT
  FOR c  IN
    (SELECT *
    FROM
      (SELECT brd_point
      FROM flt_opr_leg a
      WHERE a.flt_key = v_flt_key
      AND a.sch_date  = v_flt_date
      AND a.flt_type  = DECODE(v_flt_type,'I','A','E','D',v_flt_type)
      ORDER BY leg_ord desc
      )
    WHERE rownum <= 3
    )
  LOOP
    p_port := p_port || c.brd_point;
  END LOOP;
  IF p_port IS NULL THEN
    RETURN FALSE;
  END IF;
  p_port := rpad(p_port, 9, ' ');
  RETURN TRUE;
END;
/************************************/
/*GET HEADER INFORMATION:FLIGHT INFO,AWB INFO AND SO NO
************************************/
FUNCTION get_hdr_info_int
  RETURN BOOLEAN
IS
  s_port VARCHAR2(10);
BEGIN
  --GET FLIGHT PORT
  IF NOT get_port(s_port) THEN
    -- s_error_msg := v_flt_key || '/.' || to_char(v_flt_date, 'DDMONYY') ||
    --              c_flt_00002;
    --RETURN FALSE;
    NULL;
  END IF;
  s_port := rpad(s_port, 9, ' ');
  SELECT to_char(NVL(a.STFS_FLT_DATE,a.sch_date),   'YYYYMMDD'),
          to_char(NVL(a.STFS_FLT_DATE,a.sch_date),'YYYYMMDD') || --1.2.1
        rpad(FUN_CST_ACCS_TRANSITION(FUN_CST_FLT_KEY_SUBM(NVL(a.STFS_FLT_KEY,a.flt_key),NVL(a.STFS_FLT_DATE,a.sch_date),v_ver_no)),   9,   ' ') || --1.2.2 1.2.3
        s_version_no || --1.2.4
        c_hdlg_agent || --1.2.5
        lpad(nvl(to_char(a.sch_time),   '0'),   4,   '0') || --1.2.6
        rpad(nvl(to_char(a.est_date,   'YYYYMMDD'),   ' '),   8,   ' ') || --1.2.7
    (
    CASE
      WHEN TO_CHAR(a.est_time) IS NULL
      THEN lpad(' ', 4, ' ')
      ELSE lpad(TO_CHAR(a.est_time), 4, '0')
    END)
    || --1.2.8
    --lpad(nvl(to_char(a.est_time), ' '), 4, ' ') || --1.2.8
    s_port
    || --1.2.9,2.10.2.11
    NVL(TO_CHAR(a.prty_ind), ' ')
    ||                                                                      --1.2.12
    DECODE(a.cgo_acft_type, 'PSR', 'P', 'COM', 'M', 'OTH', 'O', 'FRE', 'F') --1.2.13
    ,CASE
      WHEN TO_CHAR(a.vessel_id) IS NULL
      THEN rpad(' ', 35, ' ')
      ELSE rpad(' ' || a.vessel_id,36,' ')
    END ||CASE
      WHEN TO_CHAR(a.vessel_name) IS NULL
      THEN rpad(' ', 105, ' ')
      ELSE rpad(a.vessel_name,105,' ')
    END ||CASE
      WHEN TO_CHAR(a.voyage_num) IS NULL
      THEN rpad(' ', 17, ' ')
      ELSE rpad(a.voyage_num,17,' ')
    END ||CASE
      WHEN TO_CHAR(a.call_sign_vessel) IS NULL
      THEN rpad(' ', 40, ' ')
      ELSE rpad(a.call_sign_vessel,40,' ')
    END ||CASE
      WHEN TO_CHAR(a.shipping_agent) IS NULL
      THEN rpad(' ', 150, ' ')
      ELSE rpad(a.shipping_agent,150,' ')
    END

  INTO s_schedule_date,
    s_cons_header,s_vessel_information
  FROM flt_opr a
  WHERE a.flt_key = v_flt_key
  AND a.sch_date  = v_flt_date
  AND flt_type    = DECODE(v_flt_type,'I','A','E','D','A',flt_type);
  s_cons_header  := s_cons_header || s_cargo_ind; --1.2.14
  RETURN TRUE;
EXCEPTION
WHEN no_data_found THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
WHEN OTHERS THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
END;
FUNCTION get_hdr_info_amd
  RETURN BOOLEAN
IS
  s_port VARCHAR2(100);
BEGIN
  --get port
  IF NOT get_port(s_port) THEN
    -- s_error_msg := v_flt_key || '/.' || to_char(v_flt_date, 'DDMONYY') ||
    --              c_flt_00002;
    --RETURN FALSE;
    NULL;
  END IF;
  s_port := rpad(s_port, 9, ' ');
  SELECT TO_CHAR(NVL(a.STFS_FLT_DATE,a.sch_date), 'YYYYMMDD'),
    TO_CHAR(NVL(a.STFS_FLT_DATE,a.sch_date), 'YYYYMMDD')
    || --1.2.1
    rpad(FUN_CST_ACCS_TRANSITION(FUN_CST_FLT_KEY_SUBM(NVL(a.STFS_FLT_KEY,a.flt_key),NVL(a.STFS_FLT_DATE,a.sch_date),v_ver_no)), 9, ' ')
    || --1.2.2 1.2.3
    s_version_no
    || --1.2.4
    rpad(NVL(TO_CHAR(a.est_date, 'YYYYMMDD'), ' '), 8, ' ')
    || --1.2.5
    (
    CASE
      WHEN TO_CHAR(a.est_time) IS NULL
      THEN lpad(' ', 4, ' ')
      ELSE lpad(TO_CHAR(a.est_time), 4, '0')
    END)
    || --1.2.6
    --lpad(nvl(to_char(a.est_time), ' '), 4, ' ') || --1.2.6
    s_port
    || --1.2.7-9
    NVL(TO_CHAR(a.prty_ind), ' ')
    ||                                                                      --1.2.10
    DECODE(a.cgo_acft_type, 'PSR', 'P', 'COM', 'M', 'OTH', 'O', 'FRE', 'F') --1.2.11
    ,CASE
      WHEN TO_CHAR(a.vessel_id) IS NULL
      THEN rpad(' ', 35, ' ')
      ELSE rpad(' ' || a.vessel_id,36,' ')
    END ||CASE
      WHEN TO_CHAR(a.vessel_name) IS NULL
      THEN rpad(' ', 105, ' ')
      ELSE rpad(a.vessel_name,105,' ')
    END ||CASE
      WHEN TO_CHAR(a.voyage_num) IS NULL
      THEN rpad(' ', 17, ' ')
      ELSE rpad(a.voyage_num,17,' ')
    END ||CASE
      WHEN TO_CHAR(a.call_sign_vessel) IS NULL
      THEN rpad(' ', 40, ' ')
      ELSE rpad(a.call_sign_vessel,40,' ')
    END ||CASE
      WHEN TO_CHAR(a.shipping_agent) IS NULL
      THEN rpad(' ', 150, ' ')
      ELSE rpad(a.shipping_agent,150,' ')
    END
  INTO s_schedule_date,
    s_cons_header,s_vessel_information
  FROM flt_opr a
  WHERE a.flt_key = v_flt_key
  AND a.sch_date  = v_flt_date
  AND flt_type    = DECODE(v_flt_type,'I','A','E','D','A');

--  s_cons_header := s_cons_header || rpad(' ',2500-lengthb(s_cons_header),' ');

  RETURN insert_cst_csgnm('', cheader);
EXCEPTION
WHEN no_data_found THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
WHEN OTHERS THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
END;
FUNCTION get_hdr_info_lbs
  RETURN BOOLEAN
IS
BEGIN
  --GET FLIGHT PORT
  SELECT to_char(NVL(a.STFS_FLT_DATE,a.sch_date),   'YYYYMMDD'),
          to_char(NVL(a.STFS_FLT_DATE,a.sch_date),   'YYYYMMDD') || --1.2.1
        rpad(FUN_CST_ACCS_TRANSITION(FUN_CST_FLT_KEY_SUBM(NVL(a.STFS_FLT_KEY,a.flt_key),NVL(a.STFS_FLT_DATE,a.sch_date),v_ver_no)),   9,   ' ') || --1.2.2 1.2.3
        s_version_no || --1.2.4
        c_hdlg_agent --1.2.5
        ,CASE
      WHEN TO_CHAR(a.vessel_id) IS NULL
      THEN rpad(' ', 35, ' ')
      ELSE rpad(' ' || a.vessel_id,36,' ')
    END ||CASE
      WHEN TO_CHAR(a.vessel_name) IS NULL
      THEN rpad(' ', 105, ' ')
      ELSE rpad(a.vessel_name,105,' ')
    END ||CASE
      WHEN TO_CHAR(a.voyage_num) IS NULL
      THEN rpad(' ', 17, ' ')
      ELSE rpad(a.voyage_num,17,' ')
    END ||CASE
      WHEN TO_CHAR(a.call_sign_vessel) IS NULL
      THEN rpad(' ', 40, ' ')
      ELSE rpad(a.call_sign_vessel,40,' ')
    END ||CASE
      WHEN TO_CHAR(a.shipping_agent) IS NULL
      THEN rpad(' ', 150, ' ')
      ELSE rpad(a.shipping_agent,150,' ')
    END
  INTO s_schedule_date,
    s_cons_header,s_vessel_information
  FROM flt_opr a
  WHERE a.flt_key = v_flt_key
                                                                                                                                                                                                                                                                                                            AND a.sch_date  = v_flt_date
  AND flt_type    =DECODE(v_flt_type,'I','A','E','D',v_flt_type);

--  s_cons_heade  r := s_cons_header || rpad(' ',2500-lengthb(s_cons_header),' ');

  RETURN insert_cst_csgnm('', cheader);
EXCEPTION
WHEN no_data_found THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
WHEN OTHERS THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
END;
/************************************/
/*GET THE AWB INFORMATION AND HOUSE AWB INFO AND
INSERT INTO TABLE
************************************/
FUNCTION get_hawb_info
  RETURN BOOLEAN
IS
  s_sql_str VARCHAR2(400);
  cur_hawb cursor_t;
  s_error BOOLEAN := FALSE;
  c_hawb cst_hawb%ROWTYPE;
  --s_hawb_no    VARCHAR2(20);
  s_msg_length NUMBER;
  v_count      NUMBER;
  v_chinese VARCHAR2(1);

BEGIN
  --IF SIMPLE SHIPMENT THERE IS NO HOUSE AIRWAY BILL
  IF s_cnsl_ind = 'N' THEN
    RETURN TRUE;
  END IF;
  --IF DELETE AWB IT NEED NOT SEND HOUSE AIRWAY BILL INFO
  IF s_action_code = 'D' AND s_int_amd = 'AMD' THEN
    RETURN TRUE;
  END IF;
  --GET THE SQL STRING
--  IF s_int_amd IN ('AMD', 'BDS') THEN
--    s_sql_str  := 'SELECT * FROM CST_HAWB WHERE AWB_NO = :V_AWB_NO AND AWB_DATE = :V_AWB_DATE AND HAWB_NO = NVL(:V_HAWB_NO,HAWB_NO)';
--    -- AND (ACCS_IND = ''N'' OR(ACCS_IND=''Y'' AND CHANGE_IND!=''A''))';
--  ELSE
--    s_sql_str := 'SELECT * FROM CST_HAWB WHERE AWB_NO = :V_AWB_NO AND AWB_DATE = :V_AWB_DATE AND HAWB_NO = NVL(:V_HAWB_NO,HAWB_NO)';
--  END IF;
IF s_int_amd IN ('AMD', 'BDS') THEN
     if v_flt_type ='E' then
   s_sql_str  := 'SELECT * FROM CST_HAWB WHERE AWB_NO = :V_AWB_NO AND AWB_DATE = :V_AWB_DATE AND HAWB_NO = NVL(:V_HAWB_NO,HAWB_NO) AND FLT_KEY=:v_flt_key AND FLT_DATE=:v_flt_date';
   ELSE
    s_sql_str  := 'SELECT * FROM CST_HAWB WHERE AWB_NO = :V_AWB_NO AND AWB_DATE = :V_AWB_DATE AND HAWB_NO = NVL(:V_HAWB_NO,HAWB_NO) AND NVL(FLT_TYPE,:v_dummy_flt_type) <> :v_dummy_exp_flt_type';
   END IF;
    -- AND (ACCS_IND = ''N'' OR(ACCS_IND=''Y'' AND CHANGE_IND!=''A''))';
  ELSE
     if v_flt_type ='E' then
       s_sql_str := 'SELECT * FROM CST_HAWB WHERE AWB_NO = :V_AWB_NO AND AWB_DATE = :V_AWB_DATE AND HAWB_NO = NVL(:V_HAWB_NO,HAWB_NO) AND FLT_KEY=:v_flt_key AND FLT_DATE=:v_flt_date';
     else
      s_sql_str := 'SELECT * FROM CST_HAWB WHERE AWB_NO = :V_AWB_NO AND AWB_DATE = :V_AWB_DATE AND HAWB_NO = NVL(:V_HAWB_NO,HAWB_NO) AND NVL(FLT_TYPE,:v_dummy_flt_type) <> :v_dummy_exp_flt_type';
     END IF;

  END IF;
  IF cur_hawb%ISOPEN THEN
    CLOSE cur_hawb;
  END IF;
  IF v_flt_type ='E' then
  OPEN cur_hawb FOR s_sql_str USING v_awb_no,
  v_awb_date,
  v_hawb_no,v_flt_key,v_flt_date;
  ELSE
    OPEN cur_hawb FOR s_sql_str USING v_awb_no,
  v_awb_date, v_hawb_no, v_dummy_flt_type , v_dummy_exp_flt_type;
  END IF ;
  LOOP
    FETCH cur_hawb INTO c_hawb;
    EXIT
  WHEN cur_hawb%NOTFOUND;
    s_cons_detail := '';
    --get handle agent start
    BEGIN
      SELECT hdlg_agent
      INTO c_hawb.hdlg_agent
      FROM cst_awb
      WHERE flt_type = v_flt_type
      AND flt_key    = v_flt_key
      AND flt_date   = v_flt_date
      AND awb_no     = v_awb_no
      AND rownum     = 1;
    EXCEPTION
    WHEN no_data_found THEN
      NULL;
    WHEN OTHERS THEN
      NULL;
    END;
    --get handle agent end
    /*
    IF get_isdhl(c_hawb.hdlg_agent) THEN
    s_shpt_typ := get_others_shpt_type(c_hawb.des);
    END IF;
    */
    BEGIN
      SELECT COUNT(1)
      INTO v_count
      FROM mast_handler_local_dest
      WHERE ect_handler = c_hawb.hdlg_agent;
    EXCEPTION
    WHEN no_data_found THEN
      v_count := 0;
    END;

    BEGIN
    if v_flt_type ='E' then
     v_chinese:='N';
    else
      SELECT nvl(CHINESE_CHAR_YN,'N')
        INTO v_chinese
      FROM edi_fhl_hawb h
      join edi_fhl a on a.tr_no = h.tr_no
      WHERE awb_no     = v_awb_no
      and awb_date = v_awb_date
      and hawb_no = c_hawb.hawb_no
      AND rownum     = 1;
    END IF;
    EXCEPTION
    WHEN no_data_found THEN
      NULL;
    WHEN OTHERS THEN
      NULL;
    END;

    IF v_awb_shpm_type is null THEN
      v_awb_shpm_type := pkg_cst.get_shpt_type(v_awb_no, v_awb_date, c_hawb.hdlg_agent, 'N');
    END IF;

    IF NVL(v_count, 0) = 0 or v_awb_shpm_type != 'M' THEN
      --s_shpt_typ := pkg_cst.get_shpt_type(v_awb_no, v_awb_date, c_hawb.hdlg_agent, 'N');
      s_shpt_typ := v_awb_shpm_type;
    ELSE
      s_shpt_typ := pkg_cst.get_hawb_shpt_type(c_hawb.hdlg_agent, c_hawb.des);
    END IF;
    --validation start
    --airway bill and house airway bill
    IF LENGTH(c_hawb.awb_no) <> 11 OR c_hawb.hawb_no IS NULL THEN
      -- s_cms3_error := c_hawb.awb_no || '/' || c_hawb.hawb_no ||
      --               c_awb_00002;
      --RETURN FALSE;
      NULL;
    END IF;
    IF instr(c_hawb.awb_no, ' ') > 0 THEN
      --s_cms3_error := c_hawb.awb_no || '/' || c_hawb.hawb_no ||
      --              c_awb_00014;
      --RETURN FALSE;
      NULL;
    END IF;
    --house airway bill origin and destination
    IF c_hawb.org IS NULL OR c_hawb.des IS NULL OR NVL(c_hawb.rtg_apt_code, s_ldg_point) IS NULL OR LENGTH(c_hawb.org) <> 3 OR LENGTH(c_hawb.des) <> 3 OR LENGTH(NVL(c_hawb.rtg_apt_code, s_ldg_point)) <> 3 THEN
      --s_cms3_error := c_hawb.awb_no || '/' || c_hawb.hawb_no ||
      --              c_awb_00003;
      --RETURN FALSE;
      NULL;
    END IF;
    --house airway bill piece and weight
    IF NVL(c_hawb.pcs, 0) = 0 OR NVL(c_hawb.wgt, 0) = 0 THEN
      --s_cms3_error := c_hawb.awb_no || '/' || c_hawb.hawb_no ||
      --              c_awb_00004;
      --RETURN FALSE;
      NULL;
    END IF;
    --house airway bill content
    IF NVL(c_hawb.content, s_content) IS NULL THEN
      --s_cms3_error := c_hawb.awb_no || '/' || c_hawb.hawb_no ||
      --              c_awb_00005;
      --RETURN FALSE;
      NULL;
    END IF;
    --house airway bill customs declare value
    IF NVL(c_hawb.cvd_chg_cust_val, 0) = 0 THEN
      c_hawb.cvd_chg_cust_ind         := 'NCV';
      c_hawb.cvd_iso_curr_code        := ' ';
    ELSE
      IF c_hawb.cvd_iso_curr_code IS NULL THEN
        --s_cms3_error := c_hawb.awb_no || '/' || c_hawb.hawb_no ||
        --              c_awb_00008;
        --RETURN FALSE;
        NULL;
      END IF;
      c_hawb.cvd_chg_cust_ind := NULL;
    END IF;
    --house airway bill consignee
    IF c_hawb.csgne_name IS NULL OR c_hawb.csgne_addr IS NULL THEN
      --s_cms3_error := c_hawb.awb_no || '/' || c_hawb.hawb_no ||
      --              c_awb_00006;
      --RETURN FALSE;
      NULL;
    END IF;
    --house airway bill shipper
    IF c_hawb.shpr_name IS NULL OR c_hawb.shpr_addr IS NULL THEN
      --s_cms3_error := c_hawb.awb_no || '/' || c_hawb.hawb_no ||
      --              c_awb_00007;
      --RETURN FALSE;
      NULL;
    END IF;

--
--CSGNE_PLACE                    VARCHAR2(17)
--CSGNE_CTRY_CODE                VARCHAR2(3)
--CSGNE_STATE_PROVINCE           VARCHAR2(9)
--CSGNE_PIN_CODE                 VARCHAR2(9)

  -- Country, State, City and Postal Code -- 15120201_CR_Additional address information to ACCS for MAWB and HAWB
  s_hawb_csgn_addr := null;

    if c_hawb.csgne_addr is not null
        or c_hawb.csgne_addr2 is not null
        or  c_hawb.csgne_addr3 is not null
        or c_hawb.csgne_addr4 is not null
        or c_hawb.csgne_addr5 is not null then
    s_hawb_csgn_addr := FUN_CONCAT_ADDR_WITHSPACE(c_hawb.csgne_addr , c_hawb.csgne_addr2 , c_hawb.csgne_addr3 , c_hawb.csgne_addr4 , c_hawb.csgne_addr5 , c_hawb.CSGNE_PLACE , c_hawb.CSGNE_STATE_PROVINCE , c_hawb.CSGNE_CTRY_CODE , c_hawb.CSGNE_PIN_CODE)  ;
    end if;

--  SHPR_PLACE                     VARCHAR2(17)
--SHPR_CTRY_CODE                 VARCHAR2(3)
--SHPR_STATE_PROVINCE            VARCHAR2(9)
--SHPR_PIN_CODE                  VARCHAR2(9)

   s_hawb_shpr_addr := null;

    if c_hawb.SHPR_addr is not null
        or c_hawb.SHPR_addr2 is not null
        or  c_hawb.SHPR_addr3 is not null
        or c_hawb.SHPR_addr4 is not null
        or c_hawb.SHPR_addr5 is not null then
    s_hawb_shpr_addr := FUN_CONCAT_ADDR_WITHSPACE(c_hawb.SHPR_addr , c_hawb.SHPR_addr2 , c_hawb.SHPR_addr3 , c_hawb.SHPR_addr4 , c_hawb.SHPR_addr5 , c_hawb.SHPR_PLACE , c_hawb.SHPR_STATE_PROVINCE , c_hawb.SHPR_CTRY_CODE , c_hawb.SHPR_PIN_CODE)  ;
    end if;

 --
--NOTIFY_PLACE                   VARCHAR2(17)
--NOTIFY_CTRY_CODE               VARCHAR2(3)
--NOTIFY_STATE_PROVINCE          VARCHAR2(9)
--NOTIFY_PIN_CODE                VARCHAR2(9)

  s_hawb_noti_addr := null;

    if c_hawb.NOTIFY_name is not null and
        (c_hawb.NOTIFY_addr is not null
        or c_hawb.NOTIFY_addr2 is not null
        or  c_hawb.NOTIFY_addr3 is not null
        or c_hawb.NOTIFY_addr4 is not null
        or c_hawb.NOTIFY_addr5 is not null) then
    s_hawb_noti_addr := FUN_CONCAT_ADDR_WITHSPACE(c_hawb.NOTIFY_addr , c_hawb.NOTIFY_addr2 , c_hawb.NOTIFY_addr3 , c_hawb.NOTIFY_addr4 , c_hawb.NOTIFY_addr5 , c_hawb.NOTIFY_PLACE ,  c_hawb.NOTIFY_STATE_PROVINCE , c_hawb.NOTIFY_CTRY_CODE , c_hawb.NOTIFY_PIN_CODE)  ;
    end if;

    if V_STFS_FLT_KEY IS NOT NULL then
       BEGIN
         SELECT instr(STRAGG(STRINGDELIM(rule_value,',')), substr(V_STFS_FLT_KEY,0,2)) into V_STFS_SOUTH_BND
          FROM cmsrules where rule_code = 'STFS_SB_DUMMY_FLIGHT';
      EXCEPTION
      WHEN no_data_found THEN
        V_STFS_SOUTH_BND := 0;
      END;

       if(V_STFS_SOUTH_BND > 0) then
         stfs_shpt_type := 'I';
       end if;
   end if;

    --validation end
    s_cons_detail := s_schedule_date || --2.2.1
    rpad(FUN_CST_ACCS_TRANSITION(FUN_CST_FLT_KEY_SUBM(NVL(V_STFS_FLT_KEY,v_flt_key),NVL(V_STFS_FLT_DATE,v_flt_date),v_ver_no)), 9, ' ') ||          --2.2.2-3
    s_version_no ||                     --2.2.4
    (
      CASE
      WHEN s_int_amd = 'BDS' THEN
        'BLB'
      ELSE
        ''
      END) ||                                                         --ONLY FOR LBS
    SUBSTR(c_hawb.awb_no, 1, 3) || '-' || SUBSTR(c_hawb.awb_no, 4) || --2.2.5
    rpad(c_hawb.hawb_no, 18, ' ') ||                                  --2.2.6
    c_hawb.org ||                                                     --2.2.7
        nvl(c_hawb.rtg_apt_code,   s_ldg_point) || --2.2.8
    c_hawb.des ||                                                     --2.2.9
    lpad(c_hawb.pcs, 6, '0') ||                                       --2.2.10
        lpad(TRIM(to_char(c_hawb.wgt,   '9999999.0')),   9,   '0') || --2.2.11
    lpad(c_hawb.pcs, 6, '0') ||                                       --2.2.12
        lpad(TRIM(to_char(c_hawb.wgt,   '9999999.0')),   9,   '0') || --2.2.13
        FUN_CONCAT_ACCS_ADDRESS_VALUE(nvl(c_hawb.content,   s_content) || rpad(' ',265-lengthb(nvl(c_hawb.content,   s_content)),' ')) || --2.2.14 Changed for new 175 to 265
    --RPAD(NVL(C_HAWB.CVD_ISO_CURR_CODE,' '),3,' ')|| --2.2.15
    (CASE
        WHEN nvl(c_hawb.cvd_chg_cust_val,   0) = 0 THEN rpad(' ',   3,   ' ')
        ELSE c_hawb.cvd_iso_curr_code
        END) ||(
      CASE
        WHEN nvl(c_hawb.cvd_chg_cust_val,   0) = 0 THEN rpad('NCV',   12,   ' ')
        ELSE lpad(c_hawb.cvd_chg_cust_val,   12,   '0')
      END) ||                                                                                                                                                                                  --2.2.16

--        rpad(c_hawb.csgne_name,   95,   ' ') || --2.2.17-18 Changed for new 75 to 95

/*        (CASE
--         when c_hawb.csgne_name is null then rpad(' ',   95,   ' ')
        WHEN lengthb(c_hawb.csgne_name || rpad(' ',95-lengthb(c_hawb.csgne_name),' ')) < 95 THEN
            c_hawb.csgne_name || rpad(' ',95-lengthb(c_hawb.csgne_name),' ') || rpad(' ', 95 - lengthb(c_hawb.csgne_name || rpad(' ',95-lengthb(c_hawb.csgne_name),' ')), ' ')
        else
            c_hawb.csgne_name || rpad(' ',95-lengthb(c_hawb.csgne_name),' ')
        END)
*/
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
        case when v_chinese = 'N' and length(c_hawb.csgne_name) = lengthb(c_hawb.csgne_name)then
          c_hawb.csgne_name || rpad(' ',130-lengthb(c_hawb.csgne_name),' ')
        else
          rpad('DUMMY', 70, ' ') ||
          c_hawb.csgne_name || rpad(' ',60-lengthb(c_hawb.csgne_name),' ')
        end ||
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
--         case when v_chinese = 'Y' and length(c_hawb.csgne_name) <> lengthb(c_hawb.csgne_name)then
--            rpad('DUMMY', 35, ' ') ||
--          c_hawb.csgne_name || rpad(' ',60-lengthb(c_hawb.csgne_name),' ')
--        default
--         c_hawb.csgne_name || rpad(' ',95-lengthb(c_hawb.csgne_name),' ')
--        end ||
--         rpad(nvl(c_hawb.csgne_addr,   ' '),   53,   ' ') ||

/*        (CASE
--        when c_hawb.csgne_addr is null then rpad(' ',   53,   ' ')
        WHEN lengthb(c_hawb.csgne_addr || rpad(' ',53-lengthb(c_hawb.csgne_addr),' ')) < 53 THEN
            c_hawb.csgne_addr || rpad(' ',53-lengthb(c_hawb.csgne_addr),' ') || rpad(' ', 53 - lengthb(c_hawb.csgne_addr || rpad(' ',53-lengthb(c_hawb.csgne_addr),' ')), ' ')
        else
            c_hawb.csgne_addr || rpad(' ',53-lengthb(c_hawb.csgne_addr),' ')
        END)
*/

--  s_hawb_csgn_addr
    FUN_CONCAT_ACCS_ADDRESS_VALUE(nvl(s_hawb_csgn_addr,   'XXX') || rpad(' ',265-lengthb(nvl(s_hawb_csgn_addr,   'XXX')),' ')) ||

--        CASE
--            WHEN c_hawb.csgne_addr IS NULL THEN  rpad(' ', 53, ' ')
--        ELSE
--            c_hawb.csgne_addr || rpad(' ',53-lengthb(c_hawb.csgne_addr),' ')
--        END ||

--      rpad(nvl(c_hawb.csgne_addr2,   ' '),   53,   ' ') ||

/*        (CASE
--        when c_hawb.csgne_addr2 is null then rpad(' ',   53,   ' ')
        WHEN lengthb(c_hawb.csgne_addr2 || rpad(' ',53-lengthb(c_hawb.csgne_addr2),' ')) < 53 THEN
            c_hawb.csgne_addr2 || rpad(' ',53-lengthb(c_hawb.csgne_addr2),' ') || rpad(' ', 53 - lengthb(c_hawb.csgne_addr2 || rpad(' ',53-lengthb(c_hawb.csgne_addr2),' ')), ' ')
        else
            c_hawb.csgne_addr2 || rpad(' ',53-lengthb(c_hawb.csgne_addr2),' ')
        END)
*/

--        CASE
--            WHEN c_hawb.csgne_addr2 IS NULL THEN  rpad(' ', 53, ' ')
--        ELSE
--            c_hawb.csgne_addr2 || rpad(' ',53-lengthb(c_hawb.csgne_addr2),' ')
--        END ||

--      rpad(nvl(c_hawb.csgne_addr3,   ' '),   53,   ' ') ||

/*        (CASE
--        when c_hawb.csgne_addr3 is null then rpad(' ',   53,   ' ')
        WHEN lengthb(c_hawb.csgne_addr3 || rpad(' ',53-lengthb(c_hawb.csgne_addr3),' ')) < 53 THEN
           c_hawb.csgne_addr3 || rpad(' ',53-lengthb(c_hawb.csgne_addr3),' ') || rpad(' ', 53 - lengthb(c_hawb.csgne_addr3 || rpad(' ',53-lengthb(c_hawb.csgne_addr3),' ')), ' ')
        else
            c_hawb.csgne_addr3 || rpad(' ',53-lengthb(c_hawb.csgne_addr3),' ')
        END)
*/
--        CASE
--            WHEN c_hawb.csgne_addr3 IS NULL THEN  rpad(' ', 53, ' ')
--        ELSE
--            c_hawb.csgne_addr3 || rpad(' ',53-lengthb(c_hawb.csgne_addr3),' ')
--        END ||

--      rpad(nvl(c_hawb.csgne_addr4,   ' '),   106,   ' ') ||

/*        (CASE
--        when c_hawb.csgne_addr4 is null then rpad(' ',   106,   ' ')
        WHEN lengthb(c_hawb.csgne_addr4 || rpad(' ',106-lengthb(c_hawb.csgne_addr4),' ')) < 106 THEN
            c_hawb.csgne_addr4 || rpad(' ',106-lengthb(c_hawb.csgne_addr4),' ') || rpad(' ', 106 - lengthb(c_hawb.csgne_addr4 || rpad(' ',106-lengthb(c_hawb.csgne_addr4),' ')), ' ')
        else
            c_hawb.csgne_addr4 || rpad(' ',106-lengthb(c_hawb.csgne_addr4),' ')
        END)
*/
--        CASE
--            WHEN c_hawb.csgne_addr4 IS NULL THEN  rpad(' ', 106, ' ')
--        ELSE
--            c_hawb.csgne_addr4 || rpad(' ',106-lengthb(c_hawb.csgne_addr4),' ')
--        END ||

--2.2.19 Changed for new 35 to 53
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
       case when c_hawb.notify_name is null and s_hawb_noti_addr is null then
        rpad(' ',   130,   ' ')
        else
          case when v_chinese = 'N' and length(c_hawb.notify_name) = lengthb(c_hawb.notify_name) then
            c_hawb.notify_name  || rpad(' ',130-lengthb(c_hawb.notify_name),' ')
          else
            rpad('DUMMY', 70, ' ') ||
            c_hawb.notify_name || rpad(' ',60-lengthb(c_hawb.notify_name),' ')
          end
        end || --2.2.23-24 Changed for new 75 to 95
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
--     rpad(' ',   60,   ' ') || --Notify Party Chinese Name

--    s_hawb_noti_addr
    case when c_hawb.notify_name is not null and s_hawb_noti_addr is not null then
    FUN_CONCAT_ACCS_ADDRESS_VALUE(nvl(s_hawb_noti_addr,   ' ') || rpad(' ',265-lengthb(nvl(s_hawb_noti_addr,   ' ')),' '))
    else
    rpad(' ',   265,   ' ')
    end || --Notify Party Address Name
--        lpad(' ',   395,   ' ') || --2.2.20-22
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
        case when v_chinese = 'N' and length(c_hawb.shpr_name) = lengthb(c_hawb.shpr_name) then
          c_hawb.shpr_name  || rpad(' ',130-lengthb(c_hawb.shpr_name),' ')
        else
          rpad('DUMMY', 70, ' ') ||
          c_hawb.shpr_name || rpad(' ',60-lengthb(c_hawb.shpr_name),' ')
        end || --2.29523-24 Changed for new 75 to 95
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
 --    s_hawb_shpr_addr
      FUN_CONCAT_ACCS_ADDRESS_VALUE(nvl(s_hawb_shpr_addr,   'XXX') || rpad(' ',265-lengthb(nvl(s_hawb_shpr_addr,   'XXX')),' ')) ||
--        CASE
--            WHEN c_hawb.shpr_addr IS NULL THEN  rpad(' ', 53, ' ')
--        ELSE
--            c_hawb.shpr_addr || rpad(' ',53-lengthb(c_hawb.shpr_addr),' ')
--        END ||
--
--        CASE
--            WHEN c_hawb.shpr_addr2 IS NULL THEN  rpad(' ', 53, ' ')
--        ELSE
--            c_hawb.shpr_addr2 || rpad(' ',53-lengthb(c_hawb.shpr_addr2),' ')
--        END ||
--
--        CASE
--            WHEN c_hawb.shpr_addr3 IS NULL THEN  rpad(' ', 53, ' ')
--        ELSE
--            c_hawb.shpr_addr3 || rpad(' ',53-lengthb(c_hawb.shpr_addr3),' ')
--        END ||
--
--        CASE
--            WHEN c_hawb.shpr_addr4 IS NULL THEN  rpad(' ', 106, ' ')
--        ELSE
--            c_hawb.shpr_addr4 || rpad(' ',106-lengthb(c_hawb.shpr_addr4),' ')
--        END ||

--        c_hawb.shpr_addr  || rpad(' ',53-lengthb(c_hawb.shpr_addr),' ') ||
--        c_hawb.shpr_addr2 || rpad(' ',53-lengthb(c_hawb.shpr_addr2),' ') ||
--        c_hawb.shpr_addr3 || rpad(' ',53-lengthb(c_hawb.shpr_addr3),' ') ||
--        c_hawb.shpr_addr4 || rpad(' ',106-lengthb(c_hawb.shpr_addr4),' ') ||


       -- rpad(nvl(c_hawb.shpr_name,   ' '),   95,   ' ')
        --rpad(nvl(c_hawb.shpr_addr,   ' '),   53,   ' ') ||
        --rpad(nvl(c_hawb.shpr_addr2,   ' '),   53,   ' ') ||
        --rpad(nvl(c_hawb.shpr_addr3,   ' '),   53,   ' ') ||
        --rpad(nvl(c_hawb.shpr_addr4,   ' '),   106,   ' ') || --2.2.25 Changed for new 35 to 53
    NVL(stfs_shpt_type,s_shpt_typ) ||                                                                                                                                                                              --2.2.26
    NVL(s_rel_ind, ' ') ||                                                                                                                                                                     --2.2.27
    rpad(NVL(c_hawb.sph_spl_code1 || c_hawb.sph_spl_code2 || c_hawb.sph_spl_code3 || c_hawb.sph_spl_code4 || c_hawb.sph_spl_code5 || c_hawb.sph_spl_code6, ' '), 18, ' ') ||                   --2.2.28
    rpad(NVL(SUBSTR(c_hawb.awb_remarks, 1, 35), ' '), 35, ' ') ||                                                                                                                              --2.2.29
    rpad(NVL(c_hawb.ref_carr, ' '), 2, ' ') ||                                                                                                                                                 --2.2.30
    rpad(NVL(c_hawb.ref_num, ' '), 7, ' ') ||                                                                                                                                                  --2.2.31
    rpad(NVL(TO_CHAR(c_hawb.ref_date, 'YYYYMMDD'), ' '), 8, ' ') ||                                                                                                                            --2.2.32
    rpad(NVL(c_hawb.uld_key1 || c_hawb.uld_key2 || c_hawb.uld_key1 || c_hawb.uld_key2, ' '), 44, ' ') ||                                                                                       --2.2.33
    s_lic_per ||                                                                                                                                                                               --2.2.34
    'N' ||                                                                                                                                                                                     --2.2.35
    lpad(' ', 11, ' ') ||                                                                                                                                                                      --2.2.36
        CASE c_hawb.hdlg_agent
      WHEN 'CPCT' THEN
        c_hdlg_agent
      ELSE
        nvl(c_hawb.hdlg_agent,   c_hdlg_agent)
      END || --2.2.37
    (
      CASE s_int_amd
    WHEN 'BDS' THEN lpad(' ',   4,   ' ') || NVL(stfs_shpt_type,v_awb_shpm_type) || ' ' --LBS
    ELSE lpad(' ',   5,   ' ')
    END);
    --INT AND AMD 2.2.38-39

    IF s_int_amd = 'AMD' THEN
      /*IF c_hawb.change_ind = 'A' AND c_hawb.accs_ind = 'INT' THEN
      s_cons_detail := 'U' || s_cons_detail;
      ELSE
      s_cons_detail := c_hawb.change_ind || s_cons_detail;
      END IF;*/
      IF c_hawb.change_ind = 'A' THEN
        BEGIN
          SELECT 1
          INTO v_cnt
          FROM cst_csgnm
          WHERE flt_type    = v_flt_type
          AND flt_key       = NVL(V_STFS_FLT_KEY,v_flt_key)
          AND flt_date      = NVL(V_STFS_FLT_DATE,v_flt_date)
          AND recv_rec_type = 'INT'
          AND ver_no        = s_int_ver_no
          AND awb_no        = v_awb_no
          AND hawb_no       = c_hawb.hawb_no
          AND rownum        = 1;
        EXCEPTION
        WHEN no_data_found THEN
          v_cnt := 0;
        WHEN OTHERS THEN
          v_cnt := 0;
        END;
        IF NVL(v_cnt, 0) > 0 THEN
          s_cons_detail := 'U' || s_cons_detail;
        ELSE
          s_cons_detail := 'A' || s_cons_detail;
        END IF;
      ELSE
        s_cons_detail := c_hawb.change_ind || s_cons_detail;
      END IF;
    END IF;
    --
    s_hawb_cnt := s_hawb_cnt + 1;
    --MESSAGE VAILDATION START
    s_msg_length := LENGTHB(s_cons_detail);

--    s_cons_detail := s_cons_detail || rpad(' ',2500-lengthb(s_cons_detail),' ');
    DBMS_OUTPUT.PUT_LINE('Check s_cons_detail -- s_cons_detail - '||s_cons_detail);

    IF s_int_amd = 'INT' THEN
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401  1824 + 105 = 1929
      IF s_msg_length <> 1929 THEN
        s_cms3_error := 'INT / ' || c_hawb.awb_no || '/' || c_hawb.hawb_no || c_awb_00009 || s_msg_length;
        RETURN FALSE;
      END IF;

      ELSIF s_int_amd = 'AMD' THEN
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401  1825 + 105 = 1930
        IF s_msg_length <> 1930 THEN
          s_cms3_error := 'AMD / ' || c_hawb.awb_no || '/' || c_hawb.hawb_no || c_awb_00009 || s_msg_length;
          RETURN FALSE;
        END IF;

        ELSIF s_int_amd = 'BDS' THEN
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401  1828 + 105 = 1933
          IF s_msg_length <> 1933 THEN
            s_cms3_error := 'BDS / ' || c_hawb.awb_no || '/' || c_hawb.hawb_no || c_awb_00009 || s_msg_length;
            RETURN FALSE;
          END IF;

        END IF;

    --MESSAGE VALIDATION END
    IF NOT insert_cst_csgnm(c_hawb.hawb_no, cdetail) THEN
      s_error := TRUE;
      EXIT;
    END IF;
  END LOOP;
  IF cur_hawb%ISOPEN THEN
    CLOSE cur_hawb;
  END IF;
  IF s_error THEN
    RETURN FALSE;
  END IF;
  --update house airway bill status
  RETURN update_accs_ind('CST_HAWB');
END;
/************************************/
/*GET THE FOOTER INFORMATION
************************************/
FUNCTION get_ftr_info
  RETURN BOOLEAN
IS

BEGIN

  BEGIN
   SELECT  stfs_flt_key,stfs_flt_date  INTO V_STFS_FLT_KEY,V_STFS_FLT_DATE from flt_opr
    where sch_date = v_flt_date and flt_key=v_flt_key and flt_type=DECODE(v_flt_type,'I','A','E','D',v_flt_type);
     EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_STFS_FLT_KEY:=NULL;
          V_STFS_FLT_DATE:=NULL;
  END;

  s_cons_footer := s_schedule_date || --3.2.1
  rpad(FUN_CST_ACCS_TRANSITION(FUN_CST_FLT_KEY_SUBM(NVL(V_STFS_FLT_KEY,v_flt_key),NVL(V_STFS_FLT_DATE,v_flt_date),v_ver_no)), 9, ' ') ||          --3.2.2-3
  s_version_no ||                     --3.2.4
  'C';                                --3.2.5

--   s_cons_footer := s_cons_footer || rpad(' ',2500-lengthb(s_cons_footer),' ');
  RETURN insert_cst_csgnm(' ', cfooter);
END;
/************************************/
/*GET THE FLIGHT NIL CARGO INDICATOR
************************************/
PROCEDURE get_flt_ind
IS
  v_nil_count NUMBER;
  v_nil_seg   NUMBER;
BEGIN
  s_cargo_ind := 'Y';
  IF v_flt_key = 'E' then

      BEGIN
            SELECT count(1) INTO v_nil_count
            FROM exp_pmanifest_awb pman
            WHERE pman.flt_key     = v_flt_key
                  AND pman.flt_date    = v_flt_date;
        EXCEPTION
          WHEN no_data_found THEN
              SELECT count(1) INTO v_nil_count
              FROM exp_pman_tarmac_awb pman
              WHERE pman.flt_key     = v_flt_key
                    AND pman.flt_date    = v_flt_date;
          WHEN OTHERS THEN
            v_nil_count := 0;
        END;


    IF NVL(v_nil_count, 0) = 0  THEN
      s_cargo_ind         := 'N';
    END IF;

  ELSE
  SELECT COUNT(c.awb_no),
    SUM(DECODE(b.nil_ind, 'Y', 1, 0))
  INTO v_nil_count,
    v_nil_seg
  FROM edi_ffm_msg a,
    edi_ffm_uld b,
    edi_ffm_shp c
  WHERE a.tr_no          = b.tr_no
  AND b.tr_no            = c.tr_no(+)
  AND b.doc_line_no      = c.udoc_line_no(+)
  AND a.flt_key          = v_flt_key
  AND a.flt_date         = v_flt_date
  AND a.ffm_status       = 'P';
  IF NVL(v_nil_count, 0) = 0 AND NVL(v_nil_seg, 0) > 0 THEN
    s_cargo_ind         := 'N';
  END IF;
  END IF;
END;
/************************************/
/*MAIN FUNCTION-INITIAL CONSIGNMENT SUBMISSION
************************************/
FUNCTION pro_awb_info
  RETURN BOOLEAN
IS
  l_man_wt  NUMBER;
  l_man_pcs NUMBER;
BEGIN

  DBMS_OUTPUT.PUT_LINE('start pro_awb_info v_awb_no '|| v_awb_no);
  l_man_wt  := 0;
  l_man_pcs := 0;
  s_uid     := '';
  --GET MANIFEST PIECES AND MANIFEST WEIGHT
  IF v_flt_type ='E' then
   BEGIN
    SELECT pman.pman_pcs,pman.pman_wt,
          'HKG' as brd_point,c.content as content
          INTO l_man_pcs,l_man_wt,s_ldg_point,s_content
          FROM exp_pmanifest_awb pman, exp_car c
          WHERE  c.awb_no=pman.awb_no
           and pman.flt_key     = v_flt_key
           AND pman.flt_date    = v_flt_date
           and  pman.awb_no      = v_awb_no;
      EXCEPTION
       WHEN no_data_found THEN
        SELECT sum(nvl(bulk_pcs,0)+nvl(ppk_pcs,0)) PMAN_PCS, sum(nvl(bulk_wt,0)+nvl(ppk_wt,0)) PMAN_WT,
			  'HKG' as brd_point,c.content as content
			  INTO l_man_pcs,l_man_wt,s_ldg_point,s_content
			  FROM exp_pman_tarmac_awb pman, exp_car c
			  WHERE  c.awb_no=pman.awb_no
			   and pman.flt_key     = v_flt_key
			   AND pman.flt_date    = v_flt_date
			   and  pman.awb_no      = v_awb_no group by flt_key,flt_date,pman.awb_no,'HKG',c.content;
    END;

  ELSE
  FOR cc IN
  (SELECT NVL(b.uld_key, ' ') uld_key,
    SUM(c.man_pcs) man_pcs,
    SUM(c.man_wt) man_wt,
    MAX(c.brd_point) brd_point,
    MAX(c.content) content
  FROM edi_ffm_msg a,
    edi_ffm_uld b,
    edi_ffm_shp c
  WHERE a.tr_no     = b.tr_no
  AND b.tr_no       = c.tr_no
  AND b.doc_line_no = c.udoc_line_no
  AND a.flt_key     = v_flt_key
  AND a.flt_date    = v_flt_date
  AND a.ffm_status IN ('P', 'F')
  AND c.awb_no      = v_awb_no
  GROUP BY b.uld_key
  )
  LOOP
    s_ldg_point     := cc.brd_point;
    s_content       := cc.content;
    l_man_wt        := l_man_wt  + cc.man_wt;
    l_man_pcs       := l_man_pcs + cc.man_pcs;
    IF LENGTH(s_uid) < 44 OR s_uid IS NULL THEN
      s_uid         := s_uid || lpad(cc.uld_key, 11, ' ');
    END IF;
  END LOOP;
  END IF;

  s_uid     := rpad(NVL(s_uid, ' '), 44, ' ');
  l_man_wt  := NVL(l_man_wt, 0);
  l_man_pcs := NVL(l_man_pcs, 0);
  s_man_wt  := lpad(TRIM(TO_CHAR(l_man_wt, '9999999.0')), 9, '0');
  s_man_pcs := lpad(l_man_pcs, 6, '0');
  --DEAL THE INFORMATIONS
  IF s_cargo_ind = 'Y' THEN
    IF NOT get_awb_info THEN
      RETURN FALSE;
    END IF;
    IF NOT get_hawb_info THEN
      RETURN FALSE;
    END IF;
  END IF;
  RETURN TRUE;
END;
FUNCTION submit_accs(
    p_flt_key  VARCHAR2,
    p_flt_date VARCHAR2,
    p_ver_no OUT NUMBER,
    p_flt_type  VARCHAR2)
  RETURN VARCHAR2
IS
  n_cnt    NUMBER;
  b_result BOOLEAN;
BEGIN
  init;
  s_cms3_error := NULL;
  v_flt_key    := p_flt_key;
  v_flt_type    := p_flt_type;
  v_flt_date   := to_date(p_flt_date, 'DDMONYY');
  v_ver_no := s_version_no;
  pro_awb_list;
  IF NOT get_ver_no THEN
    RETURN c_flt_00003;
  END IF;
  p_ver_no := s_version_no;
  --GET HEADER INFOMATION
  IF s_int_amd    = 'INT' THEN
    b_result     := get_hdr_info_int; --INITIAL CONSIGNMENT HEADER
  ELSIF s_int_amd = 'AMD' THEN
    b_result     := get_hdr_info_amd; --AMEND CONSIGNMENT HEADER
  ELSE
    b_result := get_hdr_info_lbs; --LEFT BEHIND CONSIGNMENT HEADER
  END IF;
  IF NOT b_result THEN
    --RETURN s_error_msg;
    NULL;
  END IF;
  --GET FOOTER INFOMATION
  IF NOT get_ftr_info THEN
    --RETURN 'CST_202';
    NULL;
  END IF;
  --
  IF s_int_amd = 'AMD' THEN
    BEGIN
--      SELECT NVL(MAX(ver_no), 1)
--      INTO s_int_ver_no
--      FROM cst_subm c, flt_opr f
--      WHERE c.rec_type = 'INT'
--      AND flt_type   = v_flt_type
--      AND flt_key    = NVL(v_flt_key)
--      AND flt_date   = v_flt_date;
SELECT NVL(MAX(ver_no), 1)
      INTO s_int_ver_no
      FROM cst_subm c, flt_opr f
      WHERE c.rec_type = 'INT'
		AND C.FLT_KEY  = NVL(F.STFS_FLT_KEY,F.FLT_KEY)
		AND C.FLT_DATE   = NVL(F.STFS_FLT_DATE,F.SCH_DATE)
		AND f.flt_type=DECODE(c.flt_type,'I','A','E','D','A')
		AND F.FLT_KEY    = v_flt_key
		AND F.SCH_DATE   = v_flt_date
		AND c.flt_type   =v_flt_type;
    EXCEPTION
    WHEN OTHERS THEN
      s_int_ver_no := 1;
    END;
  END IF;
  --
--   DBMS_OUTPUT.PUT_LINE('start submit_accs s_cargo_ind '|| s_cargo_ind);
  n_cnt         := t_awb.COUNT;
  IF s_cargo_ind = 'Y' THEN
    FOR i       IN 1 .. n_cnt
    LOOP
      v_awb_no    := t_awb(i).awb_no;
      v_hawb_no   := NULL;
      IF s_int_amd = 'AMD' THEN
        v_hawb_no := t_awb(i).hawb_no;
      END IF;
      s_cms3_error := NULL;
      IF NOT pro_awb_info THEN
        EXIT;
      END IF;
    END LOOP;
  END IF;
  IF s_cms3_error IS NOT NULL THEN
    RETURN s_cms3_error;
  END IF;
  IF s_int_amd     = 'INT' THEN
    s_cons_header := s_cons_header || lpad(s_simp_cnt + s_cnsl_cnt, 5, '0') || --1.2.15
    lpad(s_hawb_cnt, 5, '0') ||                                                --1.2.16
    lpad(s_simp_cnt, 5, '0') ||                                                --1.2.17
    lpad(s_cnsl_cnt, 5, '0') ||                                                --1.2.18
    lpad(s_hawb_cnt + s_simp_cnt + s_cnsl_cnt, 5, '0');                        --1.2.19;

--     s_cons_header := s_cons_header || rpad(' ',2500-lengthb(s_cons_header),' ');
    --INSERT HEADER
    IF NOT insert_cst_csgnm('', cheader) THEN
      RETURN s_cms3_error;
    END IF;
  END IF;
--  INSERT
--  INTO cst_auto_submit_log VALUES
--    (
--      'S_SIMP_CNT:'
--      || NVL(s_simp_cnt, 0)
--      || 'S_CNSL_CNT:'
--      || NVL(s_cnsl_cnt, 0)
--      || 'S_HAWB_CNT:'
--      || NVL(s_hawb_cnt, 0)
--    );
  RETURN 'TRUE';
EXCEPTION
WHEN OTHERS THEN
  s_error_msg := SUBSTR
  (
    SQLCODE || SQLERRM, 1, 100
  )
  ;
  RETURN s_error_msg;
END;
/**************************************************************/
/*SUBMIT INITIAL CONSIGNMENT
/**************************************************************/
FUNCTION initial_consignment_submission
  (
    p_flt_key  VARCHAR2,
    p_flt_date VARCHAR2,
    p_ver_no  IN OUT NUMBER,
    p_user_id IN VARCHAR2,
    p_lm_date IN DATE,
    P_FLT_TYPE IN VARCHAR2
  )
  RETURN VARCHAR2
IS
BEGIN
  s_int_amd := 'INT';
  s_user_id := p_user_id;
  s_lm_date := p_lm_date;
  RETURN submit_accs
  (
    p_flt_key, p_flt_date, p_ver_no,P_FLT_TYPE
  )
  ;
END;
/**************************************************************/
/*SUBMIT AMEND CONSIGNMENT
/**************************************************************/
FUNCTION amend_consignment_submission
  (
    p_flt_key  VARCHAR2,
    p_flt_date VARCHAR2,
    p_ver_no  IN OUT NUMBER,
    p_user_id IN VARCHAR2,
    p_lm_date IN DATE,
    P_FLT_TYPE IN VARCHAR2
  )
  RETURN VARCHAR2
IS
BEGIN
  s_int_amd := 'AMD';
  s_user_id := p_user_id;
  s_lm_date := p_lm_date;
  RETURN submit_accs
  (
    p_flt_key, p_flt_date, p_ver_no,P_FLT_TYPE
  )
  ;
END;
/**************************************************************/
/*SUBMIT AMEND CONSIGNMENT
/**************************************************************/
FUNCTION behind_consignment_submission
  (
    p_flt_key  VARCHAR2,
    p_flt_date VARCHAR2,
    p_ver_no  IN OUT NUMBER,
    p_user_id IN VARCHAR2,
    p_lm_date IN DATE,
    P_FLT_TYPE IN VARCHAR2
  )
  RETURN VARCHAR2
IS
BEGIN
  s_int_amd := 'BDS';
  s_user_id := p_user_id;
  s_lm_date := p_lm_date;
  RETURN submit_accs
  (
    p_flt_key, p_flt_date, p_ver_no,P_FLT_TYPE
  )
  ;
END;

/* START FOR CR - 16051801_CR_Customs Submission */
FUNCTION FUN_VALIDATE_AWB_SUBM
  (
    P_FLT_KEY IN VARCHAR2,
    P_FLT_DATE IN DATE,
    P_AWB_NO IN VARCHAR2,
    P_AWB_DATE IN DATE
  )
  RETURN VARCHAR2
IS
  V_RET_CODE  VARCHAR2(1) := 'F';
  V_AWB_TYPE  VARCHAR2(1) := '';
  V_CST_PC_CNT  VARCHAR2(1) := '';
BEGIN

 BEGIN
    SELECT AWB_TYPE INTO V_AWB_TYPE FROM AWB WHERE AWB_NO = P_AWB_NO AND AWB_DATE  = P_AWB_DATE ;
    IF V_AWB_TYPE <> 'I' THEN
           V_RET_CODE := 'T';
           RETURN(V_RET_CODE);
    END IF;

    IF V_AWB_TYPE = 'I' THEN
         SELECT DECODE(COUNT(1), 0,'F','T') INTO V_CST_PC_CNT FROM CST_AWB WHERE AWB_NO = P_AWB_NO AND AWB_DATE  = P_AWB_DATE AND NVL(PCS,0) > 0;
         IF V_CST_PC_CNT = 'F' THEN
           V_RET_CODE := 'F';
           RETURN(V_RET_CODE);
         END IF;
     END IF;

  END;

  SELECT 'T' INTO V_RET_CODE
  FROM (SELECT SUM(SHP_PCS) SHP_PCS, SUM(SHP_WT) SHP_WT, PCS, WT
      FROM
      (	SELECT B.FLT_KEY, B.FLT_DATE,
        CASE
        WHEN B.CIR_PCS_TYPE = 'SL' THEN SUM(NVL(B.RECD_PCS,0))
        WHEN B.CIR_PCS_TYPE = 'SP' AND (COUNT(C.FLT_KEY||C.FLT_DATE) > 0 OR (B.FLT_KEY = P_FLT_KEY AND B.FLT_DATE = P_FLT_DATE  )) THEN SUM(NVL(B.MANIFEST_PCS,0))
        WHEN B.CIR_PCS_TYPE IS NULL AND (COUNT(C.FLT_KEY||C.FLT_DATE) > 0 OR (B.FLT_KEY = P_FLT_KEY AND B.FLT_DATE = P_FLT_DATE )) THEN SUM(NVL(B.MANIFEST_PCS,0))
        ELSE 0
        END SHP_PCS,
        CASE
        WHEN B.CIR_WT_TYPE = 'SL' THEN SUM(NVL(B.RECD_WT,0))
        WHEN B.CIR_WT_TYPE = 'SP' AND (COUNT(C.FLT_KEY||C.FLT_DATE) > 0 OR (B.FLT_KEY = P_FLT_KEY AND B.FLT_DATE = P_FLT_DATE  )) THEN SUM(NVL(B.MANIFEST_WT,0))
        WHEN B.CIR_WT_TYPE IS NULL AND (COUNT(C.FLT_KEY||C.FLT_DATE) > 0 OR (B.FLT_KEY = P_FLT_KEY AND B.FLT_DATE = P_FLT_DATE )) THEN SUM(NVL(B.MANIFEST_WT,0))
        ELSE 0
        END SHP_WT,
        COUNT(C.FLT_KEY||C.FLT_DATE) FLT_CNT, PCS, WT
        FROM AWB A
        JOIN IMP_CAR_SHP B
        ON A.AWB_NO = B.AWB_NO
        AND A.AWB_DATE = B.AWB_DATE
        AND A.AWB_TYPE = 'I'
        AND A.AWB_NO = P_AWB_NO
        AND A.AWB_DATE  = P_AWB_DATE
        LEFT JOIN
        (SELECT DISTINCT S.FLT_KEY , S.FLT_DATE ,S.FLT_TYPE FROM CST_SUBM S
            WHERE EXISTS ( select NULL from cst_csgnm where flt_key = S.flt_key and flt_date = S.flt_date and ver_no = S.ver_no
                    and flt_type = S.flt_type and awb_no = P_AWB_NO and recv_rec_type = S.REC_TYPE )
            AND  ( S.SEND_STATUS NOT IN ('E','R') AND  NVL(FUN_CHECK_MAN(S.flt_type,S.flt_key,TO_CHAR(S.flt_date,'DDMONYY'),S.REC_TYPE),'X') != 'X')
        ) C ON C.FLT_KEY = B.FLT_KEY  AND C.FLT_DATE = B.FLT_DATE AND C.FLT_TYPE = 'I'
        WHERE (NOT EXISTS (SELECT NULL FROM V_CST_CC_CODE VCC_CODE
                    WHERE VCC_CODE.FLT_KEY = B.FLT_KEY
                    AND VCC_CODE.FLT_DATE = B.FLT_DATE
                    AND VCC_CODE.AWB_NO = B.AWB_NO
                    AND CC_CODE = 'ND')
				) OR (B.FLT_KEY = P_FLT_KEY AND B.FLT_DATE = P_FLT_DATE)
        GROUP BY B.CIR_PCS_TYPE,B.FLT_KEY, B.FLT_DATE, B.CIR_WT_TYPE, PCS, WT)
        GROUP BY  PCS, WT) T
  WHERE T.PCS >= T.SHP_PCS AND T.WT >= T.SHP_WT;

  RETURN(V_RET_CODE);
--	SELECT 'T' INTO V_RET_CODE
--	FROM (	SELECT B.FLT_KEY, B.FLT_DATE,
--			CASE
--			WHEN NVL(B.CIR_PCS_TYPE,'*') = 'SL' THEN SUM(NVL(B.RECD_PCS,0))
--			WHEN NVL(B.CIR_PCS_TYPE,'*') <> 'SL' AND (COUNT(C.FLT_KEY||C.FLT_DATE) > 0 OR (B.FLT_KEY = P_FLT_KEY AND B.FLT_DATE = P_FLT_DATE )) THEN SUM(NVL(B.MANIFEST_PCS,0))
--			ELSE 0
--			END SHP_PCS,
--			CASE
--			WHEN NVL(B.CIR_WT_TYPE,'*') = 'SL' THEN SUM(NVL(B.RECD_WT,0))
--			WHEN NVL(B.CIR_WT_TYPE,'*') <> 'SL' AND (COUNT(C.FLT_KEY||C.FLT_DATE) > 0 OR (B.FLT_KEY = P_FLT_KEY AND B.FLT_DATE = P_FLT_DATE )) THEN SUM(NVL(B.MANIFEST_WT,0))
--			ELSE 0
--			END SHP_WT,
--      CASE
--			WHEN NVL(B.CIR_PCS_TYPE,'*') = 'SL' THEN (SELECT SUM(NVL(RECD_PCS,0)) FROM IMP_CAR_SHP WHERE AWB_NO = P_AWB_NO AND AWB_DATE  = P_AWB_DATE)
--			WHEN NVL(B.CIR_PCS_TYPE,'*') <> 'SL' AND (COUNT(C.FLT_KEY||C.FLT_DATE) > 0 OR (B.FLT_KEY = P_FLT_KEY AND B.FLT_DATE = P_FLT_DATE )) THEN
--      (SELECT SUM(NVL(MANIFEST_PCS,0)) FROM IMP_CAR_SHP WHERE AWB_NO = P_AWB_NO AND AWB_DATE  = P_AWB_DATE )  ELSE 0
--			END SHP_PCS,
--			CASE
--			WHEN NVL(B.CIR_WT_TYPE,'*') = 'SL' THEN (SELECT SUM(NVL(RECD_WT,0)) FROM IMP_CAR_SHP WHERE AWB_NO = P_AWB_NO AND AWB_DATE  = P_AWB_DATE)
--			WHEN NVL(B.CIR_WT_TYPE,'*') <> 'SL' AND (COUNT(C.FLT_KEY||C.FLT_DATE) > 0 OR (B.FLT_KEY = P_FLT_KEY AND B.FLT_DATE = P_FLT_DATE )) THEN
--        (SELECT SUM(NVL(B.MANIFEST_WT,0)) FROM IMP_CAR_SHP WHERE AWB_NO = P_AWB_NO AND AWB_DATE  = P_AWB_DATE)
--			ELSE 0
--			END SHP_WT,
--			COUNT(C.FLT_KEY||C.FLT_DATE) FLT_CNT,
--			(SELECT PCS FROM AWB WHERE AWB_NO = P_AWB_NO AND AWB_DATE  = P_AWB_DATE AND AWB_TYPE = 'I') AWB_PCS,
--			(SELECT WT FROM AWB WHERE AWB_NO = P_AWB_NO AND AWB_DATE  = P_AWB_DATE AND AWB_TYPE = 'I') AWB_WT
--	FROM AWB A
--	JOIN IMP_CAR_SHP B
--	ON A.AWB_NO = B.AWB_NO
--	AND A.AWB_DATE = B.AWB_DATE
--	AND A.AWB_TYPE = 'I'
--	AND A.AWB_NO = P_AWB_NO
--	AND A.AWB_DATE  = P_AWB_DATE
--	LEFT JOIN CST_SUBM C
--	ON C.FLT_KEY = B.FLT_KEY
--	AND C.FLT_DATE = B.FLT_DATE
--	AND C.SEND_STATUS NOT IN ('E','R')
--	AND C.FLT_KEY <> P_FLT_KEY
--	AND C.FLT_DATE <> P_FLT_DATE
--	AND NOT EXISTS (SELECT NULL FROM V_CST_CC_CODE VCC_CODE
--                  WHERE VCC_CODE.FLT_KEY = B.FLT_KEY
--                  AND VCC_CODE.FLT_DATE = B.FLT_DATE
--                  AND VCC_CODE.AWB_NO = B.AWB_NO
--                  AND CC_CODE = 'ND'
--                  AND RECV_DATE > C.SUBM_DATE) GROUP BY B.CIR_PCS_TYPE,B.FLT_KEY, B.FLT_DATE, B.CIR_WT_TYPE) T
--	WHERE T.AWB_PCS >= T.SHP_PCS AND T.AWB_WT >= T.SHP_WT
--  AND T.FLT_KEY = P_FLT_KEY AND T.FLT_DATE = P_FLT_DATE;
--	RETURN(V_RET_CODE);
EXCEPTION
	WHEN OTHERS THEN
      V_RET_CODE := 'F';
      RETURN(V_RET_CODE);
END;
/* END FOR CR - 16051801_CR_Customs Submission */


END pkg_cst_init;
/
SHOW ERRORS