--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PROCEDURE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT Creating WOSINT.SP_ARCHIVAL_AWB_NOTCLS
CREATE OR REPLACE PROCEDURE WOSINT.SP_ARCHIVAL_AWB_NOTCLS
AS
  AWB_INV_YN     VARCHAR2(4);
  AWB_FLT_EXISTS VARCHAR2(4);
  FLT_COUNT      NUMBER;
  C_FLT_KEY      VARCHAR2(50);
  C_FLT_DATE     VARCHAR2(50);
  C_FLT_TYPE     VARCHAR2(50);
  CURSOR FLTCURSOR
  IS
    SELECT OPR.FLT_KEY,
      TO_CHAR(OPR.SCH_DATE,'DDMONYY') SCH_DATE,
      OPR.FLT_TYPE,
      EVT.FLT_CLS_DATE
    FROM FLT_OPR OPR,
      FLT_OPR_EVENTS EVT
    WHERE OPR.TR_NO    = EVT.TR_NO
    AND EVT.FLT_CLS_YN = 'Y'
    AND TRUNC(EVT.FLT_CLS_DATE) BETWEEN '01JUN13' AND '30JUN13'
    AND NVL(OPR.STATUS,'**')<> 'X'
    ORDER BY SCH_DATE,
      OPR.FLT_KEY;
  CURSOR AWBEXPCLOSEDYN(P_FLT_KEY VARCHAR2,P_SCH_DATE VARCHAR2 )
  IS
    SELECT a.AWB_No,
      b.awb_closed_yn,
      A.AWB_DATE AWB_DATE,
      B.AWB_TYPE,
      B.CR_DATE CR_DATE
    FROM
      (SELECT *
      FROM (
        (SELECT AWB_NO,
          TO_CHAR(AWB_DATE,'DDMONYY') AWB_DATE
        FROM EXP_PMANIFEST_AWB
        WHERE FLT_KEY      =P_FLT_KEY
        AND TRUNC(FLT_DATE)=TO_DATE(P_SCH_DATE,'DDMONYY')
        )
    UNION
      (SELECT AWB_NO,
        TO_CHAR(AWB_DATE,'DDMONYY') AWB_DATE
      FROM EXP_PMAN_TARMAC_AWB
      WHERE FLT_KEY      =P_FLT_KEY
      AND TRUNC(FLT_DATE)=TO_DATE(P_SCH_DATE,'DDMONYY')
      )
    UNION
      (SELECT AWB_NO,
        TO_CHAR(AWB_DATE,'DDMONYY') AWB_DATE
      FROM EXP_PMAN_TARMAC_ULD_AWB
      WHERE FLT_KEY      =P_FLT_KEY
      AND TRUNC(FLT_DATE)=TO_DATE(P_SCH_DATE,'DDMONYY')
      )
    UNION
      (SELECT DISTINCT AWB_NO,
        TO_CHAR(AWB_DATE,'DDMONYY') AWB_DATE
      FROM TRN_FBL A,
        TRN_FBL_SHP B
      WHERE A.TR_NO=B.TR_NO
      AND A.FLT_KEY
        ||
        (SELECT TRN_FLT_SUFFIX FROM SYS_PARAM WHERE ROWNUM=1
        )                  =P_FLT_KEY
      AND TRUNC(A.FLT_DATE)=TO_DATE(P_SCH_DATE,'DDMONYY')
      AND A.FBL_STATUS     ='P'
      ) )
      ) A,
      AWB B
    WHERE A.AWB_NO                   =B.AWB_NO
    AND TO_DATE(A.AWB_DATE,'DDMONYY')=TRUNC(B.AWB_DATE)
    AND B.AWB_CLOSED_YN              ='N'
      --        AND NOT EXISTS (SELECT 1 FROM AWB_INVENTORY C
      --        WHERE A.AWB_NO=C.AWB_NO AND A.AWB_DATE=C.AWB_DATE)
      ;
    CURSOR AWBIMPCLOSEDYN(P_FLT_KEY VARCHAR2,P_SCH_DATE VARCHAR2 )
    IS
      SELECT A.AWB_NO,
        B.AWB_CLOSED_YN,
        A.AWB_DATE,
        B.AWB_TYPE,
        B.CR_DATE CR_DATE
      FROM
        (SELECT *
        FROM (
          (SELECT AWB_NO,
            TO_CHAR(AWB_DATE,'DDMONYY') AWB_DATE
          FROM IMP_CAR_SHP
          WHERE FLT_KEY      =P_FLT_KEY
          AND TRUNC(FLT_DATE)=TO_DATE(P_SCH_DATE,'DDMONYY')
          )
      UNION
        (SELECT DISTINCT AWB_NO,
          TO_CHAR(AWB_DATE,'DDMONYY') AWB_DATE
        FROM TRN_FFM_MSG A,
          TRN_FFM_SHP B
        WHERE A.TR_NO=B.TR_NO
        AND A.FLT_KEY
          ||
          (SELECT TRN_FLT_SUFFIX FROM SYS_PARAM WHERE ROWNUM=1
          )                  =P_FLT_KEY
        AND TRUNC(A.FLT_DATE)=TO_DATE(P_SCH_DATE,'DDMONYY')
        AND A.FFM_STATUS     ='P'
        ) )
        ) A,
        AWB B
      WHERE A.AWB_NO                   =B.AWB_NO
      AND TO_DATE(A.AWB_DATE,'DDMONYY')=TRUNC(B.AWB_DATE)
      AND B.AWB_CLOSED_YN              ='N'
        --        AND NOT EXISTS (SELECT 1 FROM AWB_INVENTORY C
        --        WHERE A.AWB_NO=C.AWB_NO AND A.AWB_DATE=C.AWB_DATE)
        ;
    BEGIN
      --DELETE DATA FOR TABLE
     -- DELETE FROM ARCHIVE_AWB_NOT_CLOSED;
      DEBUG_OBJ_ARCH('**************PROCEDURE SP_FLT_AWB STARTS*****************');
      FOR FC IN FLTCURSOR
      LOOP
        -- DEBUG_OBJ_ARCH('FLIGTH CURSOR : '||FC.FLT_KEY||' ' ||TO_DATE(FC.SCH_DATE,'DDMONYY'));
        IF(FC.FLT_TYPE='D') THEN
          --DEBUG_OBJ_ARCH('FLT TYPE : '||FC.FLT_TYPE);
          FOR AWBYN IN AWBEXPCLOSEDYN(FC.FLT_KEY,FC.SCH_DATE)
          LOOP
            FLT_COUNT       :=0;
            AWB_FLT_EXISTS  :='N';
            IF(AWBYN.AWB_TYPE='I') THEN
              SELECT COUNT(1)
              INTO FLT_COUNT
              FROM
                (SELECT ICS.FLT_KEY ,
                  TO_CHAR (ICS.FLT_DATE, 'DDMONYY') ,
                  ICS.FLT_TYPE
                FROM IMP_CAR_SHP ICS
                LEFT JOIN
                  (SELECT SF.AWB_NO,
                    SF.AWB_DATE,
                    SF.ORIG_FLT_KEY,
                    SF.ORIG_FLT_DATE,
                    SUM(SR.SRF_PCS) SRFPCS,
                    SUM(SR.SRF_WT) SRFWT,
                    SUM(SF.DLV_PCS) RELPCS,
                    SUM(DLV_WT) RELWT
                  FROM IMP_SRF SR
                  JOIN IMP_SRF_FLT SF
                  ON SR.SRF_NO         = SF.SRF_NO
                  WHERE ((SR.STATUS    ='ISSUED'
                  AND SR.SRF_EXPY_DATE > SYSDATE)
                  OR (SR.STATUS        ='POSTED'
                  OR SR.SRF_NO        IN
                    (SELECT SRF_NO FROM IMP_CDIF WHERE VOID_DATE IS NULL
                    )))
                  GROUP BY SF.AWB_NO,
                    SF.AWB_DATE,
                    SF.ORIG_FLT_KEY,
                    SF.ORIG_FLT_DATE
                  ) ISRF ON ICS.AWB_NO = ISRF.AWB_NO
                AND ICS.AWB_DATE       = ISRF.AWB_DATE
                AND ICS.FLT_KEY        = ISRF.ORIG_FLT_KEY
                AND ICS.FLT_DATE       = ISRF.ORIG_FLT_DATE
                LEFT JOIN V_CST_IMP_CC_CODE_AWB VCCODE
                ON VCCODE.FLT_KEY  =ICS.FLT_KEY
                AND VCCODE.FLT_DATE=ICS.FLT_DATE
                AND VCCODE.AWB_NO  =ICS.AWB_NO
                AND VCCODE.HAWB_NO ='000000000000000000'
                WHERE ICS.AWB_NO   = AWBYN.AWB_NO
                AND ICS.AWB_DATE   = TO_DATE(AWBYN.AWB_DATE,'DDMONYY')
                ORDER BY ICS.AWB_DATE
                );
              IF(FLT_COUNT     =0) THEN
                AWB_FLT_EXISTS:='N';
              ELSE
                AWB_FLT_EXISTS:='Y';
              END IF;
            ELSIF(AWBYN.AWB_TYPE='E') THEN
              SELECT COUNT(1)
              INTO FLT_COUNT
              FROM
                (SELECT EPA.FLT_KEY                 AS fltNo,
                  TO_CHAR (EPA.FLT_DATE, 'DDMONYY') AS FLTDATE,
                  EPA.FLT_TYPE                      AS fltType,
                  ''                                AS fblFltNo,
                  ''                                AS fblFltDate
                FROM
                  (SELECT flt_key,
                    flt_date,
                    flt_type,
                    awb_no,
                    awb_date,
                    SUM(manf_pc) manf_pc,
                    SUM(manf_wt) manf_wt,
                    SUM(bup_pc) bup_pc ,
                    SUM(bup_wt) bup_wt,
                    SUM(bulk_pc) bulk_pc,
                    SUM(bulk_wt) bulk_wt,
                    SUM(ppk_pc) ppk_pc,
                    SUM(ppk_wt) ppk_wt
                  FROM
                    (SELECT flt_key flt_key,
                      flt_date flt_date,
                      flt_type flt_type,
                      awb_no awb_no,
                      awb_date awb_date,
                      SUM(NVL(pman_pcs,0)) manf_pc,
                      SUM(NVL(pman_wt,0)) manf_wt,
                      SUM(NVL(BULK_PCS,0)) bulk_pc,
                      SUM(NVL(BULK_WT,0)) bulk_wt,
                      SUM( NVL(PPK_PCS,0)+NVL(MIX_PCS,0)) ppk_pc,
                      SUM( NVL(PPK_WT,0) +NVL(MIX_WT,0)) ppk_wt,
                      SUM( NVL(PPK_PCS,0)+NVL(MIX_PCS,0)+NVL(ASSIGNED_BULK_PCS,0)) bup_pc,
                      SUM( NVL(PPK_WT,0) +NVL(MIX_WT,0)+NVL(ASSIGNED_BULK_WT,0) )bup_wt
                    FROM exp_pmanifest_awb
                    GROUP BY flt_key,
                      flt_date,
                      awb_no,
                      awb_date,
                      flt_type
                    UNION
                    SELECT flt_key flt_key,
                      flt_date flt_date,
                      'E' flt_type,
                      awb_no awb_no,
                      awb_date awb_date,
                      SUM(NVL(bulk_pcs,0)+NVL(ppk_pcs,0)) manf_pc,
                      SUM(NVL(bulk_wt,0) +NVL(ppk_wt,0)) manf_wt,
                      SUM(NVL(bulk_pcs,0)) bulk_pc,
                      SUM(NVL(bulk_wt,0)) bulk_wt,
                      SUM(NVL(ppk_pcs,0)) ppk_pc,
                      SUM(NVL(ppk_wt,0)) ppk_wt,
                      SUM(NVL(bulk_pcs,0)+NVL(ppk_pcs,0)) bup_pc,
                      SUM(NVL(bulk_wt,0) +NVL(ppk_wt,0)) bup_wt
                    FROM EXP_PMAN_TARMAC_AWB
                    GROUP BY flt_key,
                      awb_no,
                      awb_date,
                      flt_date
                    )
                  GROUP BY flt_key,
                    flt_date,
                    awb_no,
                    awb_date,
                    flt_type
                  ) EPA
                WHERE EPA.AWB_NO = AWBYN.AWB_NO
                AND EPA.AWB_DATE = AWBYN.AWB_DATE
                UNION
                SELECT '',
                  '',
                  '',
                  fbl.flt_key                        AS fblFltNo,
                  TO_CHAR ( fbl.flt_date, 'DDMONYY') AS fblFltDate
                FROM edi_fbl_shp shp,
                  edi_fbl fbl
                WHERE shp.tr_no    = fbl.tr_no
                AND fbl.FBL_STATUS = 'P'
                AND shp.AWB_NO     = AWBYN.AWB_NO
                AND shp.AWB_DATE   = AWBYN.AWB_DATE
                AND NOT EXISTS
                  (SELECT NULL
                  FROM exp_pmanifest_awb
                  WHERE awb_no=AWBYN.AWB_NO
                  AND awb_date=AWBYN.AWB_DATE
                  AND FLT_KEY =fbl.flt_key
                  AND FLT_DATE=fbl.flt_date
                  )
                GROUP BY fbl.flt_key,
                  fbl.flt_date,
                  fbl.carr_code
                UNION
                SELECT '',
                  '',
                  '',
                  OFAWB.flt_key                        AS fblFltNo,
                  TO_CHAR ( OFAWB.flt_date, 'DDMONYY') AS fblFltDate
                FROM EXP_OFFLOAD_ULD_AWB OFAWB
                WHERE OFAWB.AWB_NO    = AWBYN.AWB_NO
                AND OFAWB.AWB_DATE    = AWBYN.AWB_DATE
                AND OFAWB.CONFIRMED_YN='Y'
                AND NOT EXISTS
                  (SELECT NULL
                  FROM exp_pmanifest_awb
                  WHERE awb_no=AWBYN.AWB_NO
                  AND awb_date=AWBYN.AWB_DATE
                  AND FLT_KEY =OFAWB.flt_key
                  AND FLT_DATE=OFAWB.flt_date
                  )
                AND NOT EXISTS
                  (SELECT NULL
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.awb_no   = AWBYN.AWB_NO
                  AND shp.awb_date   =AWBYN.AWB_DATE
                  AND fbl.flt_key    =OFAWB.flt_key
                  AND fbl.flt_date   =OFAWB.flt_date
                  AND SHP.TR_NO      = FBL.TR_NO
                  AND FBL.FBL_STATUS = 'P'
                  )
                AND NOT EXISTS
                  (SELECT NULL
                  FROM EXP_PMAN_TARMAC_AWB
                  WHERE AWB_NO=AWBYN.AWB_NO
                  AND AWB_DATE=AWBYN.AWB_DATE
                  AND FLT_KEY =OFAWB.FLT_KEY
                  AND FLT_DATE=OFAWB.FLT_DATE
                  )
                UNION
                SELECT EOUA.FLT_KEY                  AS fltNo,
                  TO_CHAR (EOUA.FLT_DATE, 'DDMONYY') AS FLTDATE,
                  'E'                                AS fltType,
                  ''                                 AS fblFltNo,
                  ''                                 AS fblFltDate
                FROM EXP_OFFLOAD_ULD_AWB EOUA
                WHERE EOUA.AWB_NO = AWBYN.AWB_NO
                AND EOUA.AWB_DATE = AWBYN.AWB_DATE
                AND CONFIRMED_YN  = 'Y'
                AND NOT EXISTS
                  (SELECT NULL
                  FROM exp_pmanifest_awb
                  WHERE awb_no=AWBYN.AWB_NO
                  AND awb_date=AWBYN.AWB_DATE
                  UNION
                  SELECT NULL
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.tr_no    = fbl.tr_no
                  AND fbl.FBL_STATUS = 'P'
                  AND shp.AWB_NO     = AWBYN.AWB_NO
                  AND SHP.AWB_DATE   =AWBYN.AWB_DATE
                  )
                GROUP BY EOUA.FLT_KEY,
                  EOUA.FLT_DATE
                );
              IF(FLT_COUNT     =0) THEN
                AWB_FLT_EXISTS:='N';
              ELSE
                AWB_FLT_EXISTS:='Y';
              END IF;
            ELSIF(AWBYN.AWB_TYPE='T') THEN
              SELECT COUNT(1)
              INTO FLT_COUNT
              FROM
                (SELECT ICS.FLT_KEY                 AS fltNo,
                  TO_CHAR (ICS.FLT_DATE, 'DDMONYY') AS fltDate,
                  ICS.FLT_TYPE                      AS fltType,
                  ''                                AS fblFltNo,
                  ''                                AS fblFltDate
                FROM IMP_CAR_SHP ICS
                LEFT JOIN
                  (SELECT SF.AWB_NO,
                    SF.AWB_DATE,
                    SF.ORIG_FLT_KEY,
                    SF.ORIG_FLT_DATE,
                    SUM(SR.SRF_PCS) SRFPCS,
                    SUM(SR.SRF_WT) SRFWT,
                    SUM(SF.DLV_PCS) RELPCS,
                    SUM(DLV_WT) RELWT
                  FROM IMP_SRF SR
                  JOIN IMP_SRF_FLT SF
                  ON SR.SRF_NO         = SF.SRF_NO
                  WHERE ((SR.STATUS    ='ISSUED'
                  AND SR.SRF_EXPY_DATE > SYSDATE)
                  OR (SR.STATUS        ='POSTED'
                  OR SR.SRF_NO        IN
                    (SELECT SRF_NO FROM IMP_CDIF WHERE VOID_DATE IS NULL
                    )))
                  GROUP BY SF.AWB_NO,
                    SF.AWB_DATE,
                    SF.ORIG_FLT_KEY,
                    SF.ORIG_FLT_DATE
                  ) ISRF ON ICS.AWB_NO = ISRF.AWB_NO
                AND ICS.AWB_DATE       = ISRF.AWB_DATE
                AND ICS.FLT_KEY        = ISRF.ORIG_FLT_KEY
                AND ICS.FLT_DATE       = ISRF.ORIG_FLT_DATE
                LEFT JOIN V_CST_IMP_CC_CODE_AWB VCCODE
                ON VCCODE.FLT_KEY  =ICS.FLT_KEY
                AND VCCODE.FLT_DATE=ICS.FLT_DATE
                AND VCCODE.AWB_NO  =ICS.AWB_NO
                AND VCCODE.HAWB_NO ='000000000000000000'
                LEFT JOIN
                  (SELECT SUM(shp.pcs)                 AS fblPc,
                    SUM(shp.net_wt)                    AS fblWt,
                    fbl.flt_key                        AS flt_key,
                    TO_CHAR ( fbl.flt_date, 'DDMONYY') AS flt_date,
                    shp.awb_no                         AS awb_no,
                    TO_CHAR (shp.awb_date, 'DDMONYY')  AS awb_date
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.tr_no    = fbl.tr_no
                  AND fbl.FBL_STATUS = 'P'
                  GROUP BY fbl.flt_key,
                    fbl.flt_date,
                    shp.AWB_NO,
                    shp.AWB_DATE
                  ) t4
                ON t4.awb_no     =ICS.awb_no
                AND t4.awb_date  =ICS.awb_date
                AND t4.flt_key   =ICS.flt_key
                AND t4.flt_date  =ICS.flt_date
                WHERE ICS.AWB_NO = AWBYN.AWB_NO
                AND ICS.AWB_DATE = to_date(AWBYN.AWB_DATE,'DDMONYY')
                UNION
                SELECT '' AS FLTNO,
                  ''      AS FLTDATE,
                  ''      AS FLTTYPE,
                  ''      AS fblFltNo,
                  ''      AS fblFltDate
                FROM
                  (SELECT flt_key,
                    flt_date,
                    awb_no,
                    awb_date,
                    SUM(manf_pc) manf_pc,
                    SUM(manf_wt) manf_wt,
                    SUM(bup_pc) bup_pc ,
                    SUM(bup_wt) bup_wt,
                    SUM(bulk_pc) bulk_pc,
                    SUM(bulk_wt) bulk_wt,
                    SUM(ppk_pc) ppk_pc,
                    SUM(ppk_wt) ppk_wt
                  FROM
                    (SELECT flt_key flt_key,
                      flt_date flt_date,
                      awb_no awb_no,
                      awb_date awb_date,
                      SUM(NVL(pman_pcs,0)) manf_pc,
                      SUM(NVL(pman_wt,0)) manf_wt,
                      SUM(NVL(BULK_PCS,0)) bulk_pc,
                      SUM(NVL(BULK_WT,0)) bulk_wt,
                      SUM( NVL(PPK_PCS,0)+NVL(MIX_PCS,0)) ppk_pc,
                      SUM( NVL(PPK_WT,0) +NVL(MIX_WT,0)) ppk_wt,
                      SUM( NVL(PPK_PCS,0)+NVL(MIX_PCS,0)+NVL(ASSIGNED_BULK_PCS,0)) bup_pc,
                      SUM( NVL(PPK_WT,0) +NVL(MIX_WT,0)+NVL(ASSIGNED_BULK_WT,0) )bup_wt
                    FROM exp_pmanifest_awb
                    GROUP BY flt_key,
                      flt_date,
                      awb_no,
                      awb_date
                    UNION
                    SELECT flt_key flt_key,
                      flt_date flt_date,
                      awb_no awb_no,
                      awb_date awb_date,
                      SUM(NVL(bulk_pcs,0)+NVL(ppk_pcs,0)) manf_pc,
                      SUM(NVL(bulk_wt,0) +NVL(ppk_wt,0)) manf_wt,
                      SUM(NVL(bulk_pcs,0)) bulk_pc,
                      SUM(NVL(bulk_wt,0)) bulk_wt,
                      SUM(NVL(ppk_pcs,0)) ppk_pc,
                      SUM(NVL(ppk_wt,0)) ppk_wt,
                      SUM(NVL(bulk_pcs,0)+NVL(ppk_pcs,0)) bup_pc,
                      SUM(NVL(bulk_wt,0) +NVL(ppk_wt,0)) bup_wt
                    FROM EXP_PMAN_TARMAC_AWB
                    GROUP BY flt_key,
                      awb_no,
                      awb_date,
                      flt_date
                    )
                  GROUP BY flt_key,
                    flt_date,
                    awb_no,
                    awb_date
                  ) EPA
                LEFT JOIN
                  (SELECT SUM(shp.pcs)                 AS fblPc,
                    SUM(shp.net_wt)                    AS fblWt,
                    fbl.flt_key                        AS flt_key,
                    TO_CHAR ( fbl.flt_date, 'DDMONYY') AS flt_date,
                    shp.awb_no                         AS awb_no,
                    TO_CHAR (shp.awb_date, 'DDMONYY')  AS awb_date
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.tr_no    = fbl.tr_no
                  AND fbl.FBL_STATUS = 'P'
                  GROUP BY fbl.flt_key,
                    fbl.flt_date,
                    shp.AWB_NO,
                    shp.AWB_DATE
                  ) t2
                ON t2.awb_no     =EPA.awb_no
                AND t2.awb_date  =EPA.awb_date
                AND t2.flt_key   =EPA.flt_key
                AND t2.flt_date  =EPA.flt_date
                WHERE EPA.AWB_NO = AWBYN.AWB_NO
                AND EPA.AWB_DATE = AWBYN.AWB_DATE
                UNION
                SELECT ''     AS FLTNO,
                  ''          AS FLTDATE,
                  ''          AS FLTTYPE,
                  t1.flt_key  AS fblFltNo,
                  t1.flt_date AS fblFltDate
                FROM
                  (SELECT SUM(shp.pcs)                 AS fblPc,
                    SUM(shp.net_wt)                    AS fblWt,
                    fbl.flt_key                        AS flt_key,
                    TO_CHAR ( fbl.flt_date, 'DDMONYY') AS flt_date
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.tr_no    = fbl.tr_no
                  AND shp.AWB_NO     = AWBYN.AWB_NO
                  AND shp.AWB_DATE   = AWBYN.AWB_DATE
                  AND fbl.FBL_STATUS = 'P'
                  AND NOT EXISTS
                    (SELECT NULL
                    FROM exp_pmanifest_awb
                    WHERE awb_no=AWBYN.AWB_NO
                    AND awb_date=AWBYN.AWB_DATE
                    AND FLT_KEY =fbl.flt_key
                    AND FLT_DATE=fbl.flt_date
                    )
                  AND NOT EXISTS
                    (SELECT NULL
                    FROM EXP_PMAN_TARMAC_AWB
                    WHERE awb_no=AWBYN.AWB_NO
                    AND awb_date=AWBYN.AWB_DATE
                    AND FLT_KEY =fbl.flt_key
                    AND FLT_DATE=fbl.flt_date
                    )
                  GROUP BY fbl.flt_key,
                    fbl.flt_date
                  ) t1
                UNION
                SELECT ''                              AS FLTNO,
                  ''                                   AS FLTDATE,
                  ''                                   AS FLTTYPE,
                  OFAWB.flt_key                        AS fblFltNo,
                  TO_CHAR ( OFAWB.flt_date, 'DDMONYY') AS fblFltDate
                FROM EXP_OFFLOAD_ULD_AWB OFAWB
                LEFT JOIN
                  (SELECT SUM(shp.pcs)                 AS fblPc,
                    SUM(shp.net_wt)                    AS fblWt,
                    fbl.flt_key                        AS flt_key,
                    TO_CHAR ( fbl.flt_date, 'DDMONYY') AS flt_date,
                    shp.awb_no                         AS awb_no,
                    TO_CHAR (shp.awb_date, 'DDMONYY')  AS awb_date
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.tr_no    = fbl.tr_no
                  AND fbl.FBL_STATUS = 'P'
                  GROUP BY fbl.flt_key,
                    fbl.flt_date,
                    shp.AWB_NO,
                    shp.AWB_DATE
                  ) t3
                ON t3.awb_no          =OFAWB.awb_no
                AND t3.awb_date       =OFAWB.awb_date
                AND t3.flt_key        =OFAWB.flt_key
                AND t3.flt_date       =OFAWB.flt_date
                WHERE OFAWB.AWB_NO    = AWBYN.AWB_NO
                AND OFAWB.AWB_DATE    = AWBYN.AWB_DATE
                AND OFAWB.CONFIRMED_YN='Y'
                AND NOT EXISTS
                  (SELECT NULL
                  FROM exp_pmanifest_awb
                  WHERE awb_no=AWBYN.AWB_NO
                  AND awb_date=AWBYN.AWB_DATE
                  AND FLT_KEY =OFAWB.flt_key
                  AND FLT_DATE=OFAWB.flt_date
                  )
                AND NOT EXISTS
                  (SELECT NULL
                  FROM EXP_PMAN_TARMAC_AWB
                  WHERE awb_no=AWBYN.AWB_NO
                  AND awb_date=AWBYN.AWB_DATE
                  AND FLT_KEY =OFAWB.flt_key
                  AND FLT_DATE=OFAWB.flt_date
                  )
                AND NOT EXISTS
                  (SELECT NULL
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.awb_no   = AWBYN.AWB_NO
                  AND shp.awb_date   =AWBYN.AWB_DATE
                  AND fbl.flt_key    =OFAWB.flt_key
                  AND FBL.FLT_DATE   =OFAWB.FLT_DATE
                  AND shp.tr_no      = fbl.tr_no
                  AND fbl.FBL_STATUS = 'P'
                  )
                UNION
                SELECT '' AS FLTNO,
                  ''      AS FLTDATE ,
                  ''      AS FLTTYPE,
                  ''      AS fblFltNo,
                  ''      AS fblFltDate
                FROM EXP_OFFLOAD_ULD_AWB EOUA
                WHERE EOUA.AWB_NO = AWBYN.AWB_NO
                AND EOUA.AWB_DATE = AWBYN.AWB_DATE
                AND CONFIRMED_YN  ='Y'
                AND NOT EXISTS
                  (SELECT NULL
                  FROM exp_pmanifest_awb
                  WHERE awb_no=AWBYN.AWB_NO
                  AND awb_date=AWBYN.AWB_DATE
                  UNION
                  SELECT NULL
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.tr_no    = fbl.tr_no
                  AND fbl.FBL_STATUS = 'P'
                  AND shp.AWB_NO     = AWBYN.AWB_NO
                  AND SHP.AWB_DATE   = AWBYN.AWB_DATE
                  )
                GROUP BY EOUA.FLT_KEY,
                  EOUA.FLT_DATE
                ) ;
              IF(FLT_COUNT     =0) THEN
                AWB_FLT_EXISTS:='N';
              ELSE
                AWB_FLT_EXISTS:='Y';
              END IF;
            ELSE
              NULL;
            END IF;
            AWB_INV_YN:=NULL;
            SELECT DECODE(COUNT(1),0,'N','Y')
            INTO AWB_INV_YN
            FROM AWB_INVENTORY
            WHERE AWB_NO=AWBYN.AWB_NO
            AND AWB_DATE=AWBYN.AWB_DATE;
            INSERT
            INTO ARCHIVE_AWB_NOT_CLOSED 
            (FLT_KEY,FLT_DATE,FLT_TYPE,AWB_NO,AWB_DATE,AWB_CLOSED_YN,FLT_CLOSE_DATE,AWB_INV_YN,AWB_CR_DATE,AWB_TYPE,AWB_FLT_EXISTS_YN)
            VALUES
              (
                FC.FLT_KEY,
                FC.SCH_DATE,
                FC.FLT_TYPE,
                AWBYN.AWB_NO,
                AWBYN.AWB_DATE,
                AWBYN.AWB_CLOSED_YN,
                fc.FLT_CLS_DATE,
                AWB_INV_YN,
                AWBYN.CR_DATE,
                AWBYN.AWB_TYPE,
                AWB_FLT_EXISTS
              );
          END LOOP;
        END IF;
        IF(FC.FLT_TYPE='A') THEN
          --DEBUG_OBJ_ARCH('FLT TYPE : '||FC.FLT_TYPE);
          FOR AWBYN IN AWBIMPCLOSEDYN
          (
            FC.FLT_KEY,FC.SCH_DATE
          )
          LOOP
            FLT_COUNT       :=0;
            AWB_FLT_EXISTS  :='N';
            IF(AWBYN.AWB_TYPE='I') THEN
              SELECT COUNT(1)
              INTO FLT_COUNT
              FROM
                (SELECT ICS.FLT_KEY ,
                  TO_CHAR (ICS.FLT_DATE, 'DDMONYY') ,
                  ICS.FLT_TYPE
                FROM IMP_CAR_SHP ICS
                LEFT JOIN
                  (SELECT SF.AWB_NO,
                    SF.AWB_DATE,
                    SF.ORIG_FLT_KEY,
                    SF.ORIG_FLT_DATE,
                    SUM(SR.SRF_PCS) SRFPCS,
                    SUM(SR.SRF_WT) SRFWT,
                    SUM(SF.DLV_PCS) RELPCS,
                    SUM(DLV_WT) RELWT
                  FROM IMP_SRF SR
                  JOIN IMP_SRF_FLT SF
                  ON SR.SRF_NO         = SF.SRF_NO
                  WHERE ((SR.STATUS    ='ISSUED'
                  AND SR.SRF_EXPY_DATE > SYSDATE)
                  OR (SR.STATUS        ='POSTED'
                  OR SR.SRF_NO        IN
                    (SELECT SRF_NO FROM IMP_CDIF WHERE VOID_DATE IS NULL
                    )))
                  GROUP BY SF.AWB_NO,
                    SF.AWB_DATE,
                    SF.ORIG_FLT_KEY,
                    SF.ORIG_FLT_DATE
                  ) ISRF ON ICS.AWB_NO = ISRF.AWB_NO
                AND ICS.AWB_DATE       = ISRF.AWB_DATE
                AND ICS.FLT_KEY        = ISRF.ORIG_FLT_KEY
                AND ICS.FLT_DATE       = ISRF.ORIG_FLT_DATE
                LEFT JOIN V_CST_IMP_CC_CODE_AWB VCCODE
                ON VCCODE.FLT_KEY  =ICS.FLT_KEY
                AND VCCODE.FLT_DATE=ICS.FLT_DATE
                AND VCCODE.AWB_NO  =ICS.AWB_NO
                AND VCCODE.HAWB_NO ='000000000000000000'
                WHERE ICS.AWB_NO   = AWBYN.AWB_NO
                AND ICS.AWB_DATE   = TO_DATE(AWBYN.AWB_DATE,'DDMONYY')
                ORDER BY ICS.AWB_DATE
                );
              IF(FLT_COUNT     =0) THEN
                AWB_FLT_EXISTS:='N';
              ELSE
                AWB_FLT_EXISTS:='Y';
              END IF;
            ELSIF(AWBYN.AWB_TYPE='E') THEN
              SELECT COUNT(1)
              INTO FLT_COUNT
              FROM
                (SELECT EPA.FLT_KEY                 AS fltNo,
                  TO_CHAR (EPA.FLT_DATE, 'DDMONYY') AS FLTDATE,
                  EPA.FLT_TYPE                      AS fltType,
                  ''                                AS fblFltNo,
                  ''                                AS fblFltDate
                FROM
                  (SELECT flt_key,
                    flt_date,
                    flt_type,
                    awb_no,
                    awb_date,
                    SUM(manf_pc) manf_pc,
                    SUM(manf_wt) manf_wt,
                    SUM(bup_pc) bup_pc ,
                    SUM(bup_wt) bup_wt,
                    SUM(bulk_pc) bulk_pc,
                    SUM(bulk_wt) bulk_wt,
                    SUM(ppk_pc) ppk_pc,
                    SUM(ppk_wt) ppk_wt
                  FROM
                    (SELECT flt_key flt_key,
                      flt_date flt_date,
                      flt_type flt_type,
                      awb_no awb_no,
                      awb_date awb_date,
                      SUM(NVL(pman_pcs,0)) manf_pc,
                      SUM(NVL(pman_wt,0)) manf_wt,
                      SUM(NVL(BULK_PCS,0)) bulk_pc,
                      SUM(NVL(BULK_WT,0)) bulk_wt,
                      SUM( NVL(PPK_PCS,0)+NVL(MIX_PCS,0)) ppk_pc,
                      SUM( NVL(PPK_WT,0) +NVL(MIX_WT,0)) ppk_wt,
                      SUM( NVL(PPK_PCS,0)+NVL(MIX_PCS,0)+NVL(ASSIGNED_BULK_PCS,0)) bup_pc,
                      SUM( NVL(PPK_WT,0) +NVL(MIX_WT,0)+NVL(ASSIGNED_BULK_WT,0) )bup_wt
                    FROM exp_pmanifest_awb
                    GROUP BY flt_key,
                      flt_date,
                      awb_no,
                      awb_date,
                      flt_type
                    UNION
                    SELECT flt_key flt_key,
                      flt_date flt_date,
                      'E' flt_type,
                      awb_no awb_no,
                      awb_date awb_date,
                      SUM(NVL(bulk_pcs,0)+NVL(ppk_pcs,0)) manf_pc,
                      SUM(NVL(bulk_wt,0) +NVL(ppk_wt,0)) manf_wt,
                      SUM(NVL(bulk_pcs,0)) bulk_pc,
                      SUM(NVL(bulk_wt,0)) bulk_wt,
                      SUM(NVL(ppk_pcs,0)) ppk_pc,
                      SUM(NVL(ppk_wt,0)) ppk_wt,
                      SUM(NVL(bulk_pcs,0)+NVL(ppk_pcs,0)) bup_pc,
                      SUM(NVL(bulk_wt,0) +NVL(ppk_wt,0)) bup_wt
                    FROM EXP_PMAN_TARMAC_AWB
                    GROUP BY flt_key,
                      awb_no,
                      awb_date,
                      flt_date
                    )
                  GROUP BY flt_key,
                    flt_date,
                    awb_no,
                    awb_date,
                    flt_type
                  ) EPA
                WHERE EPA.AWB_NO = AWBYN.AWB_NO
                AND EPA.AWB_DATE = AWBYN.AWB_DATE
                UNION
                SELECT '',
                  '',
                  '',
                  fbl.flt_key                        AS fblFltNo,
                  TO_CHAR ( fbl.flt_date, 'DDMONYY') AS fblFltDate
                FROM edi_fbl_shp shp,
                  edi_fbl fbl
                WHERE shp.tr_no    = fbl.tr_no
                AND fbl.FBL_STATUS = 'P'
                AND shp.AWB_NO     = AWBYN.AWB_NO
                AND shp.AWB_DATE   = AWBYN.AWB_DATE
                AND NOT EXISTS
                  (SELECT NULL
                  FROM exp_pmanifest_awb
                  WHERE awb_no=AWBYN.AWB_NO
                  AND awb_date=AWBYN.AWB_DATE
                  AND FLT_KEY =fbl.flt_key
                  AND FLT_DATE=fbl.flt_date
                  )
                GROUP BY fbl.flt_key,
                  fbl.flt_date,
                  fbl.carr_code
                UNION
                SELECT '',
                  '',
                  '',
                  OFAWB.flt_key                        AS fblFltNo,
                  TO_CHAR ( OFAWB.flt_date, 'DDMONYY') AS fblFltDate
                FROM EXP_OFFLOAD_ULD_AWB OFAWB
                WHERE OFAWB.AWB_NO    = AWBYN.AWB_NO
                AND OFAWB.AWB_DATE    = AWBYN.AWB_DATE
                AND OFAWB.CONFIRMED_YN='Y'
                AND NOT EXISTS
                  (SELECT NULL
                  FROM exp_pmanifest_awb
                  WHERE awb_no=AWBYN.AWB_NO
                  AND awb_date=AWBYN.AWB_DATE
                  AND FLT_KEY =OFAWB.flt_key
                  AND FLT_DATE=OFAWB.flt_date
                  )
                AND NOT EXISTS
                  (SELECT NULL
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.awb_no   = AWBYN.AWB_NO
                  AND shp.awb_date   =AWBYN.AWB_DATE
                  AND fbl.flt_key    =OFAWB.flt_key
                  AND fbl.flt_date   =OFAWB.flt_date
                  AND SHP.TR_NO      = FBL.TR_NO
                  AND FBL.FBL_STATUS = 'P'
                  )
                AND NOT EXISTS
                  (SELECT NULL
                  FROM EXP_PMAN_TARMAC_AWB
                  WHERE AWB_NO=AWBYN.AWB_NO
                  AND AWB_DATE=AWBYN.AWB_DATE
                  AND FLT_KEY =OFAWB.FLT_KEY
                  AND FLT_DATE=OFAWB.FLT_DATE
                  )
                UNION
                SELECT EOUA.FLT_KEY                  AS fltNo,
                  TO_CHAR (EOUA.FLT_DATE, 'DDMONYY') AS FLTDATE,
                  'E'                                AS fltType,
                  ''                                 AS fblFltNo,
                  ''                                 AS fblFltDate
                FROM EXP_OFFLOAD_ULD_AWB EOUA
                WHERE EOUA.AWB_NO = AWBYN.AWB_NO
                AND EOUA.AWB_DATE = AWBYN.AWB_DATE
                AND CONFIRMED_YN  = 'Y'
                AND NOT EXISTS
                  (SELECT NULL
                  FROM exp_pmanifest_awb
                  WHERE awb_no=AWBYN.AWB_NO
                  AND awb_date=AWBYN.AWB_DATE
                  UNION
                  SELECT NULL
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.tr_no    = fbl.tr_no
                  AND fbl.FBL_STATUS = 'P'
                  AND shp.AWB_NO     = AWBYN.AWB_NO
                  AND SHP.AWB_DATE   =AWBYN.AWB_DATE
                  )
                GROUP BY EOUA.FLT_KEY,
                  EOUA.FLT_DATE
                );
              IF(FLT_COUNT     =0) THEN
                AWB_FLT_EXISTS:='N';
              ELSE
                AWB_FLT_EXISTS:='Y';
              END IF;
            ELSIF(AWBYN.AWB_TYPE='T') THEN
              SELECT COUNT(1)
              INTO FLT_COUNT
              FROM
                (SELECT ICS.FLT_KEY                 AS fltNo,
                  TO_CHAR (ICS.FLT_DATE, 'DDMONYY') AS fltDate,
                  ICS.FLT_TYPE                      AS fltType,
                  ''                                AS fblFltNo,
                  ''                                AS fblFltDate
                FROM IMP_CAR_SHP ICS
                LEFT JOIN
                  (SELECT SF.AWB_NO,
                    SF.AWB_DATE,
                    SF.ORIG_FLT_KEY,
                    SF.ORIG_FLT_DATE,
                    SUM(SR.SRF_PCS) SRFPCS,
                    SUM(SR.SRF_WT) SRFWT,
                    SUM(SF.DLV_PCS) RELPCS,
                    SUM(DLV_WT) RELWT
                  FROM IMP_SRF SR
                  JOIN IMP_SRF_FLT SF
                  ON SR.SRF_NO         = SF.SRF_NO
                  WHERE ((SR.STATUS    ='ISSUED'
                  AND SR.SRF_EXPY_DATE > SYSDATE)
                  OR (SR.STATUS        ='POSTED'
                  OR SR.SRF_NO        IN
                    (SELECT SRF_NO FROM IMP_CDIF WHERE VOID_DATE IS NULL
                    )))
                  GROUP BY SF.AWB_NO,
                    SF.AWB_DATE,
                    SF.ORIG_FLT_KEY,
                    SF.ORIG_FLT_DATE
                  ) ISRF ON ICS.AWB_NO = ISRF.AWB_NO
                AND ICS.AWB_DATE       = ISRF.AWB_DATE
                AND ICS.FLT_KEY        = ISRF.ORIG_FLT_KEY
                AND ICS.FLT_DATE       = ISRF.ORIG_FLT_DATE
                LEFT JOIN V_CST_IMP_CC_CODE_AWB VCCODE
                ON VCCODE.FLT_KEY  =ICS.FLT_KEY
                AND VCCODE.FLT_DATE=ICS.FLT_DATE
                AND VCCODE.AWB_NO  =ICS.AWB_NO
                AND VCCODE.HAWB_NO ='000000000000000000'
                LEFT JOIN
                  (SELECT SUM(shp.pcs)                 AS fblPc,
                    SUM(shp.net_wt)                    AS fblWt,
                    fbl.flt_key                        AS flt_key,
                    TO_CHAR ( fbl.flt_date, 'DDMONYY') AS flt_date,
                    shp.awb_no                         AS awb_no,
                    TO_CHAR (shp.awb_date, 'DDMONYY')  AS awb_date
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.tr_no    = fbl.tr_no
                  AND fbl.FBL_STATUS = 'P'
                  GROUP BY fbl.flt_key,
                    fbl.flt_date,
                    shp.AWB_NO,
                    shp.AWB_DATE
                  ) t4
                ON t4.awb_no     =ICS.awb_no
                AND t4.awb_date  =ICS.awb_date
                AND t4.flt_key   =ICS.flt_key
                AND t4.flt_date  =ICS.flt_date
                WHERE ICS.AWB_NO = AWBYN.AWB_NO
                AND ICS.AWB_DATE = to_date(AWBYN.AWB_DATE,'DDMONYY')
                UNION
                SELECT '' AS FLTNO,
                  ''      AS FLTDATE,
                  ''      AS FLTTYPE,
                  ''      AS fblFltNo,
                  ''      AS fblFltDate
                FROM
                  (SELECT flt_key,
                    flt_date,
                    awb_no,
                    awb_date,
                    SUM(manf_pc) manf_pc,
                    SUM(manf_wt) manf_wt,
                    SUM(bup_pc) bup_pc ,
                    SUM(bup_wt) bup_wt,
                    SUM(bulk_pc) bulk_pc,
                    SUM(bulk_wt) bulk_wt,
                    SUM(ppk_pc) ppk_pc,
                    SUM(ppk_wt) ppk_wt
                  FROM
                    (SELECT flt_key flt_key,
                      flt_date flt_date,
                      awb_no awb_no,
                      awb_date awb_date,
                      SUM(NVL(pman_pcs,0)) manf_pc,
                      SUM(NVL(pman_wt,0)) manf_wt,
                      SUM(NVL(BULK_PCS,0)) bulk_pc,
                      SUM(NVL(BULK_WT,0)) bulk_wt,
                      SUM( NVL(PPK_PCS,0)+NVL(MIX_PCS,0)) ppk_pc,
                      SUM( NVL(PPK_WT,0) +NVL(MIX_WT,0)) ppk_wt,
                      SUM( NVL(PPK_PCS,0)+NVL(MIX_PCS,0)+NVL(ASSIGNED_BULK_PCS,0)) bup_pc,
                      SUM( NVL(PPK_WT,0) +NVL(MIX_WT,0)+NVL(ASSIGNED_BULK_WT,0) )bup_wt
                    FROM exp_pmanifest_awb
                    GROUP BY flt_key,
                      flt_date,
                      awb_no,
                      awb_date
                    UNION
                    SELECT flt_key flt_key,
                      flt_date flt_date,
                      awb_no awb_no,
                      awb_date awb_date,
                      SUM(NVL(bulk_pcs,0)+NVL(ppk_pcs,0)) manf_pc,
                      SUM(NVL(bulk_wt,0) +NVL(ppk_wt,0)) manf_wt,
                      SUM(NVL(bulk_pcs,0)) bulk_pc,
                      SUM(NVL(bulk_wt,0)) bulk_wt,
                      SUM(NVL(ppk_pcs,0)) ppk_pc,
                      SUM(NVL(ppk_wt,0)) ppk_wt,
                      SUM(NVL(bulk_pcs,0)+NVL(ppk_pcs,0)) bup_pc,
                      SUM(NVL(bulk_wt,0) +NVL(ppk_wt,0)) bup_wt
                    FROM EXP_PMAN_TARMAC_AWB
                    GROUP BY flt_key,
                      awb_no,
                      awb_date,
                      flt_date
                    )
                  GROUP BY flt_key,
                    flt_date,
                    awb_no,
                    awb_date
                  ) EPA
                LEFT JOIN
                  (SELECT SUM(shp.pcs)                 AS fblPc,
                    SUM(shp.net_wt)                    AS fblWt,
                    fbl.flt_key                        AS flt_key,
                    TO_CHAR ( fbl.flt_date, 'DDMONYY') AS flt_date,
                    shp.awb_no                         AS awb_no,
                    TO_CHAR (shp.awb_date, 'DDMONYY')  AS awb_date
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.tr_no    = fbl.tr_no
                  AND fbl.FBL_STATUS = 'P'
                  GROUP BY fbl.flt_key,
                    fbl.flt_date,
                    shp.AWB_NO,
                    shp.AWB_DATE
                  ) t2
                ON t2.awb_no     =EPA.awb_no
                AND t2.awb_date  =EPA.awb_date
                AND t2.flt_key   =EPA.flt_key
                AND t2.flt_date  =EPA.flt_date
                WHERE EPA.AWB_NO = AWBYN.AWB_NO
                AND EPA.AWB_DATE = AWBYN.AWB_DATE
                UNION
                SELECT ''     AS FLTNO,
                  ''          AS FLTDATE,
                  ''          AS FLTTYPE,
                  t1.flt_key  AS fblFltNo,
                  t1.flt_date AS fblFltDate
                FROM
                  (SELECT SUM(shp.pcs)                 AS fblPc,
                    SUM(shp.net_wt)                    AS fblWt,
                    fbl.flt_key                        AS flt_key,
                    TO_CHAR ( fbl.flt_date, 'DDMONYY') AS flt_date
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.tr_no    = fbl.tr_no
                  AND shp.AWB_NO     = AWBYN.AWB_NO
                  AND shp.AWB_DATE   = AWBYN.AWB_DATE
                  AND fbl.FBL_STATUS = 'P'
                  AND NOT EXISTS
                    (SELECT NULL
                    FROM exp_pmanifest_awb
                    WHERE awb_no=AWBYN.AWB_NO
                    AND awb_date=AWBYN.AWB_DATE
                    AND FLT_KEY =fbl.flt_key
                    AND FLT_DATE=fbl.flt_date
                    )
                  AND NOT EXISTS
                    (SELECT NULL
                    FROM EXP_PMAN_TARMAC_AWB
                    WHERE awb_no=AWBYN.AWB_NO
                    AND awb_date=AWBYN.AWB_DATE
                    AND FLT_KEY =fbl.flt_key
                    AND FLT_DATE=fbl.flt_date
                    )
                  GROUP BY fbl.flt_key,
                    fbl.flt_date
                  ) t1
                UNION
                SELECT ''                              AS FLTNO,
                  ''                                   AS FLTDATE,
                  ''                                   AS FLTTYPE,
                  OFAWB.flt_key                        AS fblFltNo,
                  TO_CHAR ( OFAWB.flt_date, 'DDMONYY') AS fblFltDate
                FROM EXP_OFFLOAD_ULD_AWB OFAWB
                LEFT JOIN
                  (SELECT SUM(shp.pcs)                 AS fblPc,
                    SUM(shp.net_wt)                    AS fblWt,
                    fbl.flt_key                        AS flt_key,
                    TO_CHAR ( fbl.flt_date, 'DDMONYY') AS flt_date,
                    shp.awb_no                         AS awb_no,
                    TO_CHAR (shp.awb_date, 'DDMONYY')  AS awb_date
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.tr_no    = fbl.tr_no
                  AND fbl.FBL_STATUS = 'P'
                  GROUP BY fbl.flt_key,
                    fbl.flt_date,
                    shp.AWB_NO,
                    shp.AWB_DATE
                  ) t3
                ON t3.awb_no          =OFAWB.awb_no
                AND t3.awb_date       =OFAWB.awb_date
                AND t3.flt_key        =OFAWB.flt_key
                AND t3.flt_date       =OFAWB.flt_date
                WHERE OFAWB.AWB_NO    = AWBYN.AWB_NO
                AND OFAWB.AWB_DATE    = AWBYN.AWB_DATE
                AND OFAWB.CONFIRMED_YN='Y'
                AND NOT EXISTS
                  (SELECT NULL
                  FROM exp_pmanifest_awb
                  WHERE awb_no=AWBYN.AWB_NO
                  AND awb_date=AWBYN.AWB_DATE
                  AND FLT_KEY =OFAWB.flt_key
                  AND FLT_DATE=OFAWB.flt_date
                  )
                AND NOT EXISTS
                  (SELECT NULL
                  FROM EXP_PMAN_TARMAC_AWB
                  WHERE awb_no=AWBYN.AWB_NO
                  AND awb_date=AWBYN.AWB_DATE
                  AND FLT_KEY =OFAWB.flt_key
                  AND FLT_DATE=OFAWB.flt_date
                  )
                AND NOT EXISTS
                  (SELECT NULL
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.awb_no   = AWBYN.AWB_NO
                  AND shp.awb_date   =AWBYN.AWB_DATE
                  AND fbl.flt_key    =OFAWB.flt_key
                  AND FBL.FLT_DATE   =OFAWB.FLT_DATE
                  AND shp.tr_no      = fbl.tr_no
                  AND fbl.FBL_STATUS = 'P'
                  )
                UNION
                SELECT '' AS FLTNO,
                  ''      AS FLTDATE ,
                  ''      AS FLTTYPE,
                  ''      AS fblFltNo,
                  ''      AS fblFltDate
                FROM EXP_OFFLOAD_ULD_AWB EOUA
                WHERE EOUA.AWB_NO = AWBYN.AWB_NO
                AND EOUA.AWB_DATE = AWBYN.AWB_DATE
                AND CONFIRMED_YN  ='Y'
                AND NOT EXISTS
                  (SELECT NULL
                  FROM exp_pmanifest_awb
                  WHERE awb_no=AWBYN.AWB_NO
                  AND awb_date=AWBYN.AWB_DATE
                  UNION
                  SELECT NULL
                  FROM edi_fbl_shp shp,
                    edi_fbl fbl
                  WHERE shp.tr_no    = fbl.tr_no
                  AND fbl.FBL_STATUS = 'P'
                  AND shp.AWB_NO     = AWBYN.AWB_NO
                  AND SHP.AWB_DATE   = AWBYN.AWB_DATE
                  )
                GROUP BY EOUA.FLT_KEY,
                  EOUA.FLT_DATE
                ) ;
              IF(FLT_COUNT     =0) THEN
                AWB_FLT_EXISTS:='N';
              ELSE
                AWB_FLT_EXISTS:='Y';
              END IF;
            ELSE
              NULL;
            END IF;
            AWB_INV_YN:=NULL;
            SELECT DECODE(COUNT(1),0,'N','Y')
            INTO AWB_INV_YN
            FROM AWB_INVENTORY
            WHERE AWB_NO=AWBYN.AWB_NO
            AND AWB_DATE=AWBYN.AWB_DATE;
            INSERT
            INTO ARCHIVE_AWB_NOT_CLOSED 
            (FLT_KEY,FLT_DATE,FLT_TYPE,AWB_NO,AWB_DATE,AWB_CLOSED_YN,FLT_CLOSE_DATE,AWB_INV_YN,AWB_CR_DATE,AWB_TYPE,AWB_FLT_EXISTS_YN)
            VALUES
              (
                FC.FLT_KEY,
                FC.SCH_DATE,
                FC.FLT_TYPE,
                AWBYN.AWB_NO,
                AWBYN.AWB_DATE,
                AWBYN.AWB_CLOSED_YN,
                fc.FLT_CLS_DATE,
                AWB_INV_YN,
                AWBYN.CR_DATE,
                AWBYN.AWB_TYPE,
                AWB_FLT_EXISTS
              );
          END LOOP;
        END IF;
      END LOOP;
    END SP_ARCHIVAL_AWB_NOTCLS;
/
SHOW ERRORS