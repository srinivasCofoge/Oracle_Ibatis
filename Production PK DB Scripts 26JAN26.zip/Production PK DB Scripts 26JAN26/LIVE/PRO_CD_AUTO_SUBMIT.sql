--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PROCEDURE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT Creating WOSINT.PRO_CD_AUTO_SUBMIT
CREATE OR REPLACE PROCEDURE WOSINT.PRO_CD_AUTO_SUBMIT IS
  CURSOR cc IS
    SELECT *
      FROM cst_subm_temp
     WHERE processed = 'N'
      AND rec_type   IN ('INT', 'AMD', 'BDS') and trk_flt_ind = 'Y'
       AND rownum = 1
       FOR UPDATE NOWAIT;
  v_ret    VARCHAR2(200);
  p_ver_no NUMBER;
  v_err    VARCHAR2(1000);
  v_sts    VARCHAR2(10);
  rec_subm cc%ROWTYPE;
BEGIN

--  dbms_output.enable(1000000);

  DBMS_OUTPUT.PUT_LINE('PRO_CD_AUTO_SUBMIT');

  IF cc%ISOPEN THEN
    CLOSE cc;
  END IF;

  DBMS_OUTPUT.PUT_LINE('PRO_CD_AUTO_Check');

  OPEN cc;
  FETCH cc
    INTO rec_subm;
   IF cc%ROWCOUNT = 1 THEN
    UPDATE cst_subm_temp SET processed = 'Y' WHERE CURRENT OF cc;

    p_ver_no := rec_subm.ver_no;
    v_sts    := fun_check_man(rec_subm.flt_type, rec_subm.flt_key,
                              to_char(rec_subm.flt_date, 'DDMONYY'),
                              rec_subm.rec_type, 'Y');

  DBMS_OUTPUT.PUT_LINE('PRO_CD_AUTO_Check - v_sts - '||v_sts);

    IF v_sts IS NULL OR v_sts IN ('R', 'E') THEN
      v_sts := 'N';
    END IF;

    IF v_sts NOT IN ('P', 'W') THEN
      IF v_sts = 'A' AND rec_subm.rec_type = 'INT' THEN
        DELETE FROM cst_submit_temp
         WHERE flt_key = rec_subm.flt_key
           AND flt_date = rec_subm.flt_date
           AND cst_type = rec_subm.rec_type
           AND ver_no = rec_subm.ver_no;
        DELETE FROM cst_subm_temp
         WHERE flt_key = rec_subm.flt_key
           AND flt_date = rec_subm.flt_date
           AND rec_type = rec_subm.rec_type
           AND ver_no = rec_subm.ver_no;
      ELSE
        IF rec_subm.rec_type = 'INT' AND v_sts = 'N' THEN

--          DELETE FROM cst_awb a
--           WHERE NOT EXISTS (SELECT *
--                    FROM edi_ffm_msg b, edi_ffm_shp c
--                   WHERE b.tr_no = c.tr_no
--                     AND b.flt_key = a.flt_key
--                     AND b.flt_date = a.flt_date
--                     AND c.awb_no = a.awb_no
--                     AND b.ffm_status IN ('P', 'F'))
--             AND a.flt_type = 'I';
--
--          UPDATE cst_awb a
--             SET a.accs_ind = 'N', a.change_ind = 'A'
--           WHERE flt_key = rec_subm.flt_key
--             AND flt_date = rec_subm.flt_date
--             AND flt_type = 'I';
--
--          DELETE FROM cst_hawb b
--           WHERE b.change_ind = 'D'
--             AND EXISTS (SELECT 1
--                    FROM cst_awb
--                   WHERE flt_key = rec_subm.flt_key
--                     AND flt_date = rec_subm.flt_date
--                     AND flt_type = 'I'
--                     AND awb_no = b.awb_no);
--
--          UPDATE cst_hawb b
--             SET b.accs_ind = 'N', b.change_ind = 'A'
--           WHERE EXISTS (SELECT 1
--                    FROM cst_awb
--                   WHERE flt_key = rec_subm.flt_key
--                     AND flt_date = rec_subm.flt_date
--                     AND flt_type = 'I'
--                     AND awb_no = b.awb_no);


--         DBMS_OUTPUT.PUT_LINE('PRO_CD_AUTO_SUBMIT - rec_subm.flt_key - '||rec_subm.flt_key ||'- rec_subm.flt_date - '||rec_subm.flt_date
--                              ||'- p_ver_no - '|| p_ver_no||'- rec_subm.lm_user_id - '|| rec_subm.lm_user_id
--                              ||'- rec_subm.lm_date - '|| rec_subm.lm_date);

          v_ret := pkg_cdt_cst_init.initial_cdt_csgnmt_subm(rec_subm.flt_key,
                                                               to_char(rec_subm.flt_date,
                                                                        'DDMONYY'),
                                                               p_ver_no,
                                                               rec_subm.lm_user_id,
                                                               rec_subm.lm_date);

      DBMS_OUTPUT.PUT_LINE('PRO_CD_AUTO_SUBMIT - rec_subm.flt_key - '||rec_subm.flt_key ||'- rec_subm.flt_date - '||rec_subm.flt_date
                              ||'- p_ver_no - '|| p_ver_no||'- rec_subm.lm_user_id - '|| rec_subm.lm_user_id
                              ||'- rec_subm.lm_date - '|| rec_subm.lm_date ||'- v_ret - '|| v_ret);

        ELSIF rec_subm.rec_type = 'AMD' THEN
          v_ret := pkg_cdt_cst_init.amend_cdt_csgnmt_subm(rec_subm.flt_key,
                                                             to_char(rec_subm.flt_date,
                                                                      'DDMONYY'),
                                                             p_ver_no,
                                                             rec_subm.lm_user_id,
                                                             rec_subm.lm_date);
        ELSIF rec_subm.rec_type = 'BDS' THEN
          v_ret := pkg_cdt_cst_init.behind_cdt_csgnmt_subm(rec_subm.flt_key,
                                                              to_char(rec_subm.flt_date,
                                                                       'DDMONYY'),
                                                              p_ver_no,
                                                              rec_subm.lm_user_id,
                                                              rec_subm.lm_date);
        ELSE
          NULL;
        END IF;

        IF v_ret = 'TRUE' THEN
          INSERT INTO cst_subm
            (flt_type, flt_date, flt_key, ver_no, ctrl_date, req_uid,
             msg_type, msg_id, rec_type, subm_date, send_status, send_date,
             bd_complete, lm_user_id, lm_date, lm_ver, err_msg)
          VALUES
            (rec_subm.flt_type, rec_subm.flt_date, rec_subm.flt_key,
             p_ver_no, SYSDATE, rec_subm.req_uid, rec_subm.msg_type,
             rec_subm.msg_id, rec_subm.rec_type, rec_subm.subm_date,
             rec_subm.send_status, rec_subm.send_date,
             rec_subm.bd_complete, rec_subm.lm_user_id, rec_subm.lm_date,
             rec_subm.lm_ver, rec_subm.err_msg);
        ELSE
          INSERT INTO cst_subm
            (flt_type, flt_date, flt_key, ver_no, ctrl_date, req_uid,
             msg_type, msg_id, rec_type, subm_date, send_status, send_date,
             bd_complete, lm_user_id, lm_date, lm_ver, err_msg)
          VALUES
            (rec_subm.flt_type, rec_subm.flt_date, rec_subm.flt_key,
             nvl(p_ver_no, 99), rec_subm.ctrl_date, rec_subm.req_uid,
             rec_subm.msg_type, rec_subm.msg_id, rec_subm.rec_type,
             rec_subm.subm_date, 'E', rec_subm.send_date,
             rec_subm.bd_complete, rec_subm.lm_user_id, rec_subm.lm_date,
             rec_subm.lm_ver, nvl(v_ret, 'GENERATING DATA FAILURE'));
        END IF;
        INSERT INTO cst_auto_submit_log (MSG)
        VALUES
          (rec_subm.flt_key || '/' || rec_subm.flt_date || ' ' ||
           to_char(SYSDATE, 'DDMONYY') || ' submit :' ||
           rec_subm.rec_type || ' version is ' || p_ver_no);
      END IF;
    END IF;
    DELETE FROM cst_submit_temp
     WHERE flt_key = rec_subm.flt_key
       AND flt_date = rec_subm.flt_date
       AND cst_type = rec_subm.rec_type
       AND ver_no = rec_subm.ver_no;
    DELETE FROM cst_subm_temp
     WHERE flt_key = rec_subm.flt_key
       AND flt_date = rec_subm.flt_date
       AND rec_type = rec_subm.rec_type
       AND ver_no = rec_subm.ver_no;
  END IF;
  CLOSE cc;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    IF cc%ISOPEN THEN
      CLOSE cc;
    END IF;
    v_err := substr(SQLCODE || SQLERRM, 1, 1000);
    INSERT INTO cst_auto_submit_log (MSG)
    VALUES
      (to_char(SYSDATE, 'DDMONYY HH24:MI') || ':' || v_err);
END;
/
SHOW ERRORS