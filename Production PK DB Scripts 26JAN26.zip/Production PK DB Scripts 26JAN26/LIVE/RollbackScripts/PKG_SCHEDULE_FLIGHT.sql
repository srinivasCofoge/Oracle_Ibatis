--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PACKAGE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT CREATE OR REPLACE PACKAGE WOSINT.PKG_SCHEDULE_FLIGHT
CREATE OR REPLACE PACKAGE WOSINT.PKG_SCHEDULE_FLIGHT IS

  PROCEDURE createdailyflight;

  PROCEDURE createdailyflight(p_sch_trno IN VARCHAR2);

  PROCEDURE deletedailyflight(p_sch_trno IN VARCHAR2,
                              p_flt_key IN VARCHAR2 DEFAULT NULL);

FUNCTION CHECK_FLT_SCHEDULE(P_FLT_KEY IN VARCHAR2, P_START_DATE IN VARCHAR2, P_END_DATE IN VARCHAR2, P_TR_NO IN VARCHAR, DAYS IN VARCHAR2)
 RETURN VARCHAR2;
    
  PROCEDURE updateSSMDetailsForFlight;

END pkg_schedule_flight;
/

PROMPT CREATE OR REPLACE PACKAGE BODY WOSINT.PKG_SCHEDULE_FLIGHT
CREATE OR REPLACE PACKAGE BODY WOSINT.PKG_SCHEDULE_FLIGHT IS

  cdefaultuser CONSTANT VARCHAR2(10) := 'SCHEDULER';

  g_start_date DATE;
  g_end_date   DATE;
  g_sch_trno   VARCHAR2(12);
  g_base_port  VARCHAR(3);
  g_trans_id   VARCHAR2(30);
  g_nty_users  VARCHAR2(400);
  G_ERROR          VARCHAR2(400);
  V_TRN_FLT_SFX VARCHAR2(1);
  TYPE cursor_t IS REF CURSOR;

	  
  v_ssm_type_count NUMBER;
  
  TYPE flt_sch_array IS TABLE OF DATE;
  g_cur_date flt_sch_array := flt_sch_array();
  g_cur_date_new flt_sch_array := flt_sch_array();
  g_cur_date_old flt_sch_array := flt_sch_array();

  TYPE t_flt_opr_leg IS TABLE OF flt_opr_leg%ROWTYPE;

  CURSOR cc_sch IS
    SELECT tr_no, carr_code, flt_no, start_date, end_date, frq_no, flt_key,
           jv_code,
           mon_flg || tue_flg || wed_flg || thu_flg || fri_flg ||
            sat_flg ||  sun_flg dat_flg,
           jnt_mon_flg || jnt_tue_flg || jnt_wed_flg ||
            jnt_thu_flg || jnt_fri_flg || jnt_sat_flg || jnt_sun_flg dat_jnt_flg, lm_date,
			wh_level, brkbup_off, svc_type, cgo_acft_type, flt_module1, flt_module2, exp_flt_module1, exp_flt_module2, to_ind, chkout_area, cr_date, rho_id ,
			VESSEL_ID, VESSEL_NAME, VOYAGE_NUM , CALL_SIGN_VESSEL, SHIPPING_AGENT  
      FROM flt_sch
     WHERE tr_no = nvl(g_sch_trno, tr_no) --g_sch_trno
       AND start_date <= g_end_date
       AND end_date >= g_start_date
       AND (g_sch_trno is not null or (OUTSTANDING ='N' and cr_user_id not in ('SSMRPL', 'SSMCNL', 'SSMNEW', 'SSMEQT', 'SSMTIM')))
      -- and flt_key = 'NT101'
     ORDER BY flt_key, start_date DESC;

  g_cc_sch cc_sch%ROWTYPE;
  
  CURSOR cc_sch_type IS
    SELECT tr_no, carr_code, flt_no, start_date, end_date, frq_no, flt_key,
           jv_code,
           mon_flg || tue_flg || wed_flg || thu_flg || fri_flg ||
            sat_flg ||  sun_flg dat_flg,
           jnt_mon_flg || jnt_tue_flg || jnt_wed_flg ||
            jnt_thu_flg || jnt_fri_flg || jnt_sat_flg || jnt_sun_flg dat_jnt_flg, lm_date,
            wh_level, brkbup_off, svc_type, cgo_acft_type, flt_module1, flt_module2, exp_flt_module1, exp_flt_module2, to_ind, chkout_area, 
            cr_user_id, cr_date , VESSEL_ID, VESSEL_NAME, VOYAGE_NUM , CALL_SIGN_VESSEL, SHIPPING_AGENT  
      FROM flt_sch
     WHERE start_date <= g_end_date
       AND end_date >= g_start_date
       AND ((OUTSTANDING ='N' and cr_user_id in ('SSMRPL', 'SSMNEW', 'SSMCNLNEW')) or (cr_user_id in ('SSMCNL', 'SSMEQT', 'SSMTIM')))
    --   and flt_key = 'NT101'
     ORDER BY cr_date;
  
  g_cc_sch_type cc_sch_type%ROWTYPE;

  PROCEDURE send_board_message(p_error IN VARCHAR2, p_flt_date IN DATE) IS
    v_error VARCHAR2(1000);
  BEGIN

    IF g_nty_users IS NULL OR length(TRIM(g_nty_users)) = 0 THEN
      RETURN;
    END IF;
    IF p_flt_date IS NOT NULL THEN
      v_error := g_cc_sch.flt_key || '/' ||
                 to_char(p_flt_date, 'DDMONYY') || ' ERROR:' || p_error;
    ELSE
      v_error := g_cc_sch.flt_key || '/ START DATE:' ||
                 to_char(g_cc_sch.start_date, 'DDMONYY') || ' END DATE:' ||
                 to_char(g_cc_sch.end_date, 'DDMONYY') || ' ERROR:' ||
                 p_error;
    END IF;
    INSERT INTO board_message
      (msg_id, sender_id, sender_name, recipient_group, recipient,
       sent_date, expiry_date, msg, cr_user_id, cr_date, lm_user_id,
       lm_date)
    VALUES
      (brd_msg_id_seq.NEXTVAL, 'FLIGHT_SCHEDULER',
       'FLIGHT SCHEDULE BACKGROUD JOB', 'I', g_nty_users, SYSDATE,
       SYSDATE + 3, v_error, 'ADMIN1', SYSDATE, 'ADMIN1', SYSDATE);
  END;

  PROCEDURE schedule_log(p_flt_date DATE DEFAULT NULL,
                         p_error VARCHAR2 DEFAULT NULL,
                         p_type VARCHAR2 DEFAULT NULL) IS
    v_error VARCHAR2(200);
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    v_error := p_error;
    IF p_type NOT IN ('A', 'E') THEN
      v_error := substr(SQLCODE || ' ' || SQLERRM, 1, 200);
    END IF;

    INSERT INTO flt_schedule_log
      (tr_no, sch_trno, flt_key, flt_date, start_date, end_date, log)
    VALUES
      (g_trans_id, g_cc_sch.tr_no, g_cc_sch.flt_key, p_flt_date,
       g_cc_sch.start_date, g_cc_sch.end_date, v_error);
    IF p_type <> 'A' THEN
      send_board_message(v_error, p_flt_date);
    END IF;
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END;

  PROCEDURE pro_cmsrules IS
    v_past_days   NUMBER;
    v_future_days NUMBER;
    v_curr_date   DATE := trunc(SYSDATE);
  BEGIN
    FOR c IN (SELECT rule_code, rule_value
                FROM cmsrules
               WHERE rule_code IN
                     ('FLT_SCH_PAST_DAYS', 'FLT_SCH_FUT_DAYS')) LOOP
      IF c.rule_code = 'FLT_SCH_PAST_DAYS' THEN
        v_past_days := c.rule_value;
      ELSE
        v_future_days := c.rule_value;
      END IF;
    END LOOP;

    BEGIN
      SELECT stragg(stringdelim(code, ';'))
        INTO g_nty_users
        FROM mast_code_dtl
       WHERE group_code = '38'
         AND code_type = 'SCH_MSG_RECIEVER';
    EXCEPTION
      WHEN OTHERS THEN
        g_nty_users := NULL;
    END;

    v_past_days   := nvl(v_past_days, 0);
    v_future_days := nvl(v_future_days, 10);

    g_start_date := v_curr_date - v_past_days;
    g_end_date   := v_curr_date + v_future_days;
    --dbms_output.put_line('g_start_date...'||g_start_date);
    --dbms_output.put_line('g_end_date...'||g_end_date);
    --base port
    BEGIN
      SELECT base_port INTO g_base_port FROM sys_param WHERE rownum = 1;
      IF g_base_port IS NULL THEN
        g_base_port := 'HKG';
        schedule_log('',
                     'Please maintain the base port in system parameter ,now it default to ''HKG''',
                     'E');
      END IF;
    EXCEPTION
      WHEN no_data_found THEN
        g_base_port := 'HKG';
        schedule_log('',
                     'Please maintain the base port in system parameter ,now it default to ''HKG''',
                     'E');
    END;
  END;

  FUNCTION fun_get_valid_date(p_start_date IN OUT DATE,
                              p_end_date IN OUT DATE) RETURN BOOLEAN IS
  BEGIN

    IF p_start_date > g_end_date OR p_end_date < g_start_date THEN
      RETURN FALSE;
    END IF;

    IF p_start_date < g_start_date THEN
      p_start_date := g_start_date;
    END IF;
    IF p_end_date > g_end_date THEN
      p_end_date := g_end_date;
    END IF;

    RETURN TRUE;
  END;

  PROCEDURE pro_get_create_date(p_start_date IN DATE, p_end_date IN DATE, p_flt_key IN VARCHAR2, p_cr_date IN DATE, p_tr_no IN VARCHAR2) IS
    v_curr_date  DATE;
    v_start_date DATE;
    v_end_date   DATE;
    v_ssm_cnt number;
  BEGIN
  --dbms_output.put_line('inside get create date...'||p_start_date || '.....'||p_end_date);
    v_start_date := p_start_date;
    v_end_date   := p_end_date;
    g_cur_date.delete;
    
    IF NOT fun_get_valid_date(v_start_date, v_end_date) THEN
      dbms_output.put_line('invalid dates');
      RETURN;
    END IF;
    v_curr_date := v_start_date;
    LOOP
      EXIT WHEN v_curr_date > v_end_date;
      
        begin
    		 SELECT COUNT(1) INTO v_ssm_cnt FROM SSM_FLT_SCH_LOG WHERE FLT_KEY=p_flt_key AND FLT_DATE=v_curr_date AND 
            SSM_TYPE in ('SSMCNL', 'SSMCNLNEW','ASMCNL') AND  CR_DATE > p_cr_date;  
      exception
       when no_data_found then
        begin
          select count(1) into v_ssm_cnt from ssm_flt_sch_log where flt_sch_tr_no=p_tr_no and flt_date=v_curr_date and ssm_type not in ('ASMRPL','ASMTIM');
        exception
        when no_data_found then
         begin
        select count(1) into v_ssm_cnt from ssm_flt_sch_log where ssm_type in('ASMRPL','ASMTIM') and flt_date=v_curr_date and cr_date>p_cr_date;
        exception
        when no_data_found then
          v_ssm_cnt := 0;
          end;
        end;
      end;
      
      
      IF (substr(g_cc_sch.dat_flg, to_number(to_char(v_curr_date, 'D')), 1) = 'Y' AND v_ssm_cnt = 0) THEN
        g_cur_date.EXTEND;
        g_cur_date(g_cur_date.COUNT) := v_curr_date;

        --dbms_output.put_line('valid date...'||v_curr_date);

      END IF;
      v_curr_date := v_curr_date + 1;
    END LOOP;
  END;

  PROCEDURE pro_del_invalid_flight(p_tr_no IN VARCHAR2) IS
  BEGIN
    INSERT INTO edi_perfo_test VALUES ('p_tr_no ::'||p_tr_no);
	update flt_opr set LM_USER_ID = 'SYSTEM' , TR_TYPE = 'MTDFL' WHERE tr_no = p_tr_no;
    DELETE FROM flt_opr_seg WHERE tr_no = p_tr_no;
    DELETE FROM flt_opr_leg WHERE tr_no = p_tr_no;
    DELETE FROM flt_opr WHERE tr_no = p_tr_no;
    DELETE FROM FLT_OPR_EVENTS WHERE tr_no = p_tr_no;
  END;

  PROCEDURE pro_trn_del_invalid_flight(p_tr_no IN VARCHAR2) IS
  BEGIN
    INSERT INTO edi_perfo_test VALUES ('p_tr_no ::'||p_tr_no);
    Delete From Trn_Flt_Opr_Seg Where Tr_No = P_Tr_No;
    Delete From Trn_Flt_Opr_Leg Where Tr_No = P_Tr_No;
    Delete From Trn_Flt_Opr Where Tr_No = P_Tr_No;
    Delete From trn_Flt_Opr_Events Where Tr_No = P_Tr_No;
  END;

  FUNCTION fun_ins_flt_opr(p_flt_opr flt_opr%ROWTYPE,
                           p_tr_no IN OUT VARCHAR2, p_type IN VARCHAR2) RETURN BOOLEAN IS
    v_cgo_acft_type varchar2(3);
    
    v_flt_module1 varchar2(15);
    
    v_flt_module2 varchar2(15);
  BEGIN
    SELECT flt_opr_seq.NEXTVAL INTO p_tr_no FROM dual;
    
    v_cgo_acft_type := g_cc_sch.cgo_acft_type;
    if v_cgo_acft_type is null then
      if p_flt_opr.acft_type in ('74F', '74N') or g_cc_sch.carr_code = 'LD' then
        v_cgo_acft_type := 'FRE';
      else 
        v_cgo_acft_type := 'PSR';
      end if;
    end if;
    
    if p_type = 'A' then
      v_flt_module1 := G_CC_SCH.FLT_MODULE1;
      v_flt_module2 := G_CC_SCH.FLT_MODULE2;
    elsif p_type = 'D' then
      v_flt_module1 := G_CC_SCH.EXP_FLT_MODULE1;
      v_flt_module2 := G_CC_SCH.EXP_FLT_MODULE2;
    else 
      v_flt_module1 := G_CC_SCH.FLT_MODULE1;
      v_flt_module2 := G_CC_SCH.FLT_MODULE2;
    end if;
    
    INSERT INTO flt_opr
      (tr_no, carr_code, flt_no, flt_key, org_flt_date, sch_date,
       sch_time, flt_type, acft_type, orig, orig_date, orig_time, dest,
       dest_date, dest_time, day_diff, jv_code, jnt_flt_ind, tr_status,
       cr_user_id, cr_date, lm_user_id, lm_date, sch_trno, sch_man_yn,
       prty_ind, ground_handler, cgo_acft_type, svc_type, wh_level,
       brkbup_off, flt_module1, flt_module2, chkout_area, to_ind,mhcssend_yn,rho_id,VESSEL_ID ,
      VESSEL_NAME ,VOYAGE_NUM ,CALL_SIGN_VESSEL ,SHIPPING_AGENT)
    VALUES
      (p_tr_no, g_cc_sch.carr_code, g_cc_sch.flt_no, g_cc_sch.flt_key,
       p_flt_opr.org_flt_date, p_flt_opr.sch_date, p_flt_opr.sch_time,
       p_flt_opr.flt_type, p_flt_opr.acft_type, p_flt_opr.orig,
       p_flt_opr.orig_date, p_flt_opr.orig_time, p_flt_opr.dest,
       p_flt_opr.dest_date, p_flt_opr.dest_time, p_flt_opr.day_diff,
       g_cc_sch.jv_code, p_flt_opr.jnt_flt_ind, 'N', cdefaultuser, SYSDATE,
       cdefaultuser, SYSDATE, g_cc_sch.tr_no, 'N', 0, 'CPT',
       v_cgo_acft_type, g_cc_sch.svc_type, g_cc_sch.wh_level,
       G_CC_SCH.BRKBUP_OFF, v_flt_module1, v_flt_module2, G_CC_SCH.CHKOUT_AREA, G_CC_SCH.TO_IND,'N',g_cc_sch.rho_id,
	   g_cc_sch.VESSEL_ID, g_cc_sch.VESSEL_NAME, g_cc_sch.VOYAGE_NUM , g_cc_sch.CALL_SIGN_VESSEL, g_cc_sch.SHIPPING_AGENT );
	   
	   BEGIN
	   insert into FLT_OPR_AIRLINE (SELECT p_tr_no,CARR_CODE,FLT_KEY,cdefaultuser, SYSDATE,cdefaultuser, SYSDATE FROM FLT_sch_AIRLINE where tr_no = g_cc_sch.tr_no);
	   EXCEPTION
		WHEN OTHERS THEN
		  RETURN TRUE;
	   END;
  
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;

  FUNCTION fun_ins_flt_opr_trn(p_flt_opr flt_opr%ROWTYPE,
                           p_tr_no IN OUT VARCHAR2, p_type IN VARCHAR2) RETURN BOOLEAN IS
      v_cgo_acft_type varchar2(3);
	  v_flt_module1 varchar2(15);    
	  v_flt_module2 varchar2(15);
  BEGIN
     SELECT FLT_OPR_SEQ.NEXTVAL INTO P_TR_NO FROM DUAL;
     SELECT TRN_FLT_SUFFIX INTO V_TRN_FLT_SFX FROM SYS_PARAM;
     
    v_cgo_acft_type := g_cc_sch.cgo_acft_type;
    if v_cgo_acft_type is null then
      if p_flt_opr.acft_type in ('74F', '74N') or g_cc_sch.carr_code = 'LD' then
        v_cgo_acft_type := 'FRE';
      else 
        v_cgo_acft_type := 'PSR';
      end if;
    end if;
	
	if p_type = 'A' then
      v_flt_module1 := G_CC_SCH.FLT_MODULE1;
      v_flt_module2 := G_CC_SCH.FLT_MODULE2;
    elsif p_type = 'D' then
      v_flt_module1 := G_CC_SCH.EXP_FLT_MODULE1;
      v_flt_module2 := G_CC_SCH.EXP_FLT_MODULE2;
    else 
      v_flt_module1 := G_CC_SCH.FLT_MODULE1;
      v_flt_module2 := G_CC_SCH.FLT_MODULE2;
    end if;
    
    -- Create flight with suffix V_TRN_FLT_SFX, for transition.
    INSERT INTO flt_opr
      (tr_no, carr_code, flt_no, flt_key, org_flt_date, sch_date,
       sch_time, flt_type, acft_type, orig, orig_date, orig_time, dest,
       dest_date, dest_time, day_diff, jv_code, jnt_flt_ind, tr_status,
       cr_user_id, cr_date, lm_user_id, lm_date, sch_trno, sch_man_yn,
       prty_ind, ground_handler, cgo_acft_type, svc_type, wh_level,
       brkbup_off, flt_module1, flt_module2, chkout_area, to_ind,mhcssend_yn,rho_id,
       VESSEL_ID,VESSEL_NAME ,VOYAGE_NUM ,CALL_SIGN_VESSEL ,SHIPPING_AGENT)
    VALUES
      (p_tr_no, g_cc_sch.carr_code, g_cc_sch.flt_no||V_TRN_FLT_SFX, g_cc_sch.flt_key||V_TRN_FLT_SFX,
       p_flt_opr.org_flt_date, p_flt_opr.sch_date, p_flt_opr.sch_time,
       p_flt_opr.flt_type, p_flt_opr.acft_type, p_flt_opr.orig,
       p_flt_opr.orig_date, p_flt_opr.orig_time, p_flt_opr.dest,
       p_flt_opr.dest_date, p_flt_opr.dest_time, p_flt_opr.day_diff,
       g_cc_sch.jv_code, p_flt_opr.jnt_flt_ind, 'N', cdefaultuser, SYSDATE,
       cdefaultuser, SYSDATE, g_cc_sch.tr_no, 'N', 0, 'CPT',
       v_cgo_acft_type, G_CC_SCH.SVC_TYPE, G_CC_SCH.WH_LEVEL,
       g_cc_sch.brkbup_off, v_flt_module1, v_flt_module2, g_cc_sch.chkout_area, g_cc_sch.to_ind,'N',g_cc_sch.rho_id,
	   g_cc_sch.VESSEL_ID, g_cc_sch.VESSEL_NAME, g_cc_sch.VOYAGE_NUM , g_cc_sch.CALL_SIGN_VESSEL, g_cc_sch.SHIPPING_AGENT );
	   
	   BEGIN
	   insert into FLT_OPR_AIRLINE (SELECT p_tr_no,CARR_CODE,FLT_KEY,cdefaultuser, SYSDATE,cdefaultuser, SYSDATE FROM FLT_sch_AIRLINE where tr_no = g_cc_sch.tr_no);
	   EXCEPTION
		WHEN OTHERS THEN
		  RETURN TRUE;
	   END;
	   
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  End;

  --- insert into trn_flt_opr during transition
  FUNCTION fun_ins_trn_flt_opr(p_flt_opr flt_opr%ROWTYPE,
                           p_tr_no IN OUT VARCHAR2, p_type IN VARCHAR2) RETURN BOOLEAN IS
      v_cgo_acft_type varchar2(3);
	  v_flt_module1 varchar2(15);    
	  v_flt_module2 varchar2(15);
  Begin
    Select Trn_Flt_Opr_Seq.Nextval Into P_Tr_No From Dual;

    v_cgo_acft_type := g_cc_sch.cgo_acft_type;
    if v_cgo_acft_type is null then
      if p_flt_opr.acft_type in ('74F', '74N') or g_cc_sch.carr_code = 'LD' then
        v_cgo_acft_type := 'FRE';
      else 
        v_cgo_acft_type := 'PSR';
      end if;
    end if;
	
	if p_type = 'A' then
      v_flt_module1 := G_CC_SCH.FLT_MODULE1;
      v_flt_module2 := G_CC_SCH.FLT_MODULE2;
    elsif p_type = 'D' then
      v_flt_module1 := G_CC_SCH.EXP_FLT_MODULE1;
      v_flt_module2 := G_CC_SCH.EXP_FLT_MODULE2;
    else 
      v_flt_module1 := G_CC_SCH.FLT_MODULE1;
      v_flt_module2 := G_CC_SCH.FLT_MODULE2;
    end if;

    INSERT INTO trn_flt_opr
      (tr_no, carr_code, flt_no, flt_key, org_flt_date, sch_date,
       sch_time, flt_type, acft_type, orig, orig_date, orig_time, dest,
       dest_date, dest_time, day_diff, jv_code, jnt_flt_ind, tr_status,
       cr_user_id, cr_date, lm_user_id, lm_date, sch_trno, sch_man_yn,
       prty_ind, ground_handler, cgo_acft_type, svc_type, wh_level,
       brkbup_off, flt_module1, flt_module2, chkout_area, to_ind,mhcssend_yn)
    VALUES
      (p_tr_no, g_cc_sch.carr_code, g_cc_sch.flt_no, g_cc_sch.flt_key,
       p_flt_opr.org_flt_date, p_flt_opr.sch_date, p_flt_opr.sch_time,
       p_flt_opr.flt_type, p_flt_opr.acft_type, p_flt_opr.orig,
       p_flt_opr.orig_date, p_flt_opr.orig_time, p_flt_opr.dest,
       p_flt_opr.dest_date, p_flt_opr.dest_time, p_flt_opr.day_diff,
       g_cc_sch.jv_code, p_flt_opr.jnt_flt_ind, 'N', cdefaultuser, SYSDATE,
       cdefaultuser, SYSDATE, g_cc_sch.tr_no, 'N', 0, 'CPT',
       v_cgo_acft_type, g_cc_sch.svc_type, g_cc_sch.wh_level,
       G_CC_SCH.BRKBUP_OFF, v_flt_module1, v_flt_module2, G_CC_SCH.CHKOUT_AREA, G_CC_SCH.TO_IND,'N');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Return False;
  END;

  FUNCTION fun_ins_flt_leg(p_tr_no IN VARCHAR2, p_flt_date DATE,
                           p_flt_opr_leg IN t_flt_opr_leg, p_sch_date DATE) RETURN BOOLEAN IS
    v_cnt NUMBER;
  BEGIN
    v_cnt := p_flt_opr_leg.COUNT;
    IF nvl(v_cnt, 0) = 0 THEN
      RETURN FALSE;
    END IF;
    FOR x IN 1 .. v_cnt LOOP
    --dbms_output.put_line('leg data..'||p_flt_opr_leg(x).flt_key||'...'||p_flt_opr_leg(x).flt_type||'....'||to_char(p_sch_date + p_flt_opr_leg(x).cgo_vol, 'DDMONYY')||'...'||p_flt_opr_leg(x).brd_point);
      INSERT INTO flt_opr_leg
        (tr_no, doc_line_no, carr_code, flt_no, flt_key, flt_type,
         org_flt_date, sch_date, brd_point, off_point, leg_ord,
         sch_dep_date, sch_dep_time, sch_arr_date, sch_arr_time,
         dom_flt_flg, day_diff, cgo_wgt, cgo_vol, no_of_plt, used_plt,
         acft_reg_no, acft_type, jnt_car_1, jnt_flt_1, jnt_car_2,
         jnt_flt_2, jnt_car_3, jnt_flt_3, jnt_car_4, jnt_flt_4, jnt_car_5,
         jnt_flt_5, jnt_car_6, jnt_flt_6, uow, uov, cgo_wgt_lbs,
         leg_status, tr_status, cr_user_id, cr_date, lm_user_id, lm_date, hse_bu_ind, auto_assgn_uld, prohibit_shc1, prohibit_shc2, prohibit_shc3)
      VALUES
        (p_tr_no, flt_oprlegline_seq.NEXTVAL, p_flt_opr_leg(x).carr_code,
         p_flt_opr_leg(x).flt_no, p_flt_opr_leg(x).flt_key,
         p_flt_opr_leg(x).flt_type, p_sch_date, p_flt_date,
         p_flt_opr_leg(x).brd_point, p_flt_opr_leg(x).off_point, x,
         p_sch_date + p_flt_opr_leg(x).cgo_vol,
         p_flt_opr_leg(x).sch_dep_time,
         p_sch_date + p_flt_opr_leg(x).cgo_wgt,
         p_flt_opr_leg(x).sch_arr_time, p_flt_opr_leg(x).dom_flt_flg, NULL,
         NULL, NULL, NULL, NULL, NULL, p_flt_opr_leg(x).acft_type,
         p_flt_opr_leg(x).jnt_car_1, p_flt_opr_leg(x).jnt_flt_1,
         p_flt_opr_leg(x).jnt_car_2, p_flt_opr_leg(x).jnt_flt_2,
         p_flt_opr_leg(x).jnt_car_3, p_flt_opr_leg(x).jnt_flt_3,
         p_flt_opr_leg(x).jnt_car_4, p_flt_opr_leg(x).jnt_flt_4,
         p_flt_opr_leg(x).jnt_car_5, p_flt_opr_leg(x).jnt_flt_5,
         p_flt_opr_leg(x).jnt_car_6, p_flt_opr_leg(x).jnt_flt_6,
         p_flt_opr_leg(x).uow, p_flt_opr_leg(x).uov,
         p_flt_opr_leg(x).cgo_wgt_lbs, p_flt_opr_leg(x).leg_status,
         p_flt_opr_leg(x).tr_status, p_flt_opr_leg(x).cr_user_id,
         p_flt_opr_leg(x).cr_date, p_flt_opr_leg(x).lm_user_id,
         p_flt_opr_leg(x).lm_date, nvl(p_flt_opr_leg(x).hse_bu_ind,'N'), nvl(p_flt_opr_leg(x).auto_assgn_uld,'N'),
         p_flt_opr_leg(x).prohibit_shc1,p_flt_opr_leg(x).prohibit_shc2,p_flt_opr_leg(x).prohibit_shc3);
    END LOOP;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN      
      RETURN FALSE;
  END;

  -- Create flight leg with suffix V_TRN_FLT_SFX, for transition.
  FUNCTION fun_ins_flt_leg_trn(p_tr_no IN VARCHAR2, p_flt_date DATE,
                           p_flt_opr_leg IN t_flt_opr_leg, p_sch_date DATE) RETURN BOOLEAN IS
    v_cnt NUMBER;
  BEGIN
    v_cnt := p_flt_opr_leg.COUNT;
    IF nvl(v_cnt, 0) = 0 THEN
      RETURN FALSE;
    END IF;
    
    SELECT TRN_FLT_SUFFIX INTO V_TRN_FLT_SFX FROM SYS_PARAM;
    
    FOR x IN 1 .. v_cnt LOOP
      INSERT INTO FLT_OPR_LEG
        (tr_no, doc_line_no, carr_code, flt_no, flt_key, flt_type,
         org_flt_date, sch_date, brd_point, off_point, leg_ord,
         sch_dep_date, sch_dep_time, sch_arr_date, sch_arr_time,
         dom_flt_flg, day_diff, cgo_wgt, cgo_vol, no_of_plt, used_plt,
         acft_reg_no, acft_type, jnt_car_1, jnt_flt_1, jnt_car_2,
         jnt_flt_2, jnt_car_3, jnt_flt_3, jnt_car_4, jnt_flt_4, jnt_car_5,
         jnt_flt_5, jnt_car_6, jnt_flt_6, uow, uov, cgo_wgt_lbs,
         leg_status, tr_status, cr_user_id, cr_date, lm_user_id, lm_date, hse_bu_ind, auto_assgn_uld, prohibit_shc1, prohibit_shc2, prohibit_shc3)
      VALUES
        (p_tr_no, flt_oprlegline_seq.NEXTVAL, p_flt_opr_leg(x).carr_code,
         p_flt_opr_leg(x).flt_no||V_TRN_FLT_SFX, p_flt_opr_leg(x).flt_key||V_TRN_FLT_SFX,
         p_flt_opr_leg(x).flt_type, p_sch_date, p_flt_date,
         p_flt_opr_leg(x).brd_point, p_flt_opr_leg(x).off_point, x,
         p_sch_date + p_flt_opr_leg(x).cgo_vol,
         p_flt_opr_leg(x).sch_dep_time,
         p_sch_date + p_flt_opr_leg(x).cgo_wgt,
         p_flt_opr_leg(x).sch_arr_time, p_flt_opr_leg(x).dom_flt_flg, NULL,
         NULL, NULL, NULL, NULL, NULL, p_flt_opr_leg(x).acft_type,
         p_flt_opr_leg(x).jnt_car_1, p_flt_opr_leg(x).jnt_flt_1,
         p_flt_opr_leg(x).jnt_car_2, p_flt_opr_leg(x).jnt_flt_2,
         p_flt_opr_leg(x).jnt_car_3, p_flt_opr_leg(x).jnt_flt_3,
         p_flt_opr_leg(x).jnt_car_4, p_flt_opr_leg(x).jnt_flt_4,
         p_flt_opr_leg(x).jnt_car_5, p_flt_opr_leg(x).jnt_flt_5,
         p_flt_opr_leg(x).jnt_car_6, p_flt_opr_leg(x).jnt_flt_6,
         p_flt_opr_leg(x).uow, p_flt_opr_leg(x).uov,
         p_flt_opr_leg(x).cgo_wgt_lbs, p_flt_opr_leg(x).leg_status,
         p_flt_opr_leg(x).tr_status, p_flt_opr_leg(x).cr_user_id,
         p_flt_opr_leg(x).cr_date, p_flt_opr_leg(x).lm_user_id,
         P_FLT_OPR_LEG(X).LM_DATE, NVL(P_FLT_OPR_LEG(X).HSE_BU_IND,'N'), NVL(P_FLT_OPR_LEG(X).auto_assgn_uld,'N'),
         p_flt_opr_leg(x).prohibit_shc1,p_flt_opr_leg(x).prohibit_shc2,p_flt_opr_leg(x).prohibit_shc3);
    END LOOP;
    RETURN TRUE;
  --EXCEPTION
    --WHEN OTHERS THEN
      --RETURN FALSE;
  END;

  -- c=insert into trn_flt_opr_leg
  FUNCTION fun_ins_trn_flt_leg(p_tr_no IN VARCHAR2, p_flt_date DATE,
                           p_flt_opr_leg IN t_flt_opr_leg, p_sch_date DATE) RETURN BOOLEAN IS
    v_cnt NUMBER;
  BEGIN
    v_cnt := p_flt_opr_leg.COUNT;
    IF nvl(v_cnt, 0) = 0 THEN
      RETURN FALSE;
    END IF;
    For X In 1 .. V_Cnt Loop
      INSERT INTO trn_flt_opr_leg
        (tr_no, doc_line_no, carr_code, flt_no, flt_key, flt_type,
         org_flt_date, sch_date, brd_point, off_point, leg_ord,
         sch_dep_date, sch_dep_time, sch_arr_date, sch_arr_time,
         dom_flt_flg, day_diff, cgo_wgt, cgo_vol, no_of_plt, used_plt,
         acft_reg_no, acft_type, jnt_car_1, jnt_flt_1, jnt_car_2,
         jnt_flt_2, jnt_car_3, jnt_flt_3, jnt_car_4, jnt_flt_4, jnt_car_5,
         jnt_flt_5, jnt_car_6, jnt_flt_6, uow, uov, cgo_wgt_lbs,
         leg_status, tr_status, cr_user_id, cr_date, lm_user_id, lm_date, hse_bu_ind, prohibit_shc1, prohibit_shc2, prohibit_shc3)
      VALUES
        (p_tr_no, TRN_FLT_OPRLEGLINE_SEQ.NEXTVAL, p_flt_opr_leg(x).carr_code,
         p_flt_opr_leg(x).flt_no, p_flt_opr_leg(x).flt_key,
         p_flt_opr_leg(x).flt_type, p_sch_date, p_flt_date,
         p_flt_opr_leg(x).brd_point, p_flt_opr_leg(x).off_point, x,
         p_sch_date + p_flt_opr_leg(x).cgo_vol,
         p_flt_opr_leg(x).sch_dep_time,
         p_sch_date + p_flt_opr_leg(x).cgo_wgt,
         p_flt_opr_leg(x).sch_arr_time, p_flt_opr_leg(x).dom_flt_flg, NULL,
         NULL, NULL, NULL, NULL, NULL, p_flt_opr_leg(x).acft_type,
         p_flt_opr_leg(x).jnt_car_1, p_flt_opr_leg(x).jnt_flt_1,
         p_flt_opr_leg(x).jnt_car_2, p_flt_opr_leg(x).jnt_flt_2,
         p_flt_opr_leg(x).jnt_car_3, p_flt_opr_leg(x).jnt_flt_3,
         p_flt_opr_leg(x).jnt_car_4, p_flt_opr_leg(x).jnt_flt_4,
         p_flt_opr_leg(x).jnt_car_5, p_flt_opr_leg(x).jnt_flt_5,
         p_flt_opr_leg(x).jnt_car_6, p_flt_opr_leg(x).jnt_flt_6,
         p_flt_opr_leg(x).uow, p_flt_opr_leg(x).uov,
         p_flt_opr_leg(x).cgo_wgt_lbs, p_flt_opr_leg(x).leg_status,
         p_flt_opr_leg(x).tr_status, p_flt_opr_leg(x).cr_user_id,
         p_flt_opr_leg(x).cr_date, p_flt_opr_leg(x).lm_user_id,
         p_flt_opr_leg(x).lm_date, nvl(p_flt_opr_leg(x).hse_bu_ind,'N'),
         p_flt_opr_leg(x).prohibit_shc1,p_flt_opr_leg(x).prohibit_shc2,p_flt_opr_leg(x).prohibit_shc3);
    END LOOP;
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Return False;
  END;

  FUNCTION fun_ins_flt_seg(p_tr_no IN VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DELETE FROM flt_opr_seg WHERE tr_no = p_tr_no;
    INSERT INTO flt_opr_seg
      (tr_no, doc_line_no, carr_code, flt_no, flt_key, flt_type,
       org_flt_date, sch_date, brd_point, off_point, seg_order,
       sch_dep_date, leg_flg, nfl_flg, tech_stp_flg, ffm_flg, arm_date,
       prty_ind, fin_flg, ffm_date, seg_status, tr_status, cr_user_id,
       cr_date, lm_user_id, lm_date)
      (SELECT p_tr_no, rownum, carr_code, flt_no, flt_key, flt_type,
              org_flt_date, sch_date, brd_point, off_point, rownum,
              sch_dep_date, leg_flg, NULL, 'N', NULL, NULL, NULL, NULL,
              NULL, NULL, 'N', cr_user_id, SYSDATE, lm_user_id, SYSDATE
         FROM (SELECT a.carr_code, a.flt_no, a.flt_key, a.flt_type,
                       a.org_flt_date, a.sch_date, a.brd_point, b.off_point,
                       a.leg_ord, a.sch_dep_date,
                       decode(a.off_point, b.off_point, 'Y', '') leg_flg,
                       a.cr_user_id, a.lm_user_id
                  FROM flt_opr_leg a, flt_opr_leg b
                 WHERE a.tr_no = b.tr_no
                   AND a.leg_ord <= b.leg_ord
                   AND a.tr_no = p_tr_no
                 ORDER BY a.leg_ord,
                          DECODE(A.OFF_POINT, B.OFF_POINT, 'Y', '')));
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;

  -- insert into trn_flt_opr_seg
  FUNCTION fun_ins_trn_flt_seg(p_tr_no IN VARCHAR2) RETURN BOOLEAN IS
  Begin
    Delete From Trn_Flt_Opr_Seg Where Tr_No = P_Tr_No;
    INSERT INTO trn_flt_opr_seg
      (tr_no, doc_line_no, carr_code, flt_no, flt_key, flt_type,
       org_flt_date, sch_date, brd_point, off_point, seg_order,
       sch_dep_date, leg_flg, nfl_flg, tech_stp_flg, ffm_flg, arm_date,
       prty_ind, fin_flg, ffm_date, seg_status, tr_status, cr_user_id,
       cr_date, lm_user_id, lm_date)
      (SELECT p_tr_no, rownum, carr_code, flt_no, flt_key, flt_type,
              org_flt_date, sch_date, brd_point, off_point, rownum,
              sch_dep_date, leg_flg, NULL, 'N', NULL, NULL, NULL, NULL,
              NULL, NULL, 'N', cr_user_id, SYSDATE, lm_user_id, SYSDATE
         FROM (SELECT a.carr_code, a.flt_no, a.flt_key, a.flt_type,
                       a.org_flt_date, a.sch_date, a.brd_point, b.off_point,
                       a.leg_ord, a.sch_dep_date,
                       decode(a.off_point, b.off_point, 'Y', '') leg_flg,
                       A.Cr_User_Id, A.Lm_User_Id
                  FROM trn_flt_opr_leg a, trn_flt_opr_leg b
                 WHERE a.tr_no = b.tr_no
                   AND a.leg_ord <= b.leg_ord
                   AND a.tr_no = p_tr_no
                 ORDER BY a.leg_ord,
                          DECODE(A.OFF_POINT, B.OFF_POINT, 'Y', '')));
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Return False;
  END;

  FUNCTION fun_ins_flt_seg_trn(p_tr_no IN VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    DELETE FROM flt_opr_seg WHERE tr_no = p_tr_no;
    -- Create flight leg with suffix V_TRN_FLT_SFX, for transition.
    INSERT INTO flt_opr_seg
      (tr_no, doc_line_no, carr_code, flt_no, flt_key, flt_type,
       org_flt_date, sch_date, brd_point, off_point, seg_order,
       sch_dep_date, leg_flg, nfl_flg, tech_stp_flg, ffm_flg, arm_date,
       prty_ind, fin_flg, ffm_date, seg_status, tr_status, cr_user_id,
       CR_DATE, LM_USER_ID, LM_DATE)
      (SELECT p_tr_no, rownum, carr_code, flt_no, flt_key, flt_type,
              org_flt_date, sch_date, brd_point, off_point, rownum,
              sch_dep_date, leg_flg, NULL, 'N', NULL, NULL, NULL, NULL,
              NULL, NULL, 'N', cr_user_id, SYSDATE, lm_user_id, SYSDATE
         FROM (SELECT a.carr_code, a.flt_no, a.flt_key, a.flt_type,
                       a.org_flt_date, a.sch_date, a.brd_point, b.off_point,
                       a.leg_ord, a.sch_dep_date,
                       decode(a.off_point, b.off_point, 'Y', '') leg_flg,
                       a.cr_user_id, a.lm_user_id
                  FROM flt_opr_leg a, flt_opr_leg b
                 WHERE a.tr_no = b.tr_no
                   AND A.LEG_ORD <= B.LEG_ORD
                   AND a.tr_no = p_tr_no
                 ORDER BY A.LEG_ORD,
                          DECODE(A.OFF_POINT, B.OFF_POINT, 'Y', '')));
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN FALSE;
  END;

  FUNCTION fun_create_it(p_flt_key IN VARCHAR2, p_flt_date IN VARCHAR2,
                         p_type IN VARCHAR2) RETURN BOOLEAN IS
    v_flg VARCHAR2(1);
  BEGIN
    SELECT 'Y'
      INTO v_flg
      FROM flt_opr a
     WHERE a.flt_key = p_flt_key
       AND a.sch_date = p_flt_date
       AND a.flt_type = p_type
       AND rownum = 1;
    RETURN FALSE;
  EXCEPTION
    WHEN no_data_found THEN
      RETURN TRUE;
  END;

  FUNCTION fun_check_arch_exists(p_flt_key IN VARCHAR2, p_flt_date IN VARCHAR2,
                         p_type IN VARCHAR2) RETURN BOOLEAN IS
    v_flg VARCHAR2(1);
  BEGIN
    SELECT 'Y'
      INTO v_flg
      FROM ARCHIVE_LOG_MON
     WHERE flt_key = p_flt_key
       AND flt_date = p_flt_date
       AND flt_type = p_type
       AND archive_type='FLIGHT'
       AND rownum = 1;
    RETURN FALSE;
  EXCEPTION
    WHEN no_data_found THEN
      RETURN TRUE;
  END;
  

  FUNCTION fun_create_it_trn(p_flt_key IN VARCHAR2, p_flt_date IN VARCHAR2,
                         p_type IN VARCHAR2) RETURN BOOLEAN IS
    v_flg VARCHAR2(1);
  BEGIN
    SELECT 'Y'
      Into V_Flg
      FROM trn_flt_opr a
     WHERE a.flt_key = p_flt_key
       AND a.sch_date = p_flt_date
       AND a.flt_type = p_type
       AND rownum = 1;
    RETURN FALSE;
  EXCEPTION
    WHEN no_data_found THEN
      Return True;
  END;

  FUNCTION fun_issurport RETURN BOOLEAN IS
    v_arr_cnt NUMBER;
    v_dep_cnt NUMBER;
  BEGIN
  --dbms_output.put_line('g_cc_sch.tr_no.. '||g_cc_sch.tr_no);
    SELECT SUM(decode(brd_point, g_base_port, 1, 0)),
           SUM(decode(off_point, g_base_port, 1, 0))
      INTO v_dep_cnt, v_arr_cnt
      FROM flt_sch_leg
     WHERE tr_no = g_cc_sch.tr_no;
     --dbms_output.put_line('v_dep_cnt.. '||v_dep_cnt ||', v_arr_cnt..'||v_arr_cnt);
    IF v_dep_cnt > 1 OR v_arr_cnt > 1 THEN
      schedule_log(NULL, 'do not surport this flight master.', 'E');
      RETURN FALSE;
    END IF;
    IF v_dep_cnt = 0 AND v_arr_cnt = 0 THEN
      schedule_log(NULL, 'do not surport this flight master.', 'E');
      RETURN FALSE;
    END IF;
   -- dbms_output.put_line('fun_issurport.. RETURN TRUE');
    RETURN TRUE;
  END;

  FUNCTION fun_get_schedule_leg(p_tr_no IN VARCHAR2, p_type IN VARCHAR2)
    RETURN t_flt_opr_leg IS
    v_leg_order     NUMBER;
    v_t_flt_opr_leg t_flt_opr_leg;
    cc_leg          cursor_t;
    v_sql           VARCHAR2(4000);
    v_rec_row       flt_opr_leg%ROWTYPE;
    v_day_change    NUMBER;
  BEGIN

    v_t_flt_opr_leg := t_flt_opr_leg();

    v_sql := 'SELECT tr_no, doc_line_no, carr_code, flt_no, flt_key, ''A'',
                     trunc(sysdate),trunc(sysdate), brd_point, off_point, leg_order,
                     trunc(sysdate), sch_dep_time, trunc(sysdate), sch_arr_time, dom_flg,
                     0, nvl(arr_day_change,0), nvl(dep_day_change,0), no_of_plt, 0, NULL, acft_type,
                     (select jnt_car_1 from flt_sch_leg_jnt where tr_no = flt_sch_leg.tr_no and doc_line_no = flt_sch_leg.doc_line_no and rownum = 1) as jnt_car_1,
                     (select jnt_flt_1 from flt_sch_leg_jnt where tr_no = flt_sch_leg.tr_no and doc_line_no = flt_sch_leg.doc_line_no and rownum = 1) as jnt_flt_1,
                     (select jnt_car_2 from flt_sch_leg_jnt where tr_no = flt_sch_leg.tr_no and doc_line_no = flt_sch_leg.doc_line_no and rownum = 1) as jnt_car_2,
                     (select jnt_flt_2 from flt_sch_leg_jnt where tr_no = flt_sch_leg.tr_no and doc_line_no = flt_sch_leg.doc_line_no and rownum = 1) as jnt_flt_2,
                     (select jnt_car_3 from flt_sch_leg_jnt where tr_no = flt_sch_leg.tr_no and doc_line_no = flt_sch_leg.doc_line_no and rownum = 1) as jnt_car_3,
                     (select jnt_flt_3 from flt_sch_leg_jnt where tr_no = flt_sch_leg.tr_no and doc_line_no = flt_sch_leg.doc_line_no and rownum = 1) as jnt_flt_3,
                     (select jnt_car_4 from flt_sch_leg_jnt where tr_no = flt_sch_leg.tr_no and doc_line_no = flt_sch_leg.doc_line_no and rownum = 1) as jnt_car_4,
                     (select jnt_flt_4 from flt_sch_leg_jnt where tr_no = flt_sch_leg.tr_no and doc_line_no = flt_sch_leg.doc_line_no and rownum = 1) as jnt_flt_4,
                     (select jnt_car_5 from flt_sch_leg_jnt where tr_no = flt_sch_leg.tr_no and doc_line_no = flt_sch_leg.doc_line_no and rownum = 1) as jnt_car_5,
                     (select jnt_flt_5 from flt_sch_leg_jnt where tr_no = flt_sch_leg.tr_no and doc_line_no = flt_sch_leg.doc_line_no and rownum = 1) as jnt_flt_5,
                     (select jnt_car_6 from flt_sch_leg_jnt where tr_no = flt_sch_leg.tr_no and doc_line_no = flt_sch_leg.doc_line_no and rownum = 1) as jnt_car_6,
                     (select jnt_flt_6 from flt_sch_leg_jnt where tr_no = flt_sch_leg.tr_no and doc_line_no = flt_sch_leg.doc_line_no and rownum = 1) as jnt_flt_6,
                     uow, uov,0,''N'',''N'',USER, SYSDATE, USER, SYSDATE, hse_bu_ind,
                     prohibit_shc1,prohibit_shc2,prohibit_shc3,AUTO_ASSGN_ULD, TR_TYPE
                FROM flt_sch_leg
               WHERE tr_no = :p_tr_no';

    IF cc_leg%ISOPEN THEN
      CLOSE cc_leg;
    END IF;

    IF p_type = 'A' THEN
      SELECT MAX(leg_order)
        INTO v_leg_order
        FROM flt_sch_leg
       WHERE tr_no = p_tr_no
         AND off_point = g_base_port;

      v_sql := v_sql || chr(13) || ' AND brd_point <> :v_base_port AND leg_order <= :v_leg_order
                 ORDER BY leg_order';
    ELSIF p_type = 'D' THEN
      SELECT MIN(leg_order)
        INTO v_leg_order
        FROM flt_sch_leg
       WHERE tr_no = p_tr_no
         AND brd_point = g_base_port;

      v_sql := v_sql || chr(13) || ' AND off_point <> :v_base_port AND leg_order >= :v_leg_order
                 ORDER BY leg_order';
    ELSE
      RETURN v_t_flt_opr_leg;
    END IF;

    OPEN cc_leg FOR v_sql
      USING p_tr_no, g_base_port, v_leg_order;

    LOOP
      FETCH cc_leg
        INTO v_rec_row;
      EXIT WHEN cc_leg%NOTFOUND;
      v_t_flt_opr_leg.EXTEND;
      v_rec_row.flt_type   := p_type;
      v_rec_row.lm_user_id := cdefaultuser;
      v_rec_row.cr_user_id := cdefaultuser;
      --join flight
      BEGIN
        SELECT jnt_car_1, jnt_flt_1, jnt_car_2, jnt_flt_2, jnt_car_3,
               jnt_flt_3, jnt_car_4, jnt_flt_4, jnt_car_5, jnt_flt_5,
               jnt_car_6, jnt_flt_6
          INTO v_rec_row.jnt_car_1, v_rec_row.jnt_flt_1,
               v_rec_row.jnt_car_2, v_rec_row.jnt_flt_2,
               v_rec_row.jnt_car_3, v_rec_row.jnt_flt_3,
               v_rec_row.jnt_car_4, v_rec_row.jnt_flt_4,
               v_rec_row.jnt_car_5, v_rec_row.jnt_flt_5,
               v_rec_row.jnt_car_6, v_rec_row.jnt_flt_6
          FROM flt_sch_leg_jnt
         WHERE tr_no = v_rec_row.tr_no
           AND ldoc_line_no = v_rec_row.doc_line_no
           AND rownum = 1;
      EXCEPTION
        WHEN no_data_found THEN
          NULL;
      END;

      v_t_flt_opr_leg(v_t_flt_opr_leg.COUNT) := v_rec_row;
    END LOOP;

    RETURN v_t_flt_opr_leg;
  END;

  FUNCTION fun_get_flt_opr(p_flt_opr_leg IN OUT t_flt_opr_leg)
    RETURN flt_opr%ROWTYPE IS
    v_flt_opr flt_opr%ROWTYPE;
    v_cnt     NUMBER;
  BEGIN
    v_flt_opr.jnt_flt_ind := 'N';

    v_flt_opr.flt_key := g_cc_sch.flt_key;

    v_flt_opr.orig      := p_flt_opr_leg(1).brd_point;
    v_flt_opr.orig_date := p_flt_opr_leg(1).sch_dep_date;
    v_flt_opr.orig_time := p_flt_opr_leg(1).sch_dep_time;

    v_cnt := p_flt_opr_leg.COUNT;

    v_flt_opr.dest      := p_flt_opr_leg(v_cnt).off_point;
    v_flt_opr.dest_date := p_flt_opr_leg(v_cnt).sch_arr_date;
    v_flt_opr.dest_time := p_flt_opr_leg(v_cnt).sch_arr_time;

    RETURN v_flt_opr;
  END;

  FUNCTION fun_create_daily_flight(p_flt_opr IN OUT flt_opr%ROWTYPE,
                                   p_flt_leg IN OUT t_flt_opr_leg,
                                   p_sch_date IN DATE, p_type IN VARCHAR2)
    RETURN BOOLEAN IS
    v_tr_no VARCHAR2(20);
    v_cnt   NUMBER;
  BEGIN
  --dbms_output.put_line('inside fun_create_daily_flight');
    v_cnt := p_flt_leg.COUNT;
    IF nvl(v_cnt, 0) <= 0 THEN
      RETURN TRUE;
    END IF;
--dbms_output.put_line('inside fun_create_daily_flight.. 1');
    IF p_type = 'A' THEN
    p_flt_opr.sch_date     := p_sch_date + nvl(p_flt_leg(v_cnt).cgo_wgt, 0);
    ELSE
    p_flt_opr.sch_date     := p_sch_date + nvl(p_flt_leg(1).cgo_vol, 0);
    END IF;

    --check need create again or not
    --dbms_output.put_line('inside fun_create_daily_flight.. 2');
    IF NOT fun_create_it(p_flt_opr.flt_key, p_flt_opr.sch_date, p_type) THEN      
      RETURN TRUE;
    END IF;
    
   IF NOT fun_check_arch_exists(p_flt_opr.flt_key, p_flt_opr.sch_date, p_type) THEN
     --schedule_log('', 'Cannot create Flight as the same Flight exists in Archival System.' || SYSDATE, p_type);
      RETURN TRUE;
    END IF;
    
    --dbms_output.put_line('inside fun_create_daily_flight.. 3');
    --update flight information
    p_flt_opr.org_flt_date := p_sch_date;
    p_flt_opr.flt_type     := p_type;

    p_flt_opr.jnt_flt_ind := 'N';
    p_flt_opr.orig        := p_flt_leg(1).brd_point;
    p_flt_opr.orig_date   := p_sch_date + nvl(p_flt_leg(1).cgo_vol, 0);

    p_flt_opr.dest      := p_flt_leg(v_cnt).off_point;
    p_flt_opr.dest_date := p_sch_date + nvl(p_flt_leg(v_cnt).cgo_wgt, 0);

    p_flt_opr.acft_type := p_flt_leg(1).acft_type;
    p_flt_opr.sch_time  := p_flt_opr.orig_time;
    IF p_type = 'A' THEN
      p_flt_opr.sch_time  := p_flt_opr.dest_time;
      p_flt_opr.acft_type := p_flt_leg(v_cnt).acft_type;
    END IF;

    --flight info
     --dbms_output.put_line('calling fun_ins_flt_opr..');
    IF NOT fun_ins_flt_opr(p_flt_opr, v_tr_no, p_type) THEN
      dbms_output.put_line('cannot insert into fun_ins_flt_opr..');
      RETURN FALSE;
    END IF;
    --leg info
     --dbms_output.put_line('calling fun_ins_flt_leg..');
    IF NOT fun_ins_flt_leg(v_tr_no, p_flt_opr.sch_date, p_flt_leg, p_sch_date) THEN
      pro_del_invalid_flight(v_tr_no);
      dbms_output.put_line('cannot insert into fun_ins_flt_leg..');
      RETURN FALSE;
    END IF;
    --segment info
    IF NOT fun_ins_flt_seg(v_tr_no) THEN
      pro_del_invalid_flight(v_tr_no);
      RETURN FALSE;
    END IF;

    RETURN TRUE;
  END;

  -- insert into trn_flt tables during transition
  FUNCTION fun_create_trn_daily_flight(p_flt_opr IN OUT flt_opr%ROWTYPE,
                                   p_flt_leg IN OUT t_flt_opr_leg,
                                   p_sch_date IN DATE, p_type IN VARCHAR2)
    RETURN BOOLEAN IS
    v_tr_no VARCHAR2(20);
    v_cnt   NUMBER;
  BEGIN
  --dbms_output.put_line('inside fun_create_trn_daily_flight');
    v_cnt := p_flt_leg.COUNT;
    IF nvl(v_cnt, 0) <= 0 THEN
      RETURN TRUE;
    END IF;
--dbms_output.put_line('inside fun_create_trn_daily_flight.. 1');
    IF p_type = 'A' THEN
    p_flt_opr.sch_date     := p_sch_date + nvl(p_flt_leg(v_cnt).cgo_wgt, 0);
    ELSE
    p_flt_opr.sch_date     := p_sch_date + nvl(p_flt_leg(1).cgo_vol, 0);
    END IF;

    --check need create again or not
    --dbms_output.put_line('inside fun_create_trn_daily_flight.. 2');
    IF NOT fun_create_it_trn(p_flt_opr.flt_key, p_flt_opr.sch_date, p_type) THEN
      RETURN TRUE;
    END IF;
    --dbms_output.put_line('inside fun_create_trn_daily_flight.. 3');
    --update flight information
    p_flt_opr.org_flt_date := p_sch_date;
    p_flt_opr.flt_type     := p_type;

    p_flt_opr.jnt_flt_ind := 'N';
    p_flt_opr.orig        := p_flt_leg(1).brd_point;
    p_flt_opr.orig_date   := p_sch_date + nvl(p_flt_leg(1).cgo_vol, 0);

    p_flt_opr.dest      := p_flt_leg(v_cnt).off_point;
    p_flt_opr.dest_date := p_sch_date + nvl(p_flt_leg(v_cnt).cgo_wgt, 0);

    p_flt_opr.acft_type := p_flt_leg(1).acft_type;
    p_flt_opr.sch_time  := p_flt_opr.orig_time;
    IF p_type = 'A' THEN
      p_flt_opr.sch_time  := p_flt_opr.dest_time;
      p_flt_opr.acft_type := p_flt_leg(v_cnt).acft_type;
    END IF;

    --flight info
     --dbms_output.put_line('calling fun_ins_trn_flt_opr..');
  IF NOT fun_ins_trn_flt_opr(p_flt_opr, v_tr_no,p_type) THEN
      dbms_output.put_line('cannot insert into fun_ins_trn_flt_opr..');
      RETURN FALSE;
    END IF;
    --leg info
     --Dbms_Output.Put_Line('calling fun_ins_trn_flt_leg..');
    IF NOT fun_ins_trn_flt_leg(v_tr_no, p_flt_opr.sch_date, p_flt_leg, p_sch_date) THEN
      pro_trn_del_invalid_flight(v_tr_no);
      dbms_output.put_line('cannot insert into fun_ins_trn_flt_leg..');
      RETURN FALSE;
    END IF;
    --segment info
    IF NOT fun_ins_trn_flt_seg(v_tr_no) THEN
      pro_trn_del_invalid_flight(v_tr_no);
      RETURN FALSE;
    END IF;

    Return True;
  END;

  -- insert int flt opr with suffix V_TRN_FLT_SFX during transition
  FUNCTION fun_create_daily_flight_trn(p_flt_opr IN OUT flt_opr%ROWTYPE,
                                   p_flt_leg IN OUT t_flt_opr_leg,
                                   p_sch_date IN DATE, p_type IN VARCHAR2)
    RETURN BOOLEAN IS
    v_tr_no VARCHAR2(20);
    v_cnt   NUMBER;
  BEGIN
 -- dbms_output.put_line('inside fun_create_daily_flight_trn');
    v_cnt := p_flt_leg.COUNT;
    IF nvl(v_cnt, 0) <= 0 THEN
      RETURN TRUE;
    END IF;
--dbms_output.put_line('inside fun_create_daily_flight_trn.. 1');
    IF p_type = 'A' THEN
    p_flt_opr.sch_date     := p_sch_date + nvl(p_flt_leg(v_cnt).cgo_wgt, 0);
    ELSE
    p_flt_opr.sch_date     := p_sch_date + nvl(p_flt_leg(1).cgo_vol, 0);
    END IF;

    SELECT TRN_FLT_SUFFIX INTO V_TRN_FLT_SFX FROM SYS_PARAM;
    
    --check need create again or not
    --dbms_output.put_line('inside fun_create_daily_flight_trn.. 2...'||p_flt_opr.flt_key||V_TRN_FLT_SFX||'...'||p_flt_opr.sch_date||'...'||p_type);
    IF NOT fun_create_it(p_flt_opr.flt_key||V_TRN_FLT_SFX, p_flt_opr.sch_date, p_type) THEN
   -- dbms_output.put_line('inside.............');
      RETURN TRUE;
    END IF;
   -- dbms_output.put_line('inside fun_create_daily_flight_trn.. 3');
    --update flight information
    p_flt_opr.org_flt_date := p_sch_date;
    p_flt_opr.flt_type     := p_type;

    p_flt_opr.jnt_flt_ind := 'N';
    p_flt_opr.orig        := p_flt_leg(1).brd_point;
    p_flt_opr.orig_date   := p_sch_date + nvl(p_flt_leg(1).cgo_vol, 0);

    p_flt_opr.dest      := p_flt_leg(v_cnt).off_point;
    p_flt_opr.dest_date := p_sch_date + nvl(p_flt_leg(v_cnt).cgo_wgt, 0);

    p_flt_opr.acft_type := p_flt_leg(1).acft_type;
    p_flt_opr.sch_time  := p_flt_opr.orig_time;
    IF p_type = 'A' THEN
      p_flt_opr.sch_time  := p_flt_opr.dest_time;
      p_flt_opr.acft_type := p_flt_leg(v_cnt).acft_type;
    END IF;

    --transition flight info
   -- dbms_output.put_line('calling fun_ins_flt_opr_trn..');
    IF NOT fun_ins_flt_opr_trn(p_flt_opr, v_tr_no,p_type) THEN
    --  dbms_output.put_line('cannot insert fun_ins_flt_opr_trn..');
      RETURN FALSE;
    END IF;
    --transition leg info
   IF NOT fun_ins_flt_leg_trn(v_tr_no, p_flt_opr.sch_date, p_flt_leg, p_sch_date) THEN
      pro_del_invalid_flight(v_tr_no);
      RETURN FALSE;
    END IF;
    --transition segment info
    IF NOT fun_ins_flt_seg_trn(v_tr_no) THEN
      pro_del_invalid_flight(v_tr_no);
      RETURN FALSE;
    END IF;

    RETURN TRUE;
  END;

FUNCTION fun_check_trn_flt_req(p_sch_date IN DATE, p_carr_code IN VARCHAR2, p_flt_key IN VARCHAR2) RETURN BOOLEAN IS
    v_flg VARCHAR2(1);
  BEGIN
    Select 'Y' Into V_Flg
      From Trn_Setup A, Trn_Setup_Carr B
      Where b.tr_no=a.tr_no and
      p_sch_date between period_frm and period_to
      AND CARR_CODE=P_CARR_CODE;
      
    SELECT TRN_FLT_SUFFIX INTO V_TRN_FLT_SFX FROM SYS_PARAM;

    IF SUBSTR(P_FLT_KEY, -1) = V_TRN_FLT_SFX THEN
      RETURN TRUE;
    ELSE
      RETURN FALSE;
    END IF;

  EXCEPTION
    WHEN no_data_found THEN
      RETURN TRUE;
  END;

  FUNCTION fun_delete_daily_flight(p_sch_trno IN VARCHAR2,
                                   p_flt_key IN VARCHAR2,
                                   ins_mhcs_flt_del IN VARCHAR2,
                                   p_flt_date IN DATE DEFAULT NULL,
                                   p_flt_type IN DATE DEFAULT NULL)
    RETURN BOOLEAN IS
    v_cnt NUMBER;
    v_flt_date  DATE;
  BEGIN

    FOR c IN (SELECT *
                FROM flt_opr
               WHERE flt_key = p_flt_key
                 AND sch_date >= nvl(p_flt_date, trunc(SYSDATE))
                 AND sch_trno = p_sch_trno
                 AND tr_status = 'N') LOOP
      v_cnt := 0;
      v_flt_date:=c.sch_date;
      --ARRIVAL FLIGHT
      IF c.flt_type = 'A' THEN
        SELECT COUNT(1)
          INTO v_cnt
          FROM edi_ffm_msg a, edi_ffm_shp b
         WHERE a.tr_no = b.tr_no
           AND a.flt_key = c.flt_key
           AND a.flt_date = c.sch_date
           AND a.ffm_status = 'P'
           AND rownum = 1;
        IF nvl(v_cnt, 0) = 0 THEN
          SELECT COUNT(1)
            INTO v_cnt
            FROM imp_car_shp
           WHERE flt_key = c.flt_key
             AND flt_date = c.sch_date
             AND rownum = 1;
        IF nvl(v_cnt, 0) = 0 THEN
          SELECT COUNT(1)
            INTO v_cnt
	            FROM   ddt_msg
	            where  flt_key = c.flt_key
	            and    flt_date = c.sch_date
	            and    rownum = 1;
          END IF;
        END IF;
      END IF;
      --DEPARTURE FLIGHT
      IF c.flt_type = 'D' THEN
        SELECT COUNT(1)
          INTO v_cnt
          FROM exp_pmanifest_awb
         WHERE flt_key = c.flt_key
           AND flt_date = c.sch_date
           AND rownum = 1;
        IF nvl(v_cnt, 0) = 0 THEN
          SELECT COUNT(1)
            INTO v_cnt
            FROM exp_pman_tarmac_awb
           WHERE flt_key = c.flt_key
             AND flt_date = c.sch_date
             AND rownum = 1;
          IF nvl(v_cnt, 0) = 0 THEN
            select COUNT(1)
                      INTO v_cnt
		            from   exp_flt_uld
		            where  flt_key = c.flt_key
		            and    flt_date = c.sch_date
		            and    rownum = 1;
            IF nvl(v_cnt, 0) = 0 THEN
            select COUNT(1) INTO v_cnt
            from   FLT_OPR_EVENTS
            where  FLT_KEY = c.flt_key
            and    SCH_DATE = c.sch_date
            AND    BUILDUP_CDATE IS NOT NULL AND BUILDUP_CUSER IS NOT NULL
            and    rownum = 1;
                IF nvl(v_cnt, 0) = 0 THEN
                select COUNT(1) INTO v_cnt
                from   FLT_OPR_EVENTS
                where  FLT_KEY = c.flt_key
                and    SCH_DATE = c.sch_date
                AND    DLS_FINAL_DATE IS NOT NULL 
                and    rownum = 1;
                END IF;
                  IF nvl(v_cnt, 0) = 0 THEN
                  select COUNT(1) INTO v_cnt
                  from   FLT_OPR_EVENTS
                  where  FLT_KEY = c.flt_key
                  and    SCH_DATE = c.sch_date
                  AND    FINAL_MANF_DATE IS NOT NULL AND FINAL_MANF_USER_ID IS NOT NULL
                  and    rownum = 1;
                      IF nvl(v_cnt, 0) = 0 THEN
                      select COUNT(1) INTO v_cnt
                      from   FLT_OPR_EVENTS
                      where  FLT_KEY = c.flt_key
                      and    SCH_DATE = c.sch_date
                      AND    FLT_CLS_DATE IS NOT NULL AND FLT_CLS_USER_ID IS NOT NULL
                      and    rownum = 1;
                      END IF;
                  END IF;
            END IF;
          END IF;
        END IF;
      END IF;

      IF nvl(v_cnt, 0) = 0 THEN
      --  schedule_log(v_flt_date,'Delete daily flight  '|| c.flt_key||'/'||c.sch_date,'A');
		update flt_opr set LM_USER_ID = 'SYSTEM' , TR_TYPE = 'MTDFL' WHERE tr_no = c.tr_no;
        DELETE FROM flt_opr_leg WHERE tr_no = c.tr_no;
        DELETE FROM flt_opr_seg WHERE tr_no = c.tr_no;
        DELETE FROM flt_opr WHERE tr_no = c.tr_no;
        DELETE FROM flt_opr_events WHERE flt_key = c.flt_key and sch_date = c.sch_date and flt_type = c.flt_type;
        IF ins_mhcs_flt_del='Y' THEN
          INSERT INTO mhcs_flt_del(flt_key,flt_date,flt_type) VALUES (c.flt_key,c.sch_date,c.flt_type);
         END IF;
      --  schedule_log(v_flt_date,'Delete daily flight events  '|| c.flt_key||'/'||c.sch_date,c.flt_type);
      END IF;
    END LOOP;

    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      g_error:=SUBSTR(sqlcode||'/'||sqlerrm,1,400);
	  schedule_log(v_flt_date,g_error,'E');
      RETURN FALSE;
  END;

  --normally create daily flight
  PROCEDURE createdailyflight IS
    v_cnt     NUMBER;
    v_arr_leg t_flt_opr_leg := t_flt_opr_leg();
    v_dep_leg t_flt_opr_leg := t_flt_opr_leg();
    v_arr_opr flt_opr%ROWTYPE;
    v_dep_opr flt_opr%ROWTYPE;
    v_sch_day_ch number := 0;
  BEGIN
    alter_nls_territory;

    --transaction id
    g_trans_id := to_char(current_timestamp, 'yyyymmddhh24missFF3');
    schedule_log('', 'Processing start on ' || SYSDATE, 'A');
    --get cms config
    pro_cmsrules;
    --process flight
    IF cc_sch%ISOPEN THEN
      CLOSE cc_sch;
    END IF;
    OPEN cc_sch;
    LOOP
      FETCH cc_sch
        INTO g_cc_sch;
      EXIT WHEN cc_sch%NOTFOUND;
      --get create date
      g_cur_date.DELETE;

      IF fun_issurport THEN
       schedule_log('', 'inside fun_isurport', 'A');
        pro_get_create_date(g_cc_sch.start_date, g_cc_sch.end_date, g_cc_sch.flt_key, g_cc_sch.cr_date, g_cc_sch.tr_no);
      END IF;
     --dbms_output.put_line('valid date range...'||g_cc_sch.start_date||'......'||g_cc_sch.end_date);

      v_cnt := g_cur_date.COUNT;
      schedule_log('', 'CNT'|| v_cnt, 'A');
      --dbms_output.put_line('v_cnt...'||v_cnt);
      IF v_cnt > 0 THEN
        --get flight leg
        v_arr_leg := fun_get_schedule_leg(g_cc_sch.tr_no, 'A');
        IF v_arr_leg.COUNT > 0 THEN
          v_arr_opr := fun_get_flt_opr(v_arr_leg);
          v_sch_day_ch := nvl(v_arr_leg(v_arr_leg.COUNT).cgo_wgt, 0);
        END IF;
        v_dep_leg := fun_get_schedule_leg(g_cc_sch.tr_no, 'D');
        IF v_dep_leg.COUNT > 0 THEN
          v_dep_opr := fun_get_flt_opr(v_dep_leg);
          v_sch_day_ch := 0;
        END IF;
        
       
        --start create daily flight
        For X In 1 .. V_Cnt Loop
        --dbms_output.put_line('v_cnt.loop..'||x||'...'||G_Cur_Date(X)||'.....'||g_cc_sch.flt_key);
          If Not Fun_Check_Trn_Flt_Req(G_Cur_Date(X), g_cc_sch.carr_code, g_cc_sch.flt_key) Then
            -- insert into trn_flt tables
         --   dbms_output.put_line('in trn flt loop');
            IF NOT fun_create_trn_daily_flight(v_arr_opr, v_arr_leg,
                                         g_cur_date(x), 'A') THEN
              schedule_log(g_cur_date(x));
            END IF;
            IF NOT fun_create_trn_daily_flight(v_dep_opr, v_dep_leg,
                                         g_cur_date(x), 'D') THEN
              Schedule_Log(G_Cur_Date(X));
            End If;
          Else
            -- insert into flt tables
            IF NOT fun_create_daily_flight(v_arr_opr, v_arr_leg,
                                         g_cur_date(x), 'A') THEN
              schedule_log(g_cur_date(x));
            END IF;
            IF NOT fun_create_daily_flight(v_dep_opr, v_dep_leg,
                                         g_cur_date(x), 'D') THEN
              Schedule_Log(G_Cur_Date(X));
            END IF;
          END IF;

          IF NOT fun_check_trn_flt_req(g_cur_date(x), g_cc_sch.carr_code, g_cc_sch.flt_key) THEN
       --   dbms_output.put_line('in trn flt loop 2....');

            IF NOT fun_create_daily_flight_trn(v_arr_opr, v_arr_leg,
                                         g_cur_date(x), 'A') THEN
              schedule_log(g_cur_date(x));
            END IF;
      --    dbms_output.put_line('in trn flt loop 3');
            IF NOT fun_create_daily_flight_trn(v_dep_opr, v_dep_leg,
                                         g_cur_date(x), 'D') THEN
              schedule_log(g_cur_date(x));
            END IF;
          END IF;

        END LOOP;
      END IF;
    END LOOP;
    CLOSE cc_sch;
    schedule_log('', 'Processing end on ' || SYSDATE, 'A');
  END;

  PROCEDURE deletedailyflight(p_sch_trno IN VARCHAR2,
                              p_flt_key IN VARCHAR2 DEFAULT NULL) IS
    v_flt_key VARCHAR2(12);
  BEGIN
    v_flt_key := p_flt_key;

    IF p_flt_key IS NULL THEN
      BEGIN
        SELECT a.flt_key
          INTO v_flt_key
          FROM flt_sch a
         WHERE a.tr_no = p_sch_trno
           AND rownum <= 1;
      EXCEPTION
        WHEN no_data_found THEN
          BEGIN
            SELECT flt_key
              INTO v_flt_key
              FROM flt_opr m
             WHERE m.sch_trno = p_sch_trno
               AND rownum < 2;
          EXCEPTION
            WHEN no_data_found THEN
              v_flt_key := NULL;
          END;
      END;
    END IF;

    IF v_flt_key IS NULL THEN
      RETURN;
    END IF;

    IF NOT fun_delete_daily_flight(p_sch_trno, v_flt_key,'Y') THEN
      schedule_log;
    END IF;
  END;
  --recreate the daily flight
  PROCEDURE createdailyflight(p_sch_trno IN VARCHAR2) IS
    v_flt_key VARCHAR2(12);
  BEGIN
    g_sch_trno := p_sch_trno;
    BEGIN
      SELECT flt_key
        INTO v_flt_key
        FROM flt_sch
       WHERE tr_no = p_sch_trno;
       g_cc_sch.flt_key:=v_flt_key;
--      IF NOT fun_delete_daily_flight(p_sch_trno, v_flt_key,'N') THEN
--        RETURN;
--      END IF;
    EXCEPTION
      WHEN no_data_found THEN
        NULL;
    END;

    createdailyflight;
    g_sch_trno := NULL;

  END;
  ------------------------------------------------------------------------------

   FUNCTION CHECK_FLT_SCHEDULE(P_FLT_KEY IN VARCHAR2, P_START_DATE IN VARCHAR2, P_END_DATE IN VARCHAR2, P_TR_NO IN VARCHAR, DAYS IN VARCHAR2)
       RETURN VARCHAR2
    IS
    CURSOR cc_old_sch IS
    SELECT tr_no, carr_code, flt_no, start_date, end_date, frq_no, flt_key,
           jv_code,
           mon_flg || tue_flg || wed_flg || thu_flg || fri_flg ||
            sat_flg ||sun_flg  dat_flg,
           jnt_sun_flg || jnt_mon_flg || jnt_tue_flg || jnt_wed_flg ||
            JNT_THU_FLG || JNT_FRI_FLG || JNT_SAT_FLG DAT_JNT_FLG, LM_DATE,
     wh_level, brkbup_off, svc_type, cgo_acft_type, flt_module1, flt_module2, exp_flt_module1, exp_flt_module2,to_ind, chkout_area, cr_date, rho_id,
	 VESSEL_ID, VESSEL_NAME, VOYAGE_NUM , CALL_SIGN_VESSEL, SHIPPING_AGENT 
      FROM flt_sch
     WHERE start_date <= g_end_date
       AND end_date >= g_start_date --AND OUTSTANDING ='N'
       and flt_key = P_FLT_KEY and tr_no <> nvl(P_TR_NO, '*') 
       and cr_user_id not like 'SSM%'
     ORDER BY flt_key, start_date DESC;

    v_curr_date  DATE;
    v_start_date DATE;
    v_end_date   DATE;
    v_err varchar2(100);

    BEGIN
    g_start_date := p_start_date;
    g_end_date := p_end_date;

    IF cc_old_sch%ISOPEN THEN
      CLOSE cc_old_sch;
    END IF;
    OPEN cc_old_sch;
    LOOP
      FETCH cc_old_sch
        INTO g_cc_sch;
      EXIT WHEN cc_old_sch%NOTFOUND;

      v_start_date := g_cc_sch.start_date;
      v_end_date   := g_cc_sch.end_date;
      IF fun_get_valid_date(v_start_date, v_end_date) THEN
        v_curr_date := v_start_date;
        LOOP
          EXIT WHEN v_curr_date > v_end_date;
        --  dbms_output.put_line('existing sch days...'||g_cc_sch.dat_flg);

          IF substr(g_cc_sch.dat_flg, to_number(to_char(v_curr_date, 'D')), 1) = 'Y' THEN
            IF substr(DAYS, to_number(to_char(v_curr_date, 'D')), 1) = 'Y' THEN
              return 'C3ERR-20002';

              --PKG_COMMON.PRC_DBMS_ERR('C3ERR-20002 Entered Schedule is overlapping with the existing schedule');
            END IF;
          END IF;
          v_curr_date := v_curr_date + 1;
        END LOOP;
      END IF;
    END LOOP;

    return null;
  END;
  
  -------------------------------------------------- FOR SSM UPDATE OF FLIGHTS ------------------------------------------
  
  FUNCTION fun_is_trn_req(p_sch_date IN DATE, p_carr_code IN VARCHAR2, p_flt_key IN VARCHAR2) RETURN VARCHAR2 IS
    v_flg VARCHAR2(1);
    V_TRN_FLT_SFX VARCHAR2(1);
  BEGIN
begin
    Select 'Y' Into v_flg
      From Trn_Setup A, Trn_Setup_Carr B
      Where b.tr_no=a.tr_no and
      p_sch_date between period_frm and period_to
      AND CARR_CODE=P_CARR_CODE;
     exception
     when no_data_found then
      v_flg:= 'N';
     end;
     
      SELECT TRN_FLT_SUFFIX INTO V_TRN_FLT_SFX FROM SYS_PARAM;

    IF v_flg = 'Y' THEN
      RETURN V_TRN_FLT_SFX;
    ELSE
      RETURN NULL;
    END IF;

  END;
  
   FUNCTION fun_get_flt_type(p_tr_no IN VARCHAR2, p_flt_type in varchar2, p_day_chng out varchar2) RETURN NUMBER IS
    v_cnt number := 1;
    BEGIN
   --   dbms_output.put_line('g_base_port... '||g_base_port||'..tr..'||p_tr_no||'..flt_type..'||p_flt_type||'...p_day_chng...'||p_day_chng);
      if p_flt_type = 'D' then
        begin
          select dep_day_change into p_day_chng from flt_sch_leg where tr_no=p_tr_no and brd_point=g_base_port;
          
          exception 
            when no_data_found then
              v_cnt := 0;
              p_day_chng := 0;
        end;       
      else
        begin
          select arr_day_change into p_day_chng from flt_sch_leg where tr_no=p_tr_no and off_point=g_base_port;
          
          exception 
            when no_data_found then
              v_cnt := 0;
              p_day_chng := 0;
        end;
      end if;
      
     -- dbms_output.put_line('inside fun_get_flt_type.. v_cnt'||v_cnt||', p_day_chng.. '||p_day_chng);
      return v_cnt;
    END;
  
  PROCEDURE pro_insert_flt_sch_log(p_tr_no IN VARCHAR2, p_cur_date IN DATE, p_flt_key IN VARCHAR2, p_func_type IN VARCHAR2,p_cr_date IN DATE) IS
  
    BEGIN      
      INSERT INTO SSM_FLT_SCH_LOG VALUES(p_tr_no, p_cur_date, p_cr_date, p_flt_key, p_func_type,SYSDATE);
    END;
    
  PROCEDURE pro_upd_equip_dtls_flt(p_tr_no IN VARCHAR2, p_carr_code IN VARCHAR2, p_flt_key IN VARCHAR2,
        p_flt_type IN VARCHAR2, p_sch_date IN DATE, p_org_date IN DATE, p_func_type IN VARCHAR2,p_cr_date IN DATE) IS
    v_rec_row       flt_opr_leg%ROWTYPE;
    v_trn_flt_sfx varchar2(1);
    v_flt_key varchar2(8);
    v_leg_acft_type varchar2(3);
    v_tr_no number;
    v_trn_tr_no number;
    v_cur_cnt number;
    v_ins_flg varchar2(1) := 'N';
    
    cursor cur(v_tr_no varchar2) is
      SELECT tr_no, doc_line_no, carr_code, flt_no, flt_key, brd_point, off_point, leg_order, acft_type 
        FROM flt_sch_leg WHERE tr_no = v_tr_no;

    BEGIN
    --  dbms_output.put_line('p_flt_key... '||p_flt_key);
      v_trn_flt_sfx := fun_is_trn_req(p_org_date, p_carr_code, p_flt_key);
   --   dbms_output.put_line('v_trn_flt_sfx... '||v_trn_flt_sfx);
      v_flt_key := p_flt_key;
      if v_trn_flt_sfx is not null then
        v_flt_key := p_flt_key || v_trn_flt_sfx;
      end if;
      
     -- dbms_output.put_line('v_flt_key... '||v_flt_key);
    --  dbms_output.put_line('p_org_date... '||p_org_date);
    --  dbms_output.put_line('p_flt_type... '||p_flt_type);
      begin
        select tr_no into v_tr_no from flt_opr where flt_key=v_flt_key and org_flt_date=p_org_date and flt_type=p_flt_type;      
        EXCEPTION
          WHEN no_data_found THEN
            NULL;
      end;
      begin 
        select tr_no into v_trn_tr_no from trn_flt_opr where flt_key=p_flt_key and org_flt_date=p_org_date and flt_type=p_flt_type;
        EXCEPTION
          WHEN no_data_found THEN
            NULL;
      end;       
     -- dbms_output.put_line('v_tr_no... '||v_tr_no);
     -- dbms_output.put_line('v_trn_tr_no... '||v_trn_tr_no);
      
      if p_flt_type = 'ALL' then
        -- update all the legs of flight
        select LEG_ACFT_TYPE into v_leg_acft_type from flt_sch where tr_no = p_tr_no;
      --  dbms_output.put_line('LEG_ACFT_TYPE... '||v_leg_acft_type);
        
        --if v_leg_acft_type is not null then 
          begin
            update flt_opr_leg set acft_type=v_leg_acft_type, lm_user_id='SSM_SCHEDULER', lm_date=sysdate 
            where tr_no in (select tr_no from flt_opr where flt_key = v_flt_key and org_flt_date = p_org_date);            
  
            update flt_opr set acft_type=v_leg_acft_type, lm_user_id='SSM_SCHEDULER', lm_date=sysdate, mhcssend_yn = 'N' 
            where tr_no in (select tr_no from flt_opr where flt_key = v_flt_key and org_flt_date = p_org_date);            
            
            if v_trn_flt_sfx is not null then
              update trn_flt_opr_leg set acft_type=v_leg_acft_type, lm_user_id='SSM_SCHEDULER', lm_date=sysdate 
              where tr_no in (select tr_no from trn_flt_opr where flt_key=p_flt_key and org_flt_date=p_org_date);
  
              update trn_flt_opr set acft_type=v_leg_acft_type, lm_user_id='SSM_SCHEDULER', lm_date=sysdate 
              where tr_no in (select tr_no from trn_flt_opr where flt_key=p_flt_key and org_flt_date=p_org_date);
            end if;
            v_ins_flg := 'Y';
          EXCEPTION
            WHEN no_data_found THEN
              NULL;
            WHEN others THEN
              NULL;
          end;       
        --end if;
      else
        -- update the leg details
        for v_rec_row in cur(p_tr_no) loop
     --     dbms_output.put_line('v_rec_row... inside..');
          if v_leg_acft_type is null then
            v_leg_acft_type := v_rec_row.acft_type;
          end if;
          
          update flt_opr_leg set acft_type=v_rec_row.acft_type, lm_user_id='SSM_SCHEDULER', lm_date=sysdate where tr_no=v_tr_no and brd_point=v_rec_row.brd_point 
            and off_point=v_rec_row.off_point;
          
          if v_trn_flt_sfx is not null then
            update trn_flt_opr_leg set acft_type=v_rec_row.acft_type, lm_user_id='SSM_SCHEDULER', lm_date=sysdate where tr_no=v_trn_tr_no and brd_point=v_rec_row.brd_point 
              and off_point=v_rec_row.off_point;
          end if;
          v_ins_flg := 'Y';
        end loop;
        
        update flt_opr set acft_type=v_leg_acft_type, mhcssend_yn = 'N', lm_user_id='SSM_SCHEDULER', lm_date=sysdate 
        where tr_no=v_tr_no;

        update trn_flt_opr set acft_type=v_leg_acft_type, lm_user_id='SSM_SCHEDULER', lm_date=sysdate 
        where tr_no=v_trn_tr_no;
      end if;
      
      if v_ins_flg = 'Y' then
        pro_insert_flt_sch_log(p_tr_no, p_org_date, p_flt_key, p_func_type, p_cr_date);
      end if;
    END;
    
  PROCEDURE pro_upd_time_dtls_flt(p_tr_no IN VARCHAR2, p_flt_type IN VARCHAR2, p_sch_date IN DATE, p_carr_code in VARCHAR2, p_flt_key in VARCHAR2, p_func_type in VARCHAR2,p_cr_date IN DATE) IS
    v_rec_row       flt_opr_leg%ROWTYPE;
    v_trn_flt_sfx varchar2(1);
    v_flt_sch_st_dt date;
    v_flt_sch_ed_dt date;
    v_flt_key varchar2(8);
    v_flt_sch_tm varchar(4);
    v_flt_sch_org_tm varchar(4);
    v_flt_sch_dest_tm varchar(4);
    v_tr_no number;
    v_trn_tr_no number;
    v_ins_flg varchar2(1) := 'N';
    v_leg_order number;
    
    CURSOR CUR(V_TR_NO VARCHAR2) IS
      SELECT tr_no, doc_line_no, carr_code, flt_no, flt_key, brd_point, off_point, leg_order, sch_arr_time, sch_dep_time
        FROM flt_sch_leg WHERE tr_no = v_tr_no;
        
    BEGIN
      
      v_trn_flt_sfx := fun_is_trn_req(p_sch_date, p_carr_code, p_flt_key);
      v_flt_key := p_flt_key;
      if v_trn_flt_sfx is not null then
        v_flt_key := v_flt_key || v_trn_flt_sfx;
      end if;
      
      --dbms_output.put_line('v_flt_key... '||v_flt_key||'...date...'||p_sch_date||'.....'||p_flt_type);
      
      begin
        select tr_no into v_tr_no from flt_opr where flt_key=v_flt_key and sch_date=p_sch_date and flt_type=p_flt_type;      
        EXCEPTION
          WHEN no_data_found THEN
            RETURN;
      end;
      begin 
        select tr_no into v_trn_tr_no from trn_flt_opr where flt_key=p_flt_key and sch_date=p_sch_date and flt_type=p_flt_type;
        EXCEPTION
          WHEN no_data_found THEN
            NULL;
      end;
      
      for v_rec_row in cur(p_tr_no) 
      LOOP 
            
            UPDATE FLT_OPR_LEG SET SCH_ARR_TIME=V_REC_ROW.SCH_ARR_TIME, SCH_DEP_TIME=V_REC_ROW.SCH_DEP_TIME, LM_USER_ID='SSM_SCHEDULER', LM_DATE=SYSDATE 
            WHERE TR_NO=V_TR_NO AND BRD_POINT=V_REC_ROW.BRD_POINT AND OFF_POINT=V_REC_ROW.OFF_POINT;              
            
            if v_trn_flt_sfx is not null then
              update trn_flt_opr_leg set sch_arr_time=v_rec_row.sch_arr_time, sch_dep_time=v_rec_row.sch_dep_time, lm_user_id='SSM_SCHEDULER', lm_date=sysdate 
                where tr_no=v_trn_tr_no and brd_point=v_rec_row.brd_point and off_point=v_rec_row.off_point;
            end if;
            
            v_ins_flg := 'Y';
      end loop;
      
      select sch_dep_time into v_flt_sch_org_tm from flt_opr_leg where tr_no=v_tr_no and leg_ord = 1;      
      
      select sch_arr_time into v_flt_sch_dest_tm
      from (select sch_arr_time  from flt_opr_leg where tr_no=v_tr_no order by leg_ord desc)
      where rownum = 1;      
      
      if p_flt_type = 'A' then
          v_flt_sch_tm := v_flt_sch_dest_tm;
      else
          v_flt_sch_tm := v_flt_sch_org_tm;
      end if;
            
  --    dbms_output.put_line('times... '||p_flt_type||'...'||v_flt_sch_tm||'.....org....'||v_flt_sch_org_tm||'...dest...'||v_flt_sch_dest_tm);

      BEGIN
        update flt_opr set sch_time= v_flt_sch_tm, orig_time= v_flt_sch_org_tm, dest_time= v_flt_sch_dest_tm, 
          mhcssend_yn = 'N', lm_user_id='SSM_SCHEDULER', lm_date=sysdate where tr_no=v_tr_no;
      
        if v_trn_flt_sfx is not null then
          update trn_flt_opr set sch_time=v_flt_sch_tm, orig_time=v_flt_sch_org_tm, dest_time=v_flt_sch_dest_tm, 
            lm_user_id='SSM_SCHEDULER', lm_date=sysdate where tr_no=v_trn_tr_no;
        end if;
        
        v_ins_flg := 'Y';
      END;
      
      if v_ins_flg = 'Y' then
        pro_insert_flt_sch_log(p_tr_no, p_sch_date, p_flt_key, p_func_type,p_cr_date);
      end if;
      
    END;
  
  FUNCTION pro_del_flt_dtls(p_carr_code in varchar2, p_flt_key in varchar2, p_flt_type in varchar2, p_cur_date in date, v_tr_no out number) RETURN VARCHAR2 AS
    v_error varchar2(500) := NULL;
    v_count NUMBER := 0;
    
    v_trn_flt_sfx varchar2(1);
    v_flt_key varchar2(8);
    
    BEGIN
      v_trn_flt_sfx := fun_is_trn_req(p_cur_date, p_carr_code, p_flt_key);
	  v_flt_key := p_flt_key;
	  --
      if v_trn_flt_sfx is not null then
        v_flt_key := p_flt_key || v_trn_flt_sfx;
        
        if p_flt_type = 'ALL' then
      -- delete trn_flt_opr tables
          --dbms_output.put_line('deleteing trn_flt tables v_tr_no... '||v_tr_no);
          delete from trn_flt_opr_leg where tr_no in (select tr_no from trn_flt_opr where flt_key=p_flt_key and org_flt_date=p_cur_date);
          delete from trn_flt_opr_events where tr_no in (select tr_no from trn_flt_opr where flt_key=p_flt_key and org_flt_date=p_cur_date);
          delete from trn_flt_opr_seg where tr_no in (select tr_no from trn_flt_opr where flt_key=p_flt_key and org_flt_date=p_cur_date);
          delete from trn_flt_opr where tr_no in (select tr_no from trn_flt_opr where flt_key=p_flt_key and org_flt_date=p_cur_date);
        else
          delete from trn_flt_opr_leg where tr_no in (select tr_no from trn_flt_opr where flt_key=p_flt_key and sch_date=p_cur_date and flt_type = p_flt_type);
          delete from trn_flt_opr_events where tr_no in (select tr_no from trn_flt_opr where flt_key=p_flt_key and sch_date=p_cur_date and flt_type = p_flt_type);
          delete from trn_flt_opr_seg where tr_no in (select tr_no from trn_flt_opr where flt_key=p_flt_key and sch_date=p_cur_date and flt_type = p_flt_type);
          delete from trn_flt_opr where tr_no in (select tr_no from trn_flt_opr where flt_key=p_flt_key and sch_date=p_cur_date and flt_type = p_flt_type);
        end if;          
      end if;
      
       -- dbms_output.put_line('deleteing flt details ... ' || p_carr_code || p_flt_key || p_cur_date ||  v_tr_no);
       -- dbms_output.put_line('pro_del_flt_dtls Start');
      
      for rec in 
        (SELECT flt_type, flt_key, sch_date FROM flt_opr where flt_key = p_flt_key and org_flt_date = p_cur_date)
      loop
      
          if(rec.flt_type = 'D') THEN
             BEGIN 
                v_count := 0;                
                select count (1) into v_count from exp_pmanifest_awb where  flt_key = rec.flt_key and flt_date = rec.sch_date;            
                if(v_count > 0 ) THEN
                  v_error := 'C3ERR-06801 Premanifest Exists. Flight can not be deleted';
                  RETURN v_error ;
                END IF;
    
                select count (1) into v_count from exp_pman_tarmac_awb where  flt_key = rec.flt_key and flt_date = rec.sch_date;
                if(v_count > 0 ) THEN
                  v_error := 'C3ERR-06802 Tarmac Cargo Exists. Flight can not be deleted';
                  RETURN v_error ;
                END IF;
               
               select count (1) into v_count from exp_flt_uld where  flt_key = rec.flt_key and flt_date = rec.sch_date;
               if(v_count > 0 ) THEN
                  v_error := 'C3ERR-06803 ULD has been Assgined. Flight can not be deleted';
                  RETURN v_error ;
                END IF;  
            END;
          END IF;
          
          IF(rec.flt_type = 'A') THEN
            BEGIN            
               v_count := 0;
               select count (1) into v_count from imp_car_shp where flt_key = rec.flt_key and flt_date = rec.sch_date;
                if(v_count > 0 ) THEN
                  v_error := 'C3ERR-06901 Shipment Record exists. Flight can not be deleted';
                  RETURN v_error ;
                END IF; 
                
                select count (1) into v_count from ddt_msg where flt_key = rec.flt_key and flt_date = rec.sch_date;
                if(v_count > 0 ) THEN
                  v_error := 'C3ERR-06902 DDT Exists. Flight can not be deleted';
                  RETURN v_error ;
                END IF; 
            END;
          END IF; 
          
        BEGIN  
           v_count := 0;
           select count (1) into v_count from flt_opr a where  exists (
				   select b.flt_key || to_char (b.flt_date, 'DDMMYYYY') || decode (b.flt_type, 'E', 'D', 'I', 'A')
				   from uld_inventory b where  b.flt_key = a.flt_key and to_char (a.sch_date, 'DDMMYYYY') = to_char (b.flt_date, 'DDMMYYYY')
				   and a.flt_key = rec.flt_key and a.sch_date = rec.sch_date);           
           if(v_count > 0 ) THEN
              v_error := 'C3ERR-06802 DELETE FAILED, EVENTS ARE CREATED FOR THIS FLIGHT';
              RETURN v_error ;
           END IF;             
        END;
        
     end loop;
        
		
      -- delete flt_opr tables
        if p_flt_type = 'ALL' then
          --dbms_output.put_line('deleteing flt tables v_tr_no... '||v_tr_no);
		  update flt_opr set LM_USER_ID = 'SYSTEM', TR_TYPE = 'MTDFL' WHERE tr_no in (select tr_no from flt_opr where flt_key=v_flt_key and org_flt_date=p_cur_date AND cr_user_id = 'SCHEDULER');
          delete from flt_opr_leg where tr_no in (select tr_no from flt_opr where flt_key=v_flt_key and org_flt_date=p_cur_date AND cr_user_id = 'SCHEDULER');
          delete from flt_opr_events where tr_no in (select tr_no from flt_opr where flt_key=v_flt_key and org_flt_date=p_cur_date AND cr_user_id = 'SCHEDULER');
          delete from flt_opr_seg where tr_no in (select tr_no from flt_opr where flt_key=v_flt_key and org_flt_date=p_cur_date AND cr_user_id = 'SCHEDULER');
          delete from flt_opr where tr_no in (select tr_no from flt_opr where flt_key=v_flt_key and org_flt_date=p_cur_date AND cr_user_id = 'SCHEDULER');
        else
          --dbms_output.put_line('deleteing flt tables v_tr_no... '||v_tr_no);
		  update flt_opr set LM_USER_ID = 'SYSTEM', TR_TYPE = 'MTDFL' WHERE tr_no in (select tr_no from flt_opr where flt_key=v_flt_key and sch_date=p_cur_date and flt_type = p_flt_type AND cr_user_id = 'SCHEDULER');
          delete from flt_opr_leg where tr_no in (select tr_no from flt_opr where flt_key=v_flt_key and sch_date=p_cur_date and flt_type = p_flt_type AND cr_user_id = 'SCHEDULER');
          delete from flt_opr_events where tr_no in (select tr_no from flt_opr where flt_key=v_flt_key and sch_date=p_cur_date and flt_type = p_flt_type AND cr_user_id = 'SCHEDULER');
          delete from flt_opr_seg where tr_no in (select tr_no from flt_opr where flt_key=v_flt_key and sch_date=p_cur_date and flt_type = p_flt_type AND cr_user_id = 'SCHEDULER');
          delete from flt_opr where tr_no in (select tr_no from flt_opr where flt_key=v_flt_key and sch_date=p_cur_date and flt_type = p_flt_type AND cr_user_id = 'SCHEDULER');        
        end if;
        
       RETURN v_error;
    END;
  
  PROCEDURE pro_get_create_date_ssm(p_start_date IN DATE, p_end_date IN DATE, p_dat_flg IN VARCHAR2, p_tr_no IN VARCHAR2,p_flt_key in VARCHAR2,p_cr_date IN DATE) IS
    v_curr_date  DATE;
    v_start_date DATE;
    v_end_date   DATE;
    v_ssm_log_cnt number := 0;
  BEGIN
    v_start_date := p_start_date;
    v_end_date   := p_end_date;
    
    g_cur_date.DELETE;

    dbms_output.put_line('pro_get_create_date_ssm.. ' || ' :: ' ||  p_start_date || ' :: ' || p_end_date || ' :: ' || p_dat_flg || ' :: ' || p_cr_date || ' :: ' || p_tr_no);
    
    IF NOT fun_get_valid_date(v_start_date, v_end_date) THEN
      --dbms_output.put_line('invalid dates');
      RETURN;
    END IF;
    v_curr_date := v_start_date;   
      --dbms_output.put_line('p_cr_date.. '||p_cr_date);
    LOOP
      EXIT WHEN v_curr_date > v_end_date;    
      begin
        select count(1) into v_ssm_log_cnt from ssm_flt_sch_log where flt_sch_tr_no=p_tr_no and flt_date=v_curr_date and ssm_type not in ('ASMRPL','ASMTIM') ;
      exception
      when no_data_found then
       begin       
      select count(1) into v_ssm_log_cnt from ssm_flt_sch_log where ssm_type in('ASMRPL','ASMTIM') and flt_date=v_curr_date and cr_date>p_cr_date;
      exception
      when no_data_found then
        v_ssm_log_cnt := 0;
      end;
      end;
       --dbms_output.put_line('v_ssm_log_cnt.. '||v_ssm_log_cnt);
      IF (substr(p_dat_flg, to_number(to_char(v_curr_date, 'D')), 1) = 'Y' AND v_ssm_log_cnt = 0) THEN
     --dbms_output.put_line('v_ssm_log_cnt.. '||v_ssm_log_cnt);
        g_cur_date.EXTEND;
        g_cur_date(g_cur_date.COUNT) := v_curr_date;
       --dbms_output.put_line('valid date...'||v_curr_date);
      END IF;
      v_curr_date := v_curr_date + 1;
    END LOOP;
  END;
  
  PROCEDURE updateEquipDtlsForFlt(p_start_date IN DATE, p_end_date IN DATE, p_flt_key IN VARCHAR2, p_carr_code IN VARCHAR2, p_tr_no IN VARCHAR2, p_dat_flg IN VARCHAR2, p_func_type IN VARCHAR2,p_cr_date IN DATE) IS
    v_day_chng varchar2(3);
    v_cnt number;
    v_arr_cnt number;
    v_dep_cnt number;
    v_cur_cnt number;
    
    BEGIN
      pro_get_create_date_ssm(p_start_date, p_end_date, p_dat_flg, p_tr_no,p_flt_key,p_cr_date);            
      v_cnt := g_cur_date.COUNT;
    --  dbms_output.put_line('v_cnt.......'||v_cnt);
      
      begin
        select count(1) into v_cur_cnt from flt_sch_leg where tr_no = p_tr_no;
        EXCEPTION
          WHEN no_data_found THEN
            v_cur_cnt := 0;
      end;
      
      IF v_cnt > 0 THEN
          -- run for both flight types
        IF v_cur_cnt = 0 then
            FOR X IN 1 .. v_cnt LOOP
              BEGIN
                pro_upd_equip_dtls_flt(p_tr_no, p_carr_code, p_flt_key, 'ALL', null, g_cur_date(x), p_func_type, p_cr_date);
              END;
            END LOOP;
        ELSE
          v_arr_cnt := fun_get_flt_type(p_tr_no, 'A', v_day_chng);
      --    dbms_output.put_line('v_arr_cnt.. '||v_arr_cnt||', v_day_chng.. '||v_day_chng);
          
          if v_arr_cnt > 0 then
            -- update flt equipment details
            FOR X IN 1 .. v_cnt LOOP
              BEGIN
           --     dbms_output.put_line('calling pro_upd_equip_dtls_flt  inside arrival');
                pro_upd_equip_dtls_flt(p_tr_no, p_carr_code, p_flt_key, 'A', g_cur_date(x)+v_day_chng, g_cur_date(x), p_func_type, p_cr_date);
              END;
            END LOOP;
          end if;
          
          v_dep_cnt := fun_get_flt_type(p_tr_no, 'D', v_day_chng);
        --  dbms_output.put_line('v_dep_cnt.. '||v_dep_cnt||', v_day_chng.. '||v_day_chng);
          
          if v_dep_cnt > 0 then
            -- update flt equipment details
            FOR X IN 1 .. v_cnt LOOP
              BEGIN
           --     dbms_output.put_line('calling pro_upd_equip_dtls_flt inside Depature');
                pro_upd_equip_dtls_flt(p_tr_no, p_carr_code, p_flt_key, 'D', g_cur_date(x)+v_day_chng, g_cur_date(x), p_func_type, p_cr_date);
              END;
            END LOOP;
          end if;                  
        END IF;  
      END IF;
    END;    
  
  PROCEDURE updateTimeDtlsForFlt(p_start_date IN DATE, p_end_date IN DATE, p_carr_code IN VARCHAR2, p_flt_key IN VARCHAR2, p_tr_no IN VARCHAR2, p_dat_flg IN VARCHAR2, p_func_type IN VARCHAR2,p_cr_date IN DATE) IS
    v_day_chng varchar2(3);
    v_cnt number;
    v_arr_cnt number;
    v_dep_cnt number;
    
    BEGIN
    --  dbms_output.put_line('inside updateTimeDtlsForFlt');
    --  dbms_output.put_line('p_dat_flg.. '|| p_dat_flg);
      pro_get_create_date_ssm(p_start_date, p_end_date, p_dat_flg, p_tr_no,p_flt_key,p_cr_date);
      v_cnt := g_cur_date.COUNT;
      IF v_cnt > 0 THEN
        v_arr_cnt := fun_get_flt_type(p_tr_no, 'A', v_day_chng);
     --   dbms_output.put_line('inside updateTimeDtlsForFlt.. v_arr_cnt.. '||v_arr_cnt);
        if v_arr_cnt > 0 then
          FOR X IN 1 .. v_cnt LOOP
            BEGIN
       --       dbms_output.put_line('g_cur_date(x)...'||g_cur_date(x));
              pro_upd_time_dtls_flt(p_tr_no, 'A', g_cur_date(x)+v_day_chng, p_carr_code, p_flt_key, p_func_type, p_cr_date);
            END;
          END LOOP;
        end if;
        
        v_dep_cnt := fun_get_flt_type(p_tr_no, 'D', v_day_chng);
     --   dbms_output.put_line('inside updateTimeDtlsForFlt.. v_dep_cnt.. '||v_dep_cnt);
        if v_dep_cnt > 0 then
          FOR X IN 1 .. v_cnt LOOP
            BEGIN
        --      dbms_output.put_line('g_cur_date(x)...'||g_cur_date(x));
              pro_upd_time_dtls_flt(p_tr_no, 'D', g_cur_date(x)+v_day_chng, p_carr_code, p_flt_key, p_func_type , p_cr_date);
            END;
          END LOOP;
        end if;
      END IF;
    END;
  
  PROCEDURE log_service_error(p_carr_code VARCHAR2 DEFAULT NULL,p_flt_key VARCHAR2 DEFAULT NULL, p_flt_date DATE DEFAULT NULL, v_tr_no VARCHAR2 DEFAULT NULL, V_FLT_DEL_ERROR VARCHAR2 DEFAULT NULL) IS
  
  BEGIN  

    INSERT INTO SERVICE_ERR_LOG
      ( TR_NO, TR_TYPE, DOC_LINE_NO, TR_DATE, OWNER_ID, CARR_CODE , FLT_KEY ,FLT_DATE, RMK1, RMK2,ERR_REASON,CR_USER_ID, CR_DATE, LM_USER_ID, LM_DATE)
    VALUES
      (v_tr_no, 'SM', SERVICE_ERR_LOG_DLN_SEQ.nextval, SYSDATE,p_carr_code,p_carr_code, p_flt_key ,p_flt_date,V_FLT_DEL_ERROR,V_FLT_DEL_ERROR,V_FLT_DEL_ERROR,
		    'SCHEDULER', SYSDATE, 'SCHEDULER', SYSDATE);  
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line('SERVICE_ERR_LOG......' ||SQLERRM);
  END;
  
  PROCEDURE deleteFltDtlsForFlt(p_start_date IN DATE, p_end_date IN DATE, p_flt_key IN VARCHAR2, p_dat_flg IN VARCHAR2, p_carr_code IN VARCHAR2, p_tr_no IN VARCHAR2, p_func_type IN VARCHAR2,p_cr_date IN DATE) IS
    v_day_chng varchar2(3);
    v_cnt number;
    v_tr_no number;
    v_arr_cnt number;
    v_dep_cnt number;
    v_trn_flt_sfx varchar2(1);
    v_flt_key varchar2(8);
    V_FLT_DEL_ERROR VARCHAR2(500) := NULL;
    
    BEGIN    
      pro_get_create_date_ssm(p_start_date, p_end_date, p_dat_flg, p_tr_no,p_flt_key,p_cr_date);
      v_cnt := g_cur_date.COUNT;
      dbms_output.put_line('v_cnt......'||v_cnt||'....'||p_tr_no);
          
          FOR X IN 1 .. v_cnt LOOP
            BEGIN
              V_FLT_DEL_ERROR := pro_del_flt_dtls(p_carr_code, p_flt_key, 'ALL', g_cur_date(x), v_tr_no);
              --pro_del_flt_dtls(p_carr_code, p_flt_key, 'D', g_cur_date(x), v_tr_no);
              --dbms_output.put_line('V_FLT_DEL_ERROR :::::' || V_FLT_DEL_ERROR);              
              if (V_FLT_DEL_ERROR IS NOT NULL) THEN
                  log_service_error(p_carr_code,p_flt_key,g_cur_date(x),p_tr_no,V_FLT_DEL_ERROR);                  
                  dbms_output.put_line('log_service_error successfull:::::');
              ELSE
                pro_insert_flt_sch_log(p_tr_no, g_cur_date(x), p_flt_key, p_func_type,p_cr_date);
              END IF;
              
            END;
          END LOOP;
/*      
      IF v_cnt > 0 THEN
        v_arr_cnt := fun_get_flt_type(p_tr_no, 'A', v_day_chng);
     --   dbms_output.put_line('inside deleteFltDtlsForFlt.. v_arr_cnt...'||v_arr_cnt);
        if v_arr_cnt > 0 then
          FOR X IN 1 .. v_cnt LOOP
            BEGIN
        --      dbms_output.put_line('g_cur_date(x)...'||g_cur_date(x));
              --select tr_no into v_tr_no from flt_opr where flt_key=v_flt_key and org_flt_date=g_cur_date(x)+v_day_chng and flt_type='A';
            
              pro_del_flt_dtls(p_carr_code, p_flt_key, 'A', g_cur_date(x)+v_day_chng, v_tr_no);
            
              -- insert in SSM_FLT_SCH_LOG
              if v_tr_no is not null then
                pro_insert_flt_sch_log(p_tr_no, g_cur_date(x)+v_day_chng, p_flt_key, p_func_type);
              end if;
            END;
          END LOOP;
        end if;
      
        v_dep_cnt := fun_get_flt_type(p_tr_no, 'D', v_day_chng);
       -- dbms_output.put_line('inside deleteFltDtlsForFlt.. v_dep_cnt...'||v_dep_cnt);
        if v_dep_cnt > 0 then
          FOR X IN 1 .. v_cnt LOOP
            BEGIN
              dbms_output.put_line('g_cur_date(x)...'||g_cur_date(x));            
              --select tr_no into v_tr_no from flt_opr where flt_key=v_flt_key and org_flt_date=g_cur_date(x)+v_day_chng and flt_type='D';
            
              pro_del_flt_dtls(p_carr_code, p_flt_key, 'D', g_cur_date(x)+v_day_chng, v_tr_no);
            
              -- insert in SSM_FLT_SCH_LOG
              if v_tr_no is not null then
                pro_insert_flt_sch_log(p_tr_no, g_cur_date(x)+v_day_chng, p_flt_key, p_func_type);
              end if;
            END;
          END LOOP;
        end if;
      END IF;
*/
    END;
  
  PROCEDURE replaceFltDtlsForSSM(p_start_date IN DATE, p_end_date IN DATE, p_dat_flg IN VARCHAR2, p_carr_code IN VARCHAR2, p_flt_key IN VARCHAR2, p_tr_no IN VARCHAR2, p_func_type IN VARCHAR2,p_cr_date IN DATE) IS
    v_day_chng number;
    v_cnt number;
    v_arr_leg t_flt_opr_leg := t_flt_opr_leg();
    v_dep_leg t_flt_opr_leg := t_flt_opr_leg();
    v_arr_opr flt_opr%ROWTYPE;
    v_dep_opr flt_opr%ROWTYPE;
    v_tr_no number;
    v_arr_cnt number;
    v_dep_cnt number;
    v_ins_flg varchar2(1) := 'N';
    v_cur_date date;
    v_del_tr_no number;
     V_FLT_DEL_ERROR VARCHAR2(500) := NULL;
    
    BEGIN
      pro_get_create_date_ssm(p_start_date, p_end_date, p_dat_flg, p_tr_no,p_flt_key,p_cr_date);
      v_cnt := g_cur_date.COUNT;
      --dbms_output.put_line('v_cnt....'||v_cnt||'.....'||p_tr_no);   
      IF v_cnt > 0 THEN
        FOR x IN 1 .. v_cnt LOOP
          BEGIN
            
          --dbms_output.put_line('calling pro_del_flt_dtls  :::::');
            
            
          
            V_FLT_DEL_ERROR := pro_del_flt_dtls(p_carr_code, p_flt_key, 'ALL', g_cur_date(x), v_del_tr_no);
            
            dbms_output.put_line('V_FLT_DEL_ERROR :::::' || V_FLT_DEL_ERROR);
            
            if (V_FLT_DEL_ERROR IS NOT NULL) THEN
                  log_service_error(p_carr_code,p_flt_key,g_cur_date(x),p_tr_no,V_FLT_DEL_ERROR);
                  dbms_output.put_line('log_service_error successfull:::::');
              ELSE
                pro_insert_flt_sch_log(p_tr_no, g_cur_date(x), p_flt_key, p_func_type,p_cr_date);
              END IF;
            
          END;
        END LOOP;
/*      
      IF v_cnt > 0 THEN
        v_arr_cnt := fun_get_flt_type(p_tr_no, 'A', v_day_chng);
        if v_arr_cnt > 0 then
          FOR x IN 1 .. v_cnt LOOP
            BEGIN
            --  dbms_output.put_line('calling pro_del_flt_dtls...'||p_carr_code||', '|| p_flt_key||', '|| 'flt_type.. A'||', '|| to_char(g_cur_date(x)+v_day_chng, 'DDMONYY'));
              --select tr_no into v_tr_no from flt_opr where flt_key=p_flt_key and org_flt_date=g_cur_date(x)+v_day_chng and flt_type='A';
          
              -- delete existing flight details            
              pro_del_flt_dtls(p_carr_code, p_flt_key, 'A', g_cur_date(x)+v_day_chng, v_del_tr_no);
              --commit;
              
              if v_del_tr_no is not null then
                v_cur_date := g_cur_date(x)+v_day_chng;
                v_ins_flg := 'Y';
              end if;
            END;
          END LOOP;
        end if;

        v_dep_cnt := fun_get_flt_type(p_tr_no, 'D', v_day_chng);
        if v_dep_cnt > 0 then
        dbms_output.put_line('v_cnt..........'||v_cnt);
          FOR x IN 1 .. v_cnt LOOP
            BEGIN
             -- dbms_output.put_line('calling pro_del_flt_dtls...'||p_carr_code||', '|| p_flt_key||', '|| 'flt_type.. D'||', '|| to_char(g_cur_date(x)+v_day_chng, 'DDMONYY'));
              --select tr_no into v_tr_no from flt_opr where flt_key=p_flt_key and org_flt_date=g_cur_date(x)+v_day_chng and flt_type='D';
          
              -- delete existing flight details            
              pro_del_flt_dtls(p_carr_code, p_flt_key, 'D', g_cur_date(x)+v_day_chng, v_del_tr_no);
              --commit;
              
              if v_del_tr_no is not null then
                v_cur_date := g_cur_date(x)+v_day_chng;
                v_ins_flg := 'Y';
              end if;              
            END;
          END LOOP;
        end if;
  */      
        -- insert updated flight details
        if (V_FLT_DEL_ERROR IS NULL) THEN
           createdailyflight(p_tr_no);
         END IF;
         
      END IF;
    END;
  
  PROCEDURE updateSSMDetailsForFlight IS
    
    BEGIN
      alter_nls_territory;
      --get cms config
      pro_cmsrules;
           
      for rec in 
        (SELECT tr_no, flt_key, svc_type, WH_LEVEL, cgo_acft_type, flt_module1, flt_module2, exp_flt_module1, exp_flt_module2, to_ind , VESSEL_ID, VESSEL_NAME, VOYAGE_NUM , CALL_SIGN_VESSEL, SHIPPING_AGENT 
        FROM flt_sch
       WHERE start_date <= g_end_date
         AND end_date >= g_start_date
         AND (OUTSTANDING ='Y' and cr_user_id in ('SSMRPL', 'SSMNEW', 'SSMCNLNEW'))
        -- and flt_key = 'NT101'
       ORDER BY cr_date)
      loop
        begin
          for flt in 
          (select svc_type, WH_LEVEL, cgo_acft_type, flt_module1, flt_module2, exp_flt_module1, exp_flt_module2, to_ind , RHO_ID
          from (select * from flt_sch where flt_key = rec.flt_key and OUTSTANDING ='N' and (flt_module1 is not null or exp_flt_module1 is not null) 
              and (cr_user_id in ('SSIM', 'SSMNEW') or cr_user_id not like 'SSM%' ) order by cr_date desc)
          where rownum = 1)
          loop
            update flt_sch
            set
              CGO_ACFT_TYPE = flt.CGO_ACFT_TYPE,
              WH_LEVEL = flt.WH_LEVEL,
              SVC_TYPE = flt.SVC_TYPE,
              FLT_MODULE1 = flt.FLT_MODULE1,
              TO_IND = flt.TO_IND,
              FLT_MODULE2 = flt.FLT_MODULE2,
              EXP_FLT_MODULE1 = flt.EXP_FLT_MODULE1,             
              EXP_FLT_MODULE2 = flt.EXP_FLT_MODULE2,
              OUTSTANDING = 'N',
              RHO_ID = flt.RHO_ID,
              LM_USER_ID = 'SYSTEM',
              LM_DATE = SYSDATE
            where tr_no = rec.tr_no;
          end loop;
        end;
     end loop;
     
      --process flight
      IF cc_sch_type%ISOPEN THEN
        CLOSE cc_sch_type;
      END IF;
    
      OPEN cc_sch_type;
      LOOP
        FETCH cc_sch_type
          INTO g_cc_sch_type;
        EXIT WHEN cc_sch_type%NOTFOUND;
        
        --dbms_output.put_line('g_cc_sch_type.start_date...'||g_cc_sch_type.start_date);
        --dbms_output.put_line('g_cc_sch_type.end_date...'||g_cc_sch_type.end_date);
        --dbms_output.put_line('g_cc_sch_type.flt_key...'||g_cc_sch_type.flt_key);
        --dbms_output.put_line('g_cc_sch_type.dat_flg...'||g_cc_sch_type.dat_flg);
        --dbms_output.put_line('g_cc_sch_type.cr_user_id...'||g_cc_sch_type.cr_user_id);
        --dbms_output.put_line('g_cc_sch_type.tr_no...'||g_cc_sch_type.tr_no);
        -- Check TYPE, (RPL, EQT, TIM or CNL)
        IF (g_cc_sch_type.cr_user_id = 'SSMRPL' OR g_cc_sch_type.cr_user_id = 'SSMNEW') THEN
          replaceFltDtlsForSSM(g_cc_sch_type.start_date, g_cc_sch_type.end_date, g_cc_sch_type.dat_flg, g_cc_sch_type.carr_code, g_cc_sch_type.flt_key, g_cc_sch_type.tr_no, g_cc_sch_type.cr_user_id, g_cc_sch_type.cr_date);
        ELSIF g_cc_sch_type.cr_user_id = 'SSMEQT' THEN
          updateEquipDtlsForFlt(g_cc_sch_type.start_date, g_cc_sch_type.end_date, g_cc_sch_type.flt_key, g_cc_sch_type.carr_code, g_cc_sch_type.tr_no, g_cc_sch_type.dat_flg, g_cc_sch_type.cr_user_id, g_cc_sch_type.cr_date);
        ELSIF g_cc_sch_type.cr_user_id = 'SSMTIM' THEN
          updateTimeDtlsForFlt(g_cc_sch_type.start_date, g_cc_sch_type.end_date, g_cc_sch_type.carr_code, g_cc_sch_type.flt_key, g_cc_sch_type.tr_no, g_cc_sch_type.dat_flg, g_cc_sch_type.cr_user_id, g_cc_sch_type.cr_date);
        ELSIF g_cc_sch_type.cr_user_id = 'SSMCNL' THEN
          deleteFltDtlsForFlt(g_cc_sch_type.start_date, g_cc_sch_type.end_date, g_cc_sch_type.flt_key, g_cc_sch_type.dat_flg, g_cc_sch_type.carr_code, g_cc_sch_type.tr_no, g_cc_sch_type.cr_user_id, g_cc_sch_type.cr_date);
        END IF;
        dbms_output.put_line('prc finish...'||g_cc_sch_type.tr_no);
      END LOOP;
        
    END;
  
------------------------------------------------------------------------------------------------------------------------

END pkg_schedule_flight;
/
SHOW ERRORS