--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PROCEDURE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT Creating WOSINT.ARCHIVAL_TEST
CREATE OR REPLACE PROCEDURE WOSINT.ARCHIVAL_TEST AS 
QUERY_TEST varchar2(1000);
Query_test1 varchar2(1000);
COUNT1 number;
COUNT2 number;
cursor ARCHIVAL_MASTER is
select ENTITY_NAME from ARCH_MAIN_ENTITY where MASTER_TABLE='Y' ;
CURSOR ARCHIVAL_FLT IS
SELECT * FROM ARCH_MAIN_ENTITY WHERE ENTITY_TYPE IN ('FLT','AWB') AND (MASTER_TABLE !='LOG' OR MASTER_TABLE IS NULL) order by TO_NUMBER(DELETE_ORDER_NO);
BEGIN
  for I in ARCHIVAL_MASTER LOOP
  --DEBUG_OBJ_ARCH('ENTITY_NAME:'||i.entity_name);
  Query_test:=null;
  count1:=0;
    QUERY_TEST:='select count(1) from '||I.ENTITY_NAME;
    QUERY_TEST1:='select count(1) from '||I.ENTITY_NAME||'@dbl_wosarch';
  -- execute immediate QUERY_TEST into COUNT1;
    execute immediate QUERY_TEST1 into COUNT2;
    --if(count1=0) then
     -- DBMS_OUTPUT.PUT_LINE(I.ENTITY_NAME||' '||COUNT1);
     dbms_output.put_line(i.entity_name||' '||count2);
--    else
--    dbms_output.put_line(i.entity_name||' '||count1);
   -- end if;
  end LOOP;
--  for J in ARCHIVAL_FLT LOOP
--  --DEBUG_OBJ_ARCH('ENTITY_NAME:'||i.entity_name);
--  Query_test:=null;
--  count1:=0;
--    QUERY_TEST:='select count(1) from '||J.ENTITY_NAME;
--    QUERY_TEST1:='select count(1) from '||J.ENTITY_NAME||'@dbl_wosarch';
--    --execute immediate QUERY_TEST into COUNT1;
--    execute immediate QUERY_TEST1 into COUNT2;
--    --if(count1=0) then
--      --DBMS_OUTPUT.PUT_LINE(J.ENTITY_NAME||' '||COUNT1);
--      dbms_output.put_line(J.entity_name||' '||count2);
----    else
----    dbms_output.put_line(i.entity_name||' '||count1);
--   -- end if;
--  end loop;
END ARCHIVAL_TEST;

/
SHOW ERRORS