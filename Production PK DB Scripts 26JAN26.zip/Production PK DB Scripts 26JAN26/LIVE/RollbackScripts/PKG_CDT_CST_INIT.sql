--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PACKAGE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT CREATE OR REPLACE PACKAGE WOSINT.PKG_CDT_CST_INIT
CREATE OR REPLACE PACKAGE WOSINT.PKG_CDT_CST_INIT
IS
  FUNCTION initial_cdt_csgnmt_subm(p_flt_key IN VARCHAR2,
                                          p_flt_date IN VARCHAR2,
                                          p_ver_no IN OUT NUMBER,
                                          p_user_id IN VARCHAR2,
                                          p_lm_date IN DATE)
    RETURN VARCHAR2;
  FUNCTION amend_cdt_csgnmt_subm(p_flt_key VARCHAR2,
                                        p_flt_date VARCHAR2,
                                        p_ver_no IN OUT NUMBER,
                                        p_user_id IN VARCHAR2,
                                        p_lm_date IN DATE) RETURN VARCHAR2;
  FUNCTION behind_cdt_csgnmt_subm(p_flt_key VARCHAR2,
                                         p_flt_date VARCHAR2,
                                         p_ver_no IN OUT NUMBER,
                                         p_user_id IN VARCHAR2,
                                         p_lm_date IN DATE) RETURN VARCHAR2;
                                         
  procedure  sub_ins_cst_cd_awb_hawb(p_rec_type IN VARCHAR2, 
                                      p_truck_flt_no IN VARCHAR2,  
                                      p_truck_flt_date IN VARCHAR2,   
                                      p_itfs_flt_key IN VARCHAR2,  
                                      p_itfs_flt_date IN VARCHAR2,   
                                      p_subm_ver_no OUT NUMBER,   
                                      p_user_id IN VARCHAR2) ;
                                      

  procedure subm_awb_LBS(rec_type IN VARCHAR2, 
                        p_truck_flt_no IN VARCHAR2, 
                        p_truck_flt_date IN VARCHAR2, 
                        p_itfs_flt_key  IN VARCHAR2, 
                        p_itfs_flt_date IN VARCHAR2,
                        p_user_id IN VARCHAR2,
                        p_awb_no IN VARCHAR2, 
                        p_awb_date  IN date, 
                        p_CNSL_IND IN VARCHAR2) ;   
                        
  procedure delete_awb_LBS(rec_type IN VARCHAR2, 
                        p_truck_flt_no IN VARCHAR2, 
                        p_truck_flt_date IN VARCHAR2, 
                        p_itfs_flt_key  IN VARCHAR2, 
                        p_itfs_flt_date IN VARCHAR2);  
                        
  procedure validate_LBS(rec_type IN VARCHAR2, 
                        p_truck_flt_no IN VARCHAR2, 
                        p_truck_flt_date IN VARCHAR2, 
                        p_itfs_flt_key  IN VARCHAR2, 
                        p_itfs_flt_date IN VARCHAR2,
                        p_ret OUT VARCHAR2);                      
                  
END pkg_cdt_cst_init;
/

PROMPT CREATE OR REPLACE PACKAGE BODY WOSINT.PKG_CDT_CST_INIT
CREATE OR REPLACE PACKAGE BODY WOSINT.PKG_CDT_CST_INIT
IS
  s_cons_header   VARCHAR2(100);
  s_cons_detail   VARCHAR2(2500);
  s_cons_footer   VARCHAR2(30);
  s_schedule_date VARCHAR2(8);
  s_version_no    VARCHAR2(2);
  s_lic_per1       VARCHAR2(240);
  s_cargo_ind     VARCHAR2(1) := 'Y';
  s_cms3_error    VARCHAR2(200);
  s_error_msg     VARCHAR2(200);
  s_int_amd       VARCHAR2(3);
  s_action_code   VARCHAR2(1);
  s_cnsl_ind      VARCHAR2(1);
--  s_man_pcs       VARCHAR2(6);
--  s_man_wt        VARCHAR2(9);
--  s_content       VARCHAR2(70);
--  s_ldg_point     VARCHAR2(3);
  s_simp_cnt      NUMBER;
  s_cnsl_cnt      NUMBER;
  s_hawb_cnt      NUMBER;
--  s_shpt_typ      VARCHAR2(1);
  s_rel_ind       VARCHAR2(1);
--  v_rel_ind       VARCHAR2(1);
--  s_uid           VARCHAR2(44);
  s_user_id       VARCHAR2(20);
  s_lm_date DATE;
--  v_cnt           NUMBER;
  s_detail_seq_no NUMBER;
  s_int_ver_no    NUMBER;
--  v_awb_date DATE;
--  v_awb_shpm_type VARCHAR2(1);
  v_cvd_chg_cust_ind  VARCHAR2(12);
  v_spl_code  VARCHAR2(18);
  v_awb_rmk  VARCHAR2(35);
  
  V_CST_ITM_AWB_SEQ number;
  
  s_awb_csgn_addr   VARCHAR2(500);
  s_awb_shpr_addr   VARCHAR2(500); 
  s_hawb_csgn_addr   VARCHAR2(500);
  s_hawb_shpr_addr   VARCHAR2(500); 
  s_vessel_header  VARCHAR2(350);
  
TYPE cursor_t
IS
  REF
  CURSOR;
    t_awb awblist;
    v_truck_flt_key VARCHAR2(10);
    v_truck_flt_date DATE;
    v_flt_key VARCHAR2(10);
    v_flt_date DATE;
    v_awb_no  VARCHAR2(30);
    v_awb_date DATE;
    v_hawb_no VARCHAR2(18);
    c_hdlg_agent constant VARCHAR2(3) := 'CPA';
    cheader   CONSTANT VARCHAR2(6) := 'HEADER';
    cdetail   CONSTANT VARCHAR2(6) := 'DETAIL';
    cfooter   CONSTANT VARCHAR2(6) := 'FOOTER';
    --ERROR MESSAGE
    --c_awb_00001 CONSTANT VARCHAR2(100) := ' Airway bill declare currency code is invalid when customs declare value is not null.';
    --c_awb_00002 CONSTANT VARCHAR2(100) := ' Airway bill(house airyway bill) is null or format is wrong(its length should be 11)';
    --c_awb_00003 CONSTANT VARCHAR2(100) := ' Airway bill(house airyway bill) origin or destination value is null';
    --c_awb_00004 CONSTANT VARCHAR2(100) := ' Airway bill(house airyway bill) piece or weight is invvalid';
    --c_awb_00005 CONSTANT VARCHAR2(100) := ' Airway bill(house airyway bill) content is invalid';
    --c_awb_00006 CONSTANT VARCHAR2(100) := ' Airway bill(house airyway bill) importer is invalid';
    --c_awb_00007 CONSTANT VARCHAR2(100) := ' Airway bill(house airyway bill) shipper is invalid';
    --c_awb_00008 CONSTANT VARCHAR2(100) := ' Airway bill pieces or weight is invalid';
    c_awb_00009 CONSTANT VARCHAR2(100) := ' Generated message format is wrong.now its length is';
    --c_awb_00013 CONSTANT VARCHAR2(100) := ' Airway bill shipper/consignee address is invalid';
    --c_awb_00014 CONSTANT VARCHAR2(100) := ' House airway bill can not have space';
    --c_awb_00010 CONSTANT VARCHAR2(100) := ' Airway bill manifest piece or weight is invalid';
    --c_awb_00011 CONSTANT VARCHAR2(100) := ' No data found';
    --c_awb_00012 CONSTANT VARCHAR2(100) := ' Aireay bill release indicator is wrong';
    --c_flt_00002 CONSTANT VARCHAR2(100) := ' Flight scheduled arrival time is wrong';
    c_flt_00003 CONSTANT VARCHAR2(100) := ' Submit is in progress';
    --C_FLT_00003 CONSTANT VARCHAR2(50):=' Flight port code of flight last take off is wrong';
    v_ver_no VARCHAR2(10);
    /************************************/
    /*INSERT INTO INITIAL CONSIGNMENT INFORMATION
    INTO CST_CSGNM TABLE
    /************************************/
  FUNCTION fun_valid_hawb_no1
    RETURN BOOLEAN
  IS
  BEGIN
    s_error_msg := '';
    FOR c       IN
    (SELECT b.awb_no,
      b.hawb_no,
      a.cst_type
    FROM cst_submit_temp a
      join (select awb_no, awb_date, itfs_flt_key , itfs_flt_date, hawb_no 
              from cdt_awb 
              join cdt_hawb on cdt_hawb.tr_no = cdt_awb.tr_no) b
              on a.awb_no = b.awb_no AND a.flt_key = b.itfs_flt_key AND a.flt_date = b.itfs_flt_date
      
    WHERE a.awb_no            = b.awb_no
    AND a.flt_key             = v_flt_key
    AND a.flt_date            = v_flt_date
    AND a.ver_no              = 1
    AND a.cst_type            = s_int_amd
    AND instr(b.hawb_no, ' ') > 0
    ORDER BY b.awb_no,
      b.hawb_no
    )
  LOOP
    IF (LENGTH(s_error_msg) + LENGTH(' ' || c.awb_no || ':' || c.hawb_no)) >= 150 THEN
      EXIT;
    END IF;
    s_error_msg := s_error_msg || ' ' || c.awb_no || ':' || c.hawb_no;
  END LOOP;
  IF s_error_msg IS NOT NULL THEN
    RETURN FALSE;
  END IF;
  RETURN TRUE;
EXCEPTION
WHEN OTHERS THEN
  IF s_error_msg IS NOT NULL THEN
    RETURN FALSE;
  END IF;
  RETURN TRUE;
END;
FUNCTION insert_cst_csgnm(
    p_hawb_no VARCHAR2,
    msg_type  VARCHAR2)
  RETURN BOOLEAN
IS
  s_seq_no NUMBER;
BEGIN
  /*IF msg_type = cdetail THEN
  SELECT nvl(MAX(seq_no), 0) + 1
  INTO s_detail_seq_no
  FROM cst_csgnm a
  WHERE a.flt_type = 'I'
  AND a.flt_key = v_flt_key
  AND a.flt_date = v_flt_date
  AND ver_no = s_version_no
  AND a.recv_rec_type = s_int_amd
  AND seq_no < 9999;
  ELSE
  s_detail_seq_no := (CASE msg_type WHEN cheader THEN 0 ELSE 99999 END);
  END IF;*/
  IF msg_type        = cheader THEN
    s_seq_no        := 0;
  ELSIF msg_type     = cfooter THEN
    s_seq_no        := 99999;
  ELSIF msg_type     = cdetail THEN
    s_detail_seq_no := s_detail_seq_no + 1;
    s_seq_no        := s_detail_seq_no;
  ELSE
    NULL;
  END IF;
  INSERT
  INTO cst_auto_submit_log VALUES
    (
      'cdetail '
      || cdetail
      ||'......awb...'
      ||v_awb_no
    );
  dbms_output.put_line
  (
    'cdetail-'||cdetail||'..msg..'||msg_type||'..v_awb_no..'||v_awb_no||'..h..'||p_hawb_no||'....s_cons_detail...'||s_cons_detail
  )
  ;
  
  s_cons_detail :=s_cons_detail||' ';
  
  INSERT
  INTO cst_csgnm
    (
      carr_code,
      flt_type,
      flt_date,
      flt_key,
      ver_no,
      recv_rec_type,
      seq_no,
      ctrl_date,
      req_uid,
      awb_no,
      hawb_no,
      cns_hdr,
      cns_dtl,
      cns_ftr,
      lm_user_id,
      lm_date,
      lm_ver,
      VESSEL_FLT_INFO
    )
    VALUES
    (
      SUBSTR(v_flt_key, 1, 2),
      'T',
      v_flt_date,
      v_flt_key,
      s_version_no,
      s_int_amd,
      s_seq_no,
      SYSDATE,
      ' ',
      DECODE(msg_type, cdetail, v_awb_no, NULL),
      DECODE(msg_type, cdetail, p_hawb_no, NULL),
      DECODE(msg_type, cheader, s_cons_header, NULL),
      DECODE(msg_type, cdetail, upper(s_cons_detail), NULL),
      DECODE(msg_type, cfooter, s_cons_footer, NULL),
      USER,
      SYSDATE,
      1,
      DECODE(msg_type, cheader,s_vessel_header, NULL)
    );
    dbms_output.put_line
  (
    'cdetail-'||cdetail||'..after..'
  )
  ;
  RETURN TRUE;
EXCEPTION
WHEN OTHERS THEN
  s_error_msg := SUBSTR
  (
    SQLCODE || SQLERRM, 1, 100
  )
  ;
--  dbms_output.put_line
--  (
--    's_error_msg-'||s_error_msg||'....s_cons_detail...'||s_cons_detail
--  )
--  ;
  INSERT INTO CST_AUTO_SUBMIT_LOG VALUES
    ('s_error_msg 4 ' || sysdate ||' ' || s_error_msg
    );
    
  INSERT INTO SYS_EXCEPTION_DTLS(FUNC_CODE,FUNC_TYPE,ACCESS_USER_ID,URL_PATH,EXCEP_MSG,EXCEP_STACK_TRACE,EXCEP_OCC_DATE)
    VALUES('ACCSITFSSubm', 'C', USER, 'ACCSITFSSubmission', 's_int_amd : '||s_int_amd|| ' :: s_error_msg 4 ' || S_ERROR_MSG, UTL_RAW.CAST_TO_RAW(S_ERROR_MSG) , SYSDATE);
  
  RETURN FALSE;
END;
PROCEDURE insert_awb_event
  (
    p_awb_pcs NUMBER,
    p_awb_wt  NUMBER
  )
IS
  v_event_desc VARCHAR2
  (
    100
  )
  ;
  --v_awb_date   DATE;
  v_event_id VARCHAR2
  (
    12
  )
  ;
BEGIN 
  v_event_id :=
  (
    CASE
    WHEN s_int_amd = 'INT' THEN
      'SUBCBXINTC'
    WHEN s_int_amd = 'AMD' THEN
      'SUBCBXAMDC'
    WHEN s_int_amd = 'BDS' THEN
      'SUBCBXLBC'
    END
  )
  ;
  BEGIN
    SELECT event_desc
    INTO v_event_desc
    FROM mast_awb_events
    WHERE event_id = v_event_id;
  EXCEPTION
  WHEN no_data_found THEN
    v_event_desc :=
    (
      CASE
      WHEN s_int_amd = 'INT' THEN
        'Submit CBX INT consignment'
      WHEN s_int_amd = 'AMD' THEN
        'Submit CBX AMD consignment'
      WHEN s_int_amd = 'BDS' THEN
        'Submit CBX LB consignment'
      END);
  END;
  INSERT
  INTO awb_events
    (
      awb_no,
      awb_date,
      event_id,
      event_desc,
      flt_key,
      flt_date,
      flt_type,
      tr_no,
      pcs,
      wt,
      cr_user_id,
      cr_date,
      lm_user_id,
      lm_date
    )
    VALUES
    (
      v_awb_no,
      v_awb_date,
      v_event_id,
      v_event_desc,
      v_flt_key,
      v_flt_date,
      'T',
      awb_event_seq.NEXTVAL,
      p_awb_pcs,
      p_awb_wt,
      s_user_id,
      s_lm_date,
      s_user_id,
      s_lm_date
    );
EXCEPTION
WHEN OTHERS THEN
  RETURN;
END;
PROCEDURE pro_awb_list
IS
BEGIN

--DBMS_OUTPUT.PUT_LINE('pro_awb_list start ');

  t_awb := awblist();
  
--  DBMS_OUTPUT.PUT_LINE('awblist');
  
--  DBMS_OUTPUT.PUT_LINE('t_awb');
  
  FOR c IN
  (SELECT DISTINCT a.flt_key,
      a.flt_date,
      a.ver_no,
      a.awb_no,
      a.hawb_no,
      a.cst_type
    FROM cst_submit_temp a
    WHERE flt_key = v_flt_key
    AND FLT_DATE  = V_FLT_DATE
    AND ver_no    = 1
    AND cst_type  = s_int_amd
    ORDER BY awb_no,
      hawb_no
  )
  LOOP
    t_awb.EXTEND;
    dbms_output.put_line('pro awb list....'||c.awb_no) ;
    t_awb(t_awb.COUNT) := subm_list(c.awb_no, NVL(c.hawb_no, '000000000000000000'));
  END LOOP;
  IF t_awb.COUNT > 0 THEN
    IF t_awb(1).awb_no      = 'NIL' THEN
      s_cargo_ind := 'N';
    ELSE
      s_cargo_ind := 'Y';
    END IF;
  END IF;
  
--   DBMS_OUTPUT.PUT_LINE('pro_awb_list end s_cargo_ind - '||s_cargo_ind);
EXCEPTION
WHEN OTHERS THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 200);
--  DBMS_OUTPUT.PUT_LINE('pro_awb_list s_error_msg - '||s_error_msg);
  INSERT INTO CST_AUTO_SUBMIT_LOG VALUES('PRO_AWB_LIST 5' || sysdate ||' ' || S_ERROR_MSG);
  
  INSERT INTO SYS_EXCEPTION_DTLS(FUNC_CODE,FUNC_TYPE,ACCESS_USER_ID,URL_PATH,EXCEP_MSG,EXCEP_STACK_TRACE,EXCEP_OCC_DATE)
   		VALUES('ACCSITFSSubm', 'C', USER, 'ACCSITFSSubmission','s_int_amd : '||s_int_amd|| ' :: PRO_AWB_LIST 5 ' || S_ERROR_MSG, UTL_RAW.CAST_TO_RAW(S_ERROR_MSG) , SYSDATE);

END;

PROCEDURE init
IS
BEGIN
  s_cons_header   := NULL;
  s_cons_detail   := NULL;
  s_cons_footer   := NULL;
  s_schedule_date := NULL;
--  s_lic_per       := NULL;
  s_cargo_ind     := 'N';
  s_error_msg     := NULL;
  s_action_code   := NULL;
  s_cnsl_ind      := 'N';
--  s_man_pcs       := 0;
--  s_man_wt        := 0;
  s_simp_cnt      := 0;
  s_cnsl_cnt      := 0;
  s_hawb_cnt      := 0;
  s_detail_seq_no := 0;
END;

/************************************/
/*GET THE AWB INFORMATION WHICH HAS NO HOUSE AIRAYBILL AND
INSERT INTO TABLE
************************************/
FUNCTION get_awb_info
  RETURN BOOLEAN
IS
  --s_sql_str    VARCHAR2(400);
  c_awb CST_ITM_AWB%ROWTYPE;
  s_awb_no     VARCHAR2(30);
  v_cnt        NUMBER;
  v_old_cnt        NUMBER;
  v_new_cnt        NUMBER;
  s_msg_length NUMBER;
  v_isdhl      BOOLEAN;
  CURSOR cur_awb
  IS
    SELECT *
    FROM CST_ITM_AWB
    WHERE itfs_flt_key    = v_flt_key
    AND itfs_flt_date   = v_flt_date
    and TRUCK_FLT_NO = v_truck_flt_key
    and TRUCK_FLT_DATE  = v_truck_flt_date
    AND awb_no     = v_awb_no
    and accs_ind = s_int_amd 
    AND BRKN_DOWN_CODE IS NULL;
BEGIN

    s_action_code := null ;
 
    DBMS_OUTPUT.PUT_LINE('start get_awb_info');
  --CHECK WHETHER THE AWB MESSAGE EXISTS OR NOT
  IF s_int_amd = 'AMD' THEN
    BEGIN
      SELECT awb_no
      INTO s_awb_no
      FROM cst_csgnm
      WHERE  flt_type   = 'T'
      AND flt_key       = v_flt_key
      AND flt_date      = v_flt_date
      AND ver_no        = s_version_no
      AND recv_rec_type = 'AMD'
      AND awb_no        = v_awb_no
      AND hawb_no       = '000000000000000000';
      RETURN TRUE;
    EXCEPTION
    WHEN no_data_found THEN
      NULL;
    WHEN too_many_rows THEN
      RETURN TRUE;
    END;
  END IF;
 
--  DBMS_OUTPUT.PUT_LINE('start get_awb_info 22');
 
  IF cur_awb%ISOPEN THEN
    CLOSE cur_awb;
  END IF;
  
--  DBMS_OUTPUT.PUT_LINE('start get_awb_info 33');
  
  OPEN cur_awb;
--  DBMS_OUTPUT.PUT_LINE('start get_awb_info 331');
  FETCH cur_awb INTO c_awb;
--  DBMS_OUTPUT.PUT_LINE('start get_awb_info 332');
  IF cur_awb%NOTFOUND THEN
--  DBMS_OUTPUT.PUT_LINE('start get_awb_info 333');
    -- s_cms3_error := c_awb_00011;
    CLOSE cur_awb;
--  DBMS_OUTPUT.PUT_LINE('start get_awb_info 334');
    --  RETURN FALSE;
    NULL;
--  DBMS_OUTPUT.PUT_LINE('start get_awb_info 335');
  END IF;
--  DBMS_OUTPUT.PUT_LINE('start get_awb_info 336');
  
--  DBMS_OUTPUT.PUT_LINE('start get_awb_info 44');
  
  s_cnsl_ind  := 'N';
  IF s_int_amd = 'AMD' THEN  
    
    SELECT COUNT(1)
    INTO v_new_cnt
      FROM cdt_hawb
      WHERE nvl(hawb_no,'000000000000000000') <> '000000000000000000'
      and tr_no = (select tr_no from cdt_awb where awb_no = v_awb_no  
      and itfs_flt_key       = v_flt_key
      AND itfs_flt_date      = v_flt_date);
    
     
      SELECT COUNT(1)
    INTO v_old_cnt
      FROM cst_itm_hawb
      WHERE nvl(hawb_no,'000000000000000000') <> '000000000000000000'
      and  awb_no = v_awb_no  
      and itfs_flt_key       = v_flt_key
      AND itfs_flt_date      = v_flt_date
      and accs_ind = 'INT' ;
      
      if  c_awb.CHANGE_IND = 'D'  then
       s_action_code := 'D';
       if v_old_cnt > 0 then
           s_cnsl_ind    := 'Y';           
          else
           s_cnsl_ind    := 'N';
          end if;
      elsif  c_awb.CHANGE_IND = 'A' and v_new_cnt > 0 then
       s_cnsl_ind    := 'Y';
      elsif  c_awb.CHANGE_IND = 'U' then
          if v_new_cnt > 0 then
           s_cnsl_ind    := 'Y';
--          elsif v_old_cnt = 0 and v_new_cnt > 0 then
--           s_cnsl_ind    := 'Y';
          elsif  v_new_cnt = 0 then
           s_cnsl_ind    := 'N';
          end if;
      else 
       s_cnsl_ind    := 'N';
      end if;
--    SELECT COUNT(*)
--    INTO v_cnt
--    FROM TABLE(CAST(t_awb AS awblist))
--    WHERE awb_no     = v_awb_no
--    AND hawb_no     <> '000000000000000000';
--    IF NVL(v_cnt, 0) > 0 THEN
--      s_cnsl_ind    := 'Y';
--    ELSE
--     s_cnsl_ind := 'N';
--     DBMS_OUTPUT.PUT_LINE('get_awb_info 11');
--      BEGIN
--        SELECT 'Y'
--        INTO s_cnsl_ind
--        FROM cst_csgnm
--        WHERE  flt_type    = 'T'
--        AND flt_key       = v_flt_key
--        AND flt_date      = v_flt_date
--        AND recv_rec_type = 'INT'
--        AND awb_no        = v_awb_no
--        AND nvl(hawb_no,'000000000000000000') <> '000000000000000000'
--        AND rownum        = 1;
--      EXCEPTION
--      WHEN no_data_found THEN
--        s_cnsl_ind := 'N';
--      WHEN OTHERS THEN
--        s_cnsl_ind := 'N';
--      END;
--    END IF;
    
    DBMS_OUTPUT.PUT_LINE('get_awb_info 33  - s_cnsl_ind - '||s_cnsl_ind);
    
  ELSIF s_int_amd = 'INT' THEN  
  DBMS_OUTPUT.PUT_LINE('get_awb_info 22');
    BEGIN
      SELECT COUNT(*)
      INTO v_cnt
      FROM cdt_hawb
      WHERE nvl(hawb_no,'000000000000000000') <> '000000000000000000'
      and tr_no = (select tr_no from cdt_awb where awb_no = v_awb_no  
      and itfs_flt_key       = v_flt_key
      AND itfs_flt_date      = v_flt_date);
      
      IF NVL(v_cnt, 0) > 0 THEN
      s_cnsl_ind    := 'Y';
      else
      s_cnsl_ind    := 'N';
      end if;
--      SELECT 'Y'
--      INTO s_cnsl_ind
--      FROM cst_itm_hawb
--      WHERE awb_no = v_awb_no and nvl(hawb_no,'000000000000000000') <> '000000000000000000'
--      AND rownum   = 1;
    EXCEPTION
    WHEN no_data_found THEN
      s_cnsl_ind := 'N';
    WHEN OTHERS THEN
      s_cnsl_ind := 'N';
    END;
    
    
--    DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - s_cnsl_ind - '||s_cnsl_ind);
    
  ELSIF s_int_amd = 'BDS' THEN  
  DBMS_OUTPUT.PUT_LINE('get_awb_info 22');
    BEGIN
      SELECT COUNT(*)
      INTO v_cnt
      FROM cdt_hawb
      WHERE nvl(hawb_no,'000000000000000000') <> '000000000000000000'
      and tr_no = (select tr_no from cdt_awb where awb_no = v_awb_no  
      and itfs_flt_key       = v_flt_key
      AND itfs_flt_date      = v_flt_date);
      IF NVL(v_cnt, 0) > 0 THEN
      s_cnsl_ind    := 'Y';
      else
      s_cnsl_ind    := 'N';
      end if;
--      SELECT 'Y'
--      INTO s_cnsl_ind
--      FROM cst_itm_hawb
--      WHERE awb_no = v_awb_no and nvl(hawb_no,'000000000000000000') <> '000000000000000000'
--      AND rownum   = 1;
    EXCEPTION
    WHEN no_data_found THEN
      s_cnsl_ind := 'N';
    WHEN OTHERS THEN
      s_cnsl_ind := 'N';
    END;
    
--    DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - s_cnsl_ind - '||s_cnsl_ind);
    
  END IF;
  
  IF s_cnsl_ind = 'Y' THEN
    s_cnsl_cnt := s_cnsl_cnt + 1;
  ELSE
    s_simp_cnt := s_simp_cnt + 1;
  END IF;
  
  DBMS_OUTPUT.PUT_LINE('get_awb_info 404  - s_cnsl_cnt - '||s_cnsl_cnt);
  DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.awb_date - '|| c_awb.awb_date);
   
  begin
  select spl_code1 || spl_code2 || spl_code3 || spl_code4 || spl_code5 || spl_code6,  '' 
  into v_spl_code, v_awb_rmk
  from awb 
  where awb_no = c_awb.awb_no and awb_date = c_awb.awb_date ;
     end;
--  get_lic_per;
  s_rel_ind := ( CASE WHEN s_int_amd IN ('AMD', 'BDS') THEN ' ' ELSE 'T' END);
--  v_isdhl := get_isdhl(c_awb.hdlg_agent);
 
-- DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.itfs_flt_key - '||c_awb.itfs_flt_key);
--  DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.itfs_flt_date - '||c_awb.itfs_flt_date);
--    DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.awb_no - '||c_awb.awb_no);
--        DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.v_awb_date - '||v_awb_date);
 v_awb_date := c_awb.awb_date;
-- BEGIN
--    SELECT awb_date
--    INTO v_awb_date
--    FROM cst_itm_awb
--    WHERE itfs_flt_key = c_awb.itfs_flt_key
--    AND itfs_flt_date  = c_awb.itfs_flt_date
--    AND awb_no    = c_awb.awb_no
--    and awb_date is not null
--    AND rownum    = 1;
--  EXCEPTION
--  WHEN no_data_found THEN
--    v_awb_date := TRUNC(SYSDATE);
--  END;
--  s_shpt_typ      := pkg_cst.get_shpt_type(c_awb.awb_no, v_awb_date, 'CPA', s_cnsl_ind);
--  v_awb_shpm_type := s_shpt_typ;

--  DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - s_shpt_typ - '||s_shpt_typ);
  
--  DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - s_rel_ind - '||s_rel_ind);

--  IF s_shpt_typ = 'I'  AND s_rel_ind NOT IN ('R', 'S', 'X', ' ') THEN

--   if s_int_amd IN ('AMD', 'BDS') then
--      s_rel_ind := ' ';
--    else
--      s_rel_ind := 'X';
--   end if;

--    NULL;
--  END IF;

--  IF s_shpt_typ = 'T'  AND s_rel_ind NOT IN ('F', 'M', 'X', ' ') THEN
--    if s_int_amd IN ('AMD', 'BDS') then
--      s_rel_ind := ' ';
--    else
--      s_rel_ind := 'X';
--   end if;
--    NULL;
--  END IF;

  s_cons_detail := '';
  --validation start
  --manifest piece and weight
--  IF c_awb.change_ind        = 'D' THEN
--    IF NVL(c_awb.man_pcs, 0) = 0 OR NVL(c_awb.man_wgt, 0) = 0 THEN
--
--      NULL;
--    END IF;
--    s_man_wt  := lpad(TRIM(TO_CHAR(c_awb.man_wgt, '9999999.0')), 9, '0');
--    s_man_pcs := lpad(c_awb.man_pcs, 6, '0');
--  ELSE
-- DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - s_man_pcs - '||c_awb.man_pcs);
 
--  DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - s_man_wt - '||c_awb.man_wgt);
 
    IF to_number(c_awb.man_pcs) = 0 OR to_number(c_awb.man_wgt) = 0 THEN

      NULL;
    END IF;
--  END IF;
  --airway bill number
  
--    DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.awb_no - '||c_awb.awb_no);
    
  IF LENGTH(c_awb.awb_no) <> 11 OR c_awb.awb_no IS NULL THEN

    NULL;
  END IF;
  
--   DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.AWB_ORIGIN - '||c_awb.AWB_ORIGIN);
   
--    DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.AWB_Dest - '||c_awb.AWB_Dest);
   
--    DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - s_ldg_point - '||s_ldg_point);
   
  --airway bill origin and destination
  IF c_awb.ORG IS NULL OR c_awb.DEST IS NULL OR c_awb.unldg_pt IS NULL OR LENGTH(c_awb.ORG) <> 3 OR LENGTH(c_awb.DEST) <> 3 OR LENGTH( c_awb.unldg_pt) <> 3 THEN

    NULL;
  END IF;
  
--  DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.AWB_PCS - '||c_awb.AWB_PCS);
  
  --airway bill piece and weight
  IF NVL(c_awb.MAN_PCS, 0) = 0 OR NVL(c_awb.MAN_WGT, 0) = 0 THEN

    NULL;
  END IF;
  
--  DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.SHIP_DESC - '||c_awb.SHIP_DESC);
  --airway bill contenct
  IF c_awb.content IS NULL THEN

    NULL;
  END IF;
  
--  DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.CURR_VALUE - '||c_awb.CURR_VALUE);
--  --customs declare value
--  IF NVL(c_awb.CURR_VALUE, 0) = 0 THEN
----    c_awb.cvd_chg_cust_ind         := 'NCV';
--    v_cvd_chg_cust_ind         := 'NCV';
--    c_awb.CURR_CODE        := ' ';
--  ELSE
--    IF c_awb.CURR_CODE IS NULL THEN
--
--      NULL;
--    END IF; 
--    v_cvd_chg_cust_ind         := NULL;
----    c_awb.cvd_chg_cust_ind := NULL;
--  END IF;
  
--  DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.CSGNE_NAME - '||c_awb.CSGNE_NAME);
--  
--  DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.CSGNE_ADD1 - '||c_awb.CSGNE_ADDR);
  --consignee
  IF c_awb.CSGNE_NAME IS NULL OR c_awb.CSGNE_ADDR IS NULL THEN

    NULL;
  END IF;
  
--    DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.SHPR_NAME - '||c_awb.SHPR_NAME);
--  
--  DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.SHPR_ADD1 - '||c_awb.SHPR_ADDR);
  --shipper
  IF c_awb.SHPR_NAME IS NULL OR c_awb.SHPR_ADDR IS NULL THEN

    NULL;
  END IF;
  IF c_awb.SHPR_ADDR IS NULL OR c_awb.CSGNE_ADDR IS NULL THEN

    NULL;
  END IF;
      
  
--  DBMS_OUTPUT.PUT_LINE('get_awb_info 44 before - v_spl_code, v_awb_rmk - ');
--  
--  DBMS_OUTPUT.PUT_LINE('get_awb_info 44  - c_awb.v_spl_code - '||v_spl_code);
--  
  DBMS_OUTPUT.PUT_LINE('get_awb_info 444  - v_awb_rmk - '||v_awb_rmk);
--  dbms_output.put_line('before...'||c_awb.awb_no||'...'||s_cons_detail);
  --validation end
  
  
   s_awb_csgn_addr := null;

    if c_awb.csgne_addr is not null
        or c_awb.csgne_addr2 is not null 
        or  c_awb.csgne_addr3 is not null 
        or c_awb.csgne_addr4 is not null then 
    s_awb_csgn_addr := FUN_CONCAT_ADDR_WITHSPACE(c_awb.csgne_addr , c_awb.csgne_addr2 , c_awb.csgne_addr3 , c_awb.csgne_addr4 , null ,
    c_awb.CSGNE_PLACE , c_awb.CSGNE_STATE_PROVINCE , c_awb.CSGNE_CTRY_CODE , c_awb.CSGNE_PIN_CODE)  ;
    end if;

--  SHPR_PLACE                     VARCHAR2(17)   
--SHPR_CTRY_CODE                 VARCHAR2(3)    
--SHPR_STATE_PROVINCE            VARCHAR2(9)    
--SHPR_PIN_CODE                  VARCHAR2(9)   

   s_awb_shpr_addr := null;

    if c_awb.SHPR_addr is not null
        or c_awb.SHPR_addr2 is not null 
        or  c_awb.SHPR_addr3 is not null 
        or c_awb.SHPR_addr4 is not null then 
    s_awb_shpr_addr := FUN_CONCAT_ADDR_WITHSPACE(c_awb.SHPR_addr , c_awb.SHPR_addr2 , c_awb.SHPR_addr3 , c_awb.SHPR_addr4  , null ,
    c_awb.SHPR_PLACE , c_awb.SHPR_STATE_PROVINCE , c_awb.SHPR_CTRY_CODE , c_awb.SHPR_PIN_CODE)  ;
    end if;
 
  s_cons_detail := s_schedule_date || --2.2.1
  rpad(FUN_CST_ACCS_TRANSITION(FUN_CST_FLT_KEY_SUBM(v_flt_key,v_flt_date,v_ver_no)), 9, ' ') ||          --2.2.2-3
  s_version_no ||                     --2.2.4
  (
    CASE
    WHEN s_int_amd = 'BDS' THEN
      'BLB'
    ELSE
      ''
    END) ||                                                       --ONLY FOR LBS 2.2.5-6
  SUBSTR(c_awb.awb_no, 1, 3) || '-' || SUBSTR(c_awb.awb_no, 4) || --2.2.5
  lpad('0', 18, '0') ||                                           --2.2.6
  c_awb.ORG ||                                             --2.2.7
  c_awb.DEST ||                                                  --2.2.8
  c_awb.unldg_pt ||                                               --2.2.9
  lpad(c_awb.MAN_pcs, 6, '0') ||                                                    --2.2.10
  lpad(TRIM(to_char(c_awb.man_wgt,   '9999999.0')),   9,   '0') ||                                                     --2.2.11
  lpad(c_awb.MAN_pcs, 6, '0') ||                                      --2.2.12
      lpad(TRIM(to_char(c_awb.man_wgt,   '9999999.0')),   9,   '0') || --2.2.13
      FUN_CONCAT_ACCS_ADDRESS_VALUE(c_awb.content || rpad(' ',265-lengthb(c_awb.content),' '))|| --2.2.14
       rpad(' ',   3,   ' ') || 
       rpad('NCV',   12,   ' ') ||
--      (
--      CASE
--        WHEN nvl(c_awb.CURR_VALUE,   0) = 0 THEN rpad(' ',   3,   ' ')
--        ELSE c_awb.CURR_CODE
--        END) ||(
--      CASE
--        WHEN nvl(c_awb.CURR_VALUE,   0) = 0 THEN rpad('NCV',   12,   ' ')
--        ELSE lpad(v_cvd_chg_cust_ind,   12,   '0')
--      END) || 
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
    (CASE
    WHEN LENGTH(rpad(nvl(c_awb.csgne_name,   'XXX'),   70,   ' ')) < 70 THEN
    rpad(nvl(c_awb.csgne_name,   'XXX'),   70,   ' ') ||  rpad(' ',   70 - LENGTH(rpad(nvl(c_awb.csgne_name,   'XXX'),   70,   ' ')),   ' ')
    else rpad(nvl(c_awb.csgne_name,   'XXX'),   70,   ' ')
    END) ||
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
     rpad(' ',   60,   ' ') || --Consignee Chinese Name

--  s_awb_csgn_addr
    FUN_CONCAT_ACCS_ADDRESS_VALUE(nvl(s_awb_csgn_addr,   'XXX') || rpad(' ',265-lengthb(nvl(s_awb_csgn_addr,   'XXX')),' ')) ||
  
 --   rpad(nvl(c_awb.csgne_addr,   'XXX'),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.csgne_addr,   'XXX'),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.csgne_addr,   'XXX'),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.csgne_addr,   'XXX'),   53,   ' ')),   ' ')
--    else rpad(nvl(c_awb.csgne_addr,   'XXX'),   53,   ' ')
--    END) ||

--     rpad(nvl(c_awb.csgne_addr2,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.csgne_addr2,   ' '),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.csgne_addr2,   ' '),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.csgne_addr2,   ' '),   53,   ' ')),   ' ')
--    else  rpad(nvl(c_awb.csgne_addr2,   ' '),   53,   ' ')
--    END) ||

--    rpad(nvl(c_awb.csgne_addr3,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.csgne_addr3,   ' '),   53,   ' ')) < 53 THEN
--     rpad(nvl(c_awb.csgne_addr3,   ' '),   53,   ' ') || rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.csgne_addr3,   ' '),   53,   ' ')),   ' ')
--     else rpad(nvl(c_awb.csgne_addr3,   ' '),   53,   ' ')
--    END) ||

--     rpad(nvl(c_awb.csgne_addr4,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.csgne_addr4,   ' '),   106,   ' ')) < 106 THEN
--      rpad(nvl(c_awb.csgne_addr4,   ' '),   106,   ' ') || rpad(' ',   106 - LENGTH(rpad(nvl(c_awb.csgne_addr4,   ' '),   106,   ' ')),   ' ')
--      else  rpad(nvl(c_awb.csgne_addr4,   ' '),   106,   ' ')
--    END) ||

--     rpad(nvl(c_awb.csgne_addr4,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.csgne_add5,   ' '),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.csgne_add5,   ' '),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.csgne_add5,   ' '),   53,   ' ')),   ' ')
--    else rpad(nvl(c_awb.csgne_add5,   ' '),   53,   ' ')
--    END) ||
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
     rpad(' ',   395,   ' ') || --Notify 
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
 
--    lpad(nvl(c_awb.notify_addr,   ' '),   265,   ' ') ||
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
   (CASE
    WHEN LENGTH(rpad(nvl(c_awb.shpr_name,   'XXX'),   70,   ' ')) < 70 THEN
      rpad(nvl(c_awb.shpr_name,   'XXX'),   70,   ' ') || rpad(' ',   70 - LENGTH(rpad(nvl(c_awb.shpr_name,   'XXX'),   70,   ' ')),   ' ')
      else  rpad(nvl(c_awb.shpr_name,   'XXX'),   70,   ' ')
    END) ||
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401
     rpad(' ',   60,   ' ') || --Exporter Chinese Name

--    s_awb_shpr_addr
    FUN_CONCAT_ACCS_ADDRESS_VALUE(nvl(s_awb_shpr_addr,   'XXX') || rpad(' ',265-lengthb(nvl(s_awb_shpr_addr,   'XXX')),' ')) ||
   

--  rpad(nvl(c_awb.shpr_addr,   'XXX'),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.shpr_addr,   'XXX'),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.shpr_addr,   'XXX'),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.shpr_addr,   'XXX'),   53,   ' ')),   ' ')
--    else rpad(nvl(c_awb.shpr_addr,   'XXX'),   53,   ' ')
--    END) ||

--     rpad(nvl(c_awb.shpr_addr2,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.shpr_addr2,   ' '),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.shpr_addr2,   ' '),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.shpr_addr2,   ' '),   53,   ' ')),   ' ')
--    else rpad(nvl(c_awb.shpr_addr2,   ' '),   53,   ' ')
--    END) ||

--     rpad(nvl(c_awb.shpr_addr3,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.shpr_addr3,   ' '),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.shpr_addr3,   ' '),   53,   ' ') ||   rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.shpr_addr3,   ' '),   53,   ' ')),   ' ')
--    else  rpad(nvl(c_awb.shpr_addr3,   ' '),   53,   ' ')
--    END) ||

--     rpad(nvl(c_awb.shpr_addr4,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.shpr_addr4,   ' '),   106,   ' ')) < 106 THEN
--     rpad(nvl(c_awb.shpr_addr4,   ' '),   106,   ' ') ||  rpad(' ',   106 - LENGTH(rpad(nvl(c_awb.shpr_addr4,   ' '),   106,   ' ')),   ' ')
--     else  rpad(nvl(c_awb.shpr_addr4,   ' '),   106,   ' ')
--    END) ||

--     rpad(nvl(c_awb.shpr_addr4,   ' '),   53,   ' ') ||

--    (CASE
--    WHEN LENGTH(rpad(nvl(c_awb.shpr_add5,   ' '),   53,   ' ')) < 53 THEN
--    rpad(nvl(c_awb.shpr_add5,   ' '),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_awb.shpr_add5,   ' '),   53,   ' ')),   ' ')
--    else rpad(nvl(c_awb.shpr_add5,   ' '),   53,   ' ')
--    END) ||
--  s_shpt_typ ||                                                                                                                                                                          --2.2.26
--  NVL(s_rel_ind, ' ') ||                                                                                                                                                                 --2.2.27
  'T ' ||                                                                                                                                                                 --2.2.27
  rpad(NVL(v_spl_code, ' '), 18, ' ') ||                     --2.2.28
  rpad(NVL(SUBSTR(v_awb_rmk, 1, 35), ' '), 35, ' ') || 
  rpad( ' ', 2, ' ') ||                                                                                                                                              --2.2.30
  rpad( ' ', 7, ' ') ||                                                                                                                                               --2.2.31
  rpad( ' ', 8, ' ') ||  

  lpad(' ', 44, ' ') || --s_uid ||                         --2.2.33
  rpad(' ', 240, ' ') ||
--  s_lic_per ||                     --2.2.34
  NVL(s_cnsl_ind, 'N') ||          --2.2.35
  lpad(' ', 11, ' ') ||            --2.2.36
  c_hdlg_agent || --2.2.37

  (
    CASE s_int_amd
    WHEN 'BDS' THEN
      lpad(' ', 4, ' ') ||  'T' || ' ' -- s_shpt_typ || ' ' --LBS
    ELSE
      lpad(' ', 5, ' ')
    END); --INT AND AMD 2.2.38-39
  IF s_int_amd        = 'AMD' THEN
      s_cons_detail := c_awb.CHANGE_IND || s_cons_detail;
--      BEGIN
--        SELECT COUNT(1)
--        INTO v_cnt
--        FROM edi_ffm_msg a,
--          edi_ffm_shp b
--        WHERE a.tr_no     = b.tr_no
--        AND a.ffm_status IN ('P', 'F')
--        AND a.flt_key     = v_flt_key
--        AND a.flt_date    = v_flt_date
--        AND b.awb_no      = v_awb_no
--        AND b.man_pcs     > 0;
--      EXCEPTION
--      WHEN OTHERS THEN
--        v_cnt := 1;
--      END;
--      IF NVL(v_cnt, 0) > 0 THEN
--        s_cons_detail := 'U' || s_cons_detail;
--        s_action_code := 'U';
--      ELSE
--        s_cons_detail := 'D' || s_cons_detail;
--        s_action_code := 'D';
--      END IF;


  END IF;
  --MESSAGE VAILDATION START
  s_msg_length := LENGTHB(s_cons_detail);
  
DBMS_OUTPUT.PUT_LINE('s_msg_length...' || s_msg_length || '....' || s_cons_detail);

IF s_int_amd = 'INT' THEN
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401  1824 + 105 = 1929
  IF s_msg_length <> 1929 THEN
    s_cms3_error := 'INT - ' || c_awb.awb_no || c_awb_00009 || s_msg_length;
    RETURN FALSE;
  END IF;

  ELSIF s_int_amd = 'AMD' THEN
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401  1825 + 105 = 1930
    IF s_msg_length <> 1930 THEN
      s_cms3_error := 'AMD - ' || c_awb.awb_no || c_awb_00009 || s_msg_length;
     RETURN FALSE;
    END IF;

    ELSIF s_int_amd = 'BDS' THEN
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401  1828 + 105 = 1933
      IF s_msg_length <> 1933 THEN
        s_cms3_error := 'BDS - ' || c_awb.awb_no || c_awb_00009 || s_msg_length;
        RETURN FALSE;
      END IF;

    END IF;
  --MESSAGE VALIDATION END
  IF NOT insert_cst_csgnm(lpad('0', 18, '0'), cdetail) THEN
    s_cms3_error := 'CST_204';
    RETURN FALSE;
  END IF;
  
  DBMS_OUTPUT.PUT_LINE('insert_awb_event...');
  
  --AWB EVENTS
  insert_awb_event(c_awb.man_pcs, c_awb.man_wgt);
  --UPDATE ACCS AWB INDICATOR
  RETURN TRUE;
END;
/************************************/
/*GET VERSION NUMBER
************************************/
FUNCTION get_ver_no
  RETURN BOOLEAN
IS
  n_ver_no NUMBER;
BEGIN
  --GET VERSION NUMBER
  FOR c IN
  (SELECT ver_no,
          send_status,
          err_msg,
          nvl(length(err_msg),0) errLen
  FROM cst_subm c
  WHERE c.flt_key    = v_flt_key
  AND c.flt_date   = v_flt_date
  AND c.rec_type   = s_int_amd
  ORDER BY ver_no DESC
  )
  LOOP
    IF c.send_status = 'E' THEN -- and (c.errLen > 8 OR c.errLen = 0 OR c.errLen = 7)  THEN
      DELETE
      FROM cst_csgnm
      WHERE flt_key       = v_flt_key
      AND flt_date      = v_flt_date
      AND recv_rec_type = s_int_amd
      AND ver_no        = c.ver_no;
      DELETE
      FROM cst_subm
      WHERE flt_key        = v_flt_key
      AND flt_date       = v_flt_date
      AND rec_type       = s_int_amd
      AND ver_no         = c.ver_no;
      n_ver_no          := c.ver_no;
    ELSIF c.send_status            IN ('P', 'W') THEN
      N_VER_NO          :=          -1;
    ELSIF c.send_status IN ('R', 'A') THEN --  OR (c.send_status = 'E' and c.errLen = 8)  THEN
      n_ver_no          := c.ver_no + 1;
    END IF;
    EXIT;
  END LOOP;
  IF n_ver_no = -1 THEN
    RETURN FALSE;
  END IF;
  IF NVL(n_ver_no, 0) = 0 THEN
    n_ver_no         := 1;
  END IF;
--  DBMS_OUTPUT.PUT_LINE('1- n_ver_no in INT PKG - n '|| n_ver_no);
--  s_version_no := lpad(n_ver_no, 2, '0');

  if s_version_no = '99' then
   SELECT NVL(MAX(ver_no), 1) + 1 into n_ver_no
   FROM cst_subm c
   WHERE c.flt_key    = v_flt_key
    AND c.flt_date   = v_flt_date
    AND c.rec_type   = s_int_amd
    ORDER BY ver_no DESC;
    end if;

    s_version_no := lpad(n_ver_no, 2, '0');

--   DBMS_OUTPUT.PUT_LINE('1- s_version_no in INT PKG - n '|| s_version_no);
  RETURN TRUE;
END;
FUNCTION get_port(
    p_port OUT VARCHAR2)
  RETURN BOOLEAN
IS
BEGIN
  --GET FLIGHT PORT
  select nvl(UNLDG_PT2,'') || nvl(UNLDG_PT3,'')  into p_port  FROM ITM_TRK_FLT 
        where TRUCK_FLT_NO = v_truck_flt_key and TRUCK_FLT_DATE = v_truck_flt_date;
  IF p_port IS NULL THEN
    RETURN FALSE;
  END IF;
  p_port := rpad(p_port, 9, ' ');
  RETURN TRUE;
END;

FUNCTION get_amd_port(
    p_port OUT VARCHAR2)
  RETURN BOOLEAN
IS
BEGIN
  --GET FLIGHT PORT
  select nvl(UNLDG_PT1,'') || nvl(UNLDG_PT2,'') || nvl(UNLDG_PT3,'')  into p_port  FROM ITM_TRK_FLT 
        where TRUCK_FLT_NO = v_truck_flt_key and TRUCK_FLT_DATE = v_truck_flt_date;
  IF p_port IS NULL THEN
    RETURN FALSE;
  END IF;
  p_port := rpad(p_port, 9, ' ');
  RETURN TRUE;
END;
/************************************/
/*GET HEADER INFORMATION:FLIGHT INFO,AWB INFO AND SO NO
************************************/
FUNCTION get_hdr_info_int
  RETURN BOOLEAN
IS
  s_port VARCHAR2(10);
BEGIN
  --GET FLIGHT PORT
  IF NOT get_port(s_port) THEN
    -- s_error_msg := v_flt_key || '/.' || to_char(v_flt_date, 'DDMONYY') ||
    --              c_flt_00002;
    --RETURN FALSE;
    NULL;
  END IF;
  s_port := rpad(s_port, 9, ' ');
  SELECT --to_char(v_flt_date,   'YYYYMMDD'),
          to_char(v_flt_date,   'YYYYMMDD') || --1.2.1
          rpad(FUN_CST_ACCS_TRANSITION(FUN_CST_FLT_KEY_SUBM(v_flt_key,v_flt_date,s_version_no)), 9, ' ') ||
        --rpad(v_flt_key,   9,   ' ') ||-- 'P' || --1.2.2 1.2.3 
        s_version_no || --1.2.4
        c_hdlg_agent || --1.2.5
        lpad(nvl(to_char(sch_time),   '0'),   4,   '0') || --1.2.6      
        lpad(' ', 12, ' ') || --1.2.7 --1.2.8   
    s_port || --1.2.9--1.2.10--1.2.11
    '0' || --1.2.12
    'O' --1.2.13
    , rpad(' ', 35, ' ') || rpad(' ', 105, ' ') || rpad(' ', 17, ' ') || rpad(' ', 40, ' ') || rpad(' ', 150, ' ')
  INTO --s_schedule_date,
    s_cons_header , s_vessel_header
  FROM ITM_TRK_FLT  
  WHERE truck_flt_no = v_truck_flt_key
  AND truck_flt_date = v_truck_flt_date;
  
  s_cons_header  := s_cons_header || s_cargo_ind; --1.2.14
  RETURN TRUE;
EXCEPTION
WHEN no_data_found THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
WHEN OTHERS THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
END;
FUNCTION get_hdr_info_amd
  RETURN BOOLEAN
IS
  s_port VARCHAR2(100);
BEGIN
  --get port
  IF NOT get_port(s_port) THEN  
    NULL;
  END IF;
  s_port := rpad(s_port, 9, ' ');
  SELECT to_char(v_flt_date,   'YYYYMMDD') || --1.2.1
          rpad(FUN_CST_ACCS_TRANSITION(FUN_CST_FLT_KEY_SUBM(v_flt_key,v_flt_date,s_version_no)), 9, ' ') ||
        s_version_no || --1.2.4
        --c_hdlg_agent || --1.2.5
        --lpad(nvl(to_char(sch_time),   '0'),   4,   '0') || --1.2.6
        lpad(' ', 12, ' ') || --1.2.7 --1.2.8   
    s_port || --1.2.9--1.2.10--1.2.11
    '0' || --1.2.12
    'O' --1.2.13
  INTO s_cons_header
  FROM ITM_TRK_FLT  
  WHERE truck_flt_no = v_truck_flt_key
  AND truck_flt_date = v_truck_flt_date;
  
  RETURN insert_cst_csgnm('', cheader);
EXCEPTION
WHEN no_data_found THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
WHEN OTHERS THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
END;
FUNCTION get_hdr_info_lbs
  RETURN BOOLEAN
IS
BEGIN  
  SELECT to_char(v_flt_date,   'YYYYMMDD') || --1.2.1
          rpad(FUN_CST_ACCS_TRANSITION(FUN_CST_FLT_KEY_SUBM(v_flt_key,v_flt_date,s_version_no)), 9, ' ') ||       
        s_version_no || --1.2.4
        c_hdlg_agent 
  INTO s_cons_header
  FROM ITM_TRK_FLT  
  WHERE truck_flt_no = v_truck_flt_key
  AND truck_flt_date = v_truck_flt_date;
  
  RETURN insert_cst_csgnm('', cheader);
EXCEPTION
WHEN no_data_found THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
WHEN OTHERS THEN
  s_error_msg := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
END;
/************************************/
/*GET THE AWB INFORMATION AND HOUSE AWB INFO AND
INSERT INTO TABLE
************************************/
FUNCTION get_hawb_info
  RETURN BOOLEAN
IS
  s_sql_str VARCHAR2(400);
  cur_hawb cursor_t;
  s_error BOOLEAN := FALSE;
  c_hawb cst_itm_hawb%ROWTYPE;
  --s_hawb_no    VARCHAR2(20);
  s_msg_length NUMBER;
  v_count      NUMBER;
  
   v_chinese VARCHAR2(1);
  
--  CURSOR cur_hawb
--  IS
--    SELECT *
--    FROM CDT_HAWB
--    WHERE tr_NO  = (SELECT tr_no FROM CDT_AWB where  AWB_NO = V_AWB_NO AND AWB_DATE = V_AWB_DATE
--                  and itfs_flt_key = v_flt_key and itfs_flt_date = v_flt_date) and HAWB_NO = NVL(V_HAWB_NO,HAWB_NO);
  
BEGIN
  --IF SIMPLE SHIPMENT THERE IS NO HOUSE AIRWAY BILL
  IF s_cnsl_ind = 'N' THEN
    RETURN TRUE;
  END IF;
  --IF DELETE AWB IT NEED NOT SEND HOUSE AIRWAY BILL INFO
  IF s_action_code = 'D' AND s_int_amd = 'AMD' THEN
    RETURN TRUE;
  END IF;
  --GET THE SQL STRING
--  IF s_int_amd IN ('AMD', 'BDS') THEN
--    s_sql_str  := 'SELECT * FROM CST_HAWB WHERE AWB_NO = :V_AWB_NO AND AWB_DATE = :V_AWB_DATE AND HAWB_NO = NVL(:V_HAWB_NO,HAWB_NO)';
--    -- AND (ACCS_IND = ''N'' OR(ACCS_IND=''Y'' AND CHANGE_IND!=''A''))';  -- 
-- 

--  ELSE
--   s_sql_str := 'SELECT * FROM CDT_HAWB WHERE tr_NO = (SELECT tr_no FROM CDT_AWB where  AWB_NO = :v_awb_no  AND AWB_DATE = to_date(:v_awb_date,'|| '''DD-MON-YY HH24.MI.SS'''||')
-- AND AWB_DATE = to_date(:v_awb_date,'|| '''DD-MON-YY HH24.MI.SS'''||')
--                 and itfs_flt_key = :v_flt_key and itfs_flt_date = to_date(:v_flt_date,'|| '''DD-MON-YY HH24.MI.SS'''||')) and HAWB_NO = NVL(:v_hawb_no,HAWB_NO)' and HAWB_NO = NVL(:v_hawb_no,HAWB_NO);

    s_sql_str := 'SELECT * FROM CST_ITM_HAWB WHERE BRKN_DOWN_CODE IS NULL AND ACCS_IND = :s_int_amd  AND AWB_NO = :v_awb_no 
                 and itfs_flt_key = :v_flt_key and itfs_flt_date = to_date(:v_flt_date,'|| '''DD-MON-YY HH24.MI.SS'''||')  and HAWB_NO <>' || '''000000000000000000''';                 
   
 --  s_sql_str := 'SELECT * FROM CDT_HAWB WHERE tr_NO = (SELECT tr_no FROM CDT_AWB where  AWB_NO = ' || ''''||v_awb_no||'''' ||'  AND AWB_DATE = to_date(:V_AWB_DATE,'|| '''DD-MON-YY HH24.MI.SS'''||')
  --                and itfs_flt_key = :V_flt_key and itfs_flt_date = to_date(:v_flt_date,'|| '''DD-MON-YY HH24.MI.SS'''||')) and HAWB_NO = NVL(:V_HAWB_NO,HAWB_NO)';               
                  
   --               ' || ''''||S_FLT_DATE||'''' ||'
--  END IF;

--DBMS_OUTPUT.PUT_LINE('Check HAWB s_sql_str -- s_sql_str - '||s_sql_str);
  IF cur_hawb%ISOPEN THEN
    CLOSE cur_hawb;
  END IF;
  OPEN cur_hawb FOR s_sql_str USING s_int_amd,v_awb_no,
  v_flt_key, v_flt_date;

  LOOP
    FETCH cur_hawb INTO c_hawb;
    EXIT
  WHEN cur_hawb%NOTFOUND;
    s_cons_detail := '';
    --get handle agent start
--    BEGIN
--      SELECT hdlg_agent
--      INTO c_hawb.hdlg_agent
--      FROM cst_awb
--      WHERE flt_type = 'I'
--      AND flt_key    = v_flt_key
--      AND flt_date   = v_flt_date
--      AND awb_no     = v_awb_no
--      AND rownum     = 1;
--    EXCEPTION
--    WHEN no_data_found THEN
--      NULL;
--    WHEN OTHERS THEN
--      NULL;
--    END;
    --get handle agent end
    /*
    IF get_isdhl(c_hawb.hdlg_agent) THEN
    s_shpt_typ := get_others_shpt_type(c_hawb.des);
    END IF;
    */
--    BEGIN
--      SELECT COUNT(1)
--      INTO v_count
--      FROM mast_handler_local_dest
--      WHERE ect_handler = c_hawb.hdlg_agent;
--    EXCEPTION
--    WHEN no_data_found THEN
--      v_count := 0;
--    END;
    v_chinese := v_chinese;
    
    
    BEGIN
      SELECT chinese_yn
      INTO v_chinese
      FROM cdt_hawb
      WHERE hawb_no = c_hawb.hawb_no 
      and tr_no = (select tr_no from cdt_awb
                        where awb_no = v_awb_no  
                              and itfs_flt_key = v_flt_key 
                              and itfs_flt_date = v_flt_date
                              AND rownum     = 1)
      and rownum = 1;
    EXCEPTION
    WHEN no_data_found THEN
      NULL;
    WHEN OTHERS THEN
      NULL;
    END;
    
--    IF v_awb_shpm_type is null THEN
--      v_awb_shpm_type := pkg_cst.get_shpt_type(v_awb_no, v_awb_date, 'CPA', 'N');
--    END IF;
    
--    s_shpt_typ := pkg_cst.get_hawb_shpt_type('CPA', c_hawb.ORG);
  
    --validation start
    --airway bill and house airway bill
    IF LENGTH(v_awb_no) <> 11 OR v_awb_no IS NULL THEN
     
      NULL;
    END IF;
    IF instr(v_awb_no, ' ') > 0 THEN
     
      NULL;
    END IF;
    --house airway bill origin and destination
    IF c_hawb.ORG IS NULL OR c_hawb.DEST IS NULL OR c_hawb.unldg_pt IS NULL OR LENGTH(c_hawb.ORG) <> 3 OR LENGTH(c_hawb.DEST) <> 3 OR LENGTH(c_hawb.unldg_pt) <> 3 THEN

      NULL;
    END IF;
    --house airway bill piece and weight
    IF NVL(c_hawb.man_pcs, 0) = 0 OR NVL(c_hawb.man_wgt, 0) = 0 THEN
 
      NULL;
    END IF;
    --house airway bill content
    IF c_hawb.content IS NULL THEN
 
      NULL;
    END IF;
    --house airway bill customs declare value
    --customs declare value
--    IF NVL(c_hawb.CURR_VALUE, 0) = 0 THEN
--    --    c_hawb.cvd_chg_cust_ind         := 'NCV';
--        v_cvd_chg_cust_ind         := 'NCV';
--        c_hawb.CURR_CODE        := ' ';
--      ELSE
--        IF c_hawb.CURR_CODE IS NULL THEN
--    
--          NULL;
--        END IF; 
--        v_cvd_chg_cust_ind         := NULL;
--    END IF;
    --    c_hawb.cvd_chg_cust_ind := NULL;

    --house airway bill consignee
    IF c_hawb.csgne_name IS NULL OR c_hawb.csgne_addr IS NULL THEN
      NULL;
    END IF;
    --house airway bill shipper
    IF c_hawb.shpr_name IS NULL OR c_hawb.shpr_addr IS NULL THEN
      NULL;
    END IF;
  begin
  select spl_code1 || spl_code2 || spl_code3 || spl_code4 || spl_code5 || spl_code6,  '' 
  into v_spl_code, v_awb_rmk
  from awb 
  where awb_no = v_awb_no and awb_date = v_awb_date ;
  end;

    --validation end
    
    --
--CSGNE_PLACE                    VARCHAR2(17)   
--CSGNE_CTRY_CODE                VARCHAR2(3)    
--CSGNE_STATE_PROVINCE           VARCHAR2(9)    
--CSGNE_PIN_CODE                 VARCHAR2(9)  

  -- Country, State, City and Postal Code -- 15120201_CR_Additional address information to ACCS for MAWB and HAWB
  s_hawb_csgn_addr := null;

    if c_hawb.csgne_addr is not null
        or c_hawb.csgne_addr2 is not null 
        or  c_hawb.csgne_addr3 is not null 
        or c_hawb.csgne_addr4 is not null 
        or c_hawb.csgne_addr5 is not null then 
    s_hawb_csgn_addr := FUN_CONCAT_ADDR_WITHSPACE(c_hawb.csgne_addr , c_hawb.csgne_addr2 , c_hawb.csgne_addr3 , c_hawb.csgne_addr4 , c_hawb.csgne_addr5 ,
    c_hawb.CSGNE_PLACE , c_hawb.CSGNE_STATE_PROVINCE , c_hawb.CSGNE_CTRY_CODE , c_hawb.CSGNE_PIN_CODE) ;
    end if;

--  SHPR_PLACE                     VARCHAR2(17)   
--SHPR_CTRY_CODE                 VARCHAR2(3)    
--SHPR_STATE_PROVINCE            VARCHAR2(9)    
--SHPR_PIN_CODE                  VARCHAR2(9)   

   s_hawb_shpr_addr := null;

    if c_hawb.SHPR_addr is not null
        or c_hawb.SHPR_addr2 is not null 
        or  c_hawb.SHPR_addr3 is not null 
        or c_hawb.SHPR_addr4 is not null  
        or c_hawb.SHPR_addr5 is not null  then 
    s_hawb_shpr_addr := FUN_CONCAT_ADDR_WITHSPACE(c_hawb.SHPR_addr , c_hawb.SHPR_addr2 , c_hawb.SHPR_addr3 , c_hawb.SHPR_addr4 , c_hawb.SHPR_addr5 ,
    c_hawb.SHPR_PLACE , c_hawb.SHPR_STATE_PROVINCE , c_hawb.SHPR_CTRY_CODE , c_hawb.SHPR_PIN_CODE)  ;
    end if;
    
    
    
    s_cons_detail := s_schedule_date || --2.2.1
    rpad(FUN_CST_ACCS_TRANSITION(FUN_CST_FLT_KEY_SUBM(v_flt_key,v_flt_date,v_ver_no)), 9, ' ') ||          --2.2.2-3
    s_version_no ||                     --2.2.4
    (
      CASE
      WHEN s_int_amd = 'BDS' THEN
        'BLB'
      ELSE
        ''
      END) ||                                                         --ONLY FOR LBS
    SUBSTR(v_awb_no, 1, 3) || '-' || SUBSTR(v_awb_no, 4) || --2.2.5
    rpad(c_hawb.hawb_no, 18, ' ') ||                                  --2.2.6
    c_hawb.org ||                                                     --2.2.7
    c_hawb.dest || --2.2.8
    c_hawb.unldg_pt ||                                                     --2.2.9
    lpad(c_hawb.man_pcs, 6, '0') ||                                       --2.2.10
        lpad(TRIM(to_char(c_hawb.man_wgt,   '9999999.0')),   9,   '0') || --2.2.11
    lpad(c_hawb.man_pcs, 6, '0') ||                                       --2.2.12
        lpad(TRIM(to_char(c_hawb.man_wgt,   '9999999.0')),   9,   '0') || --2.2.13
--        rpad(c_hawb.content,   265,   ' ') || --2.2.14 Changed for new 175 to 265
        FUN_CONCAT_ACCS_ADDRESS_VALUE(c_hawb.content || rpad(' ',265-lengthb(c_hawb.content),' '))|| --2.2.14 Changed for new 175 to 265
         rpad(' ',   3,   ' ') || --2.2.15
         rpad('NCV',   12,   ' ') ||
         --rpad(nvl(c_hawb.CURR_CODE,   ' '),   3,   ' ') || --2.2.15
--        (
--          CASE (v_cvd_chg_cust_ind)
--          WHEN 'NCV' THEN
--            rpad('NCV', 12, ' ')
--          ELSE
--            lpad(c_hawb.CURR_VALUE, 12, '0') 
--          END) ||    
        
--        (CASE
--        WHEN LENGTH(rpad(c_hawb.csgne_name,   95,   ' ')) < 95 THEN
--        rpad(nvl(c_hawb.csgne_name,   ' '),   95,   ' ') ||  rpad(' ',   95 - LENGTH(rpad(nvl(c_hawb.csgne_name,   ' '),   95,   ' ')),   ' ')
--        else rpad(nvl(c_hawb.csgne_name,   ' '),   95,   ' ')
--        END) ||
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401  
        case when v_chinese = 'N' and length(c_hawb.csgne_name) = lengthb(c_hawb.csgne_name)then
          c_hawb.csgne_name || rpad(' ',130-lengthb(c_hawb.csgne_name),' ') 
        else
          rpad('DUMMY', 70, ' ') ||
          c_hawb.csgne_name || rpad(' ',60-lengthb(c_hawb.csgne_name),' ')
        end ||
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401 
--  s_hawb_csgn_addr
      FUN_CONCAT_ACCS_ADDRESS_VALUE(nvl(s_hawb_csgn_addr,   'XXX') || rpad(' ',265-lengthb(nvl(s_hawb_csgn_addr,   'XXX')),' ')) ||
  

--        (CASE
--        WHEN LENGTH(rpad(nvl(c_hawb.csgne_addr,   ' '),   53,   ' ')) < 53 THEN
--        rpad(nvl(c_hawb.csgne_addr,   ' '),   53,   ' ') ||   rpad(' ',   53 - LENGTH(rpad(nvl(c_hawb.csgne_addr,   ' '),   53,   ' ')),   ' ')
--        else rpad(nvl(c_hawb.csgne_addr,   ' '),   53,   ' ')
--        END) ||

--        CASE
--            WHEN c_hawb.csgne_addr IS NULL THEN  rpad(' ', 53, ' ')
--        ELSE
--            c_hawb.csgne_addr || rpad(' ',53-lengthb(c_hawb.csgne_addr),' ')
--        END ||

--      rpad(nvl(c_hawb.csgne_addr2,   ' '),   53,   ' ') ||

--        (CASE
--        when c_hawb.csgne_addr2 is null then rpad(' ',   53,   ' ')
--        WHEN LENGTH(rpad(nvl(c_hawb.csgne_addr2,   ' '),   53,   ' ')) < 53 THEN
--        rpad(nvl(c_hawb.csgne_addr2,   ' '),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_hawb.csgne_addr2,   ' '),   53,   ' ')),   ' ')
--        else rpad(nvl(c_hawb.csgne_addr2,   ' '),   53,   ' ')
--        END) ||
        
--        CASE
--            WHEN c_hawb.csgne_addr2 IS NULL THEN  rpad(' ', 53, ' ')
--        ELSE
--            c_hawb.csgne_addr2 || rpad(' ',53-lengthb(c_hawb.csgne_addr2),' ')
--        END ||

--      rpad(nvl(c_hawb.csgne_addr3,   ' '),   53,   ' ') ||

--        (CASE
--        when c_hawb.csgne_addr3 is null then rpad(' ',   53,   ' ')
--        WHEN LENGTH(rpad(nvl(c_hawb.csgne_addr3,   ' '),   53,   ' ')) < 53 THEN
--        rpad(nvl(c_hawb.csgne_addr3,   ' '),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_hawb.csgne_addr3,   ' '),   53,   ' ')),   ' ')
--        else rpad(nvl(c_hawb.csgne_addr3,   ' '),   53,   ' ')
--        END) ||

--        CASE
--            WHEN c_hawb.csgne_addr3 IS NULL THEN  rpad(' ', 53, ' ')
--        ELSE
--            c_hawb.csgne_addr3 || rpad(' ',53-lengthb(c_hawb.csgne_addr3),' ')
--        END ||
        
--      rpad(nvl(c_hawb.csgne_addr4,   ' '),   106,   ' ') ||

--         (CASE
--        when c_hawb.csgne_addr3 is null then rpad(' ',   53,   ' ')
--        WHEN LENGTH(rpad(nvl(c_hawb.csgne_addr4,   ' '),   106,   ' ')) < 106 THEN
--        rpad(nvl(c_hawb.csgne_addr4,   ' '),   106,   ' ') ||  rpad(' ',   106 - LENGTH(rpad(nvl(c_hawb.csgne_addr4,   ' '),   106,   ' ')),   ' ')
--        else rpad(nvl(c_hawb.csgne_addr4,   ' '),   106,   ' ')
--        END) ||
        
--        CASE
--            WHEN c_hawb.csgne_addr4 IS NULL THEN  rpad(' ', 106, ' ')
--        ELSE
--            c_hawb.csgne_addr4 || rpad(' ',106-lengthb(c_hawb.csgne_addr4),' ')
--        END ||
        
--        (CASE
----        when c_hawb.csgne_addr3 is null then rpad(' ',   53,   ' ')
--        WHEN LENGTH(rpad(nvl(c_hawb.csgne_add5,   ' '),   53,   ' ')) < 53 THEN
--        rpad(nvl(c_hawb.csgne_add5,   ' '),   53,   ' ') ||  rpad(' ',   53 - LENGTH(rpad(nvl(c_hawb.csgne_add5,   ' '),   53,   ' ')),   ' ')
--        else rpad(nvl(c_hawb.csgne_add5,   ' '),   53,   ' ')
--        END) ||
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401  
         --2.2.19 Changed for new 35 to 53
        lpad(' ',   395,   ' ') || --2.2.20-22
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401  
--        rpad(nvl(c_hawb.shpr_name,   ' '),   95,   ' ') || --2.2.23-24 Changed for new 75 to 95
--        rpad(nvl(c_hawb.shpr_addr,   ' '),   53,   ' ') || rpad(nvl(c_hawb.shpr_addr2,   ' '),   53,   ' ') || rpad(nvl(c_hawb.shpr_addr3,   ' '),   53,   ' ') || rpad(nvl(c_hawb.shpr_addr4,   ' '),   106,   ' ') || --rpad(nvl(c_hawb.shpr_add5,   ' '),   53,   ' ')  || --2.2.25 Changed for new 35 to 53
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401          
        case when v_chinese = 'N' and length(c_hawb.shpr_name) = lengthb(c_hawb.shpr_name) then
          c_hawb.shpr_name  || rpad(' ',130-lengthb(c_hawb.shpr_name),' ')
        else
          rpad('DUMMY', 70, ' ') ||
          c_hawb.shpr_name  || rpad(' ',60-lengthb(c_hawb.shpr_name),' ') 
        end || --2.2.23-24 Changed for new 75 to 95
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401          
        FUN_CONCAT_ACCS_ADDRESS_VALUE(nvl(s_hawb_shpr_addr,   'XXX') || rpad(' ',265-lengthb(nvl(s_hawb_shpr_addr,   'XXX')),' ')) ||
        
--         CASE
--            WHEN c_hawb.shpr_addr IS NULL THEN  rpad(' ', 53, ' ')
--        ELSE
--            c_hawb.shpr_addr || rpad(' ',53-lengthb(c_hawb.shpr_addr),' ')
--        END ||
--        
--        CASE
--            WHEN c_hawb.shpr_addr2 IS NULL THEN  rpad(' ', 53, ' ')
--        ELSE
--            c_hawb.shpr_addr2 || rpad(' ',53-lengthb(c_hawb.shpr_addr2),' ')
--        END ||
--        
--        CASE
--            WHEN c_hawb.shpr_addr3 IS NULL THEN  rpad(' ', 53, ' ')
--        ELSE
--            c_hawb.shpr_addr3 || rpad(' ',53-lengthb(c_hawb.shpr_addr3),' ')
--        END ||
--        
--        CASE
--            WHEN c_hawb.shpr_addr4 IS NULL THEN  rpad(' ', 106, ' ')
--        ELSE
--            c_hawb.shpr_addr4 || rpad(' ',106-lengthb(c_hawb.shpr_addr4),' ')
--        END ||
        
    'T ' ||    
--    s_shpt_typ ||                                                                                                                                                                              --2.2.26
--    NVL(s_rel_ind, ' ') ||                                                                                                                                                                     --2.2.27

  rpad(NVL(v_spl_code, ' '), 18, ' ') ||                     --2.2.28
  rpad(NVL(SUBSTR(v_awb_rmk, 1, 35), ' '), 35, ' ') || 
  rpad( ' ', 2, ' ') ||                                                                                                                                              --2.2.30
  rpad( ' ', 7, ' ') ||                                                                                                                                               --2.2.31
  rpad( ' ', 8, ' ') ||    
  lpad(' ', 44, ' ') || --s_uid ||                         --2.2.33
  lpad(' ', 240, ' ') || 
--  s_lic_per ||                     --2.2.34
  'N' ||          --2.2.35
  lpad(' ', 11, ' ') ||            --2.2.36
  c_hdlg_agent ||
     (
      CASE s_int_amd
    WHEN 'BDS' THEN lpad(' ',   4,   ' ')  ||  'T' || ' ' --|| v_awb_shpm_type || ' ' --LBS
    ELSE lpad(' ',   5,   ' ')
    END);
    --INT AND AMD 2.2.38-39

    IF s_int_amd = 'AMD' THEN
    s_cons_detail := c_hawb.CHANGE_IND || s_cons_detail;
      /*IF c_hawb.change_ind = 'A' AND c_hawb.accs_ind = 'INT' THEN
      s_cons_detail := 'U' || s_cons_detail;
      ELSE
      s_cons_detail := c_hawb.change_ind || s_cons_detail;
      END IF;*/
--      IF  c_hawb.change_ind = 'A' THEN
--        BEGIN
--          SELECT 1
--          INTO v_cnt
--          FROM cst_csgnm
--          WHERE flt_key       = v_flt_key
--          AND flt_date      = v_flt_date
--          AND recv_rec_type = 'INT'
--          AND ver_no        = s_int_ver_no
--          AND awb_no        = v_awb_no
--          AND hawb_no       = c_hawb.hawb_no
--          AND rownum        = 1;
--        EXCEPTION
--        WHEN no_data_found THEN
--          v_cnt := 0;
--        WHEN OTHERS THEN
--          v_cnt := 0;
--        END;
--        IF NVL(v_cnt, 0) > 0 THEN
--          s_cons_detail := 'U' || s_cons_detail;
--        ELSE
--          s_cons_detail := 'A' || s_cons_detail;
--        END IF;
--      ELSE
--        s_cons_detail := 'A'--c_hawb.change_ind 
--                  || s_cons_detail;
--      END IF;
    END IF;
    --
    s_hawb_cnt := s_hawb_cnt + 1;
    --MESSAGE VAILDATION START
    s_msg_length := LENGTHB(s_cons_detail);

    DBMS_OUTPUT.PUT_LINE('Check HGAWB s_cons_detail -- s_cons_detail - '||s_cons_detail);

    IF s_int_amd = 'INT' THEN
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401  1824 + 105 = 1929
      IF s_msg_length <> 1929 THEN
        s_cms3_error := 'INT / ' || v_awb_no || '/' || c_hawb.hawb_no || c_awb_00009 || s_msg_length;
        RETURN FALSE;
      END IF;

      ELSIF s_int_amd = 'AMD' THEN
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401  1825 + 105 = 1930
        IF s_msg_length <> 1930 THEN
          s_cms3_error := 'AMD / ' || v_awb_no || '/' || c_hawb.hawb_no || c_awb_00009 || s_msg_length;
          RETURN FALSE;
        END IF;

        ELSIF s_int_amd = 'BDS' THEN
-- Changes for ACCS CR change Consignee, Shipper and Notify name from 35 bytes to 70 bytes - CR - 18021401  1828 + 105 = 1933
          IF s_msg_length <> 1933 THEN
            s_cms3_error := 'BDS / ' || v_awb_no || '/' || c_hawb.hawb_no || c_awb_00009 || s_msg_length;
            RETURN FALSE;
          END IF;

        END IF;

    --MESSAGE VALIDATION END
    IF NOT insert_cst_csgnm(c_hawb.hawb_no, cdetail) THEN
      s_error := TRUE;
      EXIT;
    END IF;
  END LOOP;
  IF cur_hawb%ISOPEN THEN
    CLOSE cur_hawb;
  END IF;
  IF s_error THEN
    RETURN FALSE;
  END IF;
  --update house airway bill status
  RETURN TRUE;
END;
/************************************/
/*GET THE FOOTER INFORMATION
************************************/
FUNCTION get_ftr_info
  RETURN BOOLEAN
IS
BEGIN
  s_cons_footer := s_schedule_date || --3.2.1
  rpad(FUN_CST_ACCS_TRANSITION(FUN_CST_FLT_KEY_SUBM(v_flt_key,v_flt_date,s_version_no)), 9, ' ') ||
  --rpad(v_flt_key, 9, ' ') ||          --3.2.2-3
  s_version_no ||                     --3.2.4
  'C';                                --3.2.5
  RETURN insert_cst_csgnm(' ', cfooter);
END;

FUNCTION pro_awb_info
  RETURN BOOLEAN
IS
--  l_man_wt  NUMBER;
--  l_man_pcs NUMBER;
--  
--  p_man_wt  NUMBER;
--  p_man_pcs NUMBER;
  
  b_result BOOLEAN;
BEGIN

  DBMS_OUTPUT.PUT_LINE('start pro_awb_info v_awb_no '|| v_awb_no);
--  l_man_wt  := 0;
--  l_man_pcs := 0;
--  s_uid     := '';
  --GET MANIFEST PIECES AND MANIFEST WEIGHT
--  FOR cc IN
--  (SELECT --NVL(b.uld_key, ' ') uld_key,
--    pman_pcs man_pcs,
--    pman_wt man_wt,
--    unldg_pt
----    ,
----    content content
--  FROM CDT_PMAN_AWB
--  WHERE 
--  itfs_flt_key     = v_flt_key
--  AND itfs_flt_date    = v_flt_date
--  AND awb_no      = v_awb_no
--  )
--  LOOP
--    s_ldg_point     := cc.unldg_pt;
--    l_man_wt        := l_man_wt  + cc.man_wt;
--    l_man_pcs       := l_man_pcs + cc.man_pcs;

    
--    s_content       := cc.content;
    
--    IF LENGTH(s_uid) < 44 OR s_uid IS NULL THEN
--      s_uid         := s_uid || lpad(cc.uld_key, 11, ' ');
--    END IF;
--  END LOOP;
  
--    if s_ldg_point  is null then
--        SELECT --NVL(b.uld_key, ' ') uld_key,
--        man_pcs ,
--        man_wgt ,
--        unldg_pt
--         into p_man_pcs, p_man_wt, s_ldg_point 
--      FROM CST_ITM_AWB
--      WHERE 
--      itfs_flt_key     = v_flt_key
--      AND itfs_flt_date    = v_flt_date
--      AND awb_no      = v_awb_no;
--      
--      l_man_wt        := l_man_wt  + p_man_wt;
--      l_man_pcs       := l_man_pcs + p_man_pcs;
--  end if;
--  s_uid     := rpad(NVL(s_uid, ' '), 44, ' ');
--  l_man_wt  := NVL(l_man_wt, 0);
--  l_man_pcs := NVL(l_man_pcs, 0);
--  s_man_wt  := lpad(TRIM(TO_CHAR(l_man_wt, '9999999.0')), 9, '0');
--  s_man_pcs := lpad(l_man_pcs, 6, '0');
  
--  DBMS_OUTPUT.PUT_LINE('start pro_awb_info l_man_wt - '|| l_man_wt);
--  DBMS_OUTPUT.PUT_LINE('start pro_awb_info l_man_pcs - '|| l_man_pcs);
--  DBMS_OUTPUT.PUT_LINE('start pro_awb_info s_man_wt - '|| s_man_wt);
--  DBMS_OUTPUT.PUT_LINE('start pro_awb_info s_man_pcs - '|| s_man_pcs);
  --DEAL THE INFORMATIONS
  IF s_cargo_ind = 'Y' THEN
        IF NOT get_awb_info THEN
          RETURN FALSE;
        END IF;
        IF NOT get_hawb_info THEN
          RETURN FALSE;
        END IF;
--    IF s_int_amd    = 'INT' THEN
--        IF NOT get_awb_info THEN
--          RETURN FALSE;
--        END IF;
--        IF NOT get_hawb_info THEN
--          RETURN FALSE;
--        END IF;
--    ELSIF s_int_amd = 'AMD' THEN
--      b_result     := get_hdr_info_amd; --AMEND CONSIGNMENT HEADER
--    ELSE
--      b_result := get_hdr_info_lbs; --LEFT BEHIND CONSIGNMENT HEADER
--    END IF;
  
    
  END IF;
  RETURN TRUE;
END;
FUNCTION submit_accs(
    p_flt_key  VARCHAR2,
    p_flt_date VARCHAR2,
    p_ver_no OUT NUMBER)
  RETURN VARCHAR2
IS
  n_cnt    NUMBER;
  b_result BOOLEAN;
BEGIN
  init;
  s_cms3_error := NULL;
  v_flt_key    := p_flt_key;
  v_flt_date   := to_date(p_flt_date, 'DDMONYY');
  v_ver_no := s_version_no;

  select trk_flt_key, trk_flt_date , to_char(itfs_flt_date,   'YYYYMMDD') 
          into v_truck_flt_key,v_truck_flt_date, s_schedule_date
  from CDT_PMAN_AWB where itfs_flt_key = v_flt_key and  itfs_flt_date = p_flt_date and rownum = 1;
  
  --DBMS_OUTPUT.PUT_LINE('submit_accs - v_truck_flt_key'||v_truck_flt_key ||'- v_truck_flt_date'||v_truck_flt_date);
  pro_awb_list;
  --DBMS_OUTPUT.PUT_LINE('submit_accs - pro_awb_list');
  IF NOT get_ver_no THEN
    RETURN c_flt_00003;
  END IF;
  
  DBMS_OUTPUT.PUT_LINE('submit_accs - s_version_no - '||s_version_no);
  
  p_ver_no := s_version_no;
  --GET HEADER INFOMATION
  
  DBMS_OUTPUT.PUT_LINE('submit_accs - s_int_amd - '||s_int_amd);
  IF s_int_amd    = 'INT' THEN
    b_result     := get_hdr_info_int; --INITIAL CONSIGNMENT HEADER
  ELSIF s_int_amd = 'AMD' THEN
    b_result     := get_hdr_info_amd; --AMEND CONSIGNMENT HEADER
  ELSE
    b_result := get_hdr_info_lbs; --LEFT BEHIND CONSIGNMENT HEADER
  END IF;
  IF NOT b_result THEN
    --RETURN s_error_msg;
    NULL;
  END IF;
  
  DBMS_OUTPUT.PUT_LINE('submit_accs - b_result - ');
  
  --GET FOOTER INFOMATION
  IF NOT get_ftr_info THEN
    --RETURN 'CST_202';
    NULL;
  END IF;
  --
 DBMS_OUTPUT.PUT_LINE('submit_accs - get_ftr_info - ');
 
  IF s_int_amd = 'AMD' THEN
    BEGIN
      SELECT NVL(MAX(ver_no), 1)
      INTO s_int_ver_no
      FROM cst_subm
      WHERE rec_type = 'INT'
      AND flt_key    = v_flt_key
      AND flt_date   = v_flt_date
      AND flt_type   = 'T';
    EXCEPTION
    WHEN OTHERS THEN
      s_int_ver_no := 1;
    END;
  END IF;

  DBMS_OUTPUT.PUT_LINE('start submit_accs s_cargo_ind - '|| s_cargo_ind);
  
  n_cnt         := t_awb.COUNT;
  
  DBMS_OUTPUT.PUT_LINE('start submit_accs n_cnt - '|| n_cnt);
  
  IF s_cargo_ind = 'Y' THEN
    FOR i       IN 1 .. n_cnt
    LOOP
      v_awb_no    := t_awb(i).awb_no;
      v_hawb_no   := NULL;
      DBMS_OUTPUT.PUT_LINE('start submit_accs v_awb_no - '|| v_awb_no);
      IF s_int_amd = 'AMD' THEN
        v_hawb_no := t_awb(i).hawb_no;
      END IF;
      s_cms3_error := NULL;
      IF NOT pro_awb_info THEN
       DBMS_OUTPUT.PUT_LINE('start submit_accs  IF NOT pro_awb_info THEN  EXIT- '|| v_awb_no);
        EXIT;
      END IF;
      DBMS_OUTPUT.PUT_LINE('end submit_accs v_awb_no - '|| v_awb_no);
      DBMS_OUTPUT.PUT_LINE('end submit_accs s_cms3_error - '|| s_cms3_error);
    END LOOP;
     DBMS_OUTPUT.PUT_LINE('out loop submit_accs ');
  END IF;
   DBMS_OUTPUT.PUT_LINE('out loop submit_accs s_cms3_error -  '||s_cms3_error);
  IF s_cms3_error IS NOT NULL THEN
    RETURN s_cms3_error;
  END IF;
  
  DBMS_OUTPUT.PUT_LINE('start submit_accs before s_cons_header - '|| s_cons_header);
  
  IF s_int_amd     = 'INT' THEN
    s_cons_header := s_cons_header || lpad(s_simp_cnt + s_cnsl_cnt, 5, '0') || --1.2.15
    lpad(s_hawb_cnt, 5, '0') ||                                                --1.2.16
    lpad(s_simp_cnt, 5, '0') ||                                                --1.2.17
    lpad(s_cnsl_cnt, 5, '0') ||                                                --1.2.18
    lpad(s_hawb_cnt + s_simp_cnt + s_cnsl_cnt, 5, '0');                        --1.2.19;
    --INSERT HEADER
    IF NOT insert_cst_csgnm('', cheader) THEN
      RETURN s_cms3_error;
    END IF;
  END IF;
  
--    DBMS_OUTPUT.PUT_LINE('start submit_accs before s_cons_header - '|| s_cons_header);
    
  INSERT
  INTO cst_auto_submit_log VALUES
    (
      'S_SIMP_CNT:'  
      || NVL(s_simp_cnt, 0)
      || 'S_CNSL_CNT:'
      || NVL(s_cnsl_cnt, 0)
      || 'S_HAWB_CNT:'
      || NVL(s_hawb_cnt, 0)
    );
  RETURN 'TRUE';
EXCEPTION
WHEN OTHERS THEN
  s_error_msg := SUBSTR
  (
    SQLCODE || SQLERRM, 1, 100
  )
  ;
  RETURN s_error_msg;
END;
/**************************************************************/
/*SUBMIT INITIAL CONSIGNMENT
/**************************************************************/
FUNCTION initial_cdt_csgnmt_subm
  (
    p_flt_key  VARCHAR2,
    p_flt_date VARCHAR2,
    p_ver_no  IN OUT NUMBER,
    p_user_id IN VARCHAR2,
    p_lm_date IN DATE
  )
  RETURN VARCHAR2
IS
BEGIN
  s_int_amd := 'INT';
  s_user_id := p_user_id;
  s_lm_date := p_lm_date;
  
  DBMS_OUTPUT.PUT_LINE('initial_cdt_csgnmt_subm - p_flt_key'||p_flt_key ||'- p_flt_date'||p_flt_date||'- p_ver_no'|| p_ver_no);
  RETURN submit_accs
  (
    p_flt_key, p_flt_date, p_ver_no
  )
  ;
END;
/**************************************************************/
/*SUBMIT AMEND CONSIGNMENT
/**************************************************************/
FUNCTION amend_cdt_csgnmt_subm
  (
    p_flt_key  VARCHAR2,
    p_flt_date VARCHAR2,
    p_ver_no  IN OUT NUMBER,
    p_user_id IN VARCHAR2,
    p_lm_date IN DATE
  )
  RETURN VARCHAR2
IS
BEGIN
  s_int_amd := 'AMD';
  s_user_id := p_user_id;
  s_lm_date := p_lm_date;
  RETURN submit_accs
  (
    p_flt_key, p_flt_date, p_ver_no
  )
  ;
END;
/**************************************************************/
/*SUBMIT AMEND CONSIGNMENT
/**************************************************************/
FUNCTION behind_cdt_csgnmt_subm
  (
    p_flt_key  VARCHAR2,
    p_flt_date VARCHAR2,
    p_ver_no  IN OUT NUMBER,
    p_user_id IN VARCHAR2,
    p_lm_date IN DATE
  )
  RETURN VARCHAR2
IS
BEGIN
  s_int_amd := 'BDS';
  s_user_id := p_user_id;
  s_lm_date := p_lm_date;
  RETURN submit_accs
  (
    p_flt_key, p_flt_date, p_ver_no
  )
  ;
END;

    ----------  subm_awb_AMD_del_AWB_HAWB  start-----------------------------------

 FUNCTION subm_awb_AMD_del_AWB_HAWB(p_truck_flt_no  IN VARCHAR2, p_truck_flt_date  IN VARCHAR2, p_itfs_flt_key  IN VARCHAR2,   p_itfs_flt_date IN VARCHAR2,  
                                        p_user_id IN VARCHAR2, p_awb_no IN VARCHAR2, p_awb_date IN date, p_cnsl_ind IN VARCHAR2)  
 RETURN VARCHAR2 IS 

    CURSOR c1 (c_awb_no  in varchar2, c_awb_date in date)   IS 
            SELECT *
              FROM cst_itm_hawb
             WHERE truck_flt_no = p_truck_flt_no
                  AND truck_flt_date = p_truck_flt_date
                  and itfs_flt_key = p_itfs_flt_key
                  AND itfs_flt_date = p_itfs_flt_date
                  AND accs_ind = 'INT'
                  and awb_no = c_awb_no
                  and awb_date = c_awb_date
                  and nvl(hawb_no,'000000000000000000') <> '000000000000000000';
              
    v_ret VARCHAR2(8 byte);
    l_shp_man_pcs VARCHAR2(6);
    l_shp_man_wt VARCHAR2(9);
  
    v_change_ind VARCHAR2(1);

    v_row_cnt number;
    v_itm_awb_amd_rec_cnt number;
    v_old_hawb_cnt  number;
   
    BEGIN
    
    v_row_cnt := 0;
    v_itm_awb_amd_rec_cnt := 0;
    v_old_hawb_cnt := 0;
             
             begin 
              select PMAN_PCS, PMAN_WT  into  l_shp_man_pcs , l_shp_man_wt 
                from cdt_pman_awb 
                  where awb_no = p_awb_no 
                        and awb_date = p_awb_date
                        and trk_flt_key = p_truck_flt_no
                        AND trk_flt_date = p_truck_flt_date
                        and itfs_flt_key = p_itfs_flt_key
                        AND itfs_flt_date = p_itfs_flt_date;
                
             EXCEPTION
              WHEN no_data_found THEN
                 v_change_ind := 'D'; 
              END;   
            
            if v_change_ind = 'D' then  
            
            Insert into CST_ITM_AWB 
                  (TR_NO,AWB_NO,AWB_DATE,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                              MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                              CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                              HDLG_AGENT,CNSL_IND,CONTENT,ACCS_IND,LM_VER,SUBM_VER_NO,CHANGE_IND,
                              CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,MSG_VER,UNLDG_PT) 
                              select V_CST_ITM_AWB_SEQ,AWB_NO,AWB_DATE,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                              MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                              CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                              HDLG_AGENT,CNSL_IND,CONTENT,'AMD',LM_VER,SUBM_VER_NO,v_change_ind,
                              p_user_id,sysdate,p_user_id,sysdate,MSG_VER,UNLDG_PT   
                  from  CST_ITM_AWB  
                  WHERE  p_awb_no = awb_no
                    and  p_awb_date = awb_date
                    and truck_flt_no = p_truck_flt_no
                    AND truck_flt_date = p_truck_flt_date
                    and itfs_flt_key = p_itfs_flt_key
                    AND itfs_flt_date = p_itfs_flt_date
                    AND accs_ind = 'INT' ;
              
--                if p_cnsl_ind = 'Y' then
                 DBMS_OUTPUT.PUT_LINE('End v_ret - ' || v_change_ind);
                  for i in c1(p_awb_no, p_awb_date) loop    
                  
                      Insert into CST_ITM_HAWB (TR_NO,AWB_NO,AWB_DATE,HAWB_NO,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                              MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                              CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                              HDLG_AGENT,CNSL_IND,CONTENT,ACCS_IND,LM_VER,SUBM_VER_NO,CHANGE_IND,
                              CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,MSG_VER,UNLDG_PT) 
                              select V_CST_ITM_AWB_SEQ,AWB_NO,AWB_DATE,HAWB_NO,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                              MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                              CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                              HDLG_AGENT,CNSL_IND,CONTENT,'AMD',LM_VER,SUBM_VER_NO,v_change_ind,
                              p_user_id,sysdate,p_user_id,sysdate,MSG_VER,UNLDG_PT  
                          from  CST_ITM_HAWB  
                          WHERE  p_awb_no = awb_no
                            and  p_awb_date = awb_date
                            and truck_flt_no = p_truck_flt_no
                            AND truck_flt_date = p_truck_flt_date
                            and itfs_flt_key = p_itfs_flt_key
                            AND itfs_flt_date = p_itfs_flt_date
                            AND accs_ind = 'INT'
                            and i.hawb_no = hawb_no
                            and nvl(i.hawb_no,'000000000000000000') <> '000000000000000000';
                  end loop;
--              end if;
            
            elsif v_change_ind <> 'D' or v_change_ind is null  then
                DBMS_OUTPUT.PUT_LINE('End v_ret - ' || v_change_ind);
                
                for i in c1(p_awb_no, p_awb_date) loop 
                  
                  v_change_ind := null;
                  v_old_hawb_cnt := 0;
                  v_row_cnt := 0;
                   begin 
                      
                      select PMAN_PCS, PMAN_WT  into  l_shp_man_pcs , l_shp_man_wt 
                      from cdt_pman_awb pmanAwb
                      join cdt_awb cdtAwb on  pmanAwb.awb_no = cdtAwb.awb_no and pmanAwb.awb_date = cdtAwb.awb_date
                      join cdt_hawb cdtHawb on  cdtHawb.tr_no = cdtAwb.tr_no
                        where pmanAwb.awb_no = p_awb_no 
                              and pmanAwb.awb_date = p_awb_date
                              and cdtHawb.hawb_No = i.hawb_no 
                              and pmanAwb.trk_flt_key = p_truck_flt_no
                              AND pmanAwb.trk_flt_date = p_truck_flt_date
                              and pmanAwb.itfs_flt_key = p_itfs_flt_key
                              AND pmanAwb.itfs_flt_date = p_itfs_flt_date
                              and nvl(cdtHawb.hawb_no,'000000000000000000') <> '000000000000000000';
                        
                     EXCEPTION
                      WHEN no_data_found THEN
                         v_change_ind := 'D'; 
                      END;   
                    
                    if v_change_ind = 'D' then  
                        
                        if v_row_cnt = 0 then
                        
                            SELECT count(1) into v_itm_awb_amd_rec_cnt
                            FROM cst_itm_awb itmAwb
                            WHERE  p_awb_no = itmAwb.awb_no
                            and  p_awb_date = itmAwb.awb_date
                            and truck_flt_no = p_truck_flt_no
                            AND truck_flt_date = p_truck_flt_date
                            and itfs_flt_key = p_itfs_flt_key
                            AND itfs_flt_date = p_itfs_flt_date
                            AND accs_ind in  ('AMD');  
                            
                            SELECT COUNT(*)
                            INTO v_old_hawb_cnt
                              FROM cdt_hawb
                              WHERE nvl(hawb_no,'000000000000000000') <> '000000000000000000'
                              and tr_no = (select tr_no from cdt_awb where awb_no = p_awb_no  
                                                                      and itfs_flt_key       = p_itfs_flt_key
                                                                      AND itfs_flt_date      = p_itfs_flt_date
                                                                      and trk_flt_key = p_truck_flt_no
                                                                      AND trk_flt_date = p_truck_flt_date);
                            
                            if  v_itm_awb_amd_rec_cnt = 0 and v_old_hawb_cnt = 0 then
                            
                             Insert into CST_ITM_AWB 
                                  (TR_NO,AWB_NO,AWB_DATE,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                                              MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                                              CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                                              HDLG_AGENT,CNSL_IND,CONTENT,ACCS_IND,LM_VER,SUBM_VER_NO,CHANGE_IND,
                                              CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,MSG_VER,UNLDG_PT) 
                                              select V_CST_ITM_AWB_SEQ,AWB_NO,AWB_DATE,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                                              MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                                              CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                                              HDLG_AGENT,'N',CONTENT,'AMD',LM_VER,SUBM_VER_NO,'U',
                                              p_user_id,sysdate,p_user_id,sysdate,MSG_VER,UNLDG_PT  
                                  from  CST_ITM_AWB  
                                  WHERE  p_awb_no = awb_no
                                    and  p_awb_date = awb_date
                                    and truck_flt_no = p_truck_flt_no
                                    AND truck_flt_date = p_truck_flt_date
                                    and itfs_flt_key = p_itfs_flt_key
                                    AND itfs_flt_date = p_itfs_flt_date
                                    AND accs_ind = 'INT' ;
                                  
                                  v_row_cnt := v_row_cnt + 1;
                               end if;   
                               
                            end if;
                        
                           
                            Insert into CST_ITM_HAWB (TR_NO,AWB_NO,AWB_DATE,HAWB_NO,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                              MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                              CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                              HDLG_AGENT,CNSL_IND,CONTENT,ACCS_IND,LM_VER,SUBM_VER_NO,CHANGE_IND,
                              CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,MSG_VER,UNLDG_PT) 
                              select V_CST_ITM_AWB_SEQ,AWB_NO,AWB_DATE,HAWB_NO,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                              MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                              CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                              HDLG_AGENT,CNSL_IND,CONTENT,'AMD',LM_VER,SUBM_VER_NO,v_change_ind,
                              p_user_id,sysdate,p_user_id,sysdate,MSG_VER,UNLDG_PT                              
                                from  CST_ITM_HAWB  
                                WHERE  p_awb_no = awb_no
                                  and  p_awb_date = awb_date
                                  and truck_flt_no = p_truck_flt_no
                                  AND truck_flt_date = p_truck_flt_date
                                  and itfs_flt_key = p_itfs_flt_key
                                  AND itfs_flt_date = p_itfs_flt_date
                                  AND accs_ind = 'INT'
                                  and i.hawb_no = hawb_no
                                  and nvl(i.hawb_no,'000000000000000000') <> '000000000000000000';
                   
                    end if;
                    
                 end loop;
              end if;

      RETURN '1';
   
    END;

-----------  subm_awb_AMD_del_AWB_HAWB  end-----------------------------------   

----------  subm_awb_AMD_Ver_del  start-----------------------------------
FUNCTION subm_awb_AMD_Ver_del(p_truck_flt_no  IN VARCHAR2, p_truck_flt_date  IN VARCHAR2, p_itfs_flt_key IN VARCHAR2,  p_itfs_flt_date IN VARCHAR2,  p_user_id IN VARCHAR2)  
 RETURN VARCHAR2 IS 

    CURSOR c1   IS 
            SELECT *
              FROM cst_itm_awb
               WHERE truck_flt_no = p_truck_flt_no
                  AND truck_flt_date = p_truck_flt_date
                  and itfs_flt_key = p_itfs_flt_key
                  AND itfs_flt_date = p_itfs_flt_date
                  AND accs_ind = 'INT';
              
    v_ret VARCHAR2(8 byte);
    l_shp_man_pcs VARCHAR2(6);
    l_shp_man_wt VARCHAR2(9);
  
    v_change_ind VARCHAR2(1);
    v_consol_ind VARCHAR2(1);
   
    BEGIN
              
            IF c1 % ISOPEN THEN
            CLOSE c1;
            END IF;

            for i IN c1 LOOP
             DBMS_OUTPUT.PUT_LINE('subm_awb_AMD_Ver_ONE_del  i.awb_no-  ' || i.awb_no);
            
--               if i.CNSL_IND = 'Y' then
                DBMS_OUTPUT.PUT_LINE('subm_awb_AMD_Ver_ONE_del  i.awb_no-  ' || i.awb_no);
                  v_ret := subm_awb_AMD_del_AWB_HAWB(p_truck_flt_no , p_truck_flt_date, p_itfs_flt_key,   p_itfs_flt_date,  p_user_id, i.awb_no, i.awb_Date, i.CNSL_IND);
--               end if;
            
            END LOOP;
  
      RETURN '1';
   
    END;

-----------  subm_awb_AMD_Ver_del  end-----------------------------------

-------------------------subm_awb_AMD_ADD_UPD_AWB_HAWB starts--------------------------------
 FUNCTION subm_awb_AMD_ADD_UPD_AWB_HAWB(p_truck_flt_no IN VARCHAR2, p_truck_flt_date IN VARCHAR2, p_itfs_flt_key  IN VARCHAR2, p_itfs_flt_date IN VARCHAR2,
                        p_user_id IN VARCHAR2,p_awb_no IN VARCHAR2, p_awb_date  IN date, p_CNSL_IND IN VARCHAR2, p_TRK_MANF_PCS in Number, p_TRK_MANF_WT in Number)  
 RETURN VARCHAR2 IS 
              
     CURSOR c2   (c_awb_no  in varchar2, c_awb_date in date)
        IS
              SELECT *
              FROM cst_itm_hawb
              WHERE truck_flt_no = p_truck_flt_no
              AND truck_flt_date = p_truck_flt_date
              and itfs_flt_key = p_itfs_flt_key
              AND itfs_flt_date = p_itfs_flt_date
              AND accs_ind = 'INT'
              and awb_no = c_awb_no
              and awb_date = c_awb_date
               and nvl(hawb_no,'000000000000000000') <> '000000000000000000';
              
    v_ret VARCHAR2(8 byte);
    l_shp_man_pcs VARCHAR2(6);
    l_shp_man_wt VARCHAR2(9);
    ins_upd_del_ind  VARCHAR2(1);
  
    v_change_ind VARCHAR2(1);
    v_change_hse_ind VARCHAR2(1);
    v_add_awb_ind varchar2(1);
   
--    v_awb_pc_wt_cnt number;
    v_itm_awb_rec_cnt number;
    
    v_itm_awb_amd_rec_cnt number;
    
    v_cnt number;
    v_row_cnt number;
    
    v_new_hawb_cnt number;    
    v_old_hawb_cnt number;
   
    BEGIN
--    v_awb_pc_wt_cnt := 0;
    v_itm_awb_rec_cnt := 0;
    
    v_itm_awb_amd_rec_cnt := 0;
    
    v_cnt := 0;
    v_row_cnt := 0;
    
    v_new_hawb_cnt := 0;
    v_old_hawb_cnt := 0;
   
    
     SELECT count(1) into v_itm_awb_rec_cnt
                FROM cst_itm_awb itmAwb
                WHERE  p_awb_no = itmAwb.awb_no
                and  p_awb_date = itmAwb.awb_date
                and truck_flt_no = p_truck_flt_no
                AND truck_flt_date = p_truck_flt_date
                and itfs_flt_key = p_itfs_flt_key
                AND itfs_flt_date = p_itfs_flt_date
                AND accs_ind in  ('INT');     
    
     if v_itm_awb_rec_cnt = 0 then  
                v_change_ind := 'A';
--     elsif v_itm_awb_rec_cnt > 0 then
--      
--         SELECT MAN_PCS, MAN_WGT into  l_shp_man_pcs, l_shp_man_wt 
--          FROM cst_itm_awb itmAwb
--          WHERE  p_awb_no = itmAwb.awb_no
--          and  p_awb_date = itmAwb.awb_date
--          and truck_flt_no = p_truck_flt_no
--          AND truck_flt_date = p_truck_flt_date
--          and itfs_flt_key = p_itfs_flt_key
--          AND itfs_flt_date = p_itfs_flt_date
--          AND accs_ind in  ('INT');
--          
--          if l_shp_man_pcs <> p_TRK_MANF_PCS OR l_shp_man_wt <> p_TRK_MANF_WT then 
--            v_change_ind := 'U';
--          end if;
    end if;
    
               if v_change_ind = 'A'   then
               DBMS_OUTPUT.PUT_LINE('End v_ret - ' || v_change_ind);
              
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  j.awb_no - ' ||  j.awb_no);
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  j.awb_date - ' ||  j.awb_date);
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  p_truck_no - ' ||  p_truck_no);
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  p_truck_flt_no - ' ||  p_truck_flt_no);
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  p_sch_date - ' ||  p_sch_date);
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  p_sch_time - ' ||  p_sch_time);
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  v_subm_ver_no - ' ||  v_subm_ver_no);
                                  
                Insert into CST_ITM_AWB (TR_NO,AWB_NO,AWB_DATE,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                    MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                    CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                    HDLG_AGENT,CNSL_IND,CONTENT,
                    ACCS_IND,LM_VER,SUBM_VER_NO,CHANGE_IND,CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,MSG_VER,UNLDG_PT) 
                    select V_CST_ITM_AWB_SEQ,cdtPmanAwb.AWB_NO, cdtPmanAwb.AWB_DATE, cdtPmanAwb.TRK_FLT_KEY,cdtPmanAwb.TRK_FLT_DATE,cdtPmanAwb.itfs_FLT_KEY,cdtPmanAwb.itfs_FLT_DATE,'T',cdtAwb.AWB_ORIGIN,cdtAwb.AWB_DEST,
                    cdtPmanAwb.PMAN_PCS, cdtPmanAwb.PMAN_WT,cdtAwb.SHPR_NAME,cdtAwb.SHPR_ADD1,cdtAwb.SHPR_ADD2,cdtAwb.SHPR_ADD3,cdtAwb.SHPR_ADD4,cdtAwb.SHPR_ADD5,cdtAwb.SHPR_CITY,cdtAwb.SHPR_CTRY,cdtAwb.SHPR_STATE,cdtAwb.SHPR_PIN_CODE,
                    cdtAwb.CSGNE_NAME,cdtAwb.CSGNE_ADD1,cdtAwb.CSGNE_ADD2,cdtAwb.CSGNE_ADD3,cdtAwb.CSGNE_ADD4,cdtAwb.CSGNE_ADD5,cdtAwb.CSGNE_CITY,cdtAwb.CSGNE_CTRY,cdtAwb.CSGNE_STATE,cdtAwb.CSGNE_PIN_CODE,
                    c_hdlg_agent,cdtAwb.CONSOLE_IND,SHIP_DESC, 'AMD','1','1',v_change_ind,p_user_id,sysdate,p_user_id,sysdate,'1',cdtPmanAwb.unldg_pt                   
                from  cdt_awb  cdtAwb 
                join cdt_pman_awb cdtPmanAwb on cdtAwb.awb_no = cdtPmanAwb.awb_no and cdtAwb.awb_date = cdtPmanAwb.awb_date 
                                            and cdtAwb.ITFS_FLT_KEY = cdtPmanAwb.ITFS_FLT_KEY and cdtAwb.ITFS_FLT_DATE = cdtPmanAwb.ITFS_FLT_DATE
                WHERE cdtAwb.awb_no = p_awb_no
                and cdtAwb.awb_date = p_awb_date
                and cdtAwb.itfs_flt_key = p_itfs_flt_key
                AND cdtAwb.itfs_flt_date = p_itfs_flt_date
                and cdtPmanAwb.trk_flt_key = p_truck_flt_no
                AND cdtPmanAwb.trk_flt_date = p_truck_flt_date
                and cdtPmanAwb.itfs_flt_key = p_itfs_flt_key
                AND cdtPmanAwb.itfs_flt_date = p_itfs_flt_date;-- and rownum =1;
                 
                SELECT count(1) into v_cnt
                FROM cdt_Hawb itmHawb
                WHERE  nvl(hawb_no,'000000000000000000') <> '000000000000000000'
                and tr_no = (select tr_no from cdt_awb where p_awb_no = awb_no
                                and  p_awb_date = awb_date 
                                and trk_flt_key = p_truck_flt_no
                                AND trk_flt_date = p_truck_flt_date
                                and itfs_flt_key = p_itfs_flt_key
                                AND itfs_flt_date = p_itfs_flt_date);
                 
                  if v_change_ind = 'A' and v_cnt > 0 then
                    DBMS_OUTPUT.PUT_LINE('End v_ret - ' || v_change_ind);
                  
                      Insert into CST_ITM_HAWB (TR_NO,AWB_NO,AWB_DATE,HAWB_NO,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                              MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5, SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                              CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5, CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                              HDLG_AGENT,CNSL_IND,CONTENT,ACCS_IND,LM_VER,SUBM_VER_NO,CHANGE_IND,
                              CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,MSG_VER,UNLDG_PT) 
                              select V_CST_ITM_AWB_SEQ,cdtPmanAwb.AWB_NO, cdtPmanAwb.AWB_DATE,cdthAwb.HAWB_NO,cdtPmanAwb.TRK_FLT_KEY,cdtPmanAwb.TRK_FLT_DATE,cdtPmanAwb.itfs_FLT_KEY,cdtPmanAwb.itfs_FLT_DATE,'T',nvl(cdtHawb.HAWB_ORIGIN,cdtAwb.AWB_ORIGIN),nvl(cdtHawb.HAWB_DEST,cdtAwb.AWB_DEST),
                              cdtHawb.hawb_PCS, cdtHawb.hawb_WT,cdthAwb.SHPR_NAME,cdthAwb.SHPR_ADD1,cdthAwb.SHPR_ADD2,cdthAwb.SHPR_ADD3, cdthAwb.SHPR_ADD4,cdthAwb.SHPR_ADD5,cdthAwb.SHPR_CITY,cdthAwb.SHPR_CTRY,cdthAwb.SHPR_STATE,cdthAwb.SHPR_PIN_CODE,
                              cdthAwb.CSGNE_NAME,cdthAwb.CSGNE_ADD1,cdthAwb.CSGNE_ADD2,cdthAwb.CSGNE_ADD3,cdthAwb.CSGNE_ADD4,cdthAwb.CSGNE_ADD5,cdthAwb.CSGNE_CITY,cdthAwb.CSGNE_CTRY,cdthAwb.CSGNE_STATE,cdthAwb.CSGNE_PIN_CODE,
                              c_hdlg_agent,cdtAwb.CONSOLE_IND,cdthAwb.SHIP_DESC,
                              'AMD','1','1',v_change_ind,p_user_id,sysdate,p_user_id,sysdate,'1',cdtPmanAwb.unldg_pt
                        from  cdt_awb  cdtAwb 
                        JOIN cdt_Hawb cdthAwb ON cdtAwb.TR_NO = cdthAwb.TR_NO
                        join cdt_pman_awb cdtPmanAwb on cdtAwb.awb_no = cdtPmanAwb.awb_no and cdtAwb.awb_date = cdtPmanAwb.awb_date 
                                                    and cdtAwb.ITFS_FLT_KEY = cdtPmanAwb.ITFS_FLT_KEY and cdtAwb.ITFS_FLT_DATE = cdtPmanAwb.ITFS_FLT_DATE                                            
                        WHERE cdtAwb.awb_no = p_awb_no
                        and cdtAwb.awb_date = p_awb_date
                        and cdtAwb.itfs_flt_key = p_itfs_flt_key
                        AND cdtAwb.itfs_flt_date = p_itfs_flt_date
                        and cdtPmanAwb.trk_flt_key = p_truck_flt_no
                        AND cdtPmanAwb.trk_flt_date = p_truck_flt_date
                        and cdtPmanAwb.itfs_flt_key = p_itfs_flt_key
                        AND cdtPmanAwb.itfs_flt_date = p_itfs_flt_date
                        and nvl(cdthAwb.hawb_no,'000000000000000000') <> '000000000000000000';
                  end if;
                  
                  elsif  v_change_ind = 'U' OR v_change_ind = '' OR v_change_ind  is null then
                   DBMS_OUTPUT.PUT_LINE('End v_ret - ' || v_change_ind);
                  
                  v_add_awb_ind := null;
                  
                  if v_change_ind = 'U'   then
                  
                      SELECT count(1) into v_itm_awb_amd_rec_cnt
                        FROM cst_itm_awb itmAwb
                        WHERE  p_awb_no = itmAwb.awb_no
                        and  p_awb_date = itmAwb.awb_date
                        and truck_flt_no = p_truck_flt_no
                        AND truck_flt_date = p_truck_flt_date
                        and itfs_flt_key = p_itfs_flt_key
                        AND itfs_flt_date = p_itfs_flt_date
                        AND accs_ind in  ('AMD');  
                        
                        
                        SELECT COUNT(1)
                            INTO v_new_hawb_cnt
                              FROM cdt_hawb
                              WHERE nvl(hawb_no,'000000000000000000') <> '000000000000000000'
                              and tr_no = (select tr_no from cdt_awb where awb_no = p_awb_no  
                                                                      and itfs_flt_key       = p_itfs_flt_key
                                                                      AND itfs_flt_date      = p_itfs_flt_date
                                                                      and trk_flt_key = p_truck_flt_no
                                                                      AND trk_flt_date = p_truck_flt_date);
                                                                      
                        SELECT count(1) into v_old_hawb_cnt
                        FROM cst_itm_hawb itmAwb
                        WHERE  p_awb_no = itmAwb.awb_no
                        and  p_awb_date = itmAwb.awb_date
                        and truck_flt_no = p_truck_flt_no
                        AND truck_flt_date = p_truck_flt_date
                        and itfs_flt_key = p_itfs_flt_key
                        AND itfs_flt_date = p_itfs_flt_date
                        and nvl(hawb_no,'000000000000000000') <> '000000000000000000'
                        AND accs_ind in  ('INT');                         
                        
                        v_new_hawb_cnt := 0;
                        v_old_hawb_cnt := 0;
                        
                        if  v_itm_awb_amd_rec_cnt = 0 and v_new_hawb_cnt > 0 and v_old_hawb_cnt = 0 then
                  
                           Insert into CST_ITM_AWB (TR_NO,AWB_NO,AWB_DATE,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                            MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                            CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                            HDLG_AGENT,CNSL_IND,CONTENT,
                            ACCS_IND,LM_VER,SUBM_VER_NO,CHANGE_IND,CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,MSG_VER,UNLDG_PT) 
                            select V_CST_ITM_AWB_SEQ,cdtPmanAwb.AWB_NO, cdtPmanAwb.AWB_DATE, cdtPmanAwb.TRK_FLT_KEY,cdtPmanAwb.TRK_FLT_DATE,cdtPmanAwb.itfs_FLT_KEY,cdtPmanAwb.itfs_FLT_DATE,'T',cdtAwb.AWB_ORIGIN,cdtAwb.AWB_DEST,
                            cdtPmanAwb.PMAN_PCS, cdtPmanAwb.PMAN_WT,cdtAwb.SHPR_NAME,cdtAwb.SHPR_ADD1,cdtAwb.SHPR_ADD2,cdtAwb.SHPR_ADD3,cdtAwb.SHPR_ADD4,cdtAwb.SHPR_ADD5,cdtAwb.SHPR_CITY,cdtAwb.SHPR_CTRY,cdtAwb.SHPR_STATE,cdtAwb.SHPR_PIN_CODE,
                            cdtAwb.CSGNE_NAME,cdtAwb.CSGNE_ADD1,cdtAwb.CSGNE_ADD2,cdtAwb.CSGNE_ADD3,cdtAwb.CSGNE_ADD4,cdtAwb.CSGNE_ADD5,cdtAwb.CSGNE_CITY,cdtAwb.CSGNE_CTRY,cdtAwb.CSGNE_STATE,cdtAwb.CSGNE_PIN_CODE,
                            c_hdlg_agent,cdtAwb.CONSOLE_IND,SHIP_DESC, 'AMD','1','1',v_change_ind,p_user_id,sysdate,p_user_id,sysdate,'1',cdtPmanAwb.UNLDG_PT
                            from  cdt_awb  cdtAwb 
                            join cdt_pman_awb cdtPmanAwb on cdtAwb.awb_no = cdtPmanAwb.awb_no and cdtAwb.awb_date = cdtPmanAwb.awb_date 
                                                        and cdtAwb.ITFS_FLT_KEY = cdtPmanAwb.ITFS_FLT_KEY and cdtAwb.ITFS_FLT_DATE = cdtPmanAwb.ITFS_FLT_DATE
                            WHERE cdtAwb.awb_no = p_awb_no
                            and cdtAwb.awb_date = p_awb_date
                            and cdtAwb.itfs_flt_key = p_itfs_flt_key
                            AND cdtAwb.itfs_flt_date = p_itfs_flt_date
                            and cdtPmanAwb.trk_flt_key = p_truck_flt_no
                            AND cdtPmanAwb.trk_flt_date = p_truck_flt_date
                            and cdtPmanAwb.itfs_flt_key = p_itfs_flt_key
                            AND cdtPmanAwb.itfs_flt_date = p_itfs_flt_date;
                            
                        end if;
                        v_add_awb_ind := 'Y';
                  end if;
                   
                   v_row_cnt := 0;        
                                   
                   for i in (SELECT hawb_no hawb_no, cdthAwb.HAWB_PCS TRK_MANF_PCS, cdthAwb.HAWB_WT  TRK_MANF_WT
                              from  cdt_awb  cdtAwb 
                              JOIN cdt_Hawb cdthAwb ON cdtAwb.TR_NO = cdthAwb.TR_NO
                              join cdt_pman_awb cdtPmanAwb on cdtAwb.awb_no = cdtPmanAwb.awb_no and cdtAwb.awb_date = cdtPmanAwb.awb_date 
                                                          and cdtAwb.ITFS_FLT_KEY = cdtPmanAwb.ITFS_FLT_KEY and cdtAwb.ITFS_FLT_DATE = cdtPmanAwb.ITFS_FLT_DATE                                            
                              WHERE cdtAwb.awb_no = p_awb_no
                              and cdtAwb.awb_date = p_awb_date
                              and cdtAwb.itfs_flt_key = p_itfs_flt_key
                              AND cdtAwb.itfs_flt_date = p_itfs_flt_date
                              and cdtPmanAwb.trk_flt_key = p_truck_flt_no
                              AND cdtPmanAwb.trk_flt_date = p_truck_flt_date
                              and cdtPmanAwb.itfs_flt_key = p_itfs_flt_key
                              AND cdtPmanAwb.itfs_flt_date = p_itfs_flt_date
                              and nvl(cdthAwb.hawb_no,'000000000000000000') <> '000000000000000000') 
                    loop                          
                       
                        SELECT count(1) into v_itm_awb_rec_cnt
                        FROM cst_itm_hawb
                        WHERE accs_ind = 'INT'
                        and hawb_no = i.hawb_no
                        and truck_flt_no = p_truck_flt_no
                        AND truck_flt_date = p_truck_flt_date
                        and itfs_flt_key = p_itfs_flt_key
                        AND itfs_flt_date = p_itfs_flt_date
                        and awb_no = p_awb_no
                        and awb_date = p_awb_date;
                    
                         if v_itm_awb_rec_cnt = 0 then  
                                    v_change_hse_ind := 'A';
--                        elsif v_itm_awb_rec_cnt > 0 then
--                      
--                        select MAN_PCS, MAN_WGT into  l_shp_man_pcs , l_shp_man_wt 
--                          from cst_itm_hawb
--                         WHERE accs_ind = 'INT'
--                              and hawb_no = i.hawb_no
--                              and truck_flt_no = p_truck_flt_no
--                              AND truck_flt_date = p_truck_flt_date
--                              and itfs_flt_key = p_itfs_flt_key
--                              AND itfs_flt_date = p_itfs_flt_date
--                              and awb_no = p_awb_no
--                              and awb_date = p_awb_date
--                              and nvl(hawb_no,'000000000000000000') <> '000000000000000000';  
--                          
--                            if l_shp_man_pcs <> i.TRK_MANF_PCS OR l_shp_man_wt <> i.TRK_MANF_WT then 
--                              v_change_hse_ind := 'U';
--                            end if;
                        end if;
             
                
                
                if v_change_hse_ind = 'A' or v_change_hse_ind = 'U'  then
                    DBMS_OUTPUT.PUT_LINE('End v_ret - ' || v_change_ind);
                
                if v_change_ind is null and v_change_hse_ind is not null and v_add_awb_ind is null and v_row_cnt = 0 then
                
                    SELECT count(1) into v_itm_awb_amd_rec_cnt
                        FROM cst_itm_awb itmAwb
                        WHERE  p_awb_no = itmAwb.awb_no
                        and  p_awb_date = itmAwb.awb_date
                        and truck_flt_no = p_truck_flt_no
                        AND truck_flt_date = p_truck_flt_date
                        and itfs_flt_key = p_itfs_flt_key
                        AND itfs_flt_date = p_itfs_flt_date
                        AND accs_ind in  ('AMD');  
                        
                        if  v_itm_awb_amd_rec_cnt = 0 then
                           Insert into CST_ITM_AWB (TR_NO,AWB_NO,AWB_DATE,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                            MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                            CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                            HDLG_AGENT,CNSL_IND,CONTENT,
                            ACCS_IND,LM_VER,SUBM_VER_NO,CHANGE_IND,CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,MSG_VER,UNLDG_PT) 
                            select V_CST_ITM_AWB_SEQ,cdtPmanAwb.AWB_NO, cdtPmanAwb.AWB_DATE, cdtPmanAwb.TRK_FLT_KEY,cdtPmanAwb.TRK_FLT_DATE,cdtPmanAwb.itfs_FLT_KEY,cdtPmanAwb.itfs_FLT_DATE,'T',cdtAwb.AWB_ORIGIN,cdtAwb.AWB_DEST,
                            cdtPmanAwb.PMAN_PCS, cdtPmanAwb.PMAN_WT,cdtAwb.SHPR_NAME,cdtAwb.SHPR_ADD1,cdtAwb.SHPR_ADD2,cdtAwb.SHPR_ADD3,cdtAwb.SHPR_ADD4,cdtAwb.SHPR_ADD5,cdtAwb.SHPR_CITY,cdtAwb.SHPR_CTRY,cdtAwb.SHPR_STATE,cdtAwb.SHPR_PIN_CODE,
                            cdtAwb.CSGNE_NAME,cdtAwb.CSGNE_ADD1,cdtAwb.CSGNE_ADD2,cdtAwb.CSGNE_ADD3,cdtAwb.CSGNE_ADD4,cdtAwb.CSGNE_ADD5,cdtAwb.CSGNE_CITY,cdtAwb.CSGNE_CTRY,cdtAwb.CSGNE_STATE,cdtAwb.CSGNE_PIN_CODE,
                            c_hdlg_agent,cdtAwb.CONSOLE_IND,SHIP_DESC, 'AMD','1','1','U',p_user_id,sysdate,p_user_id,sysdate,'1',cdtPmanAwb.UNLDG_PT
                        from  cdt_awb  cdtAwb 
                        join cdt_pman_awb cdtPmanAwb on cdtAwb.awb_no = cdtPmanAwb.awb_no and cdtAwb.awb_date = cdtPmanAwb.awb_date 
                                                    and cdtAwb.ITFS_FLT_KEY = cdtPmanAwb.ITFS_FLT_KEY and cdtAwb.ITFS_FLT_DATE = cdtPmanAwb.ITFS_FLT_DATE
                        WHERE cdtAwb.awb_no = p_awb_no
                        and cdtAwb.awb_date = p_awb_date
                        and cdtAwb.itfs_flt_key = p_itfs_flt_key
                        AND cdtAwb.itfs_flt_date = p_itfs_flt_date
                        and cdtPmanAwb.trk_flt_key = p_truck_flt_no
                        AND cdtPmanAwb.trk_flt_date = p_truck_flt_date
                        and cdtPmanAwb.itfs_flt_key = p_itfs_flt_key
                        AND cdtPmanAwb.itfs_flt_date = p_itfs_flt_date;
                        
                        v_add_awb_ind := 'Y';
                         v_row_cnt := v_row_cnt + 1;
                        end if;
                  end if;
                  
                      Insert into CST_ITM_HAWB (TR_NO,AWB_NO,AWB_DATE,HAWB_NO,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                              MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                              CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                              HDLG_AGENT,CNSL_IND,CONTENT,ACCS_IND,LM_VER,SUBM_VER_NO,CHANGE_IND,
                              CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,MSG_VER,UNLDG_PT) 
                              select V_CST_ITM_AWB_SEQ,cdtPmanAwb.AWB_NO, cdtPmanAwb.AWB_DATE,cdthAwb.HAWB_NO,cdtPmanAwb.TRK_FLT_KEY,cdtPmanAwb.TRK_FLT_DATE,cdtPmanAwb.itfs_FLT_KEY,cdtPmanAwb.itfs_FLT_DATE,'T',nvl(cdtHawb.HAWB_ORIGIN,cdtAwb.AWB_ORIGIN),nvl(cdtHawb.HAWB_DEST,cdtAwb.AWB_DEST),
                              cdtHawb.hawb_PCS, cdtHawb.hawb_WT,cdthAwb.SHPR_NAME,cdthAwb.SHPR_ADD1,cdthAwb.SHPR_ADD2,cdthAwb.SHPR_ADD3, cdthAwb.SHPR_ADD4,cdthAwb.SHPR_ADD5,cdthAwb.SHPR_CITY,cdthAwb.SHPR_CTRY,cdthAwb.SHPR_STATE,cdthAwb.SHPR_PIN_CODE,
                              cdthAwb.CSGNE_NAME,cdthAwb.CSGNE_ADD1,cdthAwb.CSGNE_ADD2,cdthAwb.CSGNE_ADD3, cdthAwb.CSGNE_ADD4,cdthAwb.CSGNE_ADD5,cdthAwb.CSGNE_CITY,cdthAwb.CSGNE_CTRY,cdthAwb.CSGNE_STATE,cdthAwb.CSGNE_PIN_CODE,
                              c_hdlg_agent,cdtAwb.CONSOLE_IND,cdthAwb.SHIP_DESC,
                              'AMD','1','1',v_change_hse_ind,p_user_id,sysdate,p_user_id,sysdate,'1',cdtPmanAwb.UNLDG_PT  
                        from  cdt_awb  cdtAwb 
                        JOIN cdt_Hawb cdthAwb ON cdtAwb.TR_NO = cdthAwb.TR_NO
                        join cdt_pman_awb cdtPmanAwb on cdtAwb.awb_no = cdtPmanAwb.awb_no and cdtAwb.awb_date = cdtPmanAwb.awb_date 
                                                    and cdtAwb.ITFS_FLT_KEY = cdtPmanAwb.ITFS_FLT_KEY and cdtAwb.ITFS_FLT_DATE = cdtPmanAwb.ITFS_FLT_DATE                                            
                        WHERE cdtAwb.awb_no = p_awb_no
                        and cdtAwb.awb_date = p_awb_date
                        and cdtAwb.itfs_flt_key = p_itfs_flt_key
                        AND cdtAwb.itfs_flt_date = p_itfs_flt_date
                        and cdtPmanAwb.trk_flt_key = p_truck_flt_no
                        AND cdtPmanAwb.trk_flt_date = p_truck_flt_date
                        and cdtPmanAwb.itfs_flt_key = p_itfs_flt_key
                        AND cdtPmanAwb.itfs_flt_date = p_itfs_flt_date
                        and nvl(cdthAwb.hawb_no,'000000000000000000') <> '000000000000000000'
                        and nvl(i.hawb_no,'000000000000000000') = cdthAwb.hawb_no;
                  end if;
                  
                 
                end loop;   
                                
              end if;

      RETURN v_ret;
    END;
    -------------------------subm_awb_AMD_ADD_UPD_AWB_HAWB Ends--------------------------------
-------------------------subm_awb_AMD_Ver_ADD_UPD starts--------------------------------
 FUNCTION subm_awb_AMD_Ver_ADD_UPD(p_truck_flt_no  IN VARCHAR2, p_truck_flt_date  IN VARCHAR2, p_itfs_flt_key IN VARCHAR2,  p_itfs_flt_date IN VARCHAR2,  p_user_id IN VARCHAR2)  
 RETURN VARCHAR2 IS 
              
     CURSOR c2  
        IS
              SELECT *
              FROM cdt_awb cdtAwb
              WHERE cdtAwb.itfs_flt_key = p_itfs_flt_key
              AND cdtAwb.itfs_flt_Date = p_itfs_flt_date
              and exists (select null 
                          from cdt_pman_awb  
                          where trk_flt_key = p_truck_flt_no
                                AND trk_flt_date = p_truck_flt_date
                                and itfs_flt_key = p_itfs_flt_key
                                AND itfs_flt_date = p_itfs_flt_date);
              
    v_ret VARCHAR2(8 byte);
    l_shp_man_pcs VARCHAR2(6);
    l_shp_man_wt VARCHAR2(9);
    ins_upd_del_ind  VARCHAR2(1);
  
    v_change_ind VARCHAR2(1);
    v_awb_pc_wt_cnt number;
    v_itm_awb_rec_cnt number;
    
     v_cnt number;
   
    BEGIN
            IF c2 % ISOPEN THEN
            CLOSE c2;
            END IF;
            ------------
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMD_Ver_ADD_UPD starts p_truck_- ' || p_truck_no ||' - - '||p_truck_flt_no ||' - - '|| p_sch_date ||' - - '|| p_sch_time ||' - - '|| p_user_id);
              
           for j IN c2 LOOP
--             DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ADD_UPD starts - ' || j.awb_no ||' - - '|| j.awb_Date ||' - - '|| j.CNSL_IND ||' - - '|| j.TRK_MANF_PCS ||' - - '|| j.TRK_MANF_WT);
           v_ret := subm_awb_AMD_ADD_UPD_AWB_HAWB( p_truck_flt_no , p_truck_flt_date, p_itfs_flt_key , p_itfs_flt_date, p_user_id, j.awb_no, j.awb_Date, j.CONSOLE_IND, j.AWB_PCS, j.AWB_WT);
             
            END LOOP;  
  
      RETURN v_ret;
   
    END;
-------------------------subm_awb_AMD_Ver_ADD_UPD Ends--------------------------------
-----------  subm_awb_AMD  start-----------------------------------
 FUNCTION subm_awb_AMD(p_truck_flt_no  IN VARCHAR2,  p_truck_flt_date  IN VARCHAR2,  p_itfs_flt_key  IN VARCHAR2,   p_itfs_flt_date  IN VARCHAR2, p_subm_ver_no  IN VARCHAR2,   p_user_id  IN VARCHAR2)  
 RETURN VARCHAR2 IS 
              
    v_ret VARCHAR2(8 byte);
    BEGIN
    
        delete from  CST_ITM_AWB  
                WHERE truck_flt_no = p_truck_flt_no
                  AND truck_flt_date = p_truck_flt_date
                  and itfs_flt_key = p_itfs_flt_key
                  AND itfs_flt_date = p_itfs_flt_date
                  AND accs_ind = 'AMD';
                  
         delete from  CST_ITM_HAWB  
                WHERE truck_flt_no = p_truck_flt_no
                  AND truck_flt_date = p_truck_flt_date
                  and itfs_flt_key = p_itfs_flt_key
                  AND itfs_flt_date = p_itfs_flt_date
                  AND accs_ind = 'AMD';    
         
         V_CST_ITM_AWB_SEQ := CST_ITM_AWB_SEQ.NEXTVAL;
                  
         v_ret := subm_awb_AMD_Ver_del(p_truck_flt_no, p_truck_flt_date , p_itfs_flt_key,   p_itfs_flt_date,  p_user_id);
         v_ret := subm_awb_AMD_Ver_ADD_UPD(p_truck_flt_no, p_truck_flt_date , p_itfs_flt_key,   p_itfs_flt_date,  p_user_id);
         
      RETURN '1';   
    END;

-----------  subm_awb_AMD  end-----------------------------------

/**************************************************************/
/*update for amendment Start
/**************************************************************/
    procedure  sub_ins_cst_cd_awb_hawb(p_rec_type IN VARCHAR2, p_truck_flt_no IN VARCHAR2,  p_truck_flt_date IN VARCHAR2,   p_itfs_flt_key IN VARCHAR2,  p_itfs_flt_date IN VARCHAR2,   p_subm_ver_no OUT NUMBER,   p_user_id IN VARCHAR2) 
    IS 
    
    v_check_subm VARCHAR2(3);
    v_ret VARCHAR2(1);
    v_send_status VARCHAR2(1);
    v_ver_no NUMBER(2,0);
    v_lm_ver NUMBER(2,0);
  
    
    BEGIN    
    if(p_rec_type = 'AMD') then    
      v_ret := subm_awb_AMD(p_truck_flt_no ,  p_truck_flt_date,  p_itfs_flt_key ,   p_itfs_flt_date , p_subm_ver_no ,   p_user_id );
    end if; 
     
     v_ret := '1';
     
    END;
/**************************************************************/
/*update for amendment End
/**************************************************************/
-------------------------delete_awb_LBS starts--------------------------------
 procedure delete_awb_LBS(rec_type IN VARCHAR2, p_truck_flt_no IN VARCHAR2, p_truck_flt_date IN VARCHAR2, p_itfs_flt_key  IN VARCHAR2, p_itfs_flt_date IN VARCHAR2)  
    IS
    v_ret VARCHAR2(8 byte);
    BEGIN
    --[BDS, XH001, 24SEP14, NB001P, 24SEP14, SRINIVAS, 77720149172, 15SEP14, Y]
    
--     dbms_output.enable(1000000);
  
  DBMS_OUTPUT.PUT_LINE('subm_awb_LBS');

        delete from  CST_ITM_AWB  
                WHERE truck_flt_no = p_truck_flt_no
                  AND truck_flt_date = p_truck_flt_date
                  and itfs_flt_key = p_itfs_flt_key
                  AND itfs_flt_date = p_itfs_flt_date
                  AND accs_ind = 'BDS' AND BRKN_DOWN_CODE IS NULL;
                  
        delete from  CST_ITM_AWB  
                WHERE truck_flt_no = p_truck_flt_no
                  AND truck_flt_date = p_truck_flt_date
                  and itfs_flt_key = p_itfs_flt_key
                  AND itfs_flt_date = p_itfs_flt_date
                  AND accs_ind = 'AMD' and change_ind in  ('A','U')
                  and (awb_no) not in 
                  (select awb_no 
                          from cst_csgnm where recv_rec_type = 'AMD' 
                          and flt_key = p_itfs_flt_key and flt_date = p_itfs_flt_date
                          and nvl(hawb_no,'000000000000000000') = '000000000000000000' 
                          and substr(cns_dtl,0,1)  in ('A','U')
                          and exists (select null from cst_subm where flt_key = p_itfs_flt_key and flt_date = p_itfs_flt_date 
                                          and rec_type = 'AMD' and send_status in ('P','W','A')));
                          
--         delete from  CST_ITM_AWB  
--                WHERE truck_flt_no = p_truck_flt_no
--                  AND truck_flt_date = p_truck_flt_date
--                  and itfs_flt_key = p_itfs_flt_key
--                  AND itfs_flt_date = p_itfs_flt_date
--                  AND accs_ind = 'BDS' AND BRKN_DOWN_CODE IS NOT NULL
--                  and (awb_no) not in 
--                  (select awb_no 
--                          from cst_csgnm where recv_rec_type = 'BDS' 
--                          and flt_key = p_itfs_flt_key and flt_date = p_itfs_flt_date
--                          and nvl(hawb_no,'000000000000000000') = '000000000000000000' 
--                          and substr(cns_dtl,21,2)  in ('SC','SP','LP','LC')
--                          and exists (select null from cst_subm where flt_key = p_itfs_flt_key and flt_date = p_itfs_flt_date 
--                                          and rec_type = 'BDS' and msg_type is null and send_status in ('P','W','A')));
         
                          
       DBMS_OUTPUT.PUT_LINE('subm_awb_LBS');            
         delete from  CST_ITM_HAWB  
                WHERE truck_flt_no = p_truck_flt_no
                  AND truck_flt_date = p_truck_flt_date
                  and itfs_flt_key = p_itfs_flt_key
                  AND itfs_flt_date = p_itfs_flt_date
                  AND accs_ind = 'BDS' AND BRKN_DOWN_CODE IS NULL;
           DBMS_OUTPUT.PUT_LINE('subm_awb_LBS');     
           
           
           delete from  CST_ITM_HAWB  
                WHERE truck_flt_no = p_truck_flt_no
                  AND truck_flt_date = p_truck_flt_date
                  and itfs_flt_key = p_itfs_flt_key
                  AND itfs_flt_date = p_itfs_flt_date
                  AND accs_ind = 'AMD' and change_ind in  ('A','U')
                  and (awb_no,nvl(hawb_no,'000000000000000000')) not in 
                  (select awb_no,nvl(hawb_no,'000000000000000000')
                          from cst_csgnm where recv_rec_type = 'AMD' 
                          and flt_key = p_itfs_flt_key and flt_date = p_itfs_flt_date
                          and nvl(hawb_no,'000000000000000000') <> '000000000000000000' 
                          and substr(cns_dtl,0,1)  in ('A','U')
                          and exists (select null from cst_subm where flt_key = p_itfs_flt_key and flt_date = p_itfs_flt_date 
                                          and rec_type = 'AMD' and send_status in ('P','W','A')));
                                          
--          delete from  CST_ITM_HAWB  
--                WHERE truck_flt_no = p_truck_flt_no
--                  AND truck_flt_date = p_truck_flt_date
--                  and itfs_flt_key = p_itfs_flt_key
--                  AND itfs_flt_date = p_itfs_flt_date
--                  AND accs_ind = 'BDS' AND BRKN_DOWN_CODE IS NOT NULL
--                  and (awb_no,nvl(hawb_no,'000000000000000000')) not in 
--                  (select awb_no , nvl(hawb_no,'000000000000000000')
--                          from cst_csgnm where recv_rec_type = 'BDS' 
--                          and flt_key = p_itfs_flt_key and flt_date = p_itfs_flt_date
--                          and nvl(hawb_no,'000000000000000000') = '000000000000000000' 
--                          and substr(cns_dtl,21,2)  in ('SC','SP','LP','LC')
--                          and exists (select null from cst_subm where flt_key = p_itfs_flt_key and flt_date = p_itfs_flt_date 
--                                          and rec_type = 'BDS' and msg_type is null and send_status in ('P','W','A')));
      
    END;
    -------------------------delete_awb_LBS Ends--------------------------------
-------------------------subm_awb_LBS starts--------------------------------
 procedure subm_awb_LBS(rec_type IN VARCHAR2, p_truck_flt_no IN VARCHAR2, p_truck_flt_date IN VARCHAR2, p_itfs_flt_key  IN VARCHAR2, p_itfs_flt_date IN VARCHAR2,
                        p_user_id IN VARCHAR2,p_awb_no IN VARCHAR2, p_awb_date  IN date, p_CNSL_IND IN VARCHAR2)  
    IS
    v_ret VARCHAR2(8 byte);
    BEGIN
    --[BDS, XH001, 24SEP14, NB001P, 24SEP14, SRINIVAS, 77720149172, 15SEP14, Y]
    
--     dbms_output.enable(1000000);
  
  DBMS_OUTPUT.PUT_LINE('subm_awb_LBS');
      
      V_CST_ITM_AWB_SEQ := CST_ITM_AWB_SEQ.NEXTVAL;
      
           DBMS_OUTPUT.PUT_LINE('subm_awb_LBS');        
        Insert into CST_ITM_AWB (TR_NO,AWB_NO,AWB_DATE,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
              MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
              CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
              HDLG_AGENT,CNSL_IND,CONTENT,
              ACCS_IND,LM_VER,SUBM_VER_NO,CHANGE_IND,CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,MSG_VER,UNLDG_PT) 
              select V_CST_ITM_AWB_SEQ,cdtPmanAwb.AWB_NO, cdtPmanAwb.AWB_DATE, cdtPmanAwb.TRK_FLT_KEY,cdtPmanAwb.TRK_FLT_DATE,cdtPmanAwb.itfs_FLT_KEY,cdtPmanAwb.itfs_FLT_DATE,'T',cdtAwb.AWB_ORIGIN,cdtAwb.AWB_DEST,
              cdtPmanAwb.PMAN_PCS, cdtPmanAwb.PMAN_WT,cdtAwb.SHPR_NAME,cdtAwb.SHPR_ADD1,cdtAwb.SHPR_ADD2,cdtAwb.SHPR_ADD3, cdtAwb.SHPR_ADD4, cdtAwb.SHPR_ADD5,cdtAwb.SHPR_CITY,cdtAwb.SHPR_CTRY,cdtAwb.SHPR_STATE,cdtAwb.SHPR_PIN_CODE,
              cdtAwb.CSGNE_NAME,cdtAwb.CSGNE_ADD1,cdtAwb.CSGNE_ADD2,cdtAwb.CSGNE_ADD3, cdtAwb.CSGNE_ADD4,cdtAwb.CSGNE_ADD5,cdtAwb.CSGNE_CITY,cdtAwb.CSGNE_CTRY,cdtAwb.CSGNE_STATE,cdtAwb.CSGNE_PIN_CODE,
              c_hdlg_agent,cdtAwb.CONSOLE_IND,SHIP_DESC, 'BDS','1','1','N',p_user_id,sysdate,p_user_id,sysdate,'1',cdtPmanAwb.UNLDG_PT                 
          from  cdt_awb  cdtAwb 
          join cdt_pman_awb cdtPmanAwb on cdtAwb.awb_no = cdtPmanAwb.awb_no and cdtAwb.awb_date = cdtPmanAwb.awb_date 
                                      and cdtAwb.ITFS_FLT_KEY = cdtPmanAwb.ITFS_FLT_KEY and cdtAwb.ITFS_FLT_DATE = cdtPmanAwb.ITFS_FLT_DATE
          WHERE cdtAwb.awb_no = p_awb_no
          and cdtAwb.awb_date = p_awb_date
          and cdtAwb.itfs_flt_key = p_itfs_flt_key
          AND cdtAwb.itfs_flt_date = p_itfs_flt_date
          and cdtPmanAwb.trk_flt_key = p_truck_flt_no
          AND cdtPmanAwb.trk_flt_date = p_truck_flt_date
          and cdtPmanAwb.itfs_flt_key = p_itfs_flt_key
          AND cdtPmanAwb.itfs_flt_date = p_itfs_flt_date;             
    
     DBMS_OUTPUT.PUT_LINE('subm_awb_LBS');
     if(p_CNSL_IND = 'Y') then
    for i in (SELECT hawb_no hawb_no, cdthAwb.HAWB_PCS TRK_MANF_PCS, cdthAwb.HAWB_WT  TRK_MANF_WT
                              from  cdt_awb  cdtAwb 
                              JOIN cdt_Hawb cdthAwb ON cdtAwb.TR_NO = cdthAwb.TR_NO
                              join cdt_pman_awb cdtPmanAwb on cdtAwb.awb_no = cdtPmanAwb.awb_no and cdtAwb.awb_date = cdtPmanAwb.awb_date 
                                                          and cdtAwb.ITFS_FLT_KEY = cdtPmanAwb.ITFS_FLT_KEY and cdtAwb.ITFS_FLT_DATE = cdtPmanAwb.ITFS_FLT_DATE                                            
                              WHERE cdtAwb.awb_no = p_awb_no
                              and cdtAwb.awb_date = p_awb_date
                              and cdtAwb.itfs_flt_key = p_itfs_flt_key
                              AND cdtAwb.itfs_flt_date = p_itfs_flt_date
                              and cdtPmanAwb.trk_flt_key = p_truck_flt_no
                              AND cdtPmanAwb.trk_flt_date = p_truck_flt_date
                              and cdtPmanAwb.itfs_flt_key = p_itfs_flt_key
                              AND cdtPmanAwb.itfs_flt_date = p_itfs_flt_date) 
                    loop    
                    
                     DBMS_OUTPUT.PUT_LINE('subm_awb_LBS');
                     
                        Insert into CST_ITM_HAWB (TR_NO,AWB_NO,AWB_DATE,HAWB_NO,TRUCK_FLT_NO,TRUCK_FLT_DATE,ITFS_FLT_KEY,ITFS_FLT_DATE,FLT_TYPE,ORG,DEST,
                              MAN_PCS,MAN_WGT,SHPR_NAME,SHPR_ADDR,SHPR_ADDR2,SHPR_ADDR3,SHPR_ADDR4,SHPR_ADDR5,SHPR_PLACE,SHPR_CTRY_CODE,SHPR_STATE_PROVINCE,SHPR_PIN_CODE,
                              CSGNE_NAME,CSGNE_ADDR,CSGNE_ADDR2,CSGNE_ADDR3,CSGNE_ADDR4,CSGNE_ADDR5,CSGNE_PLACE,CSGNE_CTRY_CODE,CSGNE_STATE_PROVINCE,CSGNE_PIN_CODE,
                              HDLG_AGENT,CNSL_IND,CONTENT,ACCS_IND,LM_VER,SUBM_VER_NO,CHANGE_IND,
                              CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,MSG_VER,UNLDG_PT) 
                              select V_CST_ITM_AWB_SEQ,cdtPmanAwb.AWB_NO, cdtPmanAwb.AWB_DATE,cdthAwb.HAWB_NO,cdtPmanAwb.TRK_FLT_KEY,cdtPmanAwb.TRK_FLT_DATE,cdtPmanAwb.itfs_FLT_KEY,cdtPmanAwb.itfs_FLT_DATE,'T',nvl(cdtHawb.HAWB_ORIGIN,cdtAwb.AWB_ORIGIN),nvl(cdtHawb.HAWB_DEST,cdtAwb.AWB_DEST),
                              cdtHawb.hawb_PCS, cdtHawb.hawb_WT,cdthAwb.SHPR_NAME,cdthAwb.SHPR_ADD1,cdthAwb.SHPR_ADD2,cdthAwb.SHPR_ADD3, cdthAwb.SHPR_ADD4,cdthAwb.SHPR_ADD5,cdthAwb.SHPR_CITY,cdthAwb.SHPR_CTRY,cdthAwb.SHPR_STATE,cdthAwb.SHPR_PIN_CODE,
                              cdthAwb.CSGNE_NAME,cdthAwb.CSGNE_ADD1,cdthAwb.CSGNE_ADD2,cdthAwb.CSGNE_ADD3, cdthAwb.CSGNE_ADD4,cdthAwb.CSGNE_ADD5,cdthAwb.CSGNE_CITY,cdthAwb.CSGNE_CTRY,cdthAwb.CSGNE_STATE,cdthAwb.CSGNE_PIN_CODE,
                              c_hdlg_agent,cdtAwb.CONSOLE_IND,cdthAwb.SHIP_DESC,
                              'BDS','1','1','N',p_user_id,sysdate,p_user_id,sysdate,'1',cdtPmanAwb.UNLDG_PT                        
                              from  cdt_awb  cdtAwb 
                              JOIN cdt_Hawb cdthAwb ON cdtAwb.TR_NO = cdthAwb.TR_NO
                              join cdt_pman_awb cdtPmanAwb on cdtAwb.awb_no = cdtPmanAwb.awb_no and cdtAwb.awb_date = cdtPmanAwb.awb_date 
                                                          and cdtAwb.ITFS_FLT_KEY = cdtPmanAwb.ITFS_FLT_KEY and cdtAwb.ITFS_FLT_DATE = cdtPmanAwb.ITFS_FLT_DATE                                            
                              WHERE cdtAwb.awb_no = p_awb_no
                              and cdtAwb.awb_date = p_awb_date
                              and cdtAwb.itfs_flt_key = p_itfs_flt_key
                              AND cdtAwb.itfs_flt_date = p_itfs_flt_date
                              and cdtPmanAwb.trk_flt_key = p_truck_flt_no
                              AND cdtPmanAwb.trk_flt_date = p_truck_flt_date
                              and cdtPmanAwb.itfs_flt_key = p_itfs_flt_key
                              AND cdtPmanAwb.itfs_flt_date = p_itfs_flt_date
                              and cdthAwb.hawb_no = i.hawb_no;
                     
                      end loop;
                end if;
    END;
    -------------------------subm_awb_AMD_ADD_UPD_AWB_HAWB Ends--------------------------------
    
     procedure validate_LBS(rec_type IN VARCHAR2, 
                        p_truck_flt_no IN VARCHAR2, 
                        p_truck_flt_date IN VARCHAR2, 
                        p_itfs_flt_key  IN VARCHAR2, 
                        p_itfs_flt_date IN VARCHAR2,
                        p_ret OUT VARCHAR2)
    IS
    v_ret VARCHAR2(8 byte);
    p_int_ind VARCHAR2(8 byte);
    p_amd_ind VARCHAR2(8 byte);
    p_clr_ind VARCHAR2(8 byte);
    p_lbs_ind VARCHAR2(8 byte);
    p_bds_ind VARCHAR2(8 byte);
    BEGIN
    --[BDS, XH001, 24SEP14, NB001P, 24SEP14, SRINIVAS, 77720149172, 15SEP14, Y]
    
--     dbms_output.enable(1000000);
  
  DBMS_OUTPUT.PUT_LINE('validate_LBS');
      
      p_int_ind := FUN_CHECK_MAN_ITFS('T',p_itfs_flt_key,p_itfs_flt_date,'INT');
      
      p_amd_ind := FUN_CHECK_MAN_ITFS('T',p_itfs_flt_key,p_itfs_flt_date,'AMD');
      
      p_lbs_ind := FUN_CHECK_MAN_ITFS('T',p_itfs_flt_key,p_itfs_flt_date,'BDS-LB');
      
      p_bds_ind := FUN_CHECK_MAN_ITFS('T',p_itfs_flt_key,p_itfs_flt_date,'BDS');
      
      p_clr_ind := FUN_CHECK_MAN_ITFS('T',p_itfs_flt_key,p_itfs_flt_date,'CLR');
      
      if(p_int_ind = 'P' or p_int_ind = 'W') then
        p_ret := 'Initial submission is in progress or pending. Please wait!';
      end if;
      
      if(p_amd_ind = 'P' or p_amd_ind = 'W') then
        p_ret := 'Amendment submission is in progress or pending. Please wait!';
      end if;
      
      if(p_clr_ind != 'Y') then
        p_ret := 'Flight clear is not done. Please get the flight clear done before left behind submission!';
      end if;
      
      if(p_lbs_ind = 'P' or p_lbs_ind = 'W') then
        p_ret := 'Left behind submission is in progress or pending. Please wait!';
      end if;
      
      if(p_bds_ind = 'P' or p_bds_ind = 'W') then
        p_ret := 'Breakdown submission is in progress or pending. Please wait!';
      end if;
        
      if (p_ret is null or (p_ret is not null and length(trim(p_ret)) = 0 )) then
        p_ret :=  'TRUE';    
      end if;
    END;
    
END pkg_cdt_cst_init;
/
SHOW ERRORS