--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PROCEDURE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT Creating WOSINT.PRO_CLEAR_FFM
 CREATE OR REPLACE PROCEDURE WOSINT.PRO_CLEAR_FFM 
  (
    p_flt_key  IN VARCHAR2 DEFAULT NULL,
    p_flt_date IN VARCHAR2 DEFAULT NULL,
    p_awb_no   IN VARCHAR2 DEFAULT NULL)
               IS
  v_flt_date DATE;
  v_awb_date DATE;
  v_error VARCHAR2(1000);
  CURSOR cc(p_flt_date DATE)
  IS
    SELECT DISTINCT *
       FROM
      (SELECT a.tr_no,
        b.doc_line_no,
        a.flt_key    ,
        a.flt_date   ,
        b.uld_key    ,
        b.nil_ind    ,
        c.awb_no
         FROM edi_ffm_msg a,
        edi_ffm_uld b      ,
        edi_ffm_shp c
        WHERE a.tr_no   = b.tr_no
      AND b.tr_no       = c.tr_no(+)
      AND b.doc_line_no = c.udoc_line_no(+)
      AND a.flt_date    = p_flt_date
      AND a.ffm_status  = 'P'
      AND b.nil_ind     = 'N'
      )
    WHERE awb_no IS NULL;
  CURSOR ff
  IS
     SELECT *
       FROM
      (SELECT a.tr_no                            ,
        b.brd_point                              ,
        b.off_point                              ,
        SUM(DECODE(b.nil_ind, 'N', 1, 0)) shp_ind,
        SUM(DECODE(b.nil_ind, 'Y', 1, 0)) nil_ind
         FROM edi_ffm_msg a,
        edi_ffm_uld b
        WHERE a.tr_no  = b.tr_no
      AND a.flt_date   = TRUNC(SYSDATE)
      AND a.ffm_status = 'P'
     GROUP BY a.tr_no,
        b.brd_point  ,
        b.off_point
      )
    WHERE shp_ind > 0
  AND nil_ind     > 0;
  CURSOR ee
  IS
     SELECT *
       FROM
      (SELECT n.flt_key,
        n.flt_date     ,
        n.awb_no       ,
        m.awb_no ffm_awb_no
         FROM
        (SELECT a.flt_key,
          a.flt_date     ,
          b.awb_no
           FROM edi_ffm_msg a,
          edi_ffm_shp b
          WHERE a.tr_no  = b.tr_no
        AND a.flt_key    = p_flt_key
        AND a.flt_date   = v_flt_date
        AND a.ffm_status = 'P'
       GROUP BY a.flt_key,
          a.flt_date     ,
          b.awb_no
        ) m,
      imp_car_shp n
      WHERE n.flt_key   = m.flt_key(+)
    AND n.flt_date      = m.flt_date(+)
    AND n.awb_no        = m.awb_no(+)
    AND n.flt_key       = p_flt_key
    AND n.flt_date      = v_flt_date
    AND n.ffm_flg       = 'Y'
    AND n.car_created   = 'N'
    AND n.recd_pcs      = 0
    AND n.cir_pcs_type IS NULL
    AND n.cir_wt_type  IS NULL
      )
      WHERE ffm_awb_no IS NULL;
  BEGIN
    --DELETE ULD WHICH HAS NO SHIPMENT
    IF p_flt_date IS NOT NULL AND p_flt_key IS NULL THEN
      v_flt_date  := to_date(p_flt_date, 'DDMONYY');
       DELETE FROM edi_ffm_msg WHERE flt_date = v_flt_date AND ffm_status = 'ERROR';

      FOR c IN cc(v_flt_date)
      LOOP
        dbms_output.put_line(c.tr_no || c.doc_line_no || c.flt_key || c.flt_date);
        BEGIN
           DELETE FROM edi_ffm_uld WHERE tr_no = c.tr_no AND doc_line_no = c.doc_line_no;
        EXCEPTION
        WHEN OTHERS THEN
          NULL;
        END;
      END LOOP;
    ELSE
      FOR x IN -1 .. 1
      LOOP
        v_flt_date := TRUNC(SYSDATE) + x;
         DELETE FROM edi_ffm_msg WHERE flt_date = v_flt_date AND ffm_status = 'ERROR';

        dbms_output.put_line('----------------------------');
        dbms_output.put_line(v_flt_date);
        FOR c IN cc(v_flt_date)
        LOOP
          dbms_output.put_line(c.tr_no || c.doc_line_no || c.flt_key || c.flt_date);
          BEGIN
             DELETE FROM edi_ffm_uld WHERE tr_no = c.tr_no AND doc_line_no = c.doc_line_no;
          EXCEPTION
          WHEN OTHERS THEN
            NULL;
          END;
        END LOOP;
        dbms_output.put_line('----------------------------');
      END LOOP;
    END IF;
    --DELETE SEGMENT WHICH HAS NIL AND SHIP BOTH
    FOR x IN ff
    LOOP
      BEGIN
         DELETE FROM edi_ffm_uld WHERE tr_no = x.tr_no AND nil_ind = 'Y';
      EXCEPTION
      WHEN OTHERS THEN
        NULL;
      END;
    END LOOP;
    IF p_flt_key IS NOT NULL AND p_flt_date IS NOT NULL THEN
      v_flt_date := to_date(p_flt_date, 'DDMONYY');
      --delete awb_no which has no ffm from import car
      FOR c IN ee
      LOOP
        dbms_output.put_line(c.flt_key || ' ' || c.flt_date || ' ' || c.awb_no);
        --v_awb_date := pkg_imp.fun_get_awbdate_existing(c.awb_no, 'I', 'FFM');
         DELETE
           FROM imp_car_shp
          WHERE flt_key = c.flt_key
        AND flt_date    = c.flt_date
        AND awb_no      = c.awb_no;
        -- AND awb_date = v_awb_date;
         DELETE
           FROM imp_car_awb a
          WHERE a.awb_no = c.awb_no
        AND a.awb_date   = v_awb_date
        AND NOT EXISTS
          (SELECT 1 FROM imp_car_shp WHERE awb_no = a.awb_no AND awb_date = a.awb_date
          );
      END LOOP;
    END IF;
  EXCEPTION
  WHEN OTHERS THEN
    v_error := SQLCODE || SQLERRM;
     INSERT INTO cst_auto_submit_log VALUES
      ('pro_clear_ffm:' || v_error
      );
  END;

/
SHOW ERRORS