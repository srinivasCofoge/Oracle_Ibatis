--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PROCEDURE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT Creating WOSINT.PRO_AUTO_ITM_SUBMIT
CREATE OR REPLACE PROCEDURE WOSINT.PRO_AUTO_ITM_SUBMIT IS CURSOR cc IS
SELECT *
FROM cst_subm_temp
WHERE processed = 'N'
 AND rec_type IN('INA',   'AMA',   'BAS')
 AND rownum = 1 FOR

UPDATE NOWAIT;

v_ret VARCHAR2(200);
p_ver_no NUMBER(3);
v_err VARCHAR2(1000);
v_sts VARCHAR2(1);
rec_subm cc % rowtype;
BEGIN


  DBMS_OUTPUT.PUT_LINE('start PRO_AUTO_ITM_SUBMIT ');

  IF cc % ISOPEN THEN
    CLOSE cc;
  END IF;

  OPEN cc;
  FETCH cc
  INTO rec_subm;

  IF cc % rowcount = 1 THEN

    UPDATE cst_subm_temp
    SET processed = 'Y'
    WHERE CURRENT OF cc;

    p_ver_no := rec_subm.ver_no;

    v_sts := fun_check_itm_man('T',   rec_subm.truck_no,   to_char(rec_subm.sch_date,   'DDMONYY'),   rec_subm.sch_time,   rec_subm.rec_type,   'Y');

    DBMS_OUTPUT.PUT_LINE('start PRO_AUTO_ITM_SUBMIT v_sts' || v_sts);

    IF(v_sts IS NULL OR v_sts IN('R',   'E')) THEN
      v_sts := 'N';
    END IF;

    --    DBMS_OUTPUT.PUT_LINE('start 11 PRO_AUTO_ITM_SUBMIT v_sts' || v_sts);

    IF v_sts NOT IN('P',   'W') THEN

      DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITM_SUBMIT 22  v_sts' || v_sts || ' -- rec_subm.rec_type -- ' || rec_subm.rec_type);

      IF v_sts = 'A'
       AND rec_subm.rec_type = 'INA' THEN

        DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITM_SUBMIT 33');

        DELETE FROM cst_submit_temp
        WHERE flt_key = rec_subm.flt_key
         AND flt_date = rec_subm.flt_date
         AND cst_type = rec_subm.rec_type
         AND ver_no = rec_subm.ver_no;

        DELETE FROM cst_subm_temp
        WHERE flt_key = rec_subm.flt_key
         AND flt_date = rec_subm.flt_date
         AND rec_type = rec_subm.rec_type
         AND ver_no = rec_subm.ver_no;
      ELSE
              DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITM_SUBMIT 44 else');
        IF rec_subm.rec_type = 'INA'
         AND v_sts = 'N' THEN

          DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITM_SUBMIT 44 ina');

          v_ret := pkg_cst_truck_init.ina_submission(rec_subm.truck_no,   to_char(rec_subm.sch_date,   'DDMONYY'),   rec_subm.flt_key,   to_char(rec_subm.flt_date,   'DDMONYY'),   rec_subm.sch_time,   p_ver_no,   rec_subm.lm_user_id,   rec_subm.lm_date);

          DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITM_SUBMIT 55 v_ret - ' || v_ret);

          ELSIF rec_subm.rec_type = 'AMA' THEN
          
          DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITM_SUBMIT 44 AMA');
          BEGIN
            v_ret := pkg_cst_truck_init.ama_submission(rec_subm.truck_no,   to_char(rec_subm.sch_date,   'DDMONYY'),   rec_subm.flt_key,   to_char(rec_subm.flt_date,   'DDMONYY'),   rec_subm.sch_time,   p_ver_no,   rec_subm.lm_user_id,   rec_subm.lm_date);
        EXCEPTION
        WHEN others THEN
        DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITM_SUBMIT 44 error --- ' ||SUBSTR(SQLCODE || sqlerrm,   1,   1000));
        END;
        
          END IF;

          IF v_ret = 'TRUE' THEN
            INSERT
            INTO cst_subm(flt_type,   flt_date,   flt_key,   ver_no,   ctrl_date,   req_uid,   msg_type,   msg_id,   rec_type,   subm_date,   send_status,   send_date,   bd_complete,   lm_user_id,   lm_date,   lm_ver,   err_msg,   truck_no,   sch_date,   sch_time)
            VALUES(rec_subm.flt_type,   rec_subm.flt_date,   rec_subm.flt_key,   p_ver_no,   sysdate,   rec_subm.req_uid,   rec_subm.msg_type,   rec_subm.msg_id,   rec_subm.rec_type,   rec_subm.subm_date,   rec_subm.send_status,   rec_subm.send_date,   rec_subm.bd_complete,   rec_subm.lm_user_id,   rec_subm.lm_date,   rec_subm.lm_ver,   rec_subm.err_msg,   rec_subm.truck_no,   rec_subm.sch_date,   rec_subm.sch_time);
          ELSE
            INSERT
            INTO cst_subm(flt_type,   flt_date,   flt_key,   ver_no,   ctrl_date,   req_uid,   msg_type,   msg_id,   rec_type,   subm_date,   send_status,   send_date,   bd_complete,   lm_user_id,   lm_date,   lm_ver,   err_msg,   truck_no,   sch_date,   sch_time)
            VALUES(rec_subm.flt_type,   rec_subm.flt_date,   rec_subm.flt_key,   nvl(p_ver_no,   99),   rec_subm.ctrl_date,   rec_subm.req_uid,   rec_subm.msg_type,   rec_subm.msg_id,   rec_subm.rec_type,   rec_subm.subm_date,   'E',   rec_subm.send_date,   rec_subm.bd_complete,   rec_subm.lm_user_id,   rec_subm.lm_date,   rec_subm.lm_ver,   nvl(v_ret,   'GENERATING DATA FAILURE'),   rec_subm.truck_no,   rec_subm.sch_date,   rec_subm.sch_time);
          END IF;

          DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITM_SUBMIT 55 v_ret - ' || v_ret);
          INSERT
          INTO cst_auto_submit_log
          VALUES(rec_subm.flt_key || '/' || rec_subm.flt_date || ' ' || to_char(sysdate,   'DDMONYY') || ' submit :' || rec_subm.rec_type || ' version is ' || p_ver_no);

          DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITM_SUBMIT 55 v_ret - ' || v_ret);

        END IF;

        DELETE FROM cst_submit_temp
        WHERE flt_key = rec_subm.flt_key
         AND flt_date = rec_subm.flt_date
         AND cst_type = rec_subm.rec_type
         AND ver_no = rec_subm.ver_no;

        DELETE FROM cst_subm_temp
        WHERE flt_key = rec_subm.flt_key
         AND flt_date = rec_subm.flt_date
         AND rec_type = rec_subm.rec_type
         AND ver_no = rec_subm.ver_no
         AND truck_no = rec_subm.truck_no
         AND sch_date = rec_subm.sch_date
         AND sch_time = rec_subm.sch_time;

      END IF;

    END IF;

    CLOSE cc;
    COMMIT;

  EXCEPTION
  WHEN others THEN

    IF cc % ISOPEN THEN
      CLOSE cc;
    END IF;

    v_err := SUBSTR(SQLCODE || sqlerrm,   1,   1000);
    INSERT
    INTO cst_auto_submit_log
    VALUES(to_char(sysdate,   'DDMONYY HH24:MI') || ':' || v_err);
  END;

/
SHOW ERRORS