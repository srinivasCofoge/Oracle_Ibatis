--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PROCEDURE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT Creating WOSINT.PRO_AUTO_HST_SUBMIT
CREATE OR REPLACE EDITIONABLE PROCEDURE WOSINT.PRO_AUTO_HST_SUBMIT IS
  CURSOR cc IS
    SELECT *
      FROM cst_subm_temp t1
     WHERE processed = 'N'
      AND rec_type   IN ('HST') 
      and ver_no = (SELECT min(ver_no) FROM cst_subm_temp t2 
                        WHERE t1.processed = t2.processed and t1.flt_key = t2.flt_key and t1.flt_date = t2.flt_date and t1.rec_type = t2.rec_type and t1.flt_date = t2.flt_date)
       AND rownum = 1 
       FOR UPDATE NOWAIT;
  v_ret    VARCHAR2(200);
  p_ver_no NUMBER;
  v_err    VARCHAR2(1000);
  v_sts    VARCHAR2(10);
  v_flt_type    VARCHAR2(1);
  rec_subm cc%ROWTYPE;
BEGIN

 --dbms_output.enable(1000000);
  
  DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT');

  IF cc%ISOPEN THEN
    CLOSE cc;
  END IF;
  
  
  OPEN cc;
  FETCH cc
    INTO rec_subm;
   IF cc%ROWCOUNT = 1 THEN
    UPDATE cst_subm_temp SET processed = 'Y' WHERE CURRENT OF cc;
 DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT rec_subm.ver_no ->'|| rec_subm.ver_no);
    p_ver_no := rec_subm.ver_no;
    
    
    if rec_subm.flt_key like 'NB%' then
      v_flt_type := 'T';
    else 
      v_flt_type := 'I';
    end if;
 
    v_sts    := fun_check_hst(v_flt_type, rec_subm.flt_key,
                      -- to_char(to_char(rec_subm.flt_date, 'DDMONYY'), 'DDMONYY'),
                            to_char(rec_subm.flt_date, 'DDMONYY'),
                              rec_subm.rec_type, 'Y');
                              
    DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT v_sts'||v_sts);
    
    IF v_sts IS NULL OR v_sts IN ('R', 'E') THEN
      v_sts := 'N';
    END IF;
		 DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT v_sts 1 -> '||v_sts);
    If V_Sts Not In ('P', 'W') Then 
    		 DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT v_sts 3'||v_sts);
      IF v_sts = 'A' AND rec_subm.rec_type = 'HST' THEN
      		 DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT v_sts 4'||v_sts);
        DELETE FROM cst_submit_temp
         WHERE flt_key = rec_subm.flt_key
           AND flt_date = rec_subm.flt_date
           AND cst_type = rec_subm.rec_type
           AND ver_no = rec_subm.ver_no;
        DELETE FROM cst_subm_temp
         WHERE flt_key = rec_subm.flt_key
           AND flt_date = rec_subm.flt_date
           AND rec_type = rec_subm.rec_type
           AND ver_no = rec_subm.ver_no;
      Else
      -- DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT v_sts 2'||v_sts);  
       --        DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT rec_subm.rec_type 2'||rec_subm.rec_type);  
        IF rec_subm.rec_type = 'HST' AND v_sts = 'N' THEN
              
            DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT v_sts 5'||v_sts);  
      --         DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT rec_subm.rec_type 7'||rec_subm.rec_type);  
          v_ret := pkg_cst_hst.hashtotal_csgnm_subm(rec_subm.flt_key,
                                                               to_char(rec_subm.flt_date,
                                                                        'DDMONYY'), rec_subm.flt_type,
                                                               p_ver_no,
                                                               rec_subm.lm_user_id,
                                                               rec_subm.lm_date);
        END IF;
      DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT 11 rec_subm.ver_no ->'|| rec_subm.ver_no);
      DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT 11 p_ver_no ->'|| p_ver_no);
        IF v_ret = 'TRUE' THEN
          INSERT INTO cst_subm
            (flt_type, flt_date, flt_key, ver_no, ctrl_date, req_uid,
             msg_type, msg_id, rec_type, subm_date, send_status, send_date,
             bd_complete, lm_user_id, lm_date, lm_ver, err_msg)
          VALUES
            (rec_subm.flt_type, rec_subm.flt_date, rec_subm.flt_key,
             rec_subm.ver_no, SYSDATE, rec_subm.req_uid, rec_subm.msg_type,
             rec_subm.msg_id, rec_subm.rec_type, rec_subm.subm_date,
             rec_subm.send_status, rec_subm.send_date,
             rec_subm.bd_complete, rec_subm.lm_user_id, rec_subm.lm_date,
             rec_subm.lm_ver, rec_subm.err_msg);
        ELSE
          INSERT INTO cst_subm
            (flt_type, flt_date, flt_key, ver_no, ctrl_date, req_uid,
             msg_type, msg_id, rec_type, subm_date, send_status, send_date,
             bd_complete, lm_user_id, lm_date, lm_ver, err_msg)
          VALUES
            (rec_subm.flt_type, rec_subm.flt_date, rec_subm.flt_key,
             nvl(rec_subm.ver_no, 99), rec_subm.ctrl_date, rec_subm.req_uid,
             rec_subm.msg_type, rec_subm.msg_id, rec_subm.rec_type,
             rec_subm.subm_date, 'E', rec_subm.send_date,
             rec_subm.bd_complete, rec_subm.lm_user_id, rec_subm.lm_date,
             rec_subm.lm_ver, nvl(v_ret, 'GENERATING DATA FAILURE'));
        END IF;
        INSERT INTO cst_auto_submit_log
        VALUES
          (rec_subm.flt_key || '/' || rec_subm.flt_date || ' ' ||
           to_char(SYSDATE, 'DDMONYY') || ' submit :' ||
           rec_subm.rec_type || ' version is ' || p_ver_no);
      END IF;
    END IF;
    DELETE FROM cst_submit_temp
     WHERE flt_key = rec_subm.flt_key
       AND flt_date = rec_subm.flt_date
       AND cst_type = rec_subm.rec_type
       AND ver_no = rec_subm.ver_no;
    DELETE FROM cst_subm_temp
     WHERE flt_key = rec_subm.flt_key
       AND flt_date = rec_subm.flt_date
       AND rec_type = rec_subm.rec_type
       AND ver_no = rec_subm.ver_no; 
  END IF;
  CLOSE cc;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    IF cc%ISOPEN THEN
      CLOSE cc;
    END IF;
    v_err := substr(SQLCODE || SQLERRM, 1, 1000);
    INSERT INTO cst_auto_submit_log
    VALUES
      (To_Char(Sysdate, 'DDMONYY HH24:MI') || ':' || V_Err);
END;
/
SHOW ERRORS