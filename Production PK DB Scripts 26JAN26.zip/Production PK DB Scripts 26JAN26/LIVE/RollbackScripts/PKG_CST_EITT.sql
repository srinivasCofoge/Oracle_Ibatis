--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PACKAGE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT CREATE OR REPLACE PACKAGE WOSINT.PKG_CST_EITT
CREATE OR REPLACE PACKAGE  WOSINT.PKG_CST_EITT
AS
  FUNCTION ITT_SUBMIT_REQ(
      P_ITT_REQ_DATE IN date,
      P_ITT_req_no   IN VARCHAR2,
      P_USER_ID      IN VARCHAR2,
      P_LM_DATE      IN DATE)
  RETURN VARCHAR2;
  FUNCTION ITT_CONFIRM_REQ(
      P_ITT_REQ_CODE IN VARCHAR2,
      P_USER_ID      IN VARCHAR2,
      P_LM_DATE      IN DATE)
  RETURN VARCHAR2;  
   FUNCTION ITT_CANCEL_REQ(
    P_ITT_REQ_DATE IN DATE,
    P_itt_req_no       IN VARCHAR2,
    P_ITT_REQ_CODE IN VARCHAR2,
    P_USER_ID      IN VARCHAR2,
    P_LM_DATE      IN DATE)
  RETURN VARCHAR2 ;
END PKG_CST_EITT;
/

PROMPT CREATE OR REPLACE PACKAGE BODY WOSINT.PKG_CST_EITT
CREATE OR REPLACE PACKAGE BODY WOSINT.PKG_CST_EITT
IS
  S_CONS_HEADER      VARCHAR2(100);
  S_CONS_DETAIL      VARCHAR2(2500);
  S_CONS_HAWB_DETAIL VARCHAR2(2500);
  S_CONS_FOOTER      VARCHAR2(30);
  S_USER_ID          VARCHAR2(20);
  S_LM_DATE          DATE;
  S_ITT_TYPE         VARCHAR2(3);
  S_ERROR_MSG        VARCHAR2(200);
  S_CMS3_ERROR       VARCHAR2(200);
  S_ITT_REQ_DATE     VARCHAR2(12);
  S_CNSL_IND         VARCHAR2(1);
  S_itt_req_no           VARCHAR2(3);
  S_DETAIL_SEQ_NO    NUMBER;
  S_LOOP_CNT         NUMBER;
  S_AWB_TYPE         VARCHAR2(1);
  S_AWB_MANF_PCS     NUMBER;
  S_AWB_MANF_WT      NUMBER;
  S_AWB_ORIGIN       VARCHAR2(3);
  S_AWB_DEST         VARCHAR2(3);
  S_CTM_REF_NO       VARCHAR2(12);
  S_DC_IND           VARCHAR2(1);
  S_CONTENT          VARCHAR2(265);
  S_HAWB_MANF_PCS    NUMBER;
  S_HAWB_MANF_WT     NUMBER;
  S_HAWB_ORIGIN      VARCHAR2(3);
  S_HAWB_DEST        VARCHAR2(3);
  S_HAWB_CONTENT     VARCHAR2(265);
  S_FLT_TYPE         VARCHAR2(1);
  S_FLT_CARR         VARCHAR2(12);
  S_FLT_NO           VARCHAR2(12);
  S_FLT_KEY          VARCHAR2(12);
  S_FLT_DATE         DATE;
  V_itt_req_no       VARCHAR2(3);
  V_ITT_REQ_DATE     DATE;
  V_ITT_REQ_CODE     VARCHAR2(16);
  V_AWB_NO           VARCHAR2(30);
  V_AWB_DATE         DATE;
  V_HAWB_NO          VARCHAR2(18);
  V_FLT_CARR         VARCHAR2(12);
  V_FLT_NO           VARCHAR2(12);
  V_FLT_KEY          VARCHAR2(12);
  V_FLT_DATE         DATE;
  Z_FLT_DATE         VARCHAR2(12);
  CHEADER            CONSTANT VARCHAR2(6)   := 'HEADER';
  CDETAIL            CONSTANT VARCHAR2(6)   := 'DETAIL';
  CFOOTER            CONSTANT VARCHAR2(6)   := 'FOOTER';
  C_FLT_00003        CONSTANT VARCHAR2(100) := ' SUBMIT IS IN PROGRESS';
  C_AWB_00011        CONSTANT VARCHAR2(100) := ' NO DATA FOUND';
  C_AWB_00009        CONSTANT VARCHAR2(100) := ' GENERATED MESSAGE FORMAT IS WRONG.NOW ITS LENGTH IS';
FUNCTION BOOL_TO_TEXT(
    P_BOOL IN BOOLEAN)
  RETURN VARCHAR2
IS
BEGIN
  RETURN
  CASE
  WHEN P_BOOL THEN
    'TRUE'
  WHEN NOT P_BOOL THEN
    'FALSE'
  ELSE
    'NULL'
  END;
END;
/********************INSERT_CST_CSGNM STARTS ****************/
FUNCTION INSERT_CST_CSGNM(
    P_HAWB_NO VARCHAR2,
    MSG_TYPE  VARCHAR2)
  RETURN BOOLEAN
IS
  S_SEQ_NO NUMBER(8);
BEGIN
  DBMS_OUTPUT.PUT_LINE('INSERT_CST_CSGNM 1 -- MSG_TYPE -- ' || MSG_TYPE);
  IF MSG_TYPE        = CHEADER THEN
    S_SEQ_NO        := 0;
  ELSIF MSG_TYPE     = CFOOTER THEN
    S_SEQ_NO        := 99999;
  ELSIF MSG_TYPE     = CDETAIL THEN
    S_DETAIL_SEQ_NO := S_DETAIL_SEQ_NO + 1;
    S_SEQ_NO        := S_DETAIL_SEQ_NO;
  ELSE
    NULL;
  END IF;
  DBMS_OUTPUT.PUT_LINE('INSERT_CST_CSGNM 2 -- S_CONS_HEADER -- ' || S_CONS_HEADER);
  DBMS_OUTPUT.PUT_LINE('INSERT_CST_CSGNM 3 -- S_CONS_DETAIL -- ' || S_CONS_DETAIL);
  DBMS_OUTPUT.PUT_LINE('INSERT_CST_CSGNM 4 -- S_CONS_FOOTER -- ' || S_CONS_FOOTER);
  DBMS_OUTPUT.PUT_LINE('INSERT_CST_CSGNM 4 -- S_CONS_FOOTER -- ' || S_CNSL_IND);
--  INSERT
--  INTO CST_AUTO_SUBMIT_LOG VALUES
--    (
--      'CDETAIL '
--      || CDETAIL
--      || '......AWB...'
--      || V_AWB_NO
--    );
--  IF S_CNSL_IND = 'N' THEN
--    DBMS_OUTPUT.PUT_LINE('CDETAIL-' || CDETAIL || '..MSG..' || MSG_TYPE || '..V_AWB_NO..' || V_AWB_NO || '..H..' || P_HAWB_NO || '....S_CONS_DETAIL...' || S_CONS_DETAIL);
--    DBMS_OUTPUT.PUT_LINE('FLT_TYPE- T ; FLT_KEY -' || V_FLT_KEY || ' FLT_DATE - ' || V_FLT_DATE || '; VER_NO - ' || V_itt_req_no || '; RECV_REC_TYPE - ' || S_ITT_TYPE || '; SEQ_NO - ' || S_SEQ_NO);
    INSERT
    INTO CST_CSGNM
      (
        CARR_CODE,
        FLT_KEY,
        FLT_DATE,
        FLT_TYPE,
        VER_NO,
        RECV_REC_TYPE,
        SEQ_NO,
        CTRL_DATE,
        REQ_UID,
        AWB_NO,
        HAWB_NO,
        CNS_HDR,
        CNS_DTL,
        CNS_FTR,
        LM_USER_ID,
        LM_DATE,
        LM_VER,
        ITT_REQ_CODE
      )
      VALUES
      (
        S_FLT_CARR,
        S_FLT_KEY,
        sysdate,
        'Z',
        to_number(V_itt_req_no),
        S_ITT_TYPE,
        S_SEQ_NO,
        TO_DATE(S_ITT_REQ_DATE, 'YYYYMMDD'),
        ' ',
        DECODE(MSG_TYPE, CDETAIL, V_AWB_NO, NULL),
        DECODE(MSG_TYPE, CDETAIL, P_HAWB_NO, NULL),
        DECODE(MSG_TYPE, CHEADER, S_CONS_HEADER, NULL),
        DECODE(MSG_TYPE, CDETAIL, S_CONS_DETAIL, NULL),
        DECODE(MSG_TYPE, CFOOTER, S_CONS_FOOTER, NULL),
        USER,
        SYSDATE,
        1,
        V_ITT_REQ_CODE
      );
--  ELSIF S_CNSL_IND = 'Y' THEN
--    DBMS_OUTPUT.PUT_LINE('CDETAIL-' || CDETAIL || '..MSG..' || MSG_TYPE || '..V_AWB_NO..' || V_AWB_NO || '..H..' || P_HAWB_NO || '....S_CONS_HAWB_DETAIL...' || S_CONS_HAWB_DETAIL);
--    DBMS_OUTPUT.PUT_LINE('FLT_TYPE- T ; FLT_KEY -' || V_FLT_KEY || ' FLT_DATE - ' || V_FLT_DATE || '; VER_NO - ' || V_itt_req_no || '; RECV_REC_TYPE - ' || S_ITT_TYPE || '; SEQ_NO - ' || S_SEQ_NO);
--    INSERT
--    INTO CST_CSGNM
--      (
--        CARR_CODE,
--        FLT_KEY,
--        FLT_DATE,
--        FLT_TYPE,
--        VER_NO,
--        RECV_REC_TYPE,
--        SEQ_NO,
--        CTRL_DATE,
--        REQ_UID,
--        AWB_NO,
--        HAWB_NO,
--        CNS_HDR,
--        CNS_DTL,
--        CNS_FTR,
--        LM_USER_ID,
--        LM_DATE,
--        LM_VER,
--        ITT_REQ_CODE
--      )
--      VALUES
--      (
--        S_FLT_CARR,
--        S_FLT_KEY,
--        sysdate,
--        'Z',
--        to_number(V_itt_req_no),
--        S_ITT_TYPE,
--        S_SEQ_NO,
--        TO_DATE(S_ITT_REQ_DATE, 'YYYYMMDD'),
--        ' ',
--        DECODE(MSG_TYPE, CDETAIL, V_AWB_NO, NULL),
--        DECODE(MSG_TYPE, CDETAIL, P_HAWB_NO, NULL),
--        DECODE(MSG_TYPE, CHEADER, S_CONS_HEADER, NULL),
--        DECODE(MSG_TYPE, CDETAIL, S_CONS_HAWB_DETAIL, NULL),
--        DECODE(MSG_TYPE, CFOOTER, S_CONS_FOOTER, NULL),
--        USER,
--        SYSDATE,
--        1,
--        V_ITT_REQ_CODE
--      );
--  END IF;
  RETURN TRUE;
EXCEPTION
WHEN OTHERS THEN
  S_ERROR_MSG := SUBSTR(SQLCODE || SQLERRM, 1, 100);
--  DBMS_OUTPUT.PUT_LINE('INSERT_CST_CSGNM 5 -- S_ERROR_MSG -- ' || S_ERROR_MSG);
  INSERT INTO CST_AUTO_SUBMIT_LOG VALUES
    ( 'S_ERROR_MSG 6 ' || sysdate ||' ' || S_ERROR_MSG
    );
    
  INSERT INTO SYS_EXCEPTION_DTLS(FUNC_CODE,FUNC_TYPE,ACCESS_USER_ID,URL_PATH,EXCEP_MSG,EXCEP_STACK_TRACE,EXCEP_OCC_DATE)
  VALUES('ACCSEITTSubm', 'C', USER, 'ACCSEITTSubmission', 'S_ITT_TYPE: '||S_ITT_TYPE||' : S_ERROR_MSG 6: ' || S_ERROR_MSG, UTL_RAW.CAST_TO_RAW(S_ERROR_MSG) , SYSDATE);

  RETURN FALSE;
END;
/********************INSERT_CST_CSGNM ENDS ****************/
/********************* INIT START HERE **************************/
PROCEDURE INIT
IS
BEGIN
  S_CONS_HEADER   := NULL;
  S_CONS_DETAIL   := NULL;
  S_CONS_FOOTER   := NULL;
  S_CNSL_IND      := 'N';
  S_DETAIL_SEQ_NO := 0;
  S_LOOP_CNT      := 0;
  S_FLT_TYPE      := 'Z';
  S_FLT_CARR      := NULL;
  S_FLT_NO        := NULL;
  S_FLT_KEY       := NULL;
  S_FLT_DATE      := sysdate;
END;
/********************* INIT END HERE **************************/
/********************* INIT_ITT_DTL START HERE **************************/
PROCEDURE INIT_ITT_DTL
IS
BEGIN
  S_CONS_DETAIL      := NULL;
  S_CONS_HAWB_DETAIL := NULL;
  S_AWB_MANF_PCS     := 0;
  S_AWB_MANF_WT      := 0;
  S_AWB_ORIGIN       := NULL;
  S_AWB_DEST         := NULL;
  S_CTM_REF_NO       := NULL;
  S_CONTENT          := NULL;
  S_HAWB_MANF_PCS    := 0;
  S_HAWB_MANF_WT     := 0;
  S_HAWB_ORIGIN      := NULL;
  S_HAWB_DEST        := NULL;
  S_HAWB_CONTENT     := NULL;
  V_HAWB_NO          := NULL;
  V_AWB_NO           := NULL;
  V_AWB_DATE         := NULL;
END;
/********************* INIT_ITT_DTL END HERE **************************/
/********************SET_CNSL_IND STARTS ****************/
FUNCTION SET_CNSL_IND
  RETURN BOOLEAN
IS
  V_CNT NUMBER;
BEGIN
  S_CNSL_IND := 'N';
  BEGIN
    SELECT AWB_DATE
    INTO V_AWB_DATE
    FROM CST_ITT_HD HD
    JOIN CST_ITT_DTL DTL
    ON HD.itt_req_no        = DTL.itt_req_no
    AND HD.ITT_REQ_DATE = DTL.ITT_REQ_DATE
    WHERE HD.itt_req_no     = V_itt_req_no
    AND HD.ITT_REQ_DATE = V_ITT_REQ_DATE
    AND DTL.AWB_NO      = V_AWB_NO
    AND DTL.FLT_KEY     = V_FLT_KEY
    AND DTL.FLT_DATE    = V_FLT_DATE;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    S_CNSL_IND := 'N';
  END;
  BEGIN
    SELECT NVL(COUNT(DISTINCT HAWB_NO), 0)
    INTO V_CNT
    FROM EDI_FHL HD,
      EDI_FHL_HAWB DTL
    WHERE HD.TR_NO  = DTL.TR_NO
    AND HD.AWB_NO   = V_AWB_NO
    AND HD.AWB_DATE = V_AWB_DATE;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    S_CNSL_IND := 'N';
  END;
  IF V_CNT      > 0 THEN
    S_CNSL_IND := 'Y';
  END IF;
  RETURN TRUE;
END;
/********************SET_CNSL_IND ENDS ****************/
/********************SET_CNSL_IND_ITF STARTS ****************/
FUNCTION SET_CNSL_IND_ITF
  RETURN BOOLEAN
IS
  V_CNT NUMBER;
BEGIN
  S_CNSL_IND := 'N';
  BEGIN
    SELECT SUM(DECODE(HAWB_NO,'000000000000000000',0,HAWB_NO,null,0,1))
    INTO V_CNT
    FROM CST_ITT_HD HD
    JOIN CST_ITT_DTL DTL
    ON ((HD.itt_req_no     = DTL.ITT_REQ_no
    AND HD.ITT_REQ_DATE = DTL.ITT_REQ_DATE) OR HD.ITT_REQ_CODE = DTL.ITT_REQ_CODE)
    WHERE ((HD.itt_req_no     = V_itt_req_no
    AND HD.ITT_REQ_DATE = V_ITT_REQ_DATE) OR HD.ITT_REQ_CODE = V_ITT_REQ_CODE)
    AND DTL.AWB_NO        = V_AWB_NO;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    S_CNSL_IND := 'N';
  END;
  IF V_CNT > 1 THEN
    S_CNSL_IND := 'Y';
  END IF;
  RETURN TRUE;
END;
/********************SET_CNSL_IND_ITF ENDS ****************/
/***********************GET_itt_req_no STARTS*************/
FUNCTION GET_itt_req_no
  RETURN BOOLEAN
IS
  N_itt_req_no NUMBER;
BEGIN
  DBMS_OUTPUT.PUT_LINE('GET_itt_req_no 1');
  FOR C IN
  (SELECT VER_NO,
    SEND_STATUS
  FROM CST_SUBM
  WHERE VER_NO  = V_itt_req_no
  AND CTRL_DATE = V_ITT_REQ_DATE
  AND REC_TYPE  = S_ITT_TYPE
  ORDER BY VER_NO DESC
  )
  LOOP
    IF C.SEND_STATUS = 'E' THEN
      DELETE
      FROM CST_CSGNM
      WHERE VER_NO      = V_itt_req_no
      AND CTRL_DATE     = V_ITT_REQ_DATE
      AND RECV_REC_TYPE = S_ITT_TYPE
      AND VER_NO        = C.VER_NO;
      DELETE
      FROM CST_SUBM
      WHERE VER_NO  = V_itt_req_no
      AND CTRL_DATE = V_ITT_REQ_DATE
      AND REC_TYPE  = S_ITT_TYPE
      AND VER_NO    = C.VER_NO;
--    ELSIF C.SEND_STATUS   IN('P', 'W') THEN
--      N_itt_req_no :=          -1;
--    ELSIF C.SEND_STATUS   IN('R', 'A') THEN
--      N_itt_req_no := C.VER_NO + 1;
    END IF;
    EXIT;
  END LOOP;
--  IF N_itt_req_no = -1 THEN
--    RETURN FALSE;
--  END IF;
--  IF NVL(N_itt_req_no, 0) = 0 THEN
--    N_itt_req_no         := 1;
--  END IF;
--  S_itt_req_no := LPAD(N_itt_req_no, 3, '0');
  RETURN TRUE;
END;
/***********************GET_itt_req_no ENDS*************/

/***********************GET_itc_req_code STARTS*************/
FUNCTION GET_itc_req_code
  RETURN BOOLEAN
IS
  N_itt_req_no NUMBER;
BEGIN
  DBMS_OUTPUT.PUT_LINE('GET_itc_req_code 1');
  FOR C IN
  (SELECT VER_NO,
    SEND_STATUS
  FROM CST_SUBM
  WHERE ((VER_NO  = V_itt_req_no
  AND CTRL_DATE = V_ITT_REQ_DATE)) -- or itt_req_COde = V_itt_req_no)
  AND REC_TYPE  = S_ITT_TYPE
  ORDER BY VER_NO DESC
  )
  LOOP
    IF C.SEND_STATUS = 'E' OR C.SEND_STATUS = 'R' THEN
      DELETE
      FROM CST_CSGNM
      WHERE ((VER_NO  = V_itt_req_no
      AND CTRL_DATE = V_ITT_REQ_DATE))-- or itt_req_COde = V_itt_req_no)
      AND RECV_REC_TYPE = S_ITT_TYPE
      AND VER_NO        = C.VER_NO;
      DELETE
      FROM CST_SUBM
      WHERE ((VER_NO  = V_itt_req_no
      AND CTRL_DATE = V_ITT_REQ_DATE))-- or itt_req_COde = V_itt_req_no)
      AND REC_TYPE  = S_ITT_TYPE
      AND VER_NO    = C.VER_NO;

    END IF;
    EXIT;
  END LOOP;

  RETURN TRUE;
END;
/***********************GET_itc_req_code ENDS*************/
/***********************GET_itf_req_code STARTS*************/
FUNCTION GET_itf_req_code
  RETURN BOOLEAN
IS
  N_itt_req_code NUMBER;
BEGIN
 
      DELETE
      FROM CST_CSGNM
      WHERE itt_req_COde = V_itt_req_Code
      AND RECV_REC_TYPE = S_ITT_TYPE;
      
      DELETE
      FROM CST_SUBM
      WHERE itt_req_COde = V_itt_req_Code
      AND REC_TYPE  = S_ITT_TYPE
      and SEND_STATUS in ('E','R');
  
  RETURN TRUE;
END;
/***********************GET_itf_req_code ENDS*************/
/*******************  GET_HDR_INFO_ITT START HERE     *****************/
FUNCTION GET_HDR_INFO_ITT
  RETURN BOOLEAN
IS
BEGIN
DBMS_OUTPUT.PUT_LINE('GET_HDR_INFO_ITT START FOR V_ITT_REQ_DATE - ' || V_ITT_REQ_DATE || ' - V_itt_req_no - ' || V_itt_req_no);
  SELECT TO_CHAR(ITT_REQ_DATE, 'YYYYMMDD'),
    TO_CHAR(ITT_REQ_DATE, 'YYYYMMDD')-- 2.1
    || LPAD(V_itt_req_no, 3, '0')
    || -- 2.2
    RPAD(decode(ORIG_CARGO_HANDLER,'CPCT','CPA',ORIG_CARGO_HANDLER), 3, ' ')
    || --  2.3
    RPAD(decode(DEST_CARGO_HANDLER,'HACTL','ST1',DEST_CARGO_HANDLER), 3, ' ')
    || --  2.4
    NVL(DC_IND, 'N')
    || -- 2.5
    LPAD(
    (SELECT NVL(COUNT(1), 0)
    FROM CST_ITT_DTL
    WHERE itt_req_no     = CST_ITT_HD.itt_req_no
    AND ITT_REQ_DATE = CST_ITT_HD.ITT_REQ_DATE
    ), 5, '0') --  2.6
  INTO S_ITT_REQ_DATE,
    S_CONS_HEADER
  FROM CST_ITT_HD
  WHERE itt_req_no     = V_itt_req_no
  AND ITT_REQ_DATE = V_ITT_REQ_DATE;
  DBMS_OUTPUT.PUT_LINE('GET_HDR_INFO_ITT START FOR S_ITT_REQ_DATE - ' || S_ITT_REQ_DATE);
  DBMS_OUTPUT.PUT_LINE('GET_HDR_INFO_ITT START FOR S_CONS_HEADER - ' || S_CONS_HEADER);
  SELECT 'Z',
    CARR_CODE,
    FLT_NO,
    FLT_KEY,
    FLT_DATE
  INTO S_FLT_TYPE,
    S_FLT_CARR,
    S_FLT_NO,
    S_FLT_KEY,
    S_FLT_DATE
  FROM CST_ITT_DTL
  WHERE itt_req_no     = V_itt_req_no
  AND ITT_REQ_DATE = V_ITT_REQ_DATE
  AND rownum       = 1;
  DBMS_OUTPUT.PUT_LINE('GET_HDR_INFO_ITT START FOR S_FLT_TYPE - ' || S_FLT_TYPE);
  IF NOT INSERT_CST_CSGNM('', CHEADER) THEN
    S_ERROR_MSG := SUBSTR(SQLCODE || SQLERRM, 1, 100);
    RETURN FALSE;
  END IF;
  RETURN TRUE;
EXCEPTION
WHEN NO_DATA_FOUND THEN
  S_ERROR_MSG := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
WHEN TOO_MANY_ROWS THEN
  S_ERROR_MSG := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
WHEN OTHERS THEN
  S_ERROR_MSG := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
END;
/*******************  GET_HDR_INFO_ITT END HERE     *****************/
/*******************  GET_HDR_INFO_ITF START HERE     *****************/
FUNCTION GET_HDR_INFO_ITF
  RETURN BOOLEAN
IS
BEGIN
  SELECT   
    LPAD(ITT_REQ_CODE, 16, ' ')
    || -- 2.2
    RPAD(decode(ORIG_CARGO_HANDLER,'CPCT','CPA',ORIG_CARGO_HANDLER), 3, ' ')
    || --  2.3
    RPAD(decode(DEST_CARGO_HANDLER,'HACTL','ST1',DEST_CARGO_HANDLER), 3, ' ')
    || --  2.4
    NVL(ITT_CONFIRM_DENY_IND,'N')
    || --  2.4
    NVL(DC_IND, 'N')
    || -- 2.5
    LPAD(
    (SELECT NVL(COUNT(1), 0)
    FROM CST_ITT_DTL
    WHERE itt_req_Code = CST_ITT_HD.ITT_REQ_CODE
    ), 5, '0') --  2.6
  INTO S_CONS_HEADER
  FROM CST_ITT_HD
  WHERE ITT_REQ_CODE = V_ITT_REQ_CODE
  AND ROWNUM         = 1;
  IF NOT INSERT_CST_CSGNM('', CHEADER) THEN
    S_ERROR_MSG := SUBSTR(SQLCODE || SQLERRM, 1, 100);
    RETURN FALSE;
  END IF;
  RETURN TRUE;
EXCEPTION
WHEN NO_DATA_FOUND THEN
  S_ERROR_MSG := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
WHEN TOO_MANY_ROWS THEN
  S_ERROR_MSG := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
WHEN OTHERS THEN
  S_ERROR_MSG := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
END;
/*******************  GET_HDR_INFO_ITF END HERE     *****************/
/*******************  GET_HDR_INFO_ITC START HERE     *****************/
FUNCTION GET_HDR_INFO_ITC
  RETURN BOOLEAN
IS
BEGIN
  SELECT TO_CHAR(ITT_REQ_DATE, 'YYYYMMDD'),   
    LPAD(ITT_REQ_CODE, 16, ' ')
    || -- 2.2
    RPAD(decode(ORIG_CARGO_HANDLER,'CPCT','CPA',ORIG_CARGO_HANDLER), 3, ' ')
    || --  2.3
    RPAD(decode(DEST_CARGO_HANDLER,'HACTL','ST1',DEST_CARGO_HANDLER), 3, ' ')
    || --  2.4    
    NVL(DC_IND, 'N')
    || -- 2.5
    LPAD(
    (SELECT NVL(COUNT(1), 0)
    FROM CST_ITT_DTL
    WHERE (itt_req_no     = CST_ITT_HD.itt_req_no
    AND ITT_REQ_DATE = CST_ITT_HD.ITT_REQ_DATE)
    or itt_req_Code = CST_ITT_HD.ITT_REQ_CODE
    ), 5, '0') --  2.6
  INTO S_ITT_REQ_DATE,
    S_CONS_HEADER
  FROM CST_ITT_HD
  WHERE 
   ((itt_req_no     = v_itt_req_no
    AND ITT_REQ_DATE = V_ITT_REQ_DATE)
  OR ITT_REQ_CODE = V_ITT_REQ_CODE)
  AND ROWNUM         = 1;
  IF NOT INSERT_CST_CSGNM('', CHEADER) THEN
    S_ERROR_MSG := SUBSTR(SQLCODE || SQLERRM, 1, 100);
    RETURN FALSE;
  END IF;
  RETURN TRUE;
EXCEPTION
WHEN NO_DATA_FOUND THEN
  S_ERROR_MSG := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
WHEN TOO_MANY_ROWS THEN
  S_ERROR_MSG := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
WHEN OTHERS THEN
  S_ERROR_MSG := SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN FALSE;
END;
/*******************  GET_HDR_INFO_ITC END HERE     *****************/
/********************SET_AWB_VALUES_ITT STARTS ****************/
FUNCTION SET_AWB_VALUES_ITT
  RETURN BOOLEAN
IS
BEGIN
  DBMS_OUTPUT.PUT_LINE('SET_AWB_VALUES_ITT 11 LENGTH(S_CONS_DETAIL) - ' || LENGTH(S_CONS_DETAIL));
  S_AWB_TYPE := 'I';
  BEGIN
    SELECT 
      ITT_CTM_REF_NO,
      TO_CHAR(DTL.FLT_DATE, 'YYYYMMDD'),
      DTL.FLT_KEY,
      DTL.CARR_CODE,
      DTL.FLT_NO,     
      DTL.PCS,
      DTL.WT,
      DTL.ORIG,
      DTL.DEST,
	    DTL.CONTENT 
    INTO S_CTM_REF_NO,
      Z_FLT_DATE,
      V_FLT_KEY,
      V_FLT_CARR,
      V_FLT_NO,      
      S_AWB_MANF_PCS,
      S_AWB_MANF_WT ,
      S_AWB_ORIGIN,
      S_AWB_DEST ,
      S_CONTENT
    FROM CST_ITT_HD HD
    JOIN CST_ITT_DTL DTL
    ON ((HD.ITT_REQ_NO    = DTL.ITT_REQ_NO and HD.ITT_REQ_DATE    = DTL.ITT_REQ_DATE)
    or HD.ITT_REQ_CODE    = DTL.ITT_REQ_CODE)
    WHERE (HD.ITT_REQ_NO = V_ITT_REQ_NO and HD.ITT_REQ_DATE = V_ITT_REQ_DATE) 
    AND DTL.AWB_NO        = V_AWB_NO
    AND DTL.AWB_DATE          = V_AWB_DATE
    AND DTL.FLT_KEY           = V_FLT_KEY
    AND DTL.FLT_DATE          = V_FLT_DATE;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('SET_AWB_VALUES_ITT 66  - ' || SUBSTR(SQLCODE || SQLERRM, 1, 100));
    RETURN FALSE;
  END;
  RETURN TRUE;
END;
/********************SET_AWB_VALUES_ITT ENDS ****************/
/********************SET_AWB_VALUES_ITF STARTS ****************/
FUNCTION SET_AWB_VALUES_ITF
  RETURN BOOLEAN
IS
BEGIN
  DBMS_OUTPUT.PUT_LINE('SET_AWB_VALUES_ITF 11 LENGTH(S_CONS_DETAIL) - ' || LENGTH(S_CONS_DETAIL));
  S_AWB_TYPE := 'I';
  BEGIN
    SELECT ITT_CTM_REF_NO,
      TO_CHAR(DTL.FLT_DATE, 'YYYYMMDD'),
      DTL.FLT_KEY,
      DTL.CARR_CODE,
      DTL.FLT_NO,
      DTL.AWB_NO
    INTO S_CTM_REF_NO,
      Z_FLT_DATE,
      V_FLT_KEY,
      V_FLT_CARR,
      V_FLT_NO,
      V_AWB_NO
    FROM CST_ITT_HD HD
    JOIN CST_ITT_DTL DTL
    ON ((HD.ITT_REQ_NO    = DTL.ITT_REQ_NO and HD.ITT_REQ_DATE    = DTL.ITT_REQ_DATE)
    or HD.ITT_REQ_CODE    = DTL.ITT_REQ_CODE)
    WHERE ((HD.ITT_REQ_NO = V_ITT_REQ_NO and HD.ITT_REQ_DATE = V_ITT_REQ_DATE)
    or HD.ITT_REQ_CODE    = V_ITT_REQ_CODE)
    AND DTL.AWB_NO        = V_AWB_NO
    AND ROWNUM            = 1;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('SET_AWB_VALUES_ITF 66  - ' || SUBSTR(SQLCODE || SQLERRM, 1, 100));
    RETURN FALSE;
  END;
  RETURN TRUE;
END;
/********************SET_AWB_VALUES_ITF ENDS ****************/
/********************CONSTRUCT_ITF_DTL START ****************/
FUNCTION CONSTRUCT_ITF_DTL
  RETURN BOOLEAN
IS
BEGIN
  S_LOOP_CNT := S_LOOP_CNT + 1;
  --  V_FLT_CARR, V_FLT_NO, S_AWB_MANF_PCS, S_AWB_MANF_WT , S_AWB_ORIGIN, S_AWB_DEST  , S_CTM_REF_NO, S_DC_IND, S_CONTENT
  BEGIN
--    IF S_CNSL_IND    = 'N' THEN
      S_CONS_DETAIL := LPAD(V_ITT_REQ_CODE, 16, '0')||        -- 16
      LPAD(S_LOOP_CNT, 5, '0') ||                             -- 21
      RPAD(S_CTM_REF_NO, 12, ' ') ||                          -- 33
      Z_FLT_DATE ||                                           -- 41
      RPAD(V_FLT_KEY, 9, ' ') ||                              -- 50
      SUBSTR(V_AWB_NO, 1, 3) || '-' || SUBSTR(V_AWB_NO, 4) || -- 62
      RPAD('0', 18, '0');                                     -- 80
--    ELSIF S_CNSL_IND      = 'Y' THEN
--      S_CONS_HAWB_DETAIL := LPAD(V_ITT_REQ_CODE, 16, '0')||   -- 16
--      LPAD(S_LOOP_CNT, 5, '0') ||                             -- 21
--      RPAD(S_CTM_REF_NO, 12, ' ') ||                          -- 33
--      Z_FLT_DATE ||                                           -- 41
--      RPAD(V_FLT_KEY, 9, ' ') ||                              -- 50
--      SUBSTR(V_AWB_NO, 1, 3) || '-' || SUBSTR(V_AWB_NO, 4) || -- 62
--      RPAD(V_HAWB_NO, 18, ' ') ;                              -- 80
--    END IF;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN FALSE;
  END;
  DBMS_OUTPUT.PUT_LINE('CONSTRUCT_ITF_DTL -- LENGTH(S_CONS_DETAIL)-- ' || LENGTH(S_CONS_DETAIL) || ' ---S_CONS_DETAIL- ' || S_CONS_DETAIL);
  RETURN TRUE;
END;
/******************CONSTRUCT_ITF_DTL END******************/
/********************CONSTRUCT_ITT_DTL START ****************/
FUNCTION CONSTRUCT_ITT_DTL
  RETURN BOOLEAN
IS
BEGIN
  S_LOOP_CNT := S_LOOP_CNT + 1;
  --  V_FLT_CARR, V_FLT_NO, S_AWB_MANF_PCS, S_AWB_MANF_WT , S_AWB_ORIGIN, S_AWB_DEST  , S_CTM_REF_NO, S_DC_IND, S_CONTENT
  BEGIN
--    IF S_CNSL_IND    = 'N' THEN
      S_CONS_DETAIL := S_ITT_REQ_DATE ||    -- 8
      LPAD(V_itt_req_no, 3, '0') ||                              -- 11
      LPAD(S_LOOP_CNT, 5, '0') ||                                -- 16
      RPAD(S_CTM_REF_NO, 12, ' ') ||                             -- 28
      TO_CHAR(V_FLT_DATE, 'YYYYMMDD') ||                         -- 36
      RPAD(V_FLT_KEY, 9, ' ') ||                                 -- 45
      SUBSTR(V_AWB_NO, 1, 3) || '-' || SUBSTR(V_AWB_NO, 4) ||    -- 57
      RPAD('0', 18, '0') ||                                      -- 75
      RPAD(S_AWB_ORIGIN, 3, ' ') ||                              -- 78
      RPAD(S_AWB_DEST, 3, ' ') ||                                -- 81
      LPAD(S_AWB_MANF_PCS, 6, '0') ||                            -- 87
      LPAD(TRIM(TO_CHAR(S_AWB_MANF_WT, '9999999.0')), 9, '0') || -- 96
      RPAD(NVL(S_CONTENT, ' '), 265, ' ') ||                     -- 361
      RPAD(NVL(S_CNSL_IND, 'N'), 1, ' ') ||                      -- 362
      'CPA'||                                                    -- 365
      RPAD(' ', 17, ' ');                                        -- || -- 382
--    ELSIF S_CNSL_IND      = 'Y' THEN
--            S_CONS_HAWB_DETAIL := S_ITT_REQ_DATE ||                       -- 8
--            LPAD(V_itt_req_no, 3, '0') ||                                 -- 11
--            LPAD(S_LOOP_CNT, 5, '0') ||                                   -- 16
--            RPAD(nvl(S_CTM_REF_NO,'NC'), 12, ' ') |_NO, 4) ||       -- 57
--            RPAD(V_HAWB_NO, 18, ' ') ||             |                                -- 28
--            TO_CHAR(V_FLT_DATE, 'YYYYMMDD') ||                            -- 36
--            RPAD(V_FLT_KEY, 9, ' ') ||                                    -- 45
--            SUBSTR(V_AWB_NO, 1, 3) || '-' || SUBSTR(V_AWB                      -- 75
--            RPAD(S_HAWB_ORIGIN, 3, ' ') ||                                -- 78
--            RPAD(S_HAWB_DEST, 3, ' ') ||                                  -- 81
--            LPAD(S_HAWB_MANF_PCS, 6, '0') ||                              -- 87
--            LPAD(TRIM(TO_CHAR(S_HAWB_MANF_WT, '9999999.0')), 9, '0') ||   -- 96
--            RPAD(NVL(S_HAWB_CONTENT, ' '), 265, ' ') ||                   -- 361
--            RPAD(NVL(S_CNSL_IND, 'Y'), 1, ' ') ||                         -- 362
--            'CPA'||                                                       -- 365
--            RPAD(' ', 17, ' ');                                           -- || -- 382
--    END IF;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RETURN FALSE;
  END;
  DBMS_OUTPUT.PUT_LINE('CONSTRUCT_ITT_DTL -- LENGTH(S_CONS_DETAIL)-- ' || LENGTH(S_CONS_DETAIL) || ' ---S_CONS_DETAIL- ' || S_CONS_DETAIL);
  RETURN TRUE;
END;
/******************CONSTRUCT_ITT_DTL END******************/
/******************VALIDATE_MSGS_ITT START******************/
FUNCTION VALIDATE_MSGS_ITT
  RETURN BOOLEAN
IS
  S_MSG_LENGTH NUMBER;
BEGIN
--  IF S_CNSL_IND = 'N' THEN
    --MESSAGE VAILDATION START
    S_MSG_LENGTH := LENGTH(S_CONS_DETAIL);
    DBMS_OUTPUT.PUT_LINE('VALIDATE_MSGS_INA ---S_MSG_LENGTH...' || S_MSG_LENGTH || '....' || CDETAIL);
--  ELSIF S_CNSL_IND = 'Y' THEN
    --MESSAGE VAILDATION START
--    S_MSG_LENGTH := LENGTH(S_CONS_HAWB_DETAIL);
--    DBMS_OUTPUT.PUT_LINE('VALIDATE_MSGS_INA ---S_MSG_LENGTH...' || S_MSG_LENGTH || '....' || CDETAIL);
--  END IF;
  IF S_ITT_TYPE       = 'ITT' THEN
    IF S_MSG_LENGTH is null OR S_MSG_LENGTH <> 382 THEN
      S_CMS3_ERROR  := 'ITT - ' || V_AWB_NO || C_AWB_00009 || S_MSG_LENGTH;
      RETURN FALSE;
    END IF;
  ELSIF S_ITT_TYPE  = 'ITF' OR S_ITT_TYPE    = 'ITC' THEN
    IF S_MSG_LENGTH is null OR S_MSG_LENGTH <> 80 THEN
      S_CMS3_ERROR  := S_ITT_TYPE || ' - ' || V_AWB_NO || C_AWB_00009 || S_MSG_LENGTH;
      RETURN FALSE;
    END IF;
  END IF;
  DBMS_OUTPUT.PUT_LINE('VALIDATE_MSGS_ITT --- END... : ');
  RETURN TRUE;
END;
/********************VALIDATE_MSGS_ITT END******************/
/********************SET_DTL_HAWB_ITT STARTS ****************/
FUNCTION SET_DTL_HAWB_ITT
  RETURN BOOLEAN
IS
BEGIN
  FOR C_HAWB IN
  (SELECT DTL.HAWB_NO HAWB_NO
  FROM EDI_FHL HD,
    EDI_FHL_HAWB DTL
  WHERE HD.TR_NO = DTL.TR_NO
  AND AWB_NO     = V_AWB_NO
  AND AWB_DATE   = V_AWB_DATE
  )
  LOOP
    DBMS_OUTPUT.PUT_LINE('SET_DTL_HAWB_ITT 1');
    V_HAWB_NO := C_HAWB.HAWB_NO;
    DBMS_OUTPUT.PUT_LINE('SET_DTL_HAWB_ITT 1 - V_HAWB_NO - ' || V_HAWB_NO);
    BEGIN
      SELECT HAWB_PCS,
        HAWB_NET_WT,
        HAWB_ORG,
        HAWB_DEST,
        MANIFEST_DESC
      INTO S_HAWB_MANF_PCS,
        S_HAWB_MANF_WT ,
        S_HAWB_ORIGIN,
        S_HAWB_DEST ,
        S_HAWB_CONTENT
      FROM EDI_FHL HD,
        EDI_FHL_HAWB DTL
      WHERE HD.TR_NO = DTL.TR_NO
      AND AWB_NO     = V_AWB_NO
      AND AWB_DATE   = V_AWB_DATE
      AND HAWB_NO    = C_HAWB.HAWB_NO;
      DBMS_OUTPUT.PUT_LINE('SET_DTL_HAWB_ITT 2 -  - ');
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN FALSE;
    END;
    --  START S_CONS_HAWB_DETAIL 2 FOR HAWB
    S_CONS_HAWB_DETAIL := '';
    IF NOT CONSTRUCT_ITT_DTL THEN
      DBMS_OUTPUT.PUT_LINE('SET_DTL_HAWB_ITT 2 -  SUBSTR(SQLCODE || SQLERRM,   1,   1000) - ' || SUBSTR(SQLCODE || SQLERRM, 1, 1000));
      RETURN FALSE;
    END IF;
    IF NOT VALIDATE_MSGS_ITT THEN
      RETURN FALSE;
    END IF;
    IF NOT INSERT_CST_CSGNM(V_HAWB_NO, CDETAIL) THEN
      S_CMS3_ERROR := 'CST_204';
      RETURN FALSE;
    END IF;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('SET_DTL_HAWB_ITT 99');
  RETURN TRUE;
END;
/********************SET_DTL_HAWB_ITT ENDS ****************/
/********************SET_DTL_HAWB_ITF STARTS ****************/
FUNCTION SET_DTL_HAWB_ITF
  RETURN BOOLEAN
IS
BEGIN
  FOR C_HAWB IN
  (SELECT dtl.hawb_NO 
  FROM CST_ITT_HD HD
  JOIN CST_ITT_DTL DTL
  ON ((HD.ITT_REQ_NO    = DTL.ITT_REQ_NO and HD.ITT_REQ_DATE    = DTL.ITT_REQ_DATE) or HD.ITT_REQ_CODE    = DTL.ITT_REQ_CODE)
  WHERE HD.ITT_REQ_CODE = V_ITT_REQ_CODE
  AND DTL.AWB_NO        = V_AWB_NO
  )
  LOOP
    DBMS_OUTPUT.PUT_LINE('SET_DTL_HAWB_ITF 1');
--    V_HAWB_NO := C_HAWB.HAWB_NO;
    DBMS_OUTPUT.PUT_LINE('SET_DTL_HAWB_ITF 1 - V_HAWB_NO - ' || V_HAWB_NO);
    BEGIN
      SELECT ITT_CTM_REF_NO,
        TO_CHAR(DTL.FLT_DATE, 'YYYYMMDD'),
        DTL.FLT_KEY,
        DTL.CARR_CODE,
        DTL.FLT_NO,
        DTL.AWB_NO,
        dtl.hawb_NO
      INTO S_CTM_REF_NO,
        V_FLT_DATE,
        V_FLT_KEY,
        V_FLT_CARR,
        V_FLT_NO,
        V_AWB_NO,
        V_HAWB_NO
      FROM CST_ITT_HD HD
      JOIN CST_ITT_DTL DTL
      ON ((HD.ITT_REQ_NO    = DTL.ITT_REQ_NO and HD.ITT_REQ_DATE    = DTL.ITT_REQ_DATE) or HD.ITT_REQ_CODE    = DTL.ITT_REQ_CODE)
      WHERE  ((HD.ITT_REQ_NO = V_ITT_REQ_NO and  HD.ITT_REQ_DATE = V_ITT_REQ_DATE)
      OR HD.ITT_REQ_CODE = V_ITT_REQ_CODE)
      AND DTL.AWB_NO        = V_AWB_NO
      AND dtl.hawb_NO       = DTL.hawb_NO;
      DBMS_OUTPUT.PUT_LINE('SET_DTL_HAWB_ITF 2 -  - ');
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RETURN FALSE;
    END;
    --  START S_CONS_HAWB_DETAIL 2 - FOR HAWB
    S_CONS_HAWB_DETAIL := '';
    IF NOT CONSTRUCT_ITF_DTL THEN
      DBMS_OUTPUT.PUT_LINE('SET_DTL_HAWB_ITF 2 -  SUBSTR(SQLCODE || SQLERRM,   1,   1000) - ' || SUBSTR(SQLCODE || SQLERRM, 1, 1000));
      RETURN FALSE;
    END IF;
    IF NOT VALIDATE_MSGS_ITT THEN
      RETURN FALSE;
    END IF;
    IF NOT INSERT_CST_CSGNM(V_HAWB_NO, CDETAIL) THEN
      S_CMS3_ERROR := 'CST_204';
      RETURN FALSE;
    END IF;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('SET_DTL_HAWB_ITF 99');
  RETURN TRUE;
END;
/********************SET_DTL_HAWB_ITF ENDS ****************/
/********************MSG_AWB_ITT STARTS ****************/
FUNCTION MSG_AWB_ITT
  RETURN BOOLEAN
IS
BEGIN
  DBMS_OUTPUT.PUT_LINE('MSG_AWB_ITT 11  LENGTH(S_CONS_DETAIL)-- ' || LENGTH(S_CONS_DETAIL));
  DBMS_OUTPUT.PUT_LINE('MSG_AWB_ITT 11  S_CONS_DETAIL-- ' || S_CONS_DETAIL);
  IF S_ITT_TYPE = 'ITT' THEN
    IF NOT CONSTRUCT_ITT_DTL THEN
      DBMS_OUTPUT.PUT_LINE('MSG_AWB_ITT 33  - ' || SUBSTR(SQLCODE || SQLERRM, 1, 100));
      RETURN FALSE;
    END IF;
  ELSIF S_ITT_TYPE = 'ITF' OR  S_ITT_TYPE = 'ITC' THEN
    IF NOT CONSTRUCT_ITF_DTL THEN
      DBMS_OUTPUT.PUT_LINE('MSG_AWB_ITT 33  - ' || SUBSTR(SQLCODE || SQLERRM, 1, 100));
      RETURN FALSE;
    END IF;
  END IF;
  IF NOT VALIDATE_MSGS_ITT THEN
    DBMS_OUTPUT.PUT_LINE('MSG_AWB_ITT 44  - ' || SUBSTR(SQLCODE || SQLERRM, 1, 100));
    RETURN FALSE;
  END IF;
  IF NOT INSERT_CST_CSGNM(LPAD('0', 18, '0'), CDETAIL) THEN
    S_CMS3_ERROR := 'CST_204';
    DBMS_OUTPUT.PUT_LINE('MSG_AWB_ITT 55  - ' || SUBSTR(SQLCODE || SQLERRM, 1, 100));
    RETURN FALSE;
  END IF;
  RETURN TRUE;
END;
/********************MSG_AWB_ITT ENDS ****************/
/******************GET_DTL_INFO_ITT START******************/
FUNCTION GET_DTL_INFO_ITT
  RETURN BOOLEAN
IS
  C_AWB CST_SUBMIT_TEMP % ROWTYPE;
  V_CNT        NUMBER;
  V_LOOP_CNT   NUMBER;
  S_MSG_LENGTH NUMBER;
  CURSOR CUR_AWB
  IS
    SELECT *
    FROM CST_SUBMIT_TEMP
    WHERE VER_NO  = V_itt_req_no
    AND CTRL_DATE = V_ITT_REQ_DATE;
BEGIN
  --CHECK WHETHER THE AWB MESSAGE EXISTS OR NOT
  IF CUR_AWB % ISOPEN THEN
    CLOSE CUR_AWB;
  END IF;
  V_LOOP_CNT := 0;
  FOR I IN CUR_AWB
  LOOP
    INIT_ITT_DTL ;
    V_LOOP_CNT := V_LOOP_CNT + 1;
    DBMS_OUTPUT.PUT_LINE('GET_DTL_INFO_ITT CLOSE CUSRSOR V_LOOP_CNT - ' || V_LOOP_CNT);
    IF CUR_AWB % NOTFOUND THEN
      S_CMS3_ERROR := C_AWB_00011;
      RETURN FALSE;
    END IF;
    DBMS_OUTPUT.PUT_LINE('GET_DTL_INFO_ITT -- I.AWB_NO -- ' || I.AWB_NO);
    V_AWB_NO   := I.AWB_NO;
    V_FLT_KEY  := I.FLT_KEY;
    V_FLT_DATE := I.FLT_DATE;
    V_AWB_Date := PKG_IMP.FUN_GET_AWBDATE_CREATE(V_AWB_NO,V_FLT_KEY,V_FLT_DATE,'N');
    DBMS_OUTPUT.PUT_LINE('GET_DTL_INFO_ITT 55');
    IF NOT SET_AWB_VALUES_ITT THEN
      RETURN FALSE;
    END IF;
    IF NOT SET_CNSL_IND THEN
      RETURN FALSE;
    END IF;
--    IF S_CNSL_IND = 'Y' THEN
--      IF NOT SET_DTL_HAWB_ITT THEN
--        RETURN FALSE;
--      END IF;
--    ELSIF S_CNSL_IND = 'N' THEN
      DBMS_OUTPUT.PUT_LINE('GET_DTL_INFO_INA 77  S_CNSL_IND-- ');
      IF NOT MSG_AWB_ITT THEN
        RETURN FALSE;
      END IF;
--    END IF;
  END LOOP;
  RETURN TRUE;
END;
/********************GET_DTL_INFO_ITT END******************/
/******************GET_DTL_INFO_ITF START******************/
FUNCTION GET_DTL_INFO_ITF
  RETURN BOOLEAN
IS
  C_AWB CST_SUBMIT_TEMP % ROWTYPE;
  V_CNT        NUMBER;
  V_LOOP_CNT   NUMBER;
  S_MSG_LENGTH NUMBER;
  CURSOR CUR_AWB
  IS
    SELECT * FROM CST_SUBMIT_TEMP WHERE (ver_no = V_ITT_REQ_NO and ctrl_date = V_ITT_REQ_DATE) OR  ITT_REQ_CODE = V_ITT_REQ_CODE;
BEGIN
  --CHECK WHETHER THE AWB MESSAGE EXISTS OR NOT
  IF CUR_AWB % ISOPEN THEN
    CLOSE CUR_AWB;
  END IF;
  V_LOOP_CNT := 0;
  FOR I IN CUR_AWB
  LOOP
    INIT_ITT_DTL ;
    V_LOOP_CNT := V_LOOP_CNT + 1;
    DBMS_OUTPUT.PUT_LINE('GET_DTL_INFO_ITF CLOSE CUSRSOR V_LOOP_CNT - ' || V_LOOP_CNT);
    IF CUR_AWB % NOTFOUND THEN
      S_CMS3_ERROR := C_AWB_00011;
      RETURN FALSE;
    END IF;
    DBMS_OUTPUT.PUT_LINE('GET_DTL_INFO_ITF -- I.AWB_NO -- ' || I.AWB_NO);
    V_AWB_NO := I.AWB_NO;
    DBMS_OUTPUT.PUT_LINE('GET_DTL_INFO_ITF 55');
    IF NOT SET_CNSL_IND_ITF THEN
      RETURN FALSE;
    END IF;
    IF NOT SET_AWB_VALUES_ITF THEN
      RETURN FALSE;
    END IF;
--    IF S_CNSL_IND = 'Y' THEN
--      IF NOT SET_DTL_HAWB_ITF THEN
--        RETURN FALSE;
--      END IF;
--    ELSIF S_CNSL_IND = 'N' THEN
      DBMS_OUTPUT.PUT_LINE('GET_DTL_INFO_INA 77  S_CNSL_IND-- ');
      IF NOT MSG_AWB_ITT THEN
        RETURN FALSE;
      END IF;
--    END IF;
  END LOOP;
  RETURN TRUE;
END;
/********************GET_DTL_INFO_ITF END******************/
/********************GET_FTR_INFO STARTS ****************/
FUNCTION GET_FTR_INFO
  RETURN BOOLEAN
IS
BEGIN
  DBMS_OUTPUT.PUT_LINE('GET_FTR_INFO  11 S_CONS_FOOTER -  ' || S_CONS_FOOTER);
  --  START
  IF S_ITT_TYPE     = 'ITT' THEN
    S_CONS_FOOTER := S_ITT_REQ_DATE || lPAD(V_itt_req_no, 3, '0') || --2.1
    'C';
  ELSIF S_ITT_TYPE  = 'ITF'  THEN
    S_CONS_FOOTER := RPAD(V_ITT_REQ_CODE, 16, ' ') || --2.1
    'C';
  ELSIF S_ITT_TYPE  = 'ITC' THEN
    S_CONS_FOOTER := RPAD(V_ITT_REQ_CODE, 16, ' ') || --2.1
    'C';
  END IF;
  -- 4.1.1.3 END
  DBMS_OUTPUT.PUT_LINE('GET_FTR_INFO  22 S_CONS_FOOTER -  ' || S_CONS_FOOTER);
  DBMS_OUTPUT.PUT_LINE('GET_FTR_INFO  22 S_CONS_FOOTER -  ' || S_ITT_REQ_DATE || lPAD(V_itt_req_no, 8, '0') || 'C');
  RETURN INSERT_CST_CSGNM(' ', CFOOTER);
END;
/********************GET_FTR_INFO ENDS ****************/
/********************* SUBMIT_ACCS_ITT START HERE **************************/
FUNCTION SUBMIT_ACCS_ITT(
    P_ITT_REQ_DATE IN DATE,
    P_itt_req_no       IN NUMBER,
    P_ITT_REQ_CODE IN VARCHAR2)
  RETURN VARCHAR2
IS
  B_RESULT BOOLEAN;
BEGIN
  INIT;
  S_CMS3_ERROR   := NULL;
  V_itt_req_no       := P_itt_req_no;
  V_ITT_REQ_DATE := P_ITT_REQ_DATE;
  V_ITT_REQ_CODE := P_ITT_REQ_CODE;
  IF NOT GET_itt_req_no THEN
    RETURN C_FLT_00003;
  END IF;
  DBMS_OUTPUT.PUT_LINE('SUBMIT_ACCS_ITT START FOR P_ITT_REQ_DATE - ' || P_ITT_REQ_DATE || ' - P_itt_req_no - ' || P_itt_req_no);
  --GET HEADER INFOMATION
  IF NOT GET_HDR_INFO_ITT THEN
    RETURN S_ERROR_MSG;
  END IF;
  DBMS_OUTPUT.PUT_LINE('SUBMIT_ACCS_ITT  B_RESULT - S_ERROR_MSG -- ' || S_ERROR_MSG);
  --GET DETAIL INFOMATION
  DBMS_OUTPUT.PUT_LINE('SUBMIT_ACCS_ITT S_CONS_DETAIL-- ' || S_CONS_DETAIL);
  IF S_ITT_TYPE = 'ITT' THEN
    B_RESULT   := GET_DTL_INFO_ITT;
  END IF;
  DBMS_OUTPUT.PUT_LINE('SUBMIT_ACCS_ITT B_RESULT-- ' || BOOL_TO_TEXT(B_RESULT));
  IF NOT B_RESULT THEN
    RETURN S_ERROR_MSG;
  END IF;
  --GET FOOTER INFOMATION
  IF NOT GET_FTR_INFO THEN
    S_ERROR_MSG := 'CST_202';
    RETURN S_ERROR_MSG;
  END IF;
  DBMS_OUTPUT.PUT_LINE('888 S_CMS3_ERROR -- ' || S_CMS3_ERROR);
  RETURN 'TRUE';
EXCEPTION
WHEN OTHERS THEN
  S_ERROR_MSG := S_CMS3_ERROR || ' ' || SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN S_ERROR_MSG;
END;
/********************* SUBMIT_ACCS_ITT END HERE   **************************/
/********************* SUBMIT_ACCS_ITF START HERE **************************/
FUNCTION SUBMIT_ACCS_ITF(
    P_ITT_REQ_CODE IN VARCHAR2)
  RETURN VARCHAR2
IS
  B_RESULT BOOLEAN;
BEGIN
  INIT;
  S_CMS3_ERROR   := NULL;

  V_ITT_REQ_CODE := P_ITT_REQ_CODE;
  IF NOT GET_itf_req_code THEN
    RETURN C_FLT_00003;
  END IF;
  --GET HEADER INFOMATION
  IF NOT GET_HDR_INFO_ITF THEN
    RETURN S_ERROR_MSG;
  END IF;
  DBMS_OUTPUT.PUT_LINE('SUBMIT_ACCS_ITF  B_RESULT - S_ERROR_MSG -- ' || S_ERROR_MSG);
  --GET DETAIL INFOMATION
  DBMS_OUTPUT.PUT_LINE('SUBMIT_ACCS_ITF S_CONS_DETAIL-- ' || S_CONS_DETAIL);
  IF S_ITT_TYPE = 'ITF' THEN
    B_RESULT   := GET_DTL_INFO_ITF;
  END IF;
  DBMS_OUTPUT.PUT_LINE('SUBMIT_ACCS_ITF B_RESULT-- ' || BOOL_TO_TEXT(B_RESULT));
  IF NOT B_RESULT THEN
    RETURN S_ERROR_MSG;
  END IF;
  --GET FOOTER INFOMATION
  IF NOT GET_FTR_INFO THEN
    S_ERROR_MSG := 'CST_202';
    RETURN S_ERROR_MSG;
  END IF;
  DBMS_OUTPUT.PUT_LINE('888 S_CMS3_ERROR -- ' || S_CMS3_ERROR);
  RETURN 'TRUE';
EXCEPTION
WHEN OTHERS THEN
  S_ERROR_MSG := S_CMS3_ERROR || ' ' || SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN S_ERROR_MSG;
END;
/********************* SUBMIT_ACCS_ITF END HERE   **************************/
/********************* SUBMIT_ACCS_ITC START HERE **************************/
FUNCTION SUBMIT_ACCS_ITC(
    P_ITT_REQ_DATE IN DATE,
    P_itt_req_no       IN VARCHAR2,
    P_ITT_REQ_CODE IN VARCHAR2)
  RETURN VARCHAR2
IS
  B_RESULT BOOLEAN;
BEGIN
  INIT;
  S_CMS3_ERROR   := NULL;
   V_itt_req_no       := P_itt_req_no;
  V_ITT_REQ_DATE := P_ITT_REQ_DATE;
  V_ITT_REQ_CODE := P_ITT_REQ_CODE;
  IF NOT GET_itc_req_code THEN
    RETURN C_FLT_00003;
  END IF;
  --GET HEADER INFOMATION
  IF NOT GET_HDR_INFO_ITC THEN
    RETURN S_ERROR_MSG;
  END IF;
  DBMS_OUTPUT.PUT_LINE('SUBMIT_ACCS_ITC  B_RESULT - S_ERROR_MSG -- ' || S_ERROR_MSG);
  --GET DETAIL INFOMATION
  DBMS_OUTPUT.PUT_LINE('SUBMIT_ACCS_ITC S_CONS_DETAIL-- ' || S_CONS_DETAIL);
  IF S_ITT_TYPE = 'ITC' THEN
    B_RESULT   := GET_DTL_INFO_ITF;
  END IF;
  DBMS_OUTPUT.PUT_LINE('SUBMIT_ACCS_ITC B_RESULT-- ' || BOOL_TO_TEXT(B_RESULT));
  IF NOT B_RESULT THEN
    RETURN S_ERROR_MSG;
  END IF;
  --GET FOOTER INFOMATION
  IF NOT GET_FTR_INFO THEN
    S_ERROR_MSG := 'CST_202';
    RETURN S_ERROR_MSG;
  END IF;
  DBMS_OUTPUT.PUT_LINE('888 S_CMS3_ERROR -- ' || S_CMS3_ERROR);
  RETURN 'TRUE';
EXCEPTION
WHEN OTHERS THEN
  S_ERROR_MSG := S_CMS3_ERROR || ' ' || SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN S_ERROR_MSG;
END;
/********************* SUBMIT_ACCS_ITC END HERE   **************************/
/********************* ITT_SUBMIT_REQ START HERE    **************************/
FUNCTION ITT_SUBMIT_REQ(
    P_ITT_REQ_DATE IN DATE,
    P_itt_req_no       IN VARCHAR2,
    P_USER_ID      IN VARCHAR2,
    P_LM_DATE      IN DATE )
  RETURN VARCHAR2
IS
  V_RET VARCHAR2(200);
BEGIN
  DBMS_OUTPUT.PUT_LINE('ITT_SUBMIT_REQ START FOR P_ITT_REQ_DATE - ' || P_ITT_REQ_DATE || ' - P_itt_req_no - ' || P_itt_req_no || ' - P_USER_ID - ' || P_USER_ID || ' - P_LM_DATE - ' || P_LM_DATE);
  S_ITT_TYPE := 'ITT';
  S_USER_ID  := P_USER_ID;
  S_LM_DATE  := P_LM_DATE;
  V_RET      := SUBMIT_ACCS_ITT(P_ITT_REQ_DATE, P_itt_req_no, NULL);
  DBMS_OUTPUT.PUT_LINE('END V_RET - ' || V_RET);
  RETURN V_RET;
EXCEPTION
WHEN OTHERS THEN
  S_ERROR_MSG := S_CMS3_ERROR || ' ' || SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN S_ERROR_MSG;
END;
/********************* ITT_SUBMIT_REQ END HERE    **************************/
/********************* ITT_CONFIRM_REQ START HERE    **************************/
FUNCTION ITT_CONFIRM_REQ(
    P_ITT_REQ_CODE IN VARCHAR2,
    P_USER_ID      IN VARCHAR2,
    P_LM_DATE      IN DATE )
  RETURN VARCHAR2
IS
  V_RET VARCHAR2(200);
BEGIN
  DBMS_OUTPUT.PUT_LINE('START FOR P_ITT_REQ_CODE - ' || P_ITT_REQ_CODE || P_USER_ID || ' - P_USER_ID - ' || ' - P_LM_DATE - ' || P_LM_DATE);
  S_ITT_TYPE := 'ITF';
  S_USER_ID  := P_USER_ID;
  S_LM_DATE  := P_LM_DATE;
  V_RET      := SUBMIT_ACCS_ITF(P_ITT_REQ_CODE);
  DBMS_OUTPUT.PUT_LINE('END V_RET - ' || V_RET);
  RETURN V_RET;
EXCEPTION
WHEN OTHERS THEN
  S_ERROR_MSG := S_CMS3_ERROR || ' ' || SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN S_ERROR_MSG;
END;
/********************* ITT_CONFIRM_REQ END HERE    **************************/
/********************* ITT_CANCEL_REQ START HERE    **************************/
FUNCTION ITT_CANCEL_REQ(
     P_ITT_REQ_DATE IN DATE,
    P_itt_req_no       IN VARCHAR2,
    P_ITT_REQ_CODE IN VARCHAR2,
    P_USER_ID      IN VARCHAR2,
    P_LM_DATE      IN DATE )
  RETURN VARCHAR2
IS
  V_RET VARCHAR2(200);
BEGIN
  DBMS_OUTPUT.PUT_LINE('START FOR P_ITT_REQ_CODE - ' || P_ITT_REQ_CODE || P_USER_ID || ' - P_USER_ID - ' || ' - P_LM_DATE - ' || P_LM_DATE);
  S_ITT_TYPE := 'ITC';
  S_USER_ID  := P_USER_ID;
  S_LM_DATE  := P_LM_DATE;
  V_RET      := SUBMIT_ACCS_ITC(P_ITT_REQ_DATE , P_itt_req_no , P_ITT_REQ_CODE);
  DBMS_OUTPUT.PUT_LINE('END V_RET - ' || V_RET);
  RETURN V_RET;
EXCEPTION
WHEN OTHERS THEN
  S_ERROR_MSG := S_CMS3_ERROR || ' ' || SUBSTR(SQLCODE || SQLERRM, 1, 100);
  RETURN S_ERROR_MSG;
END;
/********************* ITT_CANCEL_REQ END HERE    **************************/
END PKG_CST_EITT;
/
SHOW ERRORS