--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PROCEDURE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT Creating WOSINT.PRO_AUTO_SUBMIT
CREATE OR REPLACE PROCEDURE WOSINT.PRO_AUTO_SUBMIT IS
  CURSOR cc IS
    SELECT *
     FROM CST_SUBM_TEMP
     WHERE processed = 'N' and nvl(trk_flt_ind,'N') <> 'Y'
      AND REC_TYPE IN('INT',   'AMD',   'BDS') 
      OR ( PROCESSED = 'Y' AND  NVL(PROCESSED_CNT,0) < 2 and SUBM_DATE > sysdate-10) -- Submit Two times in failure cases
      AND rownum = 1 
      FOR UPDATE NOWAIT;
  v_ret    VARCHAR2(200);
  p_ver_no NUMBER;
  v_err    VARCHAR2(1000);
  v_sts    VARCHAR2(10);
  rec_subm cc%ROWTYPE;
  V_STFS_FLT_KEY              VARCHAR2(8);
  V_STFS_FLT_DATE             VARCHAR2(10);
  
  
BEGIN



  DBMS_OUTPUT.PUT_LINE('start PRO_AUTO_SUBMIT ');
  
  IF cc%ISOPEN THEN
    CLOSE cc;
  END IF;
  OPEN cc;
  FETCH cc
    INTO rec_subm;
  IF CC%ROWCOUNT = 1 THEN
    UPDATE cst_subm_temp SET processed = 'Y', PROCESSED_CNT = nvl(PROCESSED_CNT,0)+1 WHERE CURRENT OF cc;

    p_ver_no := rec_subm.ver_no;
    
     DBMS_OUTPUT.PUT_LINE('44 INT PRO_AUTO_SUBMIT -- p_ver_no - '||p_ver_no);
    
    v_sts    := fun_check_man(rec_subm.flt_type, rec_subm.flt_key,
                              to_char(rec_subm.flt_date, 'DDMONYY'),
                              rec_subm.rec_type, 'Y');

    IF v_sts IS NULL OR v_sts IN ('R', 'E') THEN
     DBMS_OUTPUT.PUT_LINE('v_sts in INT PRO_AUTO_SUBMIT - n '|| v_sts);
      v_sts := 'N';
    END IF;
    
    -- Insert cst_auto_submit_log sumission status..
    INSERT INTO cst_auto_submit_log
       VALUES
      (REC_SUBM.FLT_KEY || '/' || REC_SUBM.FLT_DATE || ' ' ||
       TO_CHAR(SYSDATE, 'DDMONYY HH24:MI:SS') || 
       ' submit :' || REC_SUBM.REC_TYPE || 
       ' v_sts  : ' || V_STS || 
       ' Line no : 50');
           
    IF v_sts NOT IN ('P', 'W') THEN
      IF v_sts = 'A' AND rec_subm.rec_type = 'INT' THEN
        DELETE FROM cst_submit_temp
         WHERE flt_key = rec_subm.flt_key
           AND flt_date = rec_subm.flt_date
           AND cst_type = rec_subm.rec_type
           AND ver_no = rec_subm.ver_no;
        DELETE FROM cst_subm_temp
         WHERE flt_key = rec_subm.flt_key
           AND flt_date = rec_subm.flt_date
           AND rec_type = rec_subm.rec_type
           AND ver_no = rec_subm.ver_no;
      ELSE
        IF rec_subm.rec_type = 'INT' AND v_sts = 'N' THEN
        
        DBMS_OUTPUT.PUT_LINE('in INT PRO_AUTO_SUBMIT ');
        
        if rec_subm.flt_type = 'E' then
--           DELETE FROM cst_awb a
--           WHERE NOT EXISTS ( SELECT *
--                    FROM exp_pmanifest_awb pman
--                   WHERE pman.flt_key = a.flt_key
--                     AND pman.flt_date = a.flt_date
--                     AND pman.awb_no = a.awb_no)
--             AND a.flt_type = rec_subm.flt_type;
--             
--           DELETE FROM cst_awb a
--           WHERE NOT EXISTS ( SELECT *
--                    FROM exp_pman_tarmac_awb pman
--                   WHERE pman.flt_key = a.flt_key
--                     AND pman.flt_date = a.flt_date
--                     AND pman.awb_no = a.awb_no)
--             AND a.flt_type = rec_subm.flt_type;
            NULL; 
        ELSE
          DELETE FROM cst_awb a
           WHERE NOT EXISTS (SELECT *
                    FROM edi_ffm_msg b, edi_ffm_shp c
                   WHERE b.tr_no = c.tr_no
                     AND b.flt_key = a.flt_key
                     AND b.flt_date = a.flt_date
                     AND c.awb_no = a.awb_no
                     AND b.ffm_status IN ('P', 'F'))
             AND a.flt_type = rec_subm.flt_type;
          END IF;

          UPDATE cst_awb a
             SET a.accs_ind = 'N', a.change_ind = 'A'
           WHERE flt_key = rec_subm.flt_key
             AND flt_date = rec_subm.flt_date
             AND flt_type = rec_subm.flt_type;

        if rec_subm.flt_type != 'E' then
           NULL;
        else 
          DELETE FROM cst_hawb b
           WHERE b.change_ind = 'D' 
             AND EXISTS (SELECT 1
                    FROM cst_awb
                   WHERE flt_key = rec_subm.flt_key
                     AND flt_date = rec_subm.flt_date
                     AND flt_type =rec_subm.flt_type
                     AND awb_no = b.awb_no);
        end if;

          UPDATE cst_hawb b
             SET b.accs_ind = 'N', b.change_ind = 'A'
           WHERE EXISTS (SELECT 1
                    FROM cst_awb
                   WHERE flt_key = rec_subm.flt_key
                     AND flt_date = rec_subm.flt_date
                     AND flt_type = rec_subm.flt_type
                     AND awb_no = b.awb_no);
          DBMS_OUTPUT.PUT_LINE('22 INT PRO_AUTO_SUBMIT -- p_ver_no - '||p_ver_no);
           DBMS_OUTPUT.PUT_LINE('22-1 INT PRO_AUTO_SUBMIT -- flight key,fltdate,flttype - '||rec_subm.flt_key||to_char(rec_subm.flt_date,
                                                                        'DDMONYY')||rec_subm.flt_type);
         
          v_ret := pkg_cst_init.initial_consignment_submission(rec_subm.flt_key,
                                                               to_char(rec_subm.flt_date,
                                                                        'DDMONYY'),
                                                               p_ver_no,
                                                               rec_subm.lm_user_id,
                                                               rec_subm.lm_date,rec_subm.flt_type);
          DBMS_OUTPUT.PUT_LINE('33 Abdul 1INT PRO_AUTO_SUBMIT -- p_ver_no - '||v_ret);                                                               
        ELSIF rec_subm.rec_type = 'AMD' THEN
          v_ret := pkg_cst_init.amend_consignment_submission(rec_subm.flt_key,
                                                             to_char(rec_subm.flt_date,
                                                                      'DDMONYY'),
                                                             p_ver_no,
                                                             rec_subm.lm_user_id,
                                                             rec_subm.lm_date,rec_subm.flt_type);
        ELSIF rec_subm.rec_type = 'BDS' THEN
          v_ret := pkg_cst_init.behind_consignment_submission(rec_subm.flt_key,
                                                              to_char(rec_subm.flt_date,
                                                                       'DDMONYY'),
                                                              p_ver_no,
                                                              rec_subm.lm_user_id,
                                                              rec_subm.lm_date,rec_subm.flt_type);
        ELSE
          NULL;
        END IF;
      DBMS_OUTPUT.PUT_LINE('00 INT PRO_AUTO_SUBMIT -- v_ret - '||v_ret);
       DBMS_OUTPUT.PUT_LINE('1100 INT PRO_AUTO_SUBMIT -- p_ver_no - '||p_ver_no);
   BEGIN
        
      SELECT  stfs_flt_key,stfs_flt_date  INTO V_STFS_FLT_KEY,V_STFS_FLT_DATE from flt_opr   
      where sch_date = rec_subm.flt_date and flt_key=rec_subm.flt_key and flt_type=DECODE(rec_subm.flt_type,'I','A','E','D',rec_subm.flt_type);
         EXCEPTION
              WHEN NO_DATA_FOUND THEN
                V_STFS_FLT_KEY:=NULL;
                V_STFS_FLT_DATE:=NULL;
   END;
--        IF V_STFS_FLT_KEY is not null then
--          rec_subm.no_flt_sfx:='Y';
--        END IF;
         
        IF v_ret = 'TRUE' THEN        
          INSERT INTO cst_subm
            (flt_type, flt_date, flt_key, ver_no, ctrl_date, req_uid,
             msg_type, msg_id, rec_type, subm_date, send_status, send_date,
             bd_complete, lm_user_id, lm_date, lm_ver, err_msg,NO_FLT_SFX)
          VALUES
            (rec_subm.flt_type,NVL(V_STFS_FLT_DATE,rec_subm.flt_date), 
            NVL(V_STFS_FLT_KEY,rec_subm.flt_key),
             p_ver_no, SYSDATE, rec_subm.req_uid, rec_subm.msg_type,
             rec_subm.msg_id, rec_subm.rec_type, rec_subm.subm_date,
             rec_subm.send_status, rec_subm.send_date,
             rec_subm.bd_complete, rec_subm.lm_user_id, rec_subm.lm_date,
             rec_subm.lm_ver, rec_subm.err_msg,rec_subm.no_flt_sfx);
        ELSE
        DBMS_OUTPUT.PUT_LINE('11 INT PRO_AUTO_SUBMIT -- p_ver_no - '||p_ver_no);
        /* Abdul Need to verify */
          INSERT INTO cst_subm
            (flt_type, flt_date, flt_key, ver_no, ctrl_date, req_uid,
             msg_type, msg_id, rec_type, subm_date, send_status, send_date,
             bd_complete, lm_user_id, lm_date, lm_ver, err_msg,NO_FLT_SFX)
          VALUES
            (rec_subm.flt_type,NVL(V_STFS_FLT_DATE,rec_subm.flt_date), 
            NVL(V_STFS_FLT_KEY,rec_subm.flt_key),
             nvl(p_ver_no, 99), rec_subm.ctrl_date, rec_subm.req_uid,
             rec_subm.msg_type, rec_subm.msg_id, rec_subm.rec_type,
             rec_subm.subm_date, 'E', rec_subm.send_date,
             rec_subm.bd_complete, rec_subm.lm_user_id, rec_subm.lm_date,
             rec_subm.lm_ver, nvl(v_ret, 'GENERATING DATA FAILURE'),rec_subm.no_flt_sfx);
        END IF;
        INSERT INTO cst_auto_submit_log
        VALUES
          (REC_SUBM.FLT_KEY || '/' || REC_SUBM.FLT_DATE || ' ' ||
           to_char(SYSDATE, 'DDMONYY HH24:MI:SS') || ' submit :' ||
           rec_subm.rec_type || ' version is ' || p_ver_no);
      END IF;
    END IF;
    DELETE FROM cst_submit_temp
     WHERE flt_key = rec_subm.flt_key
       AND flt_date = rec_subm.flt_date
       AND cst_type = rec_subm.rec_type
       AND cst_type IN('INT',   'AMD',   'BDS') 
       AND ver_no = rec_subm.ver_no
        and flt_key <> 'KA101D';
    DELETE FROM cst_subm_temp
     WHERE flt_key = rec_subm.flt_key
       AND flt_date = rec_subm.flt_date
       AND rec_type = rec_subm.rec_type
       AND rec_type IN('INT',   'AMD',   'BDS') 
       AND ver_no = rec_subm.ver_no
        and flt_key <> 'KA101D';
  END IF;
  CLOSE cc;
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    IF cc%ISOPEN THEN
      CLOSE cc;
    END IF;
    v_err := substr(SQLCODE || SQLERRM, 1, 1000);
    INSERT INTO cst_auto_submit_log
    VALUES
      (to_char(SYSDATE, 'DDMONYY HH24:MI:SS') || ':' || v_err);
END;

/
SHOW ERRORS