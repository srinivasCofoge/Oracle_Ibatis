--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PROCEDURE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT Stopping scheduler job DAILY_TONN_REPT ...

-- Good practice when pasting scripts into SQL*Plus:
SET SQLBLANKLINES ON
SET DEFINE OFF

BEGIN
  DBMS_SCHEDULER.STOP_JOB(
    job_name => 'WOSINT.DAILY_TONN_REPT',
    force    => TRUE
  );
END;
/
