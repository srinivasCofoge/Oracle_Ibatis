--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PACKAGE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT CREATE OR REPLACE PACKAGE WOSINT.PKG_CST_TRUCK_INIT
CREATE OR REPLACE PACKAGE WOSINT.PKG_CST_TRUCK_INIT

   AS
  FUNCTION ina_submission(p_truck_no IN VARCHAR2,   
                                p_sch_date IN VARCHAR2,   
                                p_flt_key IN VARCHAR2,   
                                p_flt_date IN VARCHAR2,   
                                p_sch_time IN VARCHAR2,   
                                p_ver_no IN OUT NUMBER,   
                                p_user_id IN VARCHAR2,   
                                p_lm_date IN DATE) 
  RETURN VARCHAR2;

      FUNCTION AMA_submission(p_truck_no IN VARCHAR2,
                                            p_sch_date IN VARCHAR2,
                                            p_flt_key IN VARCHAR2,
                                            p_flt_date IN VARCHAR2,
                                            p_sch_time IN VARCHAR2,
                                            p_ver_no IN OUT NUMBER,
                                            p_user_id IN VARCHAR2,
                                            p_lm_date IN DATE)
      RETURN VARCHAR2 ;
     
      
      procedure  sub_ins_cst_itm_awb_hawb(p_truck_no IN VARCHAR2,
                                            p_truck_flt_no IN VARCHAR2,
                                            p_sch_date IN VARCHAR2,
                                            p_sch_time IN VARCHAR2,
                                            P_SUBM_VER_NO OUT NUMBER,
                                            p_user_id IN VARCHAR2);

END PKG_CST_TRUCK_INIT;
/

PROMPT CREATE OR REPLACE BODY PACKAGE WOSINT.PKG_CST_TRUCK_INIT
CREATE OR REPLACE PACKAGE BODY WOSINT.PKG_CST_TRUCK_INIT IS

   s_cons_header VARCHAR2(100);
  s_cons_detail VARCHAR2(2500);
  s_cons_awb_detail VARCHAR2(2500);
  s_cons_footer VARCHAR2(30);
  s_schedule_date VARCHAR2(8);
  s_version_no VARCHAR2(2);
  s_lic_per VARCHAR2(240);
  s_cargo_ind VARCHAR2(1) := 'Y';
  s_cms3_error VARCHAR2(200);
  s_error_msg VARCHAR2(200);
  s_int_amd VARCHAR2(3);
  s_action_code VARCHAR2(1);
  s_cnsl_ind VARCHAR2(1);
  s_man_pcs VARCHAR2(6);
  s_man_wt VARCHAR2(9);
  s_content VARCHAR2(70);
  s_ldg_point VARCHAR2(3);
  s_simp_cnt NUMBER;
  s_cnsl_cnt NUMBER;
  s_hawb_cnt NUMBER;
  s_shpt_typ VARCHAR2(1);
  s_rel_ind VARCHAR2(1);
  s_user_id VARCHAR2(20);
  s_lm_date DATE;
  s_detail_seq_no NUMBER;
  s_int_ver_no NUMBER;
  v_awb_date DATE;
  v_awb_shpm_type VARCHAR2(1);

  s_awb_orig VARCHAR(3);
  s_shpr_name VARCHAR(35);
  s_shpr_add1 VARCHAR(53);
  s_shpr_add2 VARCHAR(53);
  s_shpr_add3 VARCHAR(53);
  s_shpr_add4 VARCHAR(53);
  s_shpr_add5 VARCHAR(53);
  s_shpr_place VARCHAR(53);
  s_shpr_ctry_code VARCHAR(53);
  s_shpr_pin_code VARCHAR(53);
  s_shpr_state_province VARCHAR(53);

  s_csgne_name VARCHAR(35);
  s_csgne_addr1 VARCHAR(53);
  s_csgne_addr2 VARCHAR(53);
  s_csgne_addr3 VARCHAR(53);
  s_csgne_addr4 VARCHAR(53);
  s_csgne_addr5 VARCHAR(53);
  s_csgne_place VARCHAR(53);
  s_csgne_ctry_code VARCHAR(53);
  s_csgne_pin_code VARCHAR(53);
  s_csgne_state_province VARCHAR(53);

  s_nfy_name VARCHAR(35);
  s_nfy_add1 VARCHAR(53);
  s_nfy_add2 VARCHAR(53);
  s_nfy_add3 VARCHAR(53);
  s_nfy_add4 VARCHAR(53);
  s_nfy_add5 VARCHAR(53);
  s_nfy_place VARCHAR(53);
  s_nfy_ctry_code VARCHAR(53);
  s_nfy_pin_code VARCHAR(53);

  s_awb_type VARCHAR(1);

  s_trk_manf_pcs NUMBER;
  s_trk_manf_wt NUMBER;
  s_imp_flt_key VARCHAR2(30);
  s_imp_flt_date DATE;

  type cursor_t IS ref CURSOR;

  v_truck_no VARCHAR2(10);
  v_sch_date DATE;
  v_sch_time VARCHAR2(10);
  v_flt_key VARCHAR2(10);
  v_flt_date DATE;
  v_awb_no VARCHAR2(30);
  v_hawb_no VARCHAR2(18);
  
   v_awb_list VARCHAR2(32767);
   v_hawb_list varchar(32767);
   v_subm_ver_no number;
   v_cst_itm_tr_no number;

  c_hdlg_agent constant VARCHAR2(3) := 'CPA';

  cheader constant VARCHAR2(6) := 'HEADER';
  cdetail constant VARCHAR2(6) := 'DETAIL';
  cfooter constant VARCHAR2(6) := 'FOOTER';
  --ERROR MESSAGE
  --  c_awb_00001 constant VARCHAR2(100) := ' Airway bill declare currency code is invalid when customs declare value is not null.';
  c_awb_00002 constant VARCHAR2(100) := ' Airway bill(house airyway bill) is null or format is wrong(its length should be 11)';
  c_awb_00003 constant VARCHAR2(100) := ' Airway bill(house airyway bill) origin or destination value is null';
  c_awb_00004 constant VARCHAR2(100) := ' Airway bill(house airyway bill) piece or weight is invvalid';
  c_awb_00005 constant VARCHAR2(100) := ' Airway bill(house airyway bill) content is invalid';
  c_awb_00006 constant VARCHAR2(100) := ' Airway bill(house airyway bill) importer is invalid';
  c_awb_00007 constant VARCHAR2(100) := ' Airway bill(house airyway bill) shipper is invalid';
  c_awb_00008 constant VARCHAR2(100) := ' Airway bill pieces or weight is invalid';
  c_awb_00009 constant VARCHAR2(100) := ' Generated message format is wrong.now its length is';
  c_awb_00013 constant VARCHAR2(100) := ' Airway bill shipper/consignee address is invalid';

  c_awb_00014 constant VARCHAR2(100) := ' House airway bill can not have space';

  c_awb_00015 constant VARCHAR2(100) := ' Data mismatch! Submission not done properly! Please Check and resubmit! ';

  c_awb_00010 constant VARCHAR2(100) := ' Airway bill manifest piece or weight is invalid';
  c_awb_00011 constant VARCHAR2(100) := ' No data found';
  c_awb_00012 constant VARCHAR2(100) := ' Aireay bill release indicator is wrong';
  c_flt_00002 constant VARCHAR2(100) := ' Flight scheduled arrival time is wrong';

  c_flt_00003 constant VARCHAR2(100) := ' Submit is in progress';

  --C_FLT_00003 CONSTANT VARCHAR2(50):=' Flight port code of flight last take off is wrong';

  /********************insert_cst_csgnm starts ****************/

   FUNCTION bool_to_text(p_bool IN boolean) RETURN VARCHAR2 IS
  BEGIN
    RETURN
    CASE
    WHEN p_bool THEN
      'TRUE'
    WHEN NOT p_bool THEN
      'FALSE'
    ELSE
      'NULL'
    END;
  END;

  FUNCTION insert_cst_csgnm(p_hawb_no VARCHAR2,   msg_type VARCHAR2) RETURN boolean IS s_seq_no NUMBER(8);
  BEGIN

    DBMS_OUTPUT.PUT_LINE('insert_cst_csgnm 1 -- msg_type -- ' || msg_type);

    IF msg_type = cheader THEN
      s_seq_no := 0;
      ELSIF msg_type = cfooter THEN
        s_seq_no := 99999;
        ELSIF msg_type = cdetail THEN
          s_detail_seq_no := s_detail_seq_no + 1;
          s_seq_no := s_detail_seq_no;
        ELSE
          NULL;
        END IF;

        DBMS_OUTPUT.PUT_LINE('insert_cst_csgnm 2 -- s_cons_header -- ' || s_cons_header);
        DBMS_OUTPUT.PUT_LINE('insert_cst_csgnm 3 -- s_cons_detail -- ' || s_cons_detail);
        DBMS_OUTPUT.PUT_LINE('insert_cst_csgnm 4 -- s_cons_footer -- ' || s_cons_footer);

        INSERT
        INTO cst_auto_submit_log
        VALUES('cdetail ' || cdetail || '......awb...' || v_awb_no);

        IF s_cnsl_ind = 'N' THEN
          DBMS_OUTPUT.PUT_LINE('cdetail-' || cdetail || '..msg..' || msg_type || '..v_awb_no..' || v_awb_no || '..h..' || p_hawb_no || '....s_cons_detail...' || s_cons_detail);

          DBMS_OUTPUT.PUT_LINE('FLT_TYPE- T ; FLT_KEY -' || v_flt_key || ' FLT_DATE - ' || v_flt_date || '; VER_NO - ' || s_version_no || '; RECV_REC_TYPE - ' || s_int_amd || '; SEQ_NO - ' || s_seq_no);

          INSERT
          INTO cst_csgnm(carr_code,   flt_key,   flt_date,   flt_type,   ver_no,   recv_rec_type,   seq_no,   ctrl_date,   req_uid,   awb_no,   hawb_no,   cns_hdr,   cns_dtl,   cns_ftr,   lm_user_id,   lm_date,   lm_ver,   truck_no,   sch_date,   sch_time)
          VALUES(SUBSTR(v_flt_key,   1,   2),   v_flt_key,   v_flt_date,   'T',   s_version_no,   s_int_amd,   s_seq_no,   sysdate,   ' ',   decode(msg_type,   cdetail,   v_awb_no,   NULL),   decode(msg_type,   cdetail,   p_hawb_no,   NULL),   decode(msg_type,   cheader,   s_cons_header,   NULL),   decode(msg_type,   cdetail,   s_cons_detail,   NULL),   decode(msg_type,   cfooter,   s_cons_footer,   NULL),   USER,   sysdate,   1,   v_truck_no,   v_sch_date,   v_sch_time);
          ELSIF s_cnsl_ind = 'Y' THEN

            DBMS_OUTPUT.PUT_LINE('cdetail-' || cdetail || '..msg..' || msg_type || '..v_awb_no..' || v_awb_no || '..h..' || p_hawb_no || '....s_cons_awb_detail...' || s_cons_awb_detail);

            DBMS_OUTPUT.PUT_LINE('FLT_TYPE- T ; FLT_KEY -' || v_flt_key || ' FLT_DATE - ' || v_flt_date || '; VER_NO - ' || s_version_no || '; RECV_REC_TYPE - ' || s_int_amd || '; SEQ_NO - ' || s_seq_no);

            INSERT
            INTO cst_csgnm(carr_code,   flt_key,   flt_date,   flt_type,   ver_no,   recv_rec_type,   seq_no,   ctrl_date,   req_uid,   awb_no,   hawb_no,   cns_hdr,   cns_dtl,   cns_ftr,   lm_user_id,   lm_date,   lm_ver,   truck_no,   sch_date,   sch_time)
            VALUES(SUBSTR(v_flt_key,   1,   2),   v_flt_key,   v_flt_date,   'T',   s_version_no,   s_int_amd,   s_seq_no,   sysdate,   ' ',   decode(msg_type,   cdetail,   v_awb_no,   NULL),   decode(msg_type,   cdetail,   p_hawb_no,   NULL),   decode(msg_type,   cheader,   s_cons_header,   NULL),   decode(msg_type,   cdetail,   s_cons_awb_detail,   NULL),   decode(msg_type,   cfooter,   s_cons_footer,   NULL),   USER,   sysdate,   1,   v_truck_no,   v_sch_date,   v_sch_time);
          END IF;

          RETURN TRUE;

        EXCEPTION
        WHEN others THEN
          s_error_msg := SUBSTR(SQLCODE || sqlerrm,   1,   100);
          DBMS_OUTPUT.PUT_LINE('insert_cst_csgnm 5 -- s_error_msg -- ' || s_error_msg);
          INSERT
          INTO cst_auto_submit_log
          VALUES('s_error_msg ' || s_error_msg);
          RETURN FALSE;
        END;

        /********************insert_cst_csgnm ends ****************/

         /********************* init Start here **************************/

         PROCEDURE init IS
        BEGIN
          s_cons_header := NULL;
          s_cons_detail := NULL;
          s_cons_footer := NULL;
          s_schedule_date := NULL;
          s_lic_per := NULL;
          s_cargo_ind := 'N';
          s_error_msg := NULL;
          s_action_code := NULL;
          s_cnsl_ind := 'N';
          s_man_pcs := 0;
          s_man_wt := 0;
          s_simp_cnt := 0;
          s_cnsl_cnt := 0;
          s_hawb_cnt := 0;
          s_detail_seq_no := 0;

          --        s_version_no VARCHAR2(2);
          --        s_lic_per VARCHAR2(240);
          --        s_cargo_ind VARCHAR2(1) := 'Y';
          --        s_cms3_error VARCHAR2(200);
          --        s_error_msg VARCHAR2(200);
          --        s_int_amd VARCHAR2(3);
          --        s_action_code VARCHAR2(1);
          --        s_cnsl_ind VARCHAR2(1);
          --        s_man_pcs VARCHAR2(6);
          --        s_man_wt VARCHAR2(9);
          --        s_content VARCHAR2(70);
          --        s_ldg_point VARCHAR2(3);
          --        s_simp_cnt NUMBER;
          --        s_cnsl_cnt NUMBER;
          --        s_hawb_cnt NUMBER;
          --        s_shpt_typ VARCHAR2(1);
          --        s_rel_ind VARCHAR2(1);
          --        s_user_id VARCHAR2(20);
          --        s_lm_date DATE;
          --        s_detail_seq_no NUMBER;
          --        s_int_ver_no NUMBER;
          --        v_awb_date DATE;
          --        v_awb_shpm_type VARCHAR2(1);
          --        
          --        s_awb_orig varchar(3);
          --        s_shpr_name varchar(35);
          --        s_shpr_add1 varchar(53);
          --        s_shpr_add2 varchar(53);
          --        s_shpr_add3 varchar(53);
          --        s_shpr_add4 varchar(53);
          --        s_shpr_add5 varchar(53);
          --        s_shpr_place varchar(53);
          --        s_shpr_ctry_code varchar(53);
          --        s_shpr_pin_code varchar(53);
          --        s_shpr_state_province varchar(53);
          --        
          --        s_csgne_name varchar(35);
          --        s_csgne_addr1 varchar(53);
          --        s_csgne_addr2 varchar(53);
          --        s_csgne_addr3 varchar(53);
          --        s_csgne_addr4 varchar(53);
          --        s_csgne_addr5 varchar(53);
          --        s_csgne_place varchar(53);
          --        s_csgne_ctry_code varchar(53);
          --        s_csgne_pin_code varchar(53);
          --        s_csgne_state_province varchar(53);
          --          
          --        s_awb_type varchar(1);
          --        
          --        s_trk_manf_pcs NUMBER; 
          --        s_trk_manf_wt NUMBER;
          --        s_imp_flt_key  VARCHAR2(30);
          --        s_imp_flt_date Date;

        END;

        /********************* init end here **************************/

         /***********************get_ver_no Starts*************/

         FUNCTION get_ver_no RETURN boolean IS n_ver_no NUMBER;
        BEGIN

          DBMS_OUTPUT.PUT_LINE('get_ver_no 1');

          FOR c IN
            (SELECT ver_no,
               send_status
             FROM cst_subm c
             WHERE c.flt_type = 'T'
             AND truck_no = v_truck_no
             AND sch_date = v_sch_date
             AND sch_time = v_sch_time
             AND c.rec_type = s_int_amd
             ORDER BY ver_no DESC)
          LOOP

            --          DBMS_OUTPUT.PUT_LINE('get_ver_no 1   c.send_status - ' || c.send_status);

            IF c.send_status = 'E' THEN

              DELETE FROM cst_csgnm
              WHERE flt_type = 'T'
               AND truck_no = v_truck_no
               AND sch_date = v_sch_date
               AND sch_time = v_sch_time
               AND recv_rec_type = s_int_amd
               AND ver_no = c.ver_no;

              DELETE FROM cst_subm
              WHERE flt_type = 'T'
               AND truck_no = v_truck_no
               AND sch_date = v_sch_date
               AND sch_time = v_sch_time
               AND rec_type = s_int_amd
               AND ver_no = c.ver_no;

              n_ver_no := c.ver_no;

              ELSIF c.send_status IN('P',   'W') THEN
                n_ver_no := -1;
                ELSIF c.send_status IN('R',   'A') THEN
                  n_ver_no := c.ver_no + 1;
                END IF;

                EXIT;
              END LOOP;

              IF n_ver_no = -1 THEN
                RETURN FALSE;
              END IF;

              IF nvl(n_ver_no,   0) = 0 THEN
                n_ver_no := 1;
              END IF;

              s_version_no := lpad(n_ver_no,   2,   '0');

              --            DBMS_OUTPUT.PUT_LINE('get_ver_no 1   s_version_no - ' || s_version_no);

              RETURN TRUE;
            END;

            /***********************get_ver_no Ends*************/

             /*******************  get_hdr_info_ina start here     *****************/

             FUNCTION get_hdr_info_ina RETURN boolean IS

            BEGIN

              --            DBMS_OUTPUT.PUT_LINE('get_hdr_info_ina 44 1 -- s_cons_header -- ' || s_cons_header);

              SELECT to_char(a.truck_flt_date,   'YYYYMMDD'),
                rpad(v_truck_no,   8,   ' ') || -- 2.1
              to_char(a.truck_flt_date,   'YYYYMMDD') || --  2.2
              TRIM(to_char(nvl(a.sch_time,   0),   '0000')) || --  2.3
              s_version_no || --  2.4
              c_hdlg_agent || --  2.5
              lpad(a.cls_rd_permit,   15,   ' ') || -- 2.6
              to_char(a.cross_date,   'YYYYMMDD') || --  2.7
              TRIM(to_char(nvl(a.cross_time,   0),   '0000')) || --  2.8
              rpad(' ',   15,   ' ') || --  2.9 seal No
              rpad(' ',   15,   ' ') || --  2.10 container no
              rpad(a.ctrl_pt_code,   3,   ' ') || --  2.11
              rpad(a.unldg_pt,   3,   ' ') --  2.12
              INTO s_schedule_date,
                s_cons_header
              FROM itm_trk_manf_hd a
              WHERE a.truck_flt_no = v_flt_key
               AND a.truck_flt_date = v_flt_date
               and status not in ('VOID');

              --            DBMS_OUTPUT.PUT_LINE('get_hdr_info_ina 44 2 -- s_cons_header -- ' || s_cons_header);

              IF NOT insert_cst_csgnm('',   cheader) THEN
                s_error_msg := SUBSTR(SQLCODE || sqlerrm,   1,   100);
                RETURN FALSE;
              END IF;

              --            DBMS_OUTPUT.PUT_LINE('get_hdr_info_ina 44 3 -- s_error_msg -- ' || s_error_msg);

              RETURN TRUE;

            EXCEPTION
            WHEN no_data_found THEN
              s_error_msg := SUBSTR(SQLCODE || sqlerrm,   1,   100);
              RETURN FALSE;
            WHEN too_many_rows THEN
              s_error_msg := SUBSTR(SQLCODE || sqlerrm,   1,   100);
              RETURN FALSE;
              -- WHEN others THEN
              --  s_error_msg := SUBSTR(SQLCODE || sqlerrm,   1,   100);
              --  RETURN FALSE;
            END;

            /*******************  get_hdr_info_ina end here     *****************/

             /********************construct_ina_dtl start ****************/

             FUNCTION construct_ina_dtl RETURN boolean IS
            BEGIN

              IF s_cnsl_ind = 'N' THEN
                s_cons_detail := rpad(v_truck_no,   8,   ' ') || to_char(v_sch_date,   'YYYYMMDD') || lpad(v_sch_time,   4,   '0') || s_version_no || rpad(' ',   29,   ' ') || SUBSTR(v_awb_no,   1,   3) || '-' || SUBSTR(v_awb_no,   4) || rpad('0',   18,   '0') || 'N' || 'T' || s_awb_orig || 'HKG' || s_ldg_point || lpad(s_trk_manf_pcs,   6,   '0') || lpad(TRIM(to_char(s_trk_manf_wt,   '9999999.0')),   9,   '0') || rpad(nvl(s_content,   ' '),   265,   ' ') || rpad(nvl(s_csgne_name,   ' '),   95,   ' ') || rpad(nvl(s_csgne_addr1,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr2,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr3,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr4,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr5,   ' '),   53,   ' ') || rpad(nvl(s_nfy_name,   ' '),   95,   ' ') || rpad(nvl(s_nfy_add1,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add2,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add3,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add4,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add5,   ' '),   53,   ' ') || rpad(nvl(s_shpr_name,   ' '),   95,   ' ') || rpad(nvl(s_shpr_add1,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add2,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add3,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add4,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add5,   ' '),   53,   ' ') || rpad(' ',   35,   ' ') || rpad(nvl(s_lic_per,   ' '),   120,   ' ');
                --              DBMS_OUTPUT.PUT_LINE('construct_ina_dtl 11 -- length(s_cons_detail)-- ' || LENGTH(s_cons_detail) || ' ---s_cons_detail- ' || s_cons_detail);
                --                s_cons_detail := s_cons_detail || rpad(nvl(s_content,   ' '),   265,   ' ') || rpad(nvl(s_csgne_name,   ' '),   95,   ' ') || rpad(nvl(s_csgne_addr1,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr2,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr3,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr4,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr5,   ' '),   53,   ' ') || rpad(nvl(s_nfy_name,   ' '),   95,   ' ') || rpad(nvl(s_nfy_add1,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add2,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add3,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add4,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add5,   ' '),   53,   ' ') || rpad(nvl(s_shpr_name,   ' '),   95,   ' ') || rpad(nvl(s_shpr_add1,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add2,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add3,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add4,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add5,   ' '),   53,   ' ') || rpad(' ',   35,   ' ') || rpad(nvl(s_lic_per,   ' '),   120,   ' ');
                --              DBMS_OUTPUT.PUT_LINE('construct_ina_dtl 3333 -- length(s_cons_detail)-- ' || LENGTH(s_cons_detail) || ' ---s_cons_detail- ' || s_cons_detail);

                DBMS_OUTPUT.PUT_LINE('construct_ina_dtl 22 -- length(s_cons_detail)-- ' || LENGTH(s_cons_detail) || ' ---s_cons_detail- ' || s_cons_detail);
                -- DBMS_OUTPUT.PUT_LINE('construct_ina_dtl 22  - '||SUBSTR(SQLCODE || sqlerrm,   1,   100));        
                ELSIF s_cnsl_ind = 'Y' THEN
                  s_cons_awb_detail := rpad(v_truck_no,   8,   ' ') || to_char(v_sch_date,   'YYYYMMDD') || lpad(v_sch_time,   4,   '0') || s_version_no || rpad(' ',   29,   ' ') || SUBSTR(v_awb_no,   1,   3) || '-' || SUBSTR(v_awb_no,   4) || s_cons_awb_detail || rpad(nvl(s_content,   ' '),   265,   ' ') || rpad(nvl(s_csgne_name,   ' '),   95,   ' ') || rpad(nvl(s_csgne_addr1,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr2,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr3,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr4,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr5,   ' '),   53,   ' ') || rpad(nvl(s_nfy_name,   ' '),   95,   ' ') || rpad(nvl(s_nfy_add1,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add2,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add3,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add4,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add5,   ' '),   53,   ' ') || rpad(nvl(s_shpr_name,   ' '),   95,   ' ') || rpad(nvl(s_shpr_add1,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add2,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add3,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add4,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add5,   ' '),   53,   ' ') || rpad(' ',   35,   ' ') || rpad(nvl(s_lic_per,   ' '),   120,   ' ');

                  --                DBMS_OUTPUT.PUT_LINE('construct_ina_dtl 11 -- length(s_cons_awb_detail)-- ' || LENGTH(s_cons_awb_detail) || ' ---s_cons_awb_detail- ' || s_cons_awb_detail);
                  --                  s_cons_awb_detail := s_cons_awb_detail || rpad(nvl(s_content,   ' '),   265,   ' ') || rpad(nvl(s_csgne_name,   ' '),   95,   ' ') || rpad(nvl(s_csgne_addr1,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr2,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr3,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr4,   ' '),   53,   ' ') || rpad(nvl(s_csgne_addr5,   ' '),   53,   ' ') || rpad(nvl(s_nfy_name,   ' '),   95,   ' ') || rpad(nvl(s_nfy_add1,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add2,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add3,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add4,   ' '),   53,   ' ') || rpad(nvl(s_nfy_add5,   ' '),   53,   ' ') || rpad(nvl(s_shpr_name,   ' '),   95,   ' ') || rpad(nvl(s_shpr_add1,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add2,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add3,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add4,   ' '),   53,   ' ') || rpad(nvl(s_shpr_add5,   ' '),   53,   ' ') || rpad(' ',   35,   ' ') || rpad(nvl(s_lic_per,   ' '),   120,   ' ');
                  --                DBMS_OUTPUT.PUT_LINE('construct_ina_dtl 3333 -- length(s_cons_awb_detail)-- ' || LENGTH(s_cons_awb_detail) || ' ---s_cons_awb_detail- ' || s_cons_awb_detail);

                  DBMS_OUTPUT.PUT_LINE('construct_ina_dtl 22 -- length(s_cons_awb_detail)-- ' || LENGTH(s_cons_awb_detail) || ' ---s_cons_awb_detail- ' || s_cons_awb_detail);
                  -- DBMS_OUTPUT.PUT_LINE('construct_ina_dtl 22  - '||SUBSTR(SQLCODE || sqlerrm,   1,   100));        
                END IF;

                RETURN TRUE;
              END;

              /******************construct_ina_dtl end******************/

               /********************set_cnsl_ind starts ****************/

               FUNCTION set_cnsl_ind RETURN boolean IS
              BEGIN
                s_cnsl_ind := 'N';

                BEGIN
                  SELECT cnsl_ind
                  INTO s_cnsl_ind
                  FROM cst_itm_awb
                  WHERE truck_flt_no = v_flt_key
                   AND truck_flt_date = v_flt_date
                   AND truck_no = v_truck_no
                   AND sch_date = v_sch_date
                   AND sch_time = v_sch_time
                   AND awb_no = v_awb_no
                   AND awb_date = v_awb_date
                   AND rownum = 1;

                EXCEPTION
                WHEN no_data_found THEN
                  s_cnsl_ind := 'N';
                END;
                RETURN TRUE;

              END;

              /********************init_INA ends ****************/

               /********************init_INA starts ****************/

               FUNCTION init_ina RETURN boolean IS
              BEGIN

                BEGIN
                  SELECT unldg_pt
                  INTO s_ldg_point
                  FROM itm_trk_manf_hd
                  WHERE truck_flt_no = v_flt_key
                   AND truck_flt_date = v_flt_date
                   AND truck_no = v_truck_no
                   AND sch_time = v_sch_time
                   and status not in ('VOID')
                   AND rownum = 1;

                EXCEPTION
                WHEN no_data_found THEN
                  RETURN FALSE;

                END;
                --  start s_cons_detail 2
                --                s_cons_detail := rpad(v_truck_no,   8,   ' ') || to_char(v_sch_date,   'YYYYMMDD') || lpad(v_sch_time,   4,   '0') || s_version_no || rpad(' ',   29,   ' ');
                --                DBMS_OUTPUT.PUT_LINE('init_ina  111 ... length(s_cons_detail)' || LENGTH(s_cons_detail) || '--s_cons_detail -- ' || s_cons_detail);
                RETURN TRUE;

              END;

              /********************init_INA ends ****************/

               /******************validate_msgs_ina start******************/

               FUNCTION validate_msgs_ina RETURN boolean IS s_msg_length NUMBER;

              BEGIN

                IF s_cnsl_ind = 'N' THEN
                  --                DBMS_OUTPUT.PUT_LINE('validate_msgs_ina --- s_cons_detail...' || s_cons_detail);
                  --MESSAGE VAILDATION START
                  s_msg_length := LENGTH(s_cons_detail);
                  DBMS_OUTPUT.PUT_LINE('validate_msgs_ina ---s_msg_length...' || s_msg_length || '....' || cdetail);
                  ELSIF s_cnsl_ind = 'Y' THEN
                    --                  DBMS_OUTPUT.PUT_LINE('validate_msgs_ina --- s_cons_awb_detail...' || s_cons_awb_detail);
                    --MESSAGE VAILDATION START
                    s_msg_length := LENGTH(s_cons_awb_detail);
                    DBMS_OUTPUT.PUT_LINE('validate_msgs_ina ---s_msg_length...' || s_msg_length || '....' || cdetail);
                  END IF;

                  --              DBMS_OUTPUT.PUT_LINE('validate_msgs_ina --- start...s_int_amd : '||s_int_amd );
                  --              
                  --              DBMS_OUTPUT.PUT_LINE('validate_msgs_ina --- start...s_msg_length : '||s_msg_length );

                  IF s_int_amd = 'INA' THEN

                    IF s_msg_length <> 1607 THEN
                      s_cms3_error := 'INA - ' || v_awb_no || c_awb_00009 || s_msg_length;
                      RETURN FALSE;
                    END IF;

                    ELSIF s_int_amd = 'AMA' THEN

                      IF s_msg_length <> 1608 THEN
                        s_cms3_error := 'AMA - ' || v_awb_no || c_awb_00009 || s_msg_length;
                        RETURN FALSE;
                      END IF;

                      ELSIF s_int_amd = 'BAS' THEN

                        IF s_msg_length <> 1828 THEN
                          s_cms3_error := 'BAS - ' || v_awb_no || c_awb_00009 || s_msg_length;
                          RETURN FALSE;
                        END IF;

                      END IF;

                      DBMS_OUTPUT.PUT_LINE('validate_msgs_ina --- End... : ');

                      RETURN TRUE;
                    END;

                    /********************validate_msgs_ina end******************/

                     /********************set_awb_values starts ****************/

                     FUNCTION set_awb_values RETURN boolean IS
                    BEGIN

                      --  start s_cons_detail 2
                      --                      s_cons_detail := s_cons_detail || SUBSTR(v_awb_no,   1,   3) || '-' || SUBSTR(v_awb_no,   4);

                      DBMS_OUTPUT.PUT_LINE('set_awb_values 11 length(s_cons_detail) - ' || LENGTH(s_cons_detail));
                      DBMS_OUTPUT.PUT_LINE('set_awb_values 11 v_flt_key  - ' || v_flt_key);
                      DBMS_OUTPUT.PUT_LINE('set_awb_values 11 v_sch_date  - ' || v_sch_date);
                      DBMS_OUTPUT.PUT_LINE('set_awb_values 11 v_awb_no  - ' || v_awb_no);
                      s_awb_type := 'I';

                      BEGIN
                        SELECT shp.orig,
                          shp.trk_manf_pcs,
                          shp.trk_manf_wt,
                          shp.imp_flt_key,
                          shp.imp_flt_date,
                          shp.awb_date
                        INTO s_awb_orig,
                          s_trk_manf_pcs,
                          s_trk_manf_wt,
                          s_imp_flt_key,
                          s_imp_flt_date,
                          v_awb_date
                        FROM itm_trk_manf_shp shp 
                        join itm_trk_manf_hd hd on hd.tr_no = shp.tr_no and hd.status <> 'VOID'
                        WHERE hd.truck_flt_no = v_flt_key
                         AND hd.truck_flt_date = v_sch_date
                         AND shp.awb_no = v_awb_no
                         AND rownum = 1;

                        --                      DBMS_OUTPUT.PUT_LINE('set_awb_values 22 s_cons_detail  - ' || s_awb_type);
                        --                      DBMS_OUTPUT.PUT_LINE('set_awb_values 33 v_flt_key  - ' || v_flt_key);
                        --                      DBMS_OUTPUT.PUT_LINE('set_awb_values 44 v_sch_date  - ' || v_sch_date);
                        DBMS_OUTPUT.PUT_LINE('set_awb_values 55 v_awb_no  - ' || v_awb_no);

                      EXCEPTION
                      WHEN no_data_found THEN
                        DBMS_OUTPUT.PUT_LINE('set_awb_values 66  - ' || SUBSTR(SQLCODE || sqlerrm,   1,   100));
                        RETURN FALSE;
                      END;

                      --                    DBMS_OUTPUT.PUT_LINE('set_awb_values 66 s_awb_orig - ' || s_awb_orig || ' -- s_trk_manf_pcs -- ' || s_trk_manf_pcs || ' -- s_trk_manf_wt -- ' || s_trk_manf_wt || ' -- s_imp_flt_key -- ' || s_imp_flt_key || ' -- s_imp_flt_date -- ' || s_imp_flt_date || ' -- v_awb_date  -- ' || v_awb_date);

                      IF s_imp_flt_key IS NULL THEN
                        s_awb_type := 'E';
                      END IF;

                      RETURN TRUE;

                    END;

                    /********************set_awb_values ends ****************/

                     /********************set_dtl_awb_ina starts ****************/

                     FUNCTION set_dtl_awb_ina RETURN boolean IS
                    BEGIN

                      --                    DBMS_OUTPUT.PUT_LINE('set_dtl_awb_ina 11 s_awb_type - ' || s_awb_type);
                      --                    DBMS_OUTPUT.PUT_LINE('set_dtl_awb_ina 11 s_imp_flt_key - ' || s_imp_flt_key);
                      --                    DBMS_OUTPUT.PUT_LINE('set_dtl_awb_ina 11 s_imp_flt_date - ' || s_imp_flt_date);
                      --                    DBMS_OUTPUT.PUT_LINE('set_dtl_awb_ina 11 v_awb_no - ' || v_awb_no);
                      --                    DBMS_OUTPUT.PUT_LINE('set_dtl_awb_ina 11 v_awb_date - ' || v_awb_date);

                      IF s_awb_type = 'I' THEN

                        BEGIN
                          SELECT awb_origin,
                            content,
                            shpr_name,
                            shpr_add1,
                            shpr_add2,
                            shpr_add3,
                            shpr_add4,
                            shpr_add5,
                            shpr_place,
                            shpr_ctry_code,
                            shpr_pin_code,
                            shpr_state_province,
                            csgne_name,
                            csgne_addr1,
                            csgne_addr2,
                            csgne_addr3,
                            csgne_addr4,
                            csgne_addr5,
                            csgne_place,
                            csgne_ctry_code,
                            csgne_pin_code,
                            csgne_state_province
                          INTO s_awb_orig,
                            s_content,
                            s_shpr_name,
                            s_shpr_add1,
                            s_shpr_add2,
                            s_shpr_add3,
                            s_shpr_add4,
                            s_shpr_add5,
                            s_shpr_place,
                            s_shpr_ctry_code,
                            s_shpr_pin_code,
                            s_shpr_state_province,
                            s_csgne_name,
                            s_csgne_addr1,
                            s_csgne_addr2,
                            s_csgne_addr3,
                            s_csgne_addr4,
                            s_csgne_addr5,
                            s_csgne_place,
                            s_csgne_ctry_code,
                            s_csgne_pin_code,
                            s_csgne_state_province
                          FROM imp_car_awb carawb,
                            imp_car_shp carshp
                          WHERE carawb.awb_no = carshp.awb_no
                           AND carawb.awb_date = carshp.awb_date
                           AND carshp.flt_key = s_imp_flt_key
                           AND carshp.flt_date = s_imp_flt_date
                           AND carawb.awb_no = v_awb_no
                           AND carawb.awb_date = v_awb_date;
                          RETURN TRUE;

                        EXCEPTION
                        WHEN no_data_found THEN
                          --                        DBMS_OUTPUT.PUT_LINE('set_dtl_awb_ina 22  - ' || SUBSTR(SQLCODE || sqlerrm,   1,   100));
                          RETURN FALSE;
                        END;

                        ELSIF s_awb_type = 'E' THEN
                          BEGIN
                            SELECT origin,
                              content,
                              shpr_name,
                              shpr_addr,
                              shpr_addr2,
                              shpr_addr3,
                              shpr_addr4,
                              shpr_place,
                              shpr_ctry_code,
                              shpr_pin_code,
                              shpr_state_province,
                              csgne_name,
                              csgne_addr,
                              csgne_addr2,
                              csgne_addr3,
                              csgne_addr4,
                              csgne_place,
                              csgne_ctry_code,
                              csgne_pin_code,
                              csgne_state_province
                            INTO s_awb_orig,
                              s_content,
                              s_shpr_name,
                              s_shpr_add1,
                              s_shpr_add2,
                              s_shpr_add3,
                              s_shpr_add4,
                              s_shpr_place,
                              s_shpr_ctry_code,
                              s_shpr_pin_code,
                              s_shpr_state_province,
                              s_csgne_name,
                              s_csgne_addr1,
                              s_csgne_addr2,
                              s_csgne_addr3,
                              s_csgne_addr4,
                              s_csgne_place,
                              s_csgne_ctry_code,
                              s_csgne_pin_code,
                              s_csgne_state_province
                            FROM exp_car
                            WHERE awb_no = v_awb_no
                             AND awb_date = v_awb_date;
                            RETURN TRUE;

                          EXCEPTION
                          WHEN no_data_found THEN
                            --                          DBMS_OUTPUT.PUT_LINE('set_dtl_awb_ina 33  - ' || SUBSTR(SQLCODE || sqlerrm,   1,   100));
                            RETURN FALSE;
                          END;
                        END IF;

                        RETURN TRUE;
                      END;

                      /********************set_dtl_awb_ina ends ****************/

                       /********************get_int_amd_ind starts ****************/

                       FUNCTION get_int_amd_ind RETURN VARCHAR IS l_int_amd_ind VARCHAR2(1);
                      BEGIN

                        IF s_cnsl_ind = 'N' THEN
                          SELECT change_ind
                          INTO l_int_amd_ind
                          FROM cst_itm_awb awb
                          WHERE awb.truck_flt_no = v_flt_key
                           AND awb.truck_flt_date = v_flt_date
                           AND awb.truck_no = v_truck_no
                           AND awb.sch_date = v_sch_date
                           AND awb.awb_no = v_awb_no
                           AND awb.awb_date = v_awb_date
                           AND accs_ind = 'AMA'
                           AND rownum = 1;

                          DBMS_OUTPUT.PUT_LINE('get_int_amd_ind 11 l_int_amd_ind for AWB --' || l_int_amd_ind);
                          RETURN l_int_amd_ind;
                          ELSIF s_cnsl_ind = 'Y' THEN

                            SELECT change_ind
                            INTO l_int_amd_ind
                            FROM cst_itm_hawb hawb
                            WHERE hawb.truck_flt_no = v_flt_key
                             AND hawb.truck_flt_date = v_flt_date
                             AND hawb.truck_no = v_truck_no
                             AND hawb.sch_date = v_sch_date
                             AND hawb.awb_no = v_awb_no
                             AND hawb.hawb_no = v_hawb_no
                             AND hawb.awb_date = v_awb_date
                             AND accs_ind = 'AMA'
                             AND rownum = 1;

                            DBMS_OUTPUT.PUT_LINE('get_int_amd_ind 11 l_int_amd_ind for HAWB --' || l_int_amd_ind);
                            RETURN l_int_amd_ind;
                          END IF;

                          RETURN 'D';
                        END;

                        /********************set_dtl_hawb_ina ends ****************/

                         /********************msg_awb_ina starts ****************/

                         FUNCTION msg_awb_ina RETURN boolean IS
                        BEGIN

                          --                            start s_cons_detail 2 - for hawb
                          --                          s_cons_detail := s_cons_detail || rpad('0',   18,   '0') || 'N' || 'T' || s_awb_orig || 'HKG' || s_ldg_point || lpad(s_trk_manf_pcs,   6,   '0') || lpad(TRIM(to_char(s_trk_manf_wt,   '9999999.0')),   9,   '0');

                          DBMS_OUTPUT.PUT_LINE('msg_awb_ina 11  length(s_cons_detail)-- ' || LENGTH(s_cons_detail));
                          DBMS_OUTPUT.PUT_LINE('msg_awb_ina 11  s_cons_detail-- ' || s_cons_detail);

                          IF NOT set_dtl_awb_ina THEN
                            DBMS_OUTPUT.PUT_LINE('msg_awb_ina 22  - ' || SUBSTR(SQLCODE || sqlerrm,   1,   100));
                            RETURN FALSE;
                          END IF;

                          IF NOT construct_ina_dtl THEN
                            DBMS_OUTPUT.PUT_LINE('msg_awb_ina 33  - ' || SUBSTR(SQLCODE || sqlerrm,   1,   100));
                            RETURN FALSE;
                          END IF;

                          IF s_int_amd = 'AMA' THEN
                            s_cons_detail := get_int_amd_ind || s_cons_detail;
                          END IF;

                          IF NOT validate_msgs_ina THEN
                            DBMS_OUTPUT.PUT_LINE('msg_awb_ina 44  - ' || SUBSTR(SQLCODE || sqlerrm,   1,   100));
                            RETURN FALSE;
                          END IF;

                          IF NOT insert_cst_csgnm(lpad('0',   18,   '0'),   cdetail) THEN
                            s_cms3_error := 'CST_204';
                            DBMS_OUTPUT.PUT_LINE('msg_awb_ina 55  - ' || SUBSTR(SQLCODE || sqlerrm,   1,   100));
                            RETURN FALSE;
                          END IF;

                          RETURN TRUE;
                        END;

                        /********************msg_awb_ina ends ****************/

                         /********************set_dtl_hawb_ina starts ****************/

                         FUNCTION set_dtl_hawb_ina RETURN boolean IS

                        BEGIN

                          FOR c_hawb IN
                            (SELECT hawb.hawb_no hawb_no,
                               hawb.trk_manf_pcs trk_manf_pcs,
                               hawb.trk_manf_wt trk_manf_wt,
                               awb.orig orig
                             FROM itm_trk_manf_hd hd
                             join itm_trk_manf_shp awb on hd.tr_no = awb.tr_no  and hd.status <> 'VOID'
                             join itm_trk_manf_shp_hawb hawb on hd.tr_no = hawb.tr_no and awb.doc_line_no = hawb.dtl_doc_line_no
                             WHERE awb.truck_flt_no = v_flt_key
                             AND awb.truck_flt_date = v_flt_date
                             AND hawb.truck_flt_no = v_flt_key
                             AND hawb.truck_flt_date = v_flt_date
                             AND awb.awb_no = v_awb_no
                             AND awb.awb_date = v_awb_date)
                          LOOP

                            DBMS_OUTPUT.PUT_LINE('set_dtl_hawb_ina 1');

                            v_hawb_no := c_hawb.hawb_no;

                            DBMS_OUTPUT.PUT_LINE('set_dtl_hawb_ina 1 - v_hawb_no - ' || v_hawb_no);

                            --  start s_cons_detail 2 - for hawb
                            s_cons_awb_detail := '';
                            s_cons_awb_detail := rpad(c_hawb.hawb_no,   18,   ' ') || 'N' || 'T' || c_hawb.orig || 'HKG' || s_ldg_point || lpad(c_hawb.trk_manf_pcs,   6,   '0') || lpad(TRIM(to_char(c_hawb.trk_manf_wt,   '9999999.0')),   9,   '0');

                                                    DBMS_OUTPUT.PUT_LINE('cnsl_ind ------Y set_dtl_hawb_ina 1 - s_cons_awb_detail - ' || s_cons_awb_detail);
                            --
                            --                        DBMS_OUTPUT.PUT_LINE('set_dtl_hawb_ina 1 - v_awb_no - ' || v_awb_no);
                            --
                            --                        DBMS_OUTPUT.PUT_LINE('set_dtl_hawb_ina 1 - v_awb_date - ' || v_awb_date);
                            --
                            --                        DBMS_OUTPUT.PUT_LINE('set_dtl_hawb_ina 1 - c_hawb.hawb_no - ' || c_hawb.hawb_no);

                            BEGIN
                              SELECT hawb_org,
                                manifest_desc,
                                shpr_name,
                                shpr_add1,
                                shpr_add2,
                                shpr_add3,
                                shpr_add4,
                                shpr_add5,
                                shpr_place,
                                shpr_ctry_code,
                                shpr_pin_code,
                                shpr_state_province,
                                csgne_name,
                                csgne_add1,
                                csgne_add2,
                                csgne_add3,
                                csgne_add4,
                                csgne_add5,
                                csgne_place,
                                csgne_ctry_code,
                                csgne_pin_code,
                                csgne_state_province,
                                nfy_name,
                                nfy_add1,
                                nfy_add2,
                                nfy_add3,
                                nfy_add4,
                                nfy_add5,
                                nfy_place,
                                nfy_ctry_code,
                                nfy_pin_code
                              INTO s_awb_orig,
                                s_content,
                                s_shpr_name,
                                s_shpr_add1,
                                s_shpr_add2,
                                s_shpr_add3,
                                s_shpr_add4,
                                s_shpr_add5,
                                s_shpr_place,
                                s_shpr_ctry_code,
                                s_shpr_pin_code,
                                s_shpr_state_province,
                                s_csgne_name,
                                s_csgne_addr1,
                                s_csgne_addr2,
                                s_csgne_addr3,
                                s_csgne_addr4,
                                s_csgne_addr5,
                                s_csgne_place,
                                s_csgne_ctry_code,
                                s_csgne_pin_code,
                                s_csgne_state_province,
                                s_nfy_name,
                                s_nfy_add1,
                                s_nfy_add2,
                                s_nfy_add3,
                                s_nfy_add4,
                                s_nfy_add5,
                                s_nfy_place,
                                s_nfy_ctry_code,
                                s_nfy_pin_code
                              FROM edi_fhl hd,
                                edi_fhl_hawb dtl
                              WHERE -- hd.tr_no = dtl.tr_no AND 
                              awb_no = v_awb_no
                               AND awb_date = v_awb_date
                               AND hawb_no = c_hawb.hawb_no
                               AND rownum = 1;

                              DBMS_OUTPUT.PUT_LINE('set_dtl_hawb_ina 2 -  - ');

                            EXCEPTION
                            WHEN no_data_found THEN
                              RETURN FALSE;
                              --                    WHEN too_many_rows THEN
                              --                      RETURN TRUE;
                            END;

                            DBMS_OUTPUT.PUT_LINE('set_dtl_hawb_ina 2 -  - ');

                            IF NOT construct_ina_dtl THEN
                              DBMS_OUTPUT.PUT_LINE('set_dtl_hawb_ina 2 -  SUBSTR(SQLCODE || sqlerrm,   1,   1000) - ' || SUBSTR(SQLCODE || sqlerrm,   1,   1000));
                              RETURN FALSE;
                            END IF;

                            IF s_int_amd = 'AMA' THEN
                              s_cons_awb_detail := get_int_amd_ind || s_cons_awb_detail;
                            END IF;

                            --                        DBMS_OUTPUT.PUT_LINE('set_dtl_hawb_ina 3 - s_cons_detail - ' || s_cons_awb_detail);

                            IF NOT validate_msgs_ina THEN
                              --                         DBMS_OUTPUT.PUT_LINE('set_dtl_hawb_ina 3 -  SUBSTR(SQLCODE || sqlerrm,   1,   1000) - ' ||  SUBSTR(SQLCODE || sqlerrm,   1,   1000));

                              RETURN FALSE;
                            END IF;

                            --                        DBMS_OUTPUT.PUT_LINE('set_dtl_hawb_ina 4 - s_cons_detail - ' || s_cons_awb_detail);

                            IF NOT insert_cst_csgnm(v_hawb_no,   cdetail) THEN
                              s_cms3_error := 'CST_204';
                              RETURN FALSE;
                            END IF;

                            --AWB EVENTS
                            --            insert_awb_event(c_awb.man_pcs,   c_awb.man_wgt);
                            --UPDATE ACCS AWB INDICATOR
                            --            RETURN update_accs_ind('CST_AWB');    

                          END LOOP;

                          DBMS_OUTPUT.PUT_LINE('set_dtl_hawb_ina 99');
                          RETURN TRUE;
                        END;

                        /********************set_dtl_hawb_ina ends ****************/

                         /******************get_dtl_info_ina start******************/

                         FUNCTION get_dtl_info_ina RETURN boolean IS --s_sql_str    VARCHAR2(400);
                        c_awb cst_submit_temp % rowtype;

                        v_cnt NUMBER;
                        v_loop_cnt NUMBER;
                        s_msg_length NUMBER;

                        CURSOR cur_awb IS

                        SELECT *
                        FROM cst_submit_temp
                        WHERE flt_key = v_flt_key
                         AND flt_date = v_flt_date
                         AND truck_no = v_truck_no
                         AND sch_date = v_sch_date
                         AND sch_time = v_sch_time;

                        BEGIN

                          --                    SELECT count(1) into v_cnt
                          --                       FROM cst_itm_awb
                          --                       WHERE truck_flt_no = v_flt_key
                          --                         AND truck_flt_date = v_flt_date
                          --                         and truck_no = v_truck_no
                          --                         and sch_date = v_sch_date
                          --                         and sch_time = v_sch_time
                          --                         and accs_ind = 'INA'
                          --                         and change_ind in ('N');
                          --
                          --                           DBMS_OUTPUT.PUT_LINE('get_dtl_info_ina 11 v_cnt '||v_cnt);
                          --                           
                          --                           
                          --                          IF v_cnt is null or v_cnt = 0 THEN
                          --                            s_cms3_error := c_awb_00015;
                          --                            RETURN FALSE;
                          --                          END IF;

                          --                      DBMS_OUTPUT.PUT_LINE('get_dtl_info_ina 11');

                          IF NOT init_ina THEN
                            RETURN FALSE;
                          END IF;

                          --                      DBMS_OUTPUT.PUT_LINE('get_dtl_info_ina 22');
                          --CHECK WHETHER THE AWB MESSAGE EXISTS OR NOT

                          IF cur_awb % ISOPEN THEN
                            CLOSE cur_awb;
                          END IF;

                          --                          OPEN cur_awb;
                          v_loop_cnt := 0;
                          --                          FETCH cur_awb INTO c_awb;
                          FOR i IN cur_awb
                          LOOP

                            v_loop_cnt := v_loop_cnt + 1;
                            DBMS_OUTPUT.PUT_LINE('get_dtl_info_ina 11 close cusrsor v_loop_cnt - ' || v_loop_cnt);

                            --                      DBMS_OUTPUT.PUT_LINE('get_dtl_info_ina 33');

                            IF cur_awb % NOTFOUND THEN
                              s_cms3_error := c_awb_00011;
                              --                            CLOSE cur_awb;
                              RETURN FALSE;
                            END IF;

                            DBMS_OUTPUT.PUT_LINE('get_dtl_info_ina 44 -- I.awb_no -- ' || i.awb_no);
                            v_awb_no := i.awb_no;
                            --                          v_awb_no := c_awb.awb_no;
                            --                          v_awb_no := c_awb.awb_no;
                            --      v_awb_date := c_awb.awb_date;

                            DBMS_OUTPUT.PUT_LINE('get_dtl_info_ina 55');

                            IF NOT set_awb_values THEN
                              --                            CLOSE cur_awb;
                              RETURN FALSE;
                            END IF;

                            IF NOT set_cnsl_ind THEN
                              --                            CLOSE cur_awb;
                              RETURN FALSE;
                            END IF;

                            DBMS_OUTPUT.PUT_LINE('get_dtl_info_ina 66  s_cnsl_ind-- ' || s_cnsl_ind);

                            IF s_cnsl_ind = 'Y' THEN

                              IF NOT set_dtl_hawb_ina THEN
                                --                              CLOSE cur_awb;
                                RETURN FALSE;
                              END IF;

                              ELSIF s_cnsl_ind = 'N' THEN
                                DBMS_OUTPUT.PUT_LINE('get_dtl_info_ina 77  s_cnsl_ind-- ');

                                IF NOT msg_awb_ina THEN
                                  --                                CLOSE cur_awb;
                                  RETURN FALSE;
                                END IF;

                              END IF;

                              --                            CLOSE cur_awb;
                            END LOOP;

                            RETURN TRUE;
                          END;

                          /********************get_dtl_info_ina end******************/

                           /******************get_dtl_info_ama start******************/

                           FUNCTION get_dtl_info_ama RETURN boolean IS --s_sql_str    VARCHAR2(400);
                          c_awb cst_itm_awb % rowtype;

                          v_cnt NUMBER;
                          v_loop_cnt NUMBER;
                          s_msg_length NUMBER;

                          CURSOR cur_awb IS
                          SELECT *
                          FROM cst_itm_awb
                          WHERE truck_flt_no = v_flt_key
                           AND truck_flt_date = v_flt_date
                           AND truck_no = v_truck_no
                           AND sch_date = v_sch_date
                           AND sch_time = v_sch_time
                           AND accs_ind = 'AMA'
                           AND change_ind IN('A',   'U',   'D')  
                           and SUBM_VER_NO = (select max(SUBM_VER_NO) FROM cst_itm_awb
                                                WHERE truck_flt_no = v_flt_key
                                                 AND truck_flt_date = v_flt_date
                                                 AND truck_no = v_truck_no
                                                 AND sch_date = v_sch_date
                                                 AND sch_time = v_sch_time
                                                 AND accs_ind = 'AMA'
                                                 AND change_ind IN('A',   'U',   'D')) ;

                          BEGIN

                            SELECT COUNT(1)
                            INTO v_cnt
                            FROM cst_submit_temp
                            WHERE flt_key = v_flt_key
                             AND flt_date = v_flt_date
                             AND truck_no = v_truck_no
                             AND sch_date = v_sch_date
                             AND sch_time = v_sch_time;

                            DBMS_OUTPUT.PUT_LINE('get_dtl_info_ama 11 v_cnt ' || v_cnt);

                            IF v_cnt IS NULL OR v_cnt = 0 THEN
                              s_cms3_error := c_awb_00015;
                              --                            CLOSE cur_awb;
                              RETURN FALSE;
                            END IF;

                            DBMS_OUTPUT.PUT_LINE('get_dtl_info_ama 11');

                            IF NOT init_ina THEN
                              RETURN FALSE;
                            END IF;

                            DBMS_OUTPUT.PUT_LINE('get_dtl_info_ama 22');
                            --CHECK WHETHER THE AWB MESSAGE EXISTS OR NOT

                            IF cur_awb % ISOPEN THEN
                              DBMS_OUTPUT.PUT_LINE('get_dtl_info_ama 22 close cusrsor');
                              CLOSE cur_awb;
                            END IF;

                            --                          OPEN cur_awb;
                            v_loop_cnt := 0;
                            --                          FETCH cur_awb INTO c_awb;
                            FOR i IN cur_awb
                            LOOP

                              v_loop_cnt := v_loop_cnt + 1;
                              DBMS_OUTPUT.PUT_LINE('get_dtl_info_ama 11 close cusrsor v_loop_cnt - ' || v_loop_cnt);

                              IF cur_awb % NOTFOUND THEN
                                DBMS_OUTPUT.PUT_LINE('get_dtl_info_ama 22 close cusrsor DDDDDDDDDDD');
                                s_cms3_error := c_awb_00011;
                                --                            CLOSE cur_awb;
                                RETURN FALSE;
                              END IF;

                              DBMS_OUTPUT.PUT_LINE('get_dtl_info_ama 44 -- I.awb_no -- ' || i.awb_no);
                              v_awb_no := i.awb_no;
                              --                           v_awb_no := c_awb.awb_no;

                              DBMS_OUTPUT.PUT_LINE('get_dtl_info_ama 55  ;; v_awb_no -- ' || v_awb_no);

                              IF NOT set_awb_values THEN
                                --                            CLOSE cur_awb;                
                                RETURN FALSE;
                              END IF;

                              DBMS_OUTPUT.PUT_LINE('get_dtl_info_ama 555  ;; v_awb_no -- ' || v_awb_no);

                              IF NOT set_cnsl_ind THEN
                                --                            CLOSE cur_awb;
                                RETURN FALSE;
                              END IF;

                              DBMS_OUTPUT.PUT_LINE('get_dtl_info_ama 5555  ;; v_awb_no -- ' || v_awb_no);

                              DBMS_OUTPUT.PUT_LINE('get_dtl_info_ama 66  s_cnsl_ind-- ' || s_cnsl_ind);

                              IF s_cnsl_ind = 'Y' THEN

                                IF NOT set_dtl_hawb_ina THEN
                                  --                              CLOSE cur_awb;
                                  RETURN FALSE;
                                END IF;

                                ELSIF s_cnsl_ind = 'N' THEN
                                  DBMS_OUTPUT.PUT_LINE('get_dtl_info_ama 77  s_cnsl_ind--  ;; v_awb_no -- ' || v_awb_no);

                                  IF NOT msg_awb_ina THEN
                                    --                                CLOSE cur_awb;
                                    RETURN FALSE;
                                  END IF;

                                END IF;

                                --                            CLOSE cur_awb;
                              END LOOP;

                              RETURN TRUE;
                            END;

                            /********************get_dtl_info_ama end******************/

                             /********************get_ftr_info starts ****************/

                             FUNCTION get_ftr_info RETURN boolean IS
                            BEGIN
                              DBMS_OUTPUT.PUT_LINE('get_ftr_info  11 s_cons_footer -  ' || s_cons_footer);
                              -- 4.1.1.3 start
                              s_cons_footer := rpad(v_truck_no,   8,   ' ') || --2.1
                              to_char(v_flt_date,   'YYYYMMDD') || --  2.2
                              TRIM(to_char(nvl(v_sch_time,   0),   '0000')) || --  2.3
                              s_version_no || --2.4
                              'C';
                              -- 4.1.1.3 end 

                              DBMS_OUTPUT.PUT_LINE('get_ftr_info  22 s_cons_footer -  ' || s_cons_footer);
                              DBMS_OUTPUT.PUT_LINE('get_ftr_info  22 s_cons_footer -  ' || rpad(v_truck_no,   8,   ' ') || to_char(v_flt_date,   'YYYYMMDD') || TRIM(to_char(nvl(v_sch_time,   0),   '0000')) || s_version_no || 'C');

                              RETURN insert_cst_csgnm(' ',   cfooter);
                            END;

                            /********************get_ftr_info ends ****************/

                             /********************* submit_accs Start here **************************/

                             FUNCTION submit_accs(p_truck_no IN VARCHAR2,   p_sch_date IN VARCHAR2,   p_flt_key IN VARCHAR2,   p_flt_date IN VARCHAR2,   p_sch_time IN VARCHAR2,   p_ver_no IN OUT NUMBER) RETURN VARCHAR2 IS b_result boolean;
                            BEGIN

                              --                        DBMS_OUTPUT.PUT_LINE('submit_accs start for p_truck_no - ' || p_truck_no || ' - p_sch_date - ' || p_sch_date || ' - p_flt_key - ' || p_flt_key || ' - p_flt_date - ' || p_flt_date || ' - p_sch_time - ' || p_sch_time || ' - p_ver_no - ' || p_ver_no || ' - s_user_id - ' || s_user_id || ' - s_lm_date - ' || s_lm_date);
                              DBMS_OUTPUT.PUT_LINE('111 ');

                              init;

                              DBMS_OUTPUT.PUT_LINE('222 ');

                              s_cms3_error := NULL;
                              v_truck_no := p_truck_no;
                              v_sch_date := p_sch_date;
                              v_flt_key := p_flt_key;
                              v_flt_date := to_date(p_flt_date,   'DDMONYY');
                              v_sch_time := p_sch_time;

                              DBMS_OUTPUT.PUT_LINE('333 ');

                              IF NOT get_ver_no THEN
                                RETURN c_flt_00003;
                              END IF;

                              DBMS_OUTPUT.PUT_LINE('444 ');

                              p_ver_no := s_version_no;
                              --GET HEADER INFOMATION

                              IF NOT get_hdr_info_ina THEN
                                RETURN s_error_msg;
                              END IF;

                              DBMS_OUTPUT.PUT_LINE('4444  b_result - s_error_msg -- ' || s_error_msg);

                              --GET DETAIL INFOMATION
                              DBMS_OUTPUT.PUT_LINE('submit_accs 666  s_cons_detail-- ' || s_cons_detail);

                              IF s_int_amd = 'INA' THEN
                                b_result := get_dtl_info_ina;
                                --                                INITIAL CONSIGNMENT HEADER
                                ELSIF s_int_amd = 'AMA' THEN
                                  b_result := get_dtl_info_ama;
                                  --AMEND CONSIGNMENT HEADER
                                END IF;

                                DBMS_OUTPUT.PUT_LINE('submit_accs 777  s_cons_detail-- ' || s_cons_detail);
                                DBMS_OUTPUT.PUT_LINE('submit_accs 777  b_result-- ' || bool_to_text(b_result));

                                IF NOT b_result THEN
                                  RETURN s_error_msg;
                                END IF;

                                DBMS_OUTPUT.PUT_LINE('666 ret ');

                                --GET FOOTER INFOMATION

                                IF NOT get_ftr_info THEN
                                  s_error_msg := 'CST_202';
                                  RETURN s_error_msg;
                                END IF;

                                DBMS_OUTPUT.PUT_LINE('777 ');

                                DBMS_OUTPUT.PUT_LINE('888 ');
                                INSERT
                                INTO cst_auto_submit_log
                                VALUES('S_SIMP_CNT:' || nvl(s_simp_cnt,   0) || 'S_CNSL_CNT:' || nvl(s_cnsl_cnt,   0) || 'S_HAWB_CNT:' || nvl(s_hawb_cnt,   0));

                                DBMS_OUTPUT.PUT_LINE('888 s_cms3_error -- ' || s_cms3_error);
                                RETURN 'TRUE';

                              EXCEPTION
                              WHEN others THEN
                                s_error_msg := s_cms3_error || ' ' || SUBSTR(SQLCODE || sqlerrm,   1,   100);
                                RETURN s_error_msg;

                              END;

                              /********************* submit_accs End here   **************************/

                               FUNCTION ina_submission(p_truck_no IN VARCHAR2,   p_sch_date IN VARCHAR2,   p_flt_key IN VARCHAR2,   p_flt_date IN VARCHAR2,   p_sch_time IN VARCHAR2,   p_ver_no IN OUT NUMBER,   p_user_id IN VARCHAR2,   p_lm_date IN DATE) RETURN VARCHAR2 IS

                               v_ret VARCHAR2(200);

                              BEGIN
                                DBMS_OUTPUT.PUT_LINE('start for p_truck_no - ' || p_truck_no || ' - p_sch_date - ' || p_sch_date || ' - p_flt_key - ' || p_flt_key || ' - p_flt_date - ' || p_flt_date || ' - p_sch_time - ' || p_sch_time || ' - p_ver_no - ' || p_ver_no || ' - p_user_id - ' || p_user_id || ' - p_lm_date - ' || p_lm_date);
                                s_int_amd := 'INA';
                                s_user_id := p_user_id;
                                s_lm_date := p_lm_date;
                                v_ret := submit_accs(p_truck_no,   p_sch_date,   p_flt_key,   p_flt_date,   p_sch_time,   p_ver_no);

                                DBMS_OUTPUT.PUT_LINE('End v_ret - ' || v_ret);

                                RETURN v_ret;

                              EXCEPTION
                              WHEN others THEN
                                s_error_msg := s_cms3_error || ' ' || SUBSTR(SQLCODE || sqlerrm,   1,   100);
                                RETURN s_error_msg;
                              END;

                              FUNCTION ama_submission(p_truck_no IN VARCHAR2,   p_sch_date IN VARCHAR2,   p_flt_key IN VARCHAR2,   p_flt_date IN VARCHAR2,   p_sch_time IN VARCHAR2,   p_ver_no IN OUT NUMBER,   p_user_id IN VARCHAR2,   p_lm_date IN DATE) RETURN VARCHAR2 IS v_ret VARCHAR2(8 byte);
                              BEGIN
                                DBMS_OUTPUT.PUT_LINE('start for p_truck_no - ' || p_truck_no || ' - p_sch_date - ' || p_sch_date || ' - p_flt_key - ' || p_flt_key || ' - p_flt_date - ' || p_flt_date || ' - p_sch_time - ' || p_sch_time || ' - p_ver_no - ' || p_ver_no || ' - p_user_id - ' || p_user_id || ' - p_lm_date - ' || p_lm_date);
                                s_int_amd := 'AMA';
                                s_user_id := p_user_id;
                                s_lm_date := p_lm_date;
                                v_ret := submit_accs(p_truck_no,   p_sch_date,   p_flt_key,   p_flt_date,   p_sch_time,   p_ver_no);

                                DBMS_OUTPUT.PUT_LINE('End v_ret - ' || v_ret);

                                RETURN v_ret;

                              EXCEPTION
                              WHEN others THEN
                                s_error_msg := s_cms3_error || ' ' || SUBSTR(SQLCODE || sqlerrm,   1,   100);
                                RETURN s_error_msg;
                              END;


-------------------------subm_awb_AMA_Ver_ADD_UPD starts--------------------------------
 FUNCTION subm_awb_AMA_ADD_UPD_AWB_HAWB(p_truck_no IN VARCHAR2, p_truck_flt_no  IN VARCHAR2, p_sch_date IN VARCHAR2,   p_sch_time IN VARCHAR2, 
                        p_user_id IN VARCHAR2,p_awb_no IN VARCHAR2, p_awb_date  IN date, p_CNSL_IND IN VARCHAR2, p_TRK_MANF_PCS in Number, p_TRK_MANF_WT in Number)  
 RETURN VARCHAR2 IS 
              
     CURSOR c2   (c_awb_no  in varchar2, c_awb_date in date)
        IS
              SELECT *
              FROM cst_itm_hawb
              WHERE truck_no = p_truck_no
              and truck_flt_no = p_truck_flt_no
              AND sch_date = p_sch_date
              AND sch_time = p_sch_time
              AND accs_ind = 'INA'
              and awb_no = c_awb_no
              and awb_date = c_awb_date;
              
    v_ret VARCHAR2(8 byte);
    l_shp_man_pcs VARCHAR2(6);
    l_shp_man_wt VARCHAR2(9);
    ins_upd_del_ind  VARCHAR2(1);
  
    v_change_ind VARCHAR2(1);
    v_awb_pc_wt_cnt number;
    v_itm_awb_rec_cnt number;
    
     v_cnt number;
   
    BEGIN
    
    
     SELECT count(1) into v_itm_awb_rec_cnt
                FROM cst_itm_awb itmAwb
                WHERE  p_awb_no = itmAwb.awb_no
                and  p_awb_date = itmAwb.awb_date
                and truck_no = p_truck_no
                and truck_flt_no = p_truck_flt_no
                AND sch_date = p_sch_date
                AND sch_time = p_sch_time
                AND accs_ind in  ('INA');     
    
     if v_itm_awb_rec_cnt = 0 then  
                v_change_ind := 'A';
                 elsif v_itm_awb_rec_cnt > 0 then
      
         SELECT MAN_PCS, MAN_WGT into  l_shp_man_pcs, l_shp_man_wt 
          FROM cst_itm_awb itmAwb
          WHERE  p_awb_no = itmAwb.awb_no
          and  p_awb_date = itmAwb.awb_date
          and truck_no = p_truck_no
          and truck_flt_no = p_truck_flt_no
          AND sch_date = p_sch_date
          AND sch_time = p_sch_time
          AND accs_ind in  ('INA');
          
          if l_shp_man_pcs <> p_TRK_MANF_PCS OR l_shp_man_wt <> p_TRK_MANF_WT then 
            v_change_ind := 'U';
          end if;
    end if;
    
    
               if v_change_ind = 'A' OR v_change_ind = 'U'  then
               DBMS_OUTPUT.PUT_LINE('End v_ret - ' || v_change_ind);
              
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  j.awb_no - ' ||  j.awb_no);
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  j.awb_date - ' ||  j.awb_date);
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  p_truck_no - ' ||  p_truck_no);
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  p_truck_flt_no - ' ||  p_truck_flt_no);
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  p_sch_date - ' ||  p_sch_date);
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  p_sch_time - ' ||  p_sch_time);
--              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_ADD_UPD  v_subm_ver_no - ' ||  v_subm_ver_no);
                                  
                Insert into CST_ITM_AWB 
                (TR_NO,MSG_VER,AWB_NO,AWB_DATE,TRUCK_NO,TRUCK_FLT_NO,
                TRUCK_FLT_DATE,FLT_KEY,FLT_DATE,FLT_TYPE,ORG,DEST,
                MAN_PCS,MAN_WGT,SUBM_VER_NO,
                HDLG_AGENT,CNSL_IND,
                ACCS_IND,CHANGE_IND,CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,LM_VER,sch_date,sch_time) 
                select CST_ITM_AWB_SEQ.NEXTVAL , '1', itmAwb.AWB_NO, itmAwb.AWB_DATE, itmHd.TRUCK_NO, itmAwb.TRUCK_FLT_NO,
                itmAwb.TRUCK_FLT_DATE,itmAwb.IMP_FLT_KEY,itmAwb.IMP_FLT_DATE,'T',itmAwb.ORIG,itmAwb.DEST,
                itmAwb.TRK_MANF_PCS, itmAwb.TRK_MANF_WT,'1',
                c_hdlg_agent,itmAwb.CNSL_IND,
                'AMA', v_change_ind,p_user_id,sysdate,p_user_id,sysdate,'1',itmAwb.truck_flt_date,itmHd.sch_time 
                from  ITM_TRK_MANF_SHP  itmAwb, 
                ITM_TRK_MANF_HD itmHd
                WHERE itmAwb.tr_no = itmHd.tr_no
                and itmAwb.truck_flt_no = itmHd.truck_flt_no
                and itmAwb.truck_flt_date = itmHd.truck_flt_date
                and p_awb_no = itmAwb.awb_no
                and p_awb_date = itmAwb.awb_date
                and itmHd.status not in ('VOID')
                and itmAwb.truck_flt_no = p_truck_flt_no
                AND itmAwb.truck_flt_date = p_sch_date
                 AND itmHd.sch_time = p_sch_time
                 AND itmHd.truck_no = p_truck_No;-- and rownum =1;
                 
                  if p_cnsl_ind = 'Y' then
                 
                  if v_change_ind = 'A' then
                    DBMS_OUTPUT.PUT_LINE('End v_ret - ' || v_change_ind);

                  
                          Insert into CST_ITM_HAWB 
                              (TR_NO,MSG_VER,HAWB_NO,AWB_NO,AWB_DATE,TRUCK_NO,TRUCK_FLT_NO,
                              TRUCK_FLT_DATE,FLT_KEY,FLT_DATE,FLT_TYPE,ORG,DEST,
                              MAN_PCS,MAN_WGT,SUBM_VER_NO,
                              HDLG_AGENT,CNSL_IND,
                              ACCS_IND,CHANGE_IND,CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,LM_VER,sch_date,sch_time) 
                              select CST_ITM_AWB_SEQ.NEXTVAL , '1',itmHawb.hawb_no, itmAwb.AWB_NO, itmAwb.AWB_DATE, itmHd.TRUCK_NO, itmAwb.TRUCK_FLT_NO,
                                  itmAwb.TRUCK_FLT_DATE,itmAwb.IMP_FLT_KEY,itmAwb.IMP_FLT_DATE,'T',itmAwb.ORIG,itmAwb.DEST,
                                  itmAwb.TRK_MANF_PCS, itmAwb.TRK_MANF_WT,'1',
                                  c_hdlg_agent,itmAwb.CNSL_IND,
                                  'AMA', v_change_ind,p_user_id,sysdate,p_user_id,sysdate,'1',itmAwb.truck_flt_date,itmHd.sch_time 
                                  from  ITM_TRK_MANF_SHP  itmAwb,
                                  ITM_TRK_MANF_SHP_HAWB  itmHawb, 
                                  ITM_TRK_MANF_HD itmHd
                                  WHERE itmHd.status not in ('VOID')
                                  and itmHawb.tr_no = itmHd.tr_no
                                  and itmAwb.tr_no = itmHd.tr_no
                                  and itmAwb.truck_flt_no = itmHd.truck_flt_no
                                  and itmAwb.truck_flt_date = itmHd.truck_flt_date
                                  and p_awb_no = itmAwb.awb_no
                                  and p_awb_date = itmAwb.awb_date
                                  and itmAwb.DOC_LINE_NO = itmHawb.DTL_DOC_LINE_NO
                                  and itmAwb.truck_flt_no = p_truck_flt_no
                                  AND itmAwb.truck_flt_date = p_sch_date
                                   AND itmHd.sch_time = p_sch_time
                                   AND itmHd.truck_no = p_truck_No;
                     

                     
                  elsif  v_change_ind = 'U' OR v_change_ind = '' OR v_change_ind  is null then
                   DBMS_OUTPUT.PUT_LINE('End v_ret - ' || v_change_ind);
                   
                   

                  
                   for i in (SELECT hawb_no hawb_no, itmHawb.TRK_MANF_PCS TRK_MANF_PCS, itmHawb.TRK_MANF_WT  TRK_MANF_WT
                              FROM  ITM_TRK_MANF_SHP  itmAwb,
                                  ITM_TRK_MANF_SHP_HAWB  itmHawb, 
                                  ITM_TRK_MANF_HD itmHd
                                  WHERE itmHd.status not in ('VOID')
                                  and itmHawb.tr_no = itmHd.tr_no
                                  and itmAwb.tr_no = itmHd.tr_no
                                  and itmAwb.truck_flt_no = itmHd.truck_flt_no
                                  and itmAwb.truck_flt_date = itmHd.truck_flt_date
                                  and p_awb_no = itmAwb.awb_no
                                  and p_awb_date = itmAwb.awb_date
                                  and itmAwb.DOC_LINE_NO = itmHawb.DTL_DOC_LINE_NO
                                  and itmAwb.truck_flt_no = p_truck_flt_no
                                  AND itmAwb.truck_flt_date = p_sch_date
                                   AND itmHd.sch_time = p_sch_time
                                   AND itmHd.truck_no = p_truck_No) loop    
                  

                       
                        SELECT count(1) into v_itm_awb_rec_cnt
                        FROM cst_itm_hawb
                        WHERE truck_no = p_truck_no
                        and truck_flt_no = p_truck_flt_no
                        AND sch_date = p_sch_date
                        AND sch_time = p_sch_time
                        AND accs_ind = 'INA'
                        and awb_no = p_awb_no
                        and awb_date = p_awb_date
                        and hawb_no = i.hawb_no;
                    
                         if v_itm_awb_rec_cnt = 0 then  
                                    v_change_ind := 'A';
                        elsif v_itm_awb_rec_cnt > 0 then
                      
                        select MAN_PCS, MAN_WGT into  l_shp_man_pcs , l_shp_man_wt 
                          from cst_itm_hawb
                        WHERE truck_no = p_truck_no
                            and truck_flt_no = p_truck_flt_no
                            AND sch_date = p_sch_date
                            AND sch_time = p_sch_time
                            AND accs_ind = 'INA'
                            and awb_no = p_awb_no
                            and awb_date = p_awb_date
                            and hawb_no = i.hawb_no;
                          
                          if l_shp_man_pcs <> i.TRK_MANF_PCS OR l_shp_man_wt <> i.TRK_MANF_WT then 
                            v_change_ind := 'U';
                          end if;
                    end if;
                  
                  
                          Insert into CST_ITM_HAWB 
                              (TR_NO,MSG_VER,HAWB_NO,AWB_NO,AWB_DATE,TRUCK_NO,TRUCK_FLT_NO,
                              TRUCK_FLT_DATE,FLT_KEY,FLT_DATE,FLT_TYPE,ORG,DEST,
                              MAN_PCS,MAN_WGT,SUBM_VER_NO,
                              HDLG_AGENT,CNSL_IND,
                              ACCS_IND,CHANGE_IND,CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,LM_VER,sch_date,sch_time) 
                               select CST_ITM_AWB_SEQ.NEXTVAL , '1',itmHawb.hawb_no, itmAwb.AWB_NO, itmAwb.AWB_DATE, itmHd.TRUCK_NO, itmAwb.TRUCK_FLT_NO,
                                  itmAwb.TRUCK_FLT_DATE,itmAwb.IMP_FLT_KEY,itmAwb.IMP_FLT_DATE,'T',itmAwb.ORIG,itmAwb.DEST,
                                  itmAwb.TRK_MANF_PCS, itmAwb.TRK_MANF_WT,'1',
                                  c_hdlg_agent,itmAwb.CNSL_IND,
                                  'AMA', v_change_ind,p_user_id,sysdate,p_user_id,sysdate,'1',itmAwb.truck_flt_date,itmHd.sch_time 
                                  from  ITM_TRK_MANF_SHP  itmAwb,
                                  ITM_TRK_MANF_SHP_HAWB  itmHawb, 
                                  ITM_TRK_MANF_HD itmHd
                                  WHERE itmHd.status not in ('VOID')
                                  and itmHawb.tr_no = itmHd.tr_no
                                  and itmAwb.tr_no = itmHd.tr_no
                                  and itmAwb.truck_flt_no = itmHd.truck_flt_no
                                  and itmAwb.truck_flt_date = itmHd.truck_flt_date
                                  and p_awb_no = itmAwb.awb_no
                                  and p_awb_date = itmAwb.awb_date
                                  and itmAwb.DOC_LINE_NO = itmHawb.DTL_DOC_LINE_NO
                                  and itmAwb.truck_flt_no = p_truck_flt_no
                                  AND itmAwb.truck_flt_date = p_sch_date
                                   AND itmHd.sch_time = p_sch_time
                                   AND itmHd.truck_no = p_truck_No
                                and i.hawb_no = itmHawb.hawb_no;
                     
                      end loop;
                     end if;
                  end if;
              
            end if; 
    
      RETURN v_ret;
   
    END;
    -------------------------subm_awb_AMA_Ver_ADD_UPD Ends--------------------------------
-------------------------subm_awb_AMA_Ver_ADD_UPD starts--------------------------------
 FUNCTION subm_awb_AMA_Ver_ADD_UPD(p_truck_no IN VARCHAR2, p_truck_flt_no  IN VARCHAR2, p_sch_date IN VARCHAR2,   p_sch_time IN VARCHAR2,  p_user_id IN VARCHAR2)  
 RETURN VARCHAR2 IS 
              
     CURSOR c2  
        IS
              SELECT *
              FROM ITM_TRK_MANF_SHP shp
              WHERE shp.truck_flt_no = p_truck_flt_no
              AND shp.truck_flt_Date = p_sch_date
              and tr_no = (select tr_no from ITM_TRK_MANF_hd hd where  hd.status <> 'VOID' 
                                          and hd.truck_flt_no = p_truck_flt_no AND hd.truck_flt_Date = p_sch_date);
              
    v_ret VARCHAR2(8 byte);
    l_shp_man_pcs VARCHAR2(6);
    l_shp_man_wt VARCHAR2(9);
    ins_upd_del_ind  VARCHAR2(1);
  
    v_change_ind VARCHAR2(1);
    v_awb_pc_wt_cnt number;
    v_itm_awb_rec_cnt number;
    
     v_cnt number;
   
    BEGIN
            IF c2 % ISOPEN THEN
            CLOSE c2;
            END IF;
            ------------
              DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ADD_UPD starts p_truck_- ' || p_truck_no ||' - - '||p_truck_flt_no ||' - - '|| p_sch_date ||' - - '|| p_sch_time ||' - - '|| p_user_id);
              
           for j IN c2 LOOP
             DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ADD_UPD starts - ' || j.awb_no ||' - - '|| j.awb_Date ||' - - '|| j.CNSL_IND ||' - - '|| j.TRK_MANF_PCS ||' - - '|| j.TRK_MANF_WT);
           v_ret := subm_awb_AMA_ADD_UPD_AWB_HAWB(p_truck_no, p_truck_flt_no , p_sch_date,   p_sch_time,  p_user_id, j.awb_no, j.awb_Date, j.CNSL_IND, j.TRK_MANF_PCS, j.TRK_MANF_WT);
           
          
             
            END LOOP;  
  
      RETURN v_ret;
   
    END;
    -------------------------subm_awb_AMA_Ver_ADD_UPD Ends--------------------------------
    ----------  subm_awb_AMA_del_AWB_HAWB  start-----------------------------------

 FUNCTION subm_awb_AMA_del_AWB_HAWB(p_truck_no IN VARCHAR2, p_truck_flt_no  IN VARCHAR2, p_sch_date IN VARCHAR2,  
                                p_sch_time IN VARCHAR2,  p_user_id IN VARCHAR2, p_awb_no IN VARCHAR2, p_awb_date IN date, p_cnsl_ind IN VARCHAR2)  
 RETURN VARCHAR2 IS 

    CURSOR c1 (c_awb_no  in varchar2, c_awb_date in date)   IS 
            SELECT *
              FROM cst_itm_hawb
              WHERE truck_no = p_truck_no
              and truck_flt_no = p_truck_flt_no
              AND sch_date = p_sch_date
              AND sch_time = p_sch_time
              AND accs_ind = 'INA'
              and awb_no = c_awb_no
              and awb_date = c_awb_date;
              
    v_ret VARCHAR2(8 byte);
    l_shp_man_pcs VARCHAR2(6);
    l_shp_man_wt VARCHAR2(9);
  
    v_change_ind VARCHAR2(1);


    
    v_cnt number;
   
    BEGIN
             
             begin 
              select trkshp.TRK_MANF_PCS, trkshp.TRK_MANF_WT  into  l_shp_man_pcs , l_shp_man_wt 
                from itm_trk_manf_hd hd 
                join ITM_TRK_MANF_SHP trkshp on hd.tr_no = trkshp.tr_no 
                  where hd.status <> 'VOID'
                        and p_awb_no = trkshp.awb_no
                        and p_awb_date = trkshp.awb_date
                        and  p_truck_flt_no =trkshp.truck_flt_no
                        AND p_sch_Date = trkshp.truck_flt_date;
                
             EXCEPTION
              WHEN no_data_found THEN
                 v_change_ind := 'D'; 
              END;   
            
            if v_change_ind = 'D' then  
            
            Insert into CST_ITM_AWB 
                  (TR_NO,MSG_VER,AWB_NO,AWB_DATE,TRUCK_NO,TRUCK_FLT_NO,
                  TRUCK_FLT_DATE,FLT_KEY,FLT_DATE,FLT_TYPE,ORG,DEST,
                  MAN_PCS,MAN_WGT,SUBM_VER_NO,
                  HDLG_AGENT,CNSL_IND,
                  ACCS_IND,CHANGE_IND,CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,LM_VER,sch_date,sch_time) 
                  select CST_ITM_AWB_SEQ.NEXTVAL , '1', AWB_NO, AWB_DATE, TRUCK_NO, TRUCK_FLT_NO,
                  TRUCK_FLT_DATE,FLT_KEY,FLT_DATE,FLT_TYPE,ORG,DEST,
                  MAN_PCS,MAN_WGT,'1',
                  HDLG_AGENT,CNSL_IND,
                  'AMA', v_change_ind,p_user_id,sysdate,p_user_id,sysdate,'1',sch_date,sch_time 
                  from  CST_ITM_AWB  itmAwb
                  WHERE  p_awb_no = itmAwb.awb_no
                    and  p_awb_date = itmAwb.awb_date
                    and truck_no = p_truck_no
                    and truck_flt_no = p_truck_flt_no
                    AND sch_date = p_sch_date
                    AND sch_time = p_sch_time
                    AND accs_ind = 'INA' ;
              
                if p_cnsl_ind = 'Y' then
                 DBMS_OUTPUT.PUT_LINE('End v_ret - ' || v_change_ind);
                  for i in c1(p_awb_no, p_awb_date) loop    
                  
                  
                  
                      Insert into CST_ITM_HAWB 
                          (TR_NO,MSG_VER,HAWB_NO,AWB_NO,AWB_DATE,TRUCK_NO,TRUCK_FLT_NO,
                          TRUCK_FLT_DATE,FLT_KEY,FLT_DATE,FLT_TYPE,ORG,DEST,
                          MAN_PCS,MAN_WGT,SUBM_VER_NO,
                          HDLG_AGENT,CNSL_IND,
                          ACCS_IND,CHANGE_IND,CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,LM_VER,sch_date,sch_time) 
                          select CST_ITM_AWB_SEQ.NEXTVAL , '1',hawb_no,  AWB_NO, AWB_DATE, TRUCK_NO, TRUCK_FLT_NO,
                          TRUCK_FLT_DATE,FLT_KEY,FLT_DATE,FLT_TYPE,ORG,DEST,
                          MAN_PCS,MAN_WGT,'1',
                          HDLG_AGENT,CNSL_IND,
                          'AMA', v_change_ind,p_user_id,sysdate,p_user_id,sysdate,'1',sch_date,sch_time 
                          from  CST_ITM_HAWB  itmHawb
                          WHERE  p_awb_no = itmHawb.awb_no
                            and  p_awb_date = itmHawb.awb_date
                            and truck_no = p_truck_no
                            and truck_flt_no = p_truck_flt_no
                            AND sch_date = p_sch_date
                            AND sch_time = p_sch_time
                            AND accs_ind = 'INA'
                            and i.hawb_no = itmHawb.hawb_no;
                            

                  end loop;
              
            
            elsif p_cnsl_ind = 'Y' AND v_change_ind <> 'D' then
                DBMS_OUTPUT.PUT_LINE('End v_ret - ' || v_change_ind);
                
                for i in c1(p_awb_no, p_awb_date) loop 
                   begin 
                       select trkshpHawb.TRK_MANF_PCS, trkshpHawb.TRK_MANF_WT into  l_shp_man_pcs , l_shp_man_wt 
                        from itm_trk_manf_hd hd 
                        join ITM_TRK_MANF_SHP trkshp on hd.tr_no = trkshp.tr_no 
                        join ITM_TRK_MANF_SHP_HAWB trkshpHawb on hd.tr_no = trkshpHawb.tr_no and trkshp.doc_line_no = trkshpHawb.DTL_DOC_LINE_NO
                          where hd.status <> 'VOID'
                               and  i.hawb_no = trkshpHawb.hawb_no
                                and p_awb_no = trkshp.awb_no
                                and p_awb_date = trkshp.awb_date
                                and p_truck_flt_no =trkshpHawb.truck_flt_no
                                AND p_sch_Date = trkshpHawb.truck_flt_date;
                        
                     EXCEPTION
                      WHEN no_data_found THEN
                         v_change_ind := 'D'; 
                      END;   
                    
                    if v_change_ind = 'D' then  
                
                           
                            Insert into CST_ITM_HAWB 
                                (TR_NO,MSG_VER,HAWB_NO,AWB_NO,AWB_DATE,TRUCK_NO,TRUCK_FLT_NO,
                                TRUCK_FLT_DATE,FLT_KEY,FLT_DATE,FLT_TYPE,ORG,DEST,
                                MAN_PCS,MAN_WGT,SUBM_VER_NO,
                                HDLG_AGENT,CNSL_IND,
                                ACCS_IND,CHANGE_IND,CR_USER_ID,CR_DATE,LM_USER_ID,LM_DATE,LM_VER,sch_date,sch_time) 
                                select CST_ITM_AWB_SEQ.NEXTVAL , '1', hawb_no, AWB_NO, AWB_DATE, TRUCK_NO, TRUCK_FLT_NO,
                                TRUCK_FLT_DATE,FLT_KEY,FLT_DATE,FLT_TYPE,ORG,DEST,
                                MAN_PCS,MAN_WGT,'1',
                                HDLG_AGENT,CNSL_IND,
                                'AMA', v_change_ind,p_user_id,sysdate,p_user_id,sysdate,'1',sch_date,sch_time 
                                from  CST_ITM_HAWB  itmHawb
                                WHERE  p_awb_no = itmHawb.awb_no
                                  and  p_awb_date = itmHawb.awb_date
                                  and truck_no = p_truck_no
                                  and truck_flt_no = p_truck_flt_no
                                  AND sch_date = p_sch_date
                                  AND sch_time = p_sch_time
                                  AND accs_ind = 'INA'
                                  and i.hawb_no = itmHawb.hawb_no;
                   
                    end if;
                
                 end loop;
              end if;

            end if;
            
      RETURN '1';
   
    END;

-----------  subm_awb_AMA_del_AWB_HAWB  end-----------------------------------    
----------  subm_awb_AMA_Ver_del  start-----------------------------------

 FUNCTION subm_awb_AMA_Ver_del(p_truck_no IN VARCHAR2, p_truck_flt_no  IN VARCHAR2, p_sch_date IN VARCHAR2,   p_sch_time IN VARCHAR2,  p_user_id IN VARCHAR2)  
 RETURN VARCHAR2 IS 

    CURSOR c1   IS 
            SELECT *
              FROM cst_itm_awb
              WHERE truck_no = p_truck_no
              and truck_flt_no = p_truck_flt_no
              AND sch_date = p_sch_date
              AND sch_time = p_sch_time
              AND accs_ind = 'INA';
              
    v_ret VARCHAR2(8 byte);
    l_shp_man_pcs VARCHAR2(6);
    l_shp_man_wt VARCHAR2(9);
  
    v_change_ind VARCHAR2(1);
    v_consol_ind VARCHAR2(1);
   
    BEGIN
              
            IF c1 % ISOPEN THEN
            CLOSE c1;
            END IF;

            for i IN c1 LOOP
             DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_del  i.awb_no-  ' || i.awb_no);
            
--               if i.CNSL_IND = 'Y' then
                DBMS_OUTPUT.PUT_LINE('subm_awb_AMA_Ver_ONE_del  i.awb_no-  ' || i.awb_no);
                  v_ret := subm_awb_AMA_del_AWB_HAWB(p_truck_no, p_truck_flt_no , p_sch_date,   p_sch_time,  p_user_id, i.awb_no, i.awb_Date, i.CNSL_IND);
--               end if;
            
            END LOOP;
  
      RETURN '1';
   
    END;

-----------  subm_awb_AMA_Ver_del  end-----------------------------------
 FUNCTION subm_awb_Ama(p_truck_no IN VARCHAR2, p_truck_flt_no  IN VARCHAR2, p_sch_date IN VARCHAR2,   p_sch_time IN VARCHAR2,  p_user_id IN VARCHAR2)  
 RETURN VARCHAR2 IS 
              
    v_ret VARCHAR2(8 byte);
    BEGIN
    
        delete from  CST_ITM_AWB  
                WHERE truck_no = p_truck_no
                  and truck_flt_no = p_truck_flt_no
                  AND sch_date = p_sch_date
                  AND sch_time = p_sch_time
                  AND accs_ind = 'AMA';
                  
         delete from  CST_ITM_HAWB  
                WHERE truck_no = p_truck_no
                  and truck_flt_no = p_truck_flt_no
                  AND sch_date = p_sch_date
                  AND sch_time = p_sch_time
                  AND accs_ind = 'AMA';         
    
         v_ret := subm_awb_AMA_Ver_del(p_truck_no, p_truck_flt_no , p_sch_date,   p_sch_time,  p_user_id);
         v_ret := subm_awb_AMA_Ver_ADD_UPD(p_truck_no, p_truck_flt_no , p_sch_date,   p_sch_time,  p_user_id);
         
      RETURN '1';   
    END;

 
----------	
  

    procedure  sub_ins_cst_itm_awb_hawb(p_truck_no IN VARCHAR2, p_truck_flt_no IN VARCHAR2,  p_sch_date IN VARCHAR2,   p_sch_time IN VARCHAR2,   p_subm_ver_no OUT NUMBER,   p_user_id IN VARCHAR2) 
    IS 
    
    v_check_subm VARCHAR2(3);
    v_ret VARCHAR2(1);
    v_send_status VARCHAR2(1);
    v_ver_no NUMBER(2,0);
    v_lm_ver NUMBER(2,0);
  
    
    BEGIN
    

    v_ret := subm_awb_Ama(p_truck_no ,  p_truck_flt_no,  p_sch_date ,   p_sch_time ,   p_user_id );
     
     
     v_ret := '1';
     
    END;

  END PKG_CST_TRUCK_INIT;
/
SHOW ERRORS