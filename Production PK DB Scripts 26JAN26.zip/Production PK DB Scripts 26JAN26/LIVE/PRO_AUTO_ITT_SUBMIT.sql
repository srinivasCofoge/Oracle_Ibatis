--DDL Script File

--This DDL script file includes following types of DDL scripts
--1. Create/Replace script of PROCEDURE

--Prepared by		: SRINATH CH
--Prepared Date		: 23JAN26

-------------------------------------------------------------------------------
PROMPT Creating WOSINT.PRO_AUTO_ITT_SUBMIT
CREATE OR REPLACE PROCEDURE WOSINT.PRO_AUTO_ITT_SUBMIT
IS
  CURSOR cc
  IS
    SELECT *
    FROM cst_subm_temp
    WHERE processed = 'N'
    AND rec_type   IN ('ITT', 'ITF', 'ITC')
    AND rownum      = 1 FOR UPDATE NOWAIT;
  v_ret    VARCHAR2(200);
  p_ver_no NUMBER;
  v_err    VARCHAR2(1000);
  v_sts    VARCHAR2(10);
  rec_subm cc%ROWTYPE;
BEGIN

-- dbms_output.enable(1000000);

  DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT');

  delete from cst_subm where ver_no = - 1 and rec_type   IN ('ITT', 'ITF', 'ITC');

  IF cc%ISOPEN THEN
    CLOSE cc;
  END IF;
  OPEN cc;
  FETCH cc INTO rec_subm;
  IF cc%ROWCOUNT = 1 THEN
    UPDATE cst_subm_temp SET processed = 'Y' WHERE CURRENT OF cc;
    p_ver_no := rec_subm.ver_no;
    v_sts    := fun_check_man_itt(rec_subm.ver_no, rec_subm.ctrl_DATE, rec_subm.itt_req_code, rec_subm.rec_type, 'Y');

--    DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT v_sts '|| v_sts);
--    DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT rec_subm.ver_no '|| rec_subm.ver_no);
--    DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT rec_subm.ctrl_DATE '|| rec_subm.ctrl_DATE);
--    DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT rec_subm.itt_req_code '|| rec_subm.itt_req_code);
--    DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT rec_subm.rec_type '|| rec_subm.rec_type);


    IF v_sts IS NULL OR v_sts IN ('R', 'E') THEN
      v_sts  := 'N';
    END IF;
    IF v_sts NOT IN ('P', 'W') THEN
      IF v_sts = 'A' AND rec_subm.rec_type = 'ITT' THEN
        DELETE
        FROM cst_submit_temp
        WHERE ver_NO  = rec_subm.ver_NO
        AND ctrl_DATE = rec_subm.ctrl_DATE
        AND cst_type  = rec_subm.rec_type
        AND ver_no    = rec_subm.ver_no;
        DELETE
        FROM cst_subm_temp
        WHERE ver_NO  = rec_subm.ver_NO
        AND ctrl_DATE = rec_subm.ctrl_DATE
        AND rec_type  = rec_subm.rec_type
        AND ver_no    = rec_subm.ver_no;
      ELSE
--       DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT v_sts '|| v_sts);
--      DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT rec_subm.lm_user_id '|| rec_subm.lm_user_id);
--      DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT rec_subm.lm_date '|| rec_subm.lm_date);
--      DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT rec_subm.ver_NO '|| rec_subm.ver_NO);
--      DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT rec_subm.ctrl_DATE '|| rec_subm.ctrl_DATE);

        IF rec_subm.rec_type    = 'ITT' AND v_sts = 'N' THEN
         DBMS_OUTPUT.PUT_LINE('PRO_AUTO_ITT_SUBMIT v_sts 11 '|| v_sts);
          v_ret                := pkg_cst_eitt.ITT_SUBMIT_REQ(rec_subm.ctrl_DATE, rec_subm.ver_NO, rec_subm.lm_user_id, rec_subm.lm_date);
        ELSIF rec_subm.rec_type = 'ITF' THEN
          v_ret                := pkg_cst_eitt.ITT_CONFIRM_REQ(rec_subm.itt_req_code, rec_subm.lm_user_id, rec_subm.lm_date);
        ELSIF rec_subm.rec_type = 'ITC' THEN
          v_ret                := pkg_cst_eitt.ITT_CANCEL_REQ(rec_subm.ctrl_DATE, rec_subm.ver_NO,rec_subm.itt_req_code, rec_subm.lm_user_id, rec_subm.lm_date);
        ELSE
          NULL;
        END IF;
        IF v_ret = 'TRUE' THEN
          INSERT
          INTO cst_subm
            (
              flt_type,
              flt_date,
              flt_key,
              ver_no,
              ctrl_date,
              req_uid,
              msg_type,
              msg_id,
              rec_type,
              subm_date,
              send_status,
              send_date,
              bd_complete,
              lm_user_id,
              lm_date,
              lm_ver,
              err_msg,
              itt_req_code
            )
            VALUES
            (
              rec_subm.flt_type,
              rec_subm.flt_date,
              rec_subm.flt_key,
              decode(rec_subm.rec_type,'ITF',null,nvl(rec_subm.ver_NO,0)),
              decode(rec_subm.rec_type,'ITF',null,nvl(rec_subm.ctrl_DATE,sysdate)),
              rec_subm.req_uid,
              rec_subm.msg_type,
              rec_subm.msg_id,
              rec_subm.rec_type,
              rec_subm.subm_date,
              rec_subm.send_status,
              rec_subm.send_date,
              rec_subm.bd_complete,
              rec_subm.lm_user_id,
              rec_subm.lm_date,
              rec_subm.lm_ver,
              rec_subm.err_msg,
              rec_subm.itt_req_code
            );
        ELSE
          INSERT
          INTO cst_subm
            (
              flt_type,
              flt_date,
              flt_key,
              ver_no,
              ctrl_date,
              req_uid,
              msg_type,
              msg_id,
              rec_type,
              subm_date,
              send_status,
              send_date,
              bd_complete,
              lm_user_id,
              lm_date,
              lm_ver,
              err_msg,
              itt_req_code
            )
            VALUES
            (
              rec_subm.flt_type,
              rec_subm.flt_date,
              rec_subm.flt_key,
              decode(rec_subm.rec_type,'ITF',null,NVL(rec_subm.ver_NO, -1)),
              decode(rec_subm.rec_type,'ITF',null,NVL(rec_subm.ctrl_date,sysdate)),
              rec_subm.req_uid,
              rec_subm.msg_type,
              rec_subm.msg_id,
              rec_subm.rec_type,
              rec_subm.subm_date,
              'E',
              rec_subm.send_date,
              rec_subm.bd_complete,
              rec_subm.lm_user_id,
              rec_subm.lm_date,
              rec_subm.lm_ver,
              NVL(v_ret, 'GENERATING DATA FAILURE'),
              rec_subm.itt_req_code
            );
        END IF;
        INSERT
        INTO cst_auto_submit_log (MSG) VALUES 
          (
            rec_subm.flt_key
            || '/'
            || rec_subm.flt_date
            || ' '
            || TO_CHAR(rec_subm.ctrl_DATE, 'DDMONYY')
            || ' submit :'
            || rec_subm.rec_type
            || ' version is '
            || rec_subm.ver_NO
          );
      END IF;
    END IF;
    DELETE
    FROM cst_submit_temp
    WHERE ((ctrl_date = rec_subm.ctrl_date
    AND ver_no    = rec_subm.ver_no)
    or itt_req_code = rec_subm.itt_req_code)
    AND cst_type  = rec_subm.rec_type;
    DELETE
    FROM cst_subm_temp
    WHERE ((ctrl_date = rec_subm.ctrl_date
    AND ver_no    = rec_subm.ver_no)
    or itt_req_code = rec_subm.itt_req_code)
    AND rec_type  = rec_subm.rec_type;

  END IF;
  CLOSE cc;
  COMMIT;
EXCEPTION
WHEN OTHERS THEN
  IF cc%ISOPEN THEN
    CLOSE cc;
  END IF;
  v_err := SUBSTR(SQLCODE || SQLERRM, 1, 1000);
  INSERT
  INTO cst_auto_submit_log (MSG) VALUES 
    (
      TO_CHAR(SYSDATE, 'DDMONYY HH24:MI')
      || ':'
      || v_err
    );
END;
/
SHOW ERRORS